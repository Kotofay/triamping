﻿// Decompiled with JetBrains decompiler
// Type: ChipStudio.CECModuleSettings
// Assembly: ChipStudio, Version=1.2.9.0, Culture=neutral, PublicKeyToken=null
// MVID: 334E3BEA-37C7-4274-8118-535AAEFA1546
// Assembly location: D:\DocAndSec\Desktop\AUDIO\ChipDip\ChipStudio_soft_v1.2.9\ChipStudio_v1.2.9.exe

using System;
using System.CodeDom.Compiler;
using System.Collections;
using System.ComponentModel;
using System.Diagnostics;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Controls.Primitives;
using System.Windows.Markup;

#nullable disable
namespace ChipStudio;

public partial class CECModuleSettings : Window, IComponentConnector
{
  private readonly string[] Gpios;
  internal CheckBox IsEnabledCheck;
  internal TextBox PortNum;
  internal TextBox DevName;
  internal ComboBox VolGpioCombobox;
  internal ComboBox MuteGpioCombobox;
  internal CheckBox OptionTVon;
  internal CheckBox OptionTVoff;
  internal CheckBox OptionDeviceOn;
  internal CheckBox OptionDeviceOff;
  internal CheckBox OptionAudioStatus;
  private bool _contentLoaded;

  public CEC Settings { get; } = new CEC();

  public CECModuleSettings(CEC InitSettings, int GPIOsCount)
  {
    this.InitializeComponent();
    this.Gpios = new string[GPIOsCount];
    for (int index = 0; index < GPIOsCount; ++index)
      this.Gpios[index] = index.ToString();
    this.VolGpioCombobox.ItemsSource = (IEnumerable) this.Gpios;
    this.MuteGpioCombobox.ItemsSource = (IEnumerable) this.Gpios;
    this.IsEnabledCheck.IsChecked = new bool?(InitSettings.IsEnabled);
    this.PortNum.Text = InitSettings.PortNumber.ToString();
    this.DevName.Text = InitSettings.Name;
    this.VolGpioCombobox.SelectedIndex = InitSettings.VolumeGpio;
    this.MuteGpioCombobox.SelectedIndex = InitSettings.MuteGpio;
    this.OptionTVon.IsChecked = new bool?(InitSettings.IsTVonEnabled);
    this.OptionTVoff.IsChecked = new bool?(InitSettings.IsTVoffEnabled);
    this.OptionDeviceOn.IsChecked = new bool?(InitSettings.IsDeviceOnEnabled);
    this.OptionDeviceOff.IsChecked = new bool?(InitSettings.IsDeviceOffEnabled);
    this.OptionAudioStatus.IsChecked = new bool?(InitSettings.IsAudioStatusEnabled);
  }

  private void OKButton_Click(object sender, RoutedEventArgs e)
  {
    this.DialogResult = new bool?(true);
    this.Settings.IsEnabled = this.IsEnabledCheck.IsChecked.Value;
    int result;
    this.Settings.PortNumber = int.TryParse(this.PortNum.Text, out result) ? result : 1;
    this.Settings.Name = this.DevName.Text.Length != 0 ? this.DevName.Text : "ChipDipDAC";
    this.Settings.VolumeGpio = this.VolGpioCombobox.SelectedIndex != -1 ? this.VolGpioCombobox.SelectedIndex : 0;
    this.Settings.MuteGpio = this.MuteGpioCombobox.SelectedIndex != -1 ? this.MuteGpioCombobox.SelectedIndex : 0;
    this.Settings.IsTVonEnabled = this.OptionTVon.IsChecked.Value;
    this.Settings.IsTVoffEnabled = this.OptionTVoff.IsChecked.Value;
    CEC settings1 = this.Settings;
    bool? isChecked = this.OptionDeviceOn.IsChecked;
    int num1 = isChecked.Value ? 1 : 0;
    settings1.IsDeviceOnEnabled = num1 != 0;
    CEC settings2 = this.Settings;
    isChecked = this.OptionDeviceOff.IsChecked;
    int num2 = isChecked.Value ? 1 : 0;
    settings2.IsDeviceOffEnabled = num2 != 0;
    CEC settings3 = this.Settings;
    isChecked = this.OptionAudioStatus.IsChecked;
    int num3 = isChecked.Value ? 1 : 0;
    settings3.IsAudioStatusEnabled = num3 != 0;
  }

  private void CancelButton_Click(object sender, RoutedEventArgs e)
  {
    this.DialogResult = new bool?(false);
  }

  [DebuggerNonUserCode]
  [GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
  public void InitializeComponent()
  {
    if (this._contentLoaded)
      return;
    this._contentLoaded = true;
    Application.LoadComponent((object) this, new Uri("/ChipStudio;component/cecmodulesettings.xaml", UriKind.Relative));
  }

  [DebuggerNonUserCode]
  [GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
  [EditorBrowsable(EditorBrowsableState.Never)]
  void IComponentConnector.Connect(int connectionId, object target)
  {
    switch (connectionId)
    {
      case 1:
        this.IsEnabledCheck = (CheckBox) target;
        break;
      case 2:
        this.PortNum = (TextBox) target;
        break;
      case 3:
        this.DevName = (TextBox) target;
        break;
      case 4:
        this.VolGpioCombobox = (ComboBox) target;
        break;
      case 5:
        this.MuteGpioCombobox = (ComboBox) target;
        break;
      case 6:
        this.OptionTVon = (CheckBox) target;
        break;
      case 7:
        this.OptionTVoff = (CheckBox) target;
        break;
      case 8:
        this.OptionDeviceOn = (CheckBox) target;
        break;
      case 9:
        this.OptionDeviceOff = (CheckBox) target;
        break;
      case 10:
        this.OptionAudioStatus = (CheckBox) target;
        break;
      case 11:
        ((ButtonBase) target).Click += new RoutedEventHandler(this.OKButton_Click);
        break;
      case 12:
        ((ButtonBase) target).Click += new RoutedEventHandler(this.CancelButton_Click);
        break;
      default:
        this._contentLoaded = true;
        break;
    }
  }
}
