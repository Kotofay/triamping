﻿// Decompiled with JetBrains decompiler
// Type: ChipStudio.SchemaBlock_Read
// Assembly: ChipStudio, Version=1.2.9.0, Culture=neutral, PublicKeyToken=null
// MVID: 334E3BEA-37C7-4274-8118-535AAEFA1546
// Assembly location: D:\DocAndSec\Desktop\AUDIO\ChipDip\ChipStudio_soft_v1.2.9\ChipStudio_v1.2.9.exe

using System;
using System.CodeDom.Compiler;
using System.Collections;
using System.ComponentModel;
using System.Diagnostics;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Markup;

#nullable disable
namespace ChipStudio;

public partial class SchemaBlock_Read : SchemaBlock, IDSPDependent, IComponentConnector
{
  private static readonly string[] ReadPeriods = new string[12]
  {
    " 250",
    " 500",
    " 750",
    "1000",
    "1250",
    "1500",
    "1750",
    "2000",
    "2250",
    "2500",
    "2750",
    "3000"
  };
  private static readonly Anchor.AnchorTypes[] PointAnchors = new Anchor.AnchorTypes[1]
  {
    Anchor.AnchorTypes.FromRead
  };
  private const byte BYTES_COUNT_MAX = 8;
  private const int DEFAULT_PERIOD_INDEX = 3;
  internal Selector DSPList;
  internal ValueInput Address;
  internal ValueInput BytesCount;
  internal ComboBox PeriodsList;
  internal ItemsControl ConnectPoints;
  private bool _contentLoaded;

  public int DSPIndex
  {
    get => this.DSPList.SelectedIndex;
    set => this.DSPList.SelectedIndex = value;
  }

  public string DSP => this.DSPList.SelectedItem;

  public int PeriodIndex
  {
    get => this.PeriodsList.SelectedIndex;
    set => this.PeriodsList.SelectedIndex = value;
  }

  public override SchemaBlock.SchemaBlockTypes BlockType => SchemaBlock.SchemaBlockTypes.Read;

  public SchemaBlock_Read()
  {
    this.InitializeComponent();
    this.DataContext = (object) this;
    this.Address.SetFormat("HEX");
    this.BytesCount.SetFormat("DEC");
    this.InitConnectionPoints(SchemaBlock_Read.PointAnchors);
    this.ConnectPoints.ItemsSource = (IEnumerable) this.ConnectionPoints;
    this.PeriodsList.ItemsSource = (IEnumerable) SchemaBlock_Read.ReadPeriods;
    this.PeriodsList.SelectedIndex = 3;
  }

  public string GetAddressInput() => this.Address.GetInput();

  public string GetBytesCountInput() => this.BytesCount.GetInput();

  public ushort GetAddressValue() => (ushort) this.Address.GetValue();

  public byte GetBytesCountValue()
  {
    byte bytesCountValue = (byte) this.BytesCount.GetValue();
    if (bytesCountValue > (byte) 8)
    {
      bytesCountValue = (byte) 8;
      this.BytesCount.SetInput((byte) 8.ToString());
      int num = (int) MessageBox.Show($"Maximum Bytes count is 8.\n\r<{this.Title}>", "", MessageBoxButton.OK, MessageBoxImage.Exclamation);
    }
    return bytesCountValue;
  }

  public void SetAddress(string Addr) => this.Address.SetInput(Addr);

  public void SetBytesCount(string Bytes) => this.BytesCount.SetInput(Bytes);

  public void UpdateDSPList(string[] DSPTitles, Schema.UpdateOptions Option)
  {
    this.DSPList.Update(DSPTitles, Option);
  }

  [DebuggerNonUserCode]
  [GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
  public void InitializeComponent()
  {
    if (this._contentLoaded)
      return;
    this._contentLoaded = true;
    Application.LoadComponent((object) this, new Uri("/ChipStudio;component/schemablock_read.xaml", UriKind.Relative));
  }

  [DebuggerNonUserCode]
  [GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
  internal Delegate _CreateDelegate(Type delegateType, string handler)
  {
    return Delegate.CreateDelegate(delegateType, (object) this, handler);
  }

  [DebuggerNonUserCode]
  [GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
  [EditorBrowsable(EditorBrowsableState.Never)]
  void IComponentConnector.Connect(int connectionId, object target)
  {
    switch (connectionId)
    {
      case 1:
        ((UIElement) target).MouseLeftButtonDown += new MouseButtonEventHandler(((SchemaBlock) this).Border_MouseLeftButtonDown);
        break;
      case 2:
        this.DSPList = (Selector) target;
        break;
      case 3:
        this.Address = (ValueInput) target;
        break;
      case 4:
        this.BytesCount = (ValueInput) target;
        break;
      case 5:
        this.PeriodsList = (ComboBox) target;
        break;
      case 6:
        this.ConnectPoints = (ItemsControl) target;
        break;
      default:
        this._contentLoaded = true;
        break;
    }
  }
}
