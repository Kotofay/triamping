﻿// Decompiled with JetBrains decompiler
// Type: ChipStudio.SchemaBlock_Comment
// Assembly: ChipStudio, Version=1.2.9.0, Culture=neutral, PublicKeyToken=null
// MVID: 334E3BEA-37C7-4274-8118-535AAEFA1546
// Assembly location: D:\DocAndSec\Desktop\AUDIO\ChipDip\ChipStudio_soft_v1.2.9\ChipStudio_v1.2.9.exe

using System;
using System.CodeDom.Compiler;
using System.ComponentModel;
using System.Diagnostics;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Markup;

#nullable disable
namespace ChipStudio;

public partial class SchemaBlock_Comment : SchemaBlock, IComponentConnector
{
  internal TextBox CommentBox;
  private bool _contentLoaded;

  public override SchemaBlock.SchemaBlockTypes BlockType => SchemaBlock.SchemaBlockTypes.Comment;

  public override bool IsConnectable => false;

  public string Comment
  {
    get => this.CommentBox.Text;
    set => this.CommentBox.Text = value;
  }

  public SchemaBlock_Comment()
  {
    this.InitializeComponent();
    this.DataContext = (object) this;
  }

  [DebuggerNonUserCode]
  [GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
  public void InitializeComponent()
  {
    if (this._contentLoaded)
      return;
    this._contentLoaded = true;
    Application.LoadComponent((object) this, new Uri("/ChipStudio;component/schemablock_comment.xaml", UriKind.Relative));
  }

  [DebuggerNonUserCode]
  [GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
  [EditorBrowsable(EditorBrowsableState.Never)]
  void IComponentConnector.Connect(int connectionId, object target)
  {
    if (connectionId != 1)
    {
      if (connectionId == 2)
        this.CommentBox = (TextBox) target;
      else
        this._contentLoaded = true;
    }
    else
      ((UIElement) target).MouseLeftButtonDown += new MouseButtonEventHandler(((SchemaBlock) this).Border_MouseLeftButtonDown);
  }
}
