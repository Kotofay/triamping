﻿// Decompiled with JetBrains decompiler
// Type: ChipStudio.DSPCellParameter
// Assembly: ChipStudio, Version=1.2.9.0, Culture=neutral, PublicKeyToken=null
// MVID: 334E3BEA-37C7-4274-8118-535AAEFA1546
// Assembly location: D:\DocAndSec\Desktop\AUDIO\ChipDip\ChipStudio_soft_v1.2.9\ChipStudio_v1.2.9.exe

using System;

#nullable disable
namespace ChipStudio;

public class DSPCellParameter
{
  public string Name { get; set; }

  public ushort Address { get; set; }

  public ushort Size { get; set; }

  public byte[] Data { get; set; }

  public DSPCellParameter()
  {
  }

  public DSPCellParameter(string Name, ushort Address, ushort Size)
  {
    this.Name = Name;
    this.Address = Address;
    this.Size = Size;
    this.Data = new byte[(int) Size];
  }

  public static DSPCellParameter Clone(DSPCellParameter InitParam)
  {
    byte[] destinationArray = new byte[(int) InitParam.Size];
    Array.Copy((Array) InitParam.Data, (Array) destinationArray, (int) InitParam.Size);
    return new DSPCellParameter()
    {
      Name = InitParam.Name,
      Address = InitParam.Address,
      Size = InitParam.Size,
      Data = destinationArray
    };
  }
}
