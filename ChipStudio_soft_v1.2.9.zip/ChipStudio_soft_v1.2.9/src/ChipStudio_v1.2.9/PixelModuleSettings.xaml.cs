﻿// Decompiled with JetBrains decompiler
// Type: ChipStudio.PixelModuleSettings
// Assembly: ChipStudio, Version=1.2.9.0, Culture=neutral, PublicKeyToken=null
// MVID: 334E3BEA-37C7-4274-8118-535AAEFA1546
// Assembly location: D:\DocAndSec\Desktop\AUDIO\ChipDip\ChipStudio_soft_v1.2.9\ChipStudio_v1.2.9.exe

using System;
using System.CodeDom.Compiler;
using System.ComponentModel;
using System.Diagnostics;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Controls.Primitives;
using System.Windows.Markup;

#nullable disable
namespace ChipStudio;

public partial class PixelModuleSettings : Window, IComponentConnector
{
  internal CheckBox IsEnabledCheck;
  internal RadioButton RGBType;
  internal RadioButton RGBWType;
  internal CheckBox IsPwrOnCheck;
  private bool _contentLoaded;

  public PixelModule Settings { get; } = new PixelModule();

  public PixelModuleSettings(PixelModule InitSettings)
  {
    this.InitializeComponent();
    if (InitSettings.IsEnabled)
      this.IsEnabledCheck.IsChecked = new bool?(true);
    if (InitSettings.PixelType == PixelModule.PixelTypes.RGB)
      this.RGBType.IsChecked = new bool?(true);
    else
      this.RGBWType.IsChecked = new bool?(true);
    if (!InitSettings.IsPwrOnEnabled)
      return;
    this.IsPwrOnCheck.IsChecked = new bool?(true);
  }

  private void OKButton_Click(object sender, RoutedEventArgs e)
  {
    this.DialogResult = new bool?(true);
    bool? isChecked1 = this.IsEnabledCheck.IsChecked;
    bool flag1 = true;
    this.Settings.IsEnabled = isChecked1.GetValueOrDefault() == flag1 & isChecked1.HasValue;
    bool? isChecked2 = this.RGBType.IsChecked;
    bool flag2 = true;
    this.Settings.PixelType = !(isChecked2.GetValueOrDefault() == flag2 & isChecked2.HasValue) ? PixelModule.PixelTypes.RGBW : PixelModule.PixelTypes.RGB;
    isChecked2 = this.IsPwrOnCheck.IsChecked;
    bool flag3 = true;
    if (isChecked2.GetValueOrDefault() == flag3 & isChecked2.HasValue)
      this.Settings.IsPwrOnEnabled = true;
    else
      this.Settings.IsPwrOnEnabled = false;
  }

  private void CancelButton_Click(object sender, RoutedEventArgs e)
  {
    this.DialogResult = new bool?(false);
  }

  [DebuggerNonUserCode]
  [GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
  public void InitializeComponent()
  {
    if (this._contentLoaded)
      return;
    this._contentLoaded = true;
    Application.LoadComponent((object) this, new Uri("/ChipStudio;component/pixelmodulesettings.xaml", UriKind.Relative));
  }

  [DebuggerNonUserCode]
  [GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
  [EditorBrowsable(EditorBrowsableState.Never)]
  void IComponentConnector.Connect(int connectionId, object target)
  {
    switch (connectionId)
    {
      case 1:
        this.IsEnabledCheck = (CheckBox) target;
        break;
      case 2:
        this.RGBType = (RadioButton) target;
        break;
      case 3:
        this.RGBWType = (RadioButton) target;
        break;
      case 4:
        this.IsPwrOnCheck = (CheckBox) target;
        break;
      case 5:
        ((ButtonBase) target).Click += new RoutedEventHandler(this.OKButton_Click);
        break;
      case 6:
        ((ButtonBase) target).Click += new RoutedEventHandler(this.CancelButton_Click);
        break;
      default:
        this._contentLoaded = true;
        break;
    }
  }
}
