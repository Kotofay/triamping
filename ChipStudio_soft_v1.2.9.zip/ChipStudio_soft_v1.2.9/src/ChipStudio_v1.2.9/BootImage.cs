﻿// Decompiled with JetBrains decompiler
// Type: ChipStudio.BootImage
// Assembly: ChipStudio, Version=1.2.9.0, Culture=neutral, PublicKeyToken=null
// MVID: 334E3BEA-37C7-4274-8118-535AAEFA1546
// Assembly location: D:\DocAndSec\Desktop\AUDIO\ChipDip\ChipStudio_soft_v1.2.9\ChipStudio_v1.2.9.exe

using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;

#nullable disable
namespace ChipStudio;

public class BootImage
{
  private const int BLOCK_CONFIGURATION_SIZE = 2;
  private const int ID_SIZE = 1;
  private const int ADDRESS_IN_DSP_SIZE = 4;
  private const int USB_MANUFACTURE_MAX_LENGTH = 20;
  private const int USB_DEVICE_NAME_MAX_LENGTH = 40;
  private const int USB_VID_SIZE = 2;
  private const int USB_PID_SIZE = 2;
  private const int USB_SET_SIZE_OFFSET = 0;
  private const int USB_SET_SIZE_SIZE = 2;
  private const int USB_VID_OFFSET = 2;
  private const int USB_PID_OFFSET = 4;
  private const int USB_MANUFACT_SIZE_OFFSET = 6;
  private const int USB_MANUFACT_SIZE_SIZE = 1;
  private const int USB_MANUFACT_OFFSET = 7;
  private const int USB_MANUFACT_SIZE = 20;
  private const int FIRST_USB_DEV_NAME_MAP_OFFSET = 27;
  private const int USB_DEV_NAME_SIZE_OFFSET = 0;
  private const int USB_DEV_NAME_SIZE_SIZE = 1;
  private const int USB_DEV_NAME_OFFSET = 1;
  private const int USB_DEV_NAME_SIZE = 40;
  private const int USB_DEV_NAME_MAP_SIZE = 41;
  private const int BOOT_IMAGE_SIZE_OFFSET = 0;
  private const int BOOT_IMAGE_SIZE_SIZE = 4;
  private const int PROJECT_TYPE_OFFSET = 4;
  private const int PROJECT_TYPE_SIZE = 1;
  private const int COMBO_PROJECT_TYPE_OFFSET = 5;
  private const int COMBO_PROJECT_TYPE_SIZE = 1;
  private const int BOOT_LINES_COUNT_OFFSET = 6;
  private const int BOOT_LINES_COUNT_SIZE = 1;
  private const int COMBO_PROJECT_RECONF_TYPE_OFFSET = 7;
  private const int COMBO_PROJECT_RECONF_TYPE_SIZE = 1;
  private const int COMBO_PROJECT_MAP_RESERV_OFFSET = 8;
  private const int COMBO_PROJECT_MAP_RESERV_SIZE = 3;
  private const int COMBO_PROJECT_TABLE_SIZE_OFFSET = 11;
  private const int COMBO_PROJECT_TABLE_SIZE_SIZE = 2;
  private const int FIRST_PROJECT_MAP_OFFSET = 13;
  private const int PROJECT_NUMBER_OFFSET = 0;
  private const int PROJECT_NUMBER_SIZE = 1;
  private const int PROJECT_ADRESS_OFFSET = 1;
  private const int PROJECT_ADRESS_SIZE = 4;
  private const int PROJECT_MAP_IN_COMBO_RES_SIZE = 4;
  private const int PROJECT_MAP_IN_COMBO_SIZE = 9;
  private const int PROJECT_MAP_RESERV_OFFSET = 5;
  private const int PROJECT_MAP_RESERV_SIZE = 1;
  private const int MEMORY_MAP_TABLE_SIZE_OFFSET = 6;
  private const int MEMORY_MAP_TABLE_SIZE_SIZE = 2;
  private const int CONTROLLER_CONF_ADR_OFFSET = 8;
  private const int CONTROLLER_CONF_ADR_SIZE = 4;
  private const int CONTROLLER_CONF_SIZE_OFFSET = 12;
  private const int CONTROLLER_CONF_SIZE_SIZE = 2;
  private const int FIRST_BLOCK_CONF_MAP_OFFSET = 14;
  private const int FIRST_BLOCK_ADR_OFFSET = 15;
  private const int CONTROLLER_DELAY_CONF_SIZE = 6;
  private const int CONTROLLER_OPTIONS_SIZE = 2;
  private const int CONTROLLER_RESERVE_SIZE = 4;
  private const int CONTROLLER_CONF_MAP_SIZE = 6;
  private const byte CONTROLLER_DELAY_ACTIVE = 1;
  private const int BLOCK_ID_OFFSET = 0;
  private const int BLOCK_CONF_ADR_OFFSET = 1;
  private const int BLOCK_CONF_ADR_SIZE = 4;
  private const int BLOCK_CONF_SIZE_OFFSET = 5;
  private const int BLOCK_CONF_MAP_SIZE = 7;
  private const int DSP_ID_OFFSET = 0;
  private const int DSP_ID_SIZE = 1;
  private const int DSP_BUS_ADR_OFFSET = 1;
  private const int DSP_BUS_ADR_SIZE = 1;
  private const int DSP_CS_GPIO_NUM_OFFSET = 2;
  private const int DSP_CS_GPIO_NUM_SIZE = 1;
  private const int DSP_INTERFACE_TYPE_OFFSET = 3;
  private const int DSP_INTERFACE_TYPE_SIZE = 1;
  private const int DSP_INTERFACE_NUM_OFFSET = 4;
  private const int DSP_INTERFACE_NUM_SIZE = 1;
  private const int DSP_OPERATIONS_COUNT_OFFSET = 5;
  private const int DSP_OPERATIONS_COUNT_SIZE = 1;
  private const int DSP_FIRST_OPER_DESC_OFFSET = 6;
  private const int LINE_OWNER_ID_OFFSET = 0;
  private const int LINE_OWNER_ID_SIZE = 1;
  private const int LINE_NUMBER_OFFSET = 1;
  private const int LINE_NUMBER_SIZE = 1;
  private const int LINE_FUNCTION_BLOCK_ID1_OFFSET = 2;
  private const int LINE_FUNCTION_BLOCK_ID1_SIZE = 1;
  private const int LINE_FUNCTION_BLOCK_ID2_OFFSET = 3;
  private const int LINE_FUNCTION_BLOCK_ID2_SIZE = 1;
  private const int LINE_DSP_CELLS_COUNT_OFFSET = 4;
  private const int LINE_DSP_CELLS_COUNT_SIZE = 1;
  private const int LINE_FIRST_DSP_CELL_CONF_SIZE_OFFSET = 5;
  private const int LINE_DSP_CELL_CONF_SIZE = 3;
  private const int LINE_FIRST_DSP_CELL_CONFIG_OFFSET = 8;
  private const int COM_PIXEL_ACTIVITY_OFFSET = 0;
  private const int COM_PIXEL_ACTIVITY_SIZE = 1;
  private const int COM_PIXEL_TYPE_OFFSET = 1;
  private const int COM_PIXEL_TYPE_SIZE = 1;
  private const int COM_PIXEL_COUNT_OFFSET = 2;
  private const int COM_PIXEL_COUNT_SIZE = 1;
  private const int COM_PIXEL_PWRON_ACTIVITY_OFFSET = 3;
  private const int COM_PIXEL_PWRON_ACTIVITY_SIZE = 1;
  private const int COM_PIXEL_RESERVE_OFFSET = 4;
  private const int COM_PIXEL_RESERVE_SIZE = 3;
  private const int COM_PIXEL_PROJ_GROUP_COUNT_OFFSET = 7;
  private const int COM_PIXEL_PROJ_GROUP_COUNT_SIZE = 1;
  private const int COM_PIXEL_PROJ_1_GROUP_CONF_SIZE_OFFSET = 8;
  private const int COM_PIXEL_PROJ_GROUP_CONF_SIZE_SIZE = 1;
  private const int COM_PIXEL_PROJ_1_GROUP_CONF_OFFSET = 9;
  private const int PROJ_PIXEL_GROUP_RESERVE_OFFSET = 0;
  private const int PROJ_PIXEL_GROUP_RESERVE_SIZE = 2;
  private const int PROJ_PIXEL_GROUP_INDEX_OFFSET = 2;
  private const int PROJ_PIXEL_GROUP_INDEX_SIZE = 1;
  private const int PROJ_PIXEL_GROUP_LED_COUNT_OFFSET = 3;
  private const int PROJ_PIXEL_GROUP_LED_COUNT_SIZE = 1;
  private const int PROJ_PIXEL_GROUP_COLORS_OFFSET = 4;
  private const int CEC_GPIO_NUM_SIZE = 1;
  private const int CEC_MAX_NAME_LENGTH = 14;
  private const byte CEC_VOL_VALUES_COUNT_DEFAULT = 50;
  private const int CEC_ACTIVITY_OFFSET = 0;
  private const int CEC_ACTIVITY_SIZE = 1;
  private const int CEC_PORT_NUM_OFFSET = 1;
  private const int CEC_PORT_NUM_SIZE = 1;
  private const int CEC_DEVICE_NAME_SIZE_OFFSET = 2;
  private const int CEC_DEVICE_NAME_SIZE_SIZE = 1;
  private const int CEC_DEVICE_NAME_OFFSET = 3;
  private const int CEC_DEVICE_NAME_SIZE = 14;
  private const int CEC_OPTIONS_OFFSET = 17;
  private const int CEC_OPTIONS_SIZE = 1;
  private const int CEC_RESERVE1_OFFSET = 18;
  private const int CEC_RESERVE1_SIZE = 1;
  private const int CEC_LOGIC_ADDRESS_MASK_OFFSET = 19;
  private const int CEC_LOGIC_ADDRESS_MASK_SIZE = 2;
  private const int CEC_GPIO_NUM_VOLUME_OFFSET = 21;
  private const int CEC_GPIO_NUM_VOLUME_SIZE = 1;
  private const int CEC_VOLUME_VALUES_COUNT_OFFSET = 22;
  private const int CEC_VOLUME_VALUES_COUNT_SIZE = 1;
  private const int CEC_GPIO_NUM_MUTE_OFFSET = 23;
  private const int CEC_GPIO_NUM_MUTE_SIZE = 1;
  private const int CEC_RESERVE2_OFFSET = 24;
  private const int CEC_RESERVE2_SIZE = 9;
  private const int CEC_CONFIG_SIZE = 33;
  private const int LED_GPIO_ID_OFFSET = 0;
  private const int LED_GPIO_ID_SIZE = 1;
  private const int LED_GPIO_NUM_OFFSET = 1;
  private const int LED_GPIO_NUM_SIZE = 1;
  private const int LED_RESERVE_1_OFFSET = 2;
  private const int LED_RESERVE_1_SIZE = 3;
  private const int LED_BLOCK_ID1_OFFSET = 5;
  private const int LED_BLOCK_ID1_SIZE = 1;
  private const int LED_BLOCK_ID2_OFFSET = 6;
  private const int LED_BLOCK_ID2_SIZE = 1;
  private const int LED_RESERVE_2_OFFSET = 7;
  private const int LED_RESERVE_2_SIZE = 1;
  private const int LED_VALUES_COUNT_OFFSET = 8;
  private const int LED_VALUES_COUNT_SIZE = 1;
  private const int LED_VALUES_TABLE_OFFSET = 9;
  private const int PIXEL_GPIO_ID_OFFSET = 0;
  private const int PIXEL_GPIO_ID_SIZE = 1;
  private const int PIXEL_START_INDEX_OFFSET = 1;
  private const int PIXEL_START_INDEX_SIZE = 1;
  private const int PIXEL_COUNT_OFFSET = 2;
  private const int PIXEL_COUNT_SIZE = 1;
  private const int PIXEL_INDICATION_MODE_OFFSET = 3;
  private const int PIXEL_INDICATION_MODE_SIZE = 1;
  private const int PIXEL_RESERVE_1_OFFSET = 4;
  private const int PIXEL_RESERVE_1_SIZE = 1;
  private const int PIXEL_BLOCK_ID1_OFFSET = 5;
  private const int PIXEL_BLOCK_ID1_SIZE = 1;
  private const int PIXEL_BLOCK_ID2_OFFSET = 6;
  private const int PIXEL_BLOCK_ID2_SIZE = 1;
  private const int PIXEL_RESERVE_2_OFFSET = 7;
  private const int PIXEL_RESERVE_2_SIZE = 1;
  private const int PIXEL_BLOCK_VALUES_COUNT_OFFSET = 8;
  private const int PIXEL_BLOCK_VALUES_COUNT_SIZE = 1;
  private const int PIXEL_COLORS_TABLE_OFFSET = 9;
  private const int READ_DSP_DESCRIPTOR_OFFSET = 0;
  private const int READ_DSP_DESCRIPTOR_SIZE = 5;
  private const int READ_READ_ADDRESS_OFFSET = 5;
  private const int READ_READ_ADDRESS_SIZE = 2;
  private const int READ_RESERVE_1_OFFSET = 7;
  private const int READ_RESERVE_1_SIZE = 2;
  private const int READ_BYTE_COUNT_OFFSET = 9;
  private const int READ_BYTE_COUNT_SIZE = 1;
  private const int READ_PERIOD_OFFSET = 10;
  private const int READ_PERIOD_SIZE = 1;
  private const int READ_RESERVE_2_OFFSET = 11;
  private const int READ_RESERVE_2_SIZE = 3;
  private const int READ_CONFIG_SIZE = 14;
  private const int READ_ALL_BLOCK_COUNT_OFFSET = 0;
  private const int READ_ALL_BLOCK_COUNT_SIZE = 1;
  private const int READ_ALL_RESERVE_OFFSET = 1;
  private const int READ_ALL_RESERVE_SIZE = 3;
  private const int READ_ALL_1_BLOCK_CONFIG_OFFSET = 4;
  private const int COMPARATOR_MASK_OFFSET = 0;
  private const int COMPARATOR_MASK_SIZE = 8;
  private const int COMPARATOR_VALUE_OFFSET = 8;
  private const int COMPARATOR_VALUE_SIZE = 8;
  private const int COMPARATOR_READ_BLOCK_NUM_OFFSET = 16 /*0x10*/;
  private const int COMPARATOR_READ_BLOCK_NUM_SIZE = 1;
  private const int COMPARATOR_MODE_OFFSET = 17;
  private const int COMPARATOR_MODE_SIZE = 1;
  private const int COMPARATOR_RESERVE_OFFSET = 18;
  private const int COMPARATOR_RESERVE_SIZE = 10;
  private const int COMPARATOR_BLOCKS_COUNT_OFFSET = 28;
  private const int COMPARATOR_BLOCKS_COUNT_SIZE = 1;
  private const int COMPARATOR_1_BLOCK_CONFIG_SIZE_OFFSET = 29;
  private const int COMPARATOR_1_BLOCK_CONFIG_SIZE_SIZE = 3;
  private const int COMPARATOR_1_BLOCK_CONFIG_OFFSET = 32 /*0x20*/;
  private const int COMPARATOR_ALL_BLOCK_COUNT_OFFSET = 0;
  private const int COMPARATOR_ALL_BLOCK_COUNT_SIZE = 1;
  private const int COMPARATOR_ALL_RESERVE_OFFSET = 1;
  private const int COMPARATOR_ALL_RESERVE_SIZE = 3;
  private const int COMPARATOR_ALL_1_BLOCK_CONFIG_SIZE_OFFSET = 4;
  private const int COMPARATOR_ALL_1_BLOCK_CONFIG_SIZE_SIZE = 3;
  private const int COMPARATOR_ALL_1_BLOCK_CONFIG_OFFSET = 7;
  private const int CLI_BLOCK_NAME_OFFSET = 0;
  private const int CLI_BLOCK_NAME_SIZE = 17;
  private const int CLI_RESERVE_OFFSET = 17;
  private const int CLI_RESERVE_SIZE = 11;
  private const int CLI_DSPCELL_CONFIG_SIZE_OFFSET = 28;
  private const int CLI_DSPCELL_CONFIG_SIZE_SIZE = 3;
  private const int CLI_DSPCELL_CONFIG_OFFSET = 31 /*0x1F*/;
  private const int CLI_BLOCKS_COUNT_OFFSET = 0;
  private const int CLI_BLOCKS_COUNT_SIZE = 1;
  private const int CLI_1_BLOCK_CONFIG_SIZE_OFFSET = 1;
  private const int CLI_1_BLOCK_CONFIG_SIZE_SIZE = 3;
  private const int CLI_1_BLOCK_CONFIG_OFFSET = 4;
  private const int CLI_ALL_BLOCK_COUNT_OFFSET = 0;
  private const int CLI_ALL_BLOCK_COUNT_SIZE = 1;
  private const int CLI_ALL_RESERVE_OFFSET = 1;
  private const int CLI_ALL_RESERVE_SIZE = 3;
  private const int CLI_ALL_1_BLOCK_CONFIG_SIZE_OFFSET = 4;
  private const int CLI_ALL_1_BLOCK_CONFIG_SIZE_SIZE = 3;
  private const int CLI_ALL_1_BLOCK_CONFIG_OFFSET = 7;
  private const int MUTE_TIMPCS_OFFSET = 0;
  private const int MUTE_TIMPCS_SIZE = 2;
  private const int MUTE_TIMARR_OFFSET = 2;
  private const int MUTE_TIMARR_SIZE = 2;
  private const int MUTE_ACTIVE_LEVEL_OFFSET = 4;
  private const int MUTE_ACTIVE_LEVEL_SIZE = 1;
  private const int MUTE_RESERVE_OFFSET = 5;
  private const int MUTE_RESERVE_SIZE = 3;
  private const int MUTE_CONFIG_SIZE = 8;
  private const int PIXEL_COLOR_SIZE = 4;
  private const int LINE_DSP_CELL_RESERVE_SIZE = 8;
  private const int TransferToDSPSize = 2;
  private const int DSP_BOOT_BLOCK_ID = 0;
  private const int REGULATION_LINE_BLOCK_ID = 1;
  private const int COMMON_PIXEL_BLOCK_ID = 2;
  private const int CEC_BLOCK_ID = 3;
  private const int READS_BLOCK_ID = 4;
  private const int COMPARATORS_BLOCK_ID = 5;
  private const int CLI_BLOCK_ID = 6;
  private const int MUTE_BLOCK_ID = 7;
  private const byte NO_CHIP_SELECT_LINE = 255 /*0xFF*/;
  private const byte NO_LINE_FUNCTION_BLOCK = 255 /*0xFF*/;
  private const byte DSP_CELL_NO_ID = 255 /*0xFF*/;
  private const byte DSP_CELL_ANALOG_EN_ID = 1;
  private const byte LED_BLOCK_ID = 2;
  private const byte PIXEL_LED_BLOCK_ID = 3;
  private const byte CONTROLLER_LINE = 0;
  private const byte PROJECT_TYPE_SINGLE = 0;
  private const byte PROJECT_TYPE_COMBO = 1;
  private const byte PROJECT_CHANGE_REBOOT = 0;
  private const byte PROJECT_CHANGE_RECONFIG = 1;
  private const byte PIXEL_MODULE_DISABLED = 0;
  private const byte PIXEL_MODULE_ENABLED = 1;
  private const byte PIXEL_TYPE_RGB = 0;
  private const byte PIXEL_TYPE_RGBW = 1;
  private const byte PIXEL_PWRON_DISABLED = 0;
  private const byte PIXEL_PWRON_ENABLED = 1;
  private const byte PIXEL_MODE_DATA_TABLE = 0;
  private const byte PIXEL_MODE_SCALE = 1;
  private const byte CEC_NOT_ACTIVE = 0;
  private const byte CEC_ACTIVE = 1;
  private const int DATA_SIZE_PER_TRANSFER_MAX = 65520;

  public static void CombineProjects(
    int ComboType,
    int ComboSubType,
    bool RecongCheck,
    List<ComboProjectPart> ProjectParts,
    out List<byte> image)
  {
    image = new List<byte>();
    List<int> intList = new List<int>();
    for (int index = 0; index < 4; ++index)
      image.Add((byte) 0);
    image.Add((byte) 1);
    image.Add((byte) ComboType);
    image.Add((byte) ComboSubType);
    if (!RecongCheck)
      image.Add((byte) 0);
    else if (RecongCheck)
      image.Add((byte) 1);
    for (int index = 0; index < 5; ++index)
      image.Add((byte) 0);
    int num1 = 0;
    for (int index1 = 0; index1 < ProjectParts.Count; ++index1)
    {
      if (ProjectParts[index1].Image.Count != 0)
      {
        image.Add((byte) index1);
        for (int index2 = 0; index2 < 8; ++index2)
          image.Add((byte) 0);
        ++num1;
        intList.Add(index1);
      }
    }
    int num2 = num1 * 9;
    image[11] = (byte) num2;
    image[12] = (byte) (num2 >> 8);
    for (int index3 = 0; index3 < intList.Count; ++index3)
    {
      int index4 = intList[index3];
      int index5 = 13 + index3 * 9 + 1;
      bool flag = false;
      if (index3 > 0 && BootImage.ProjectsEqual(ProjectParts[index4].Image, ProjectParts[intList[index3 - 1]].Image))
        flag = true;
      if (!flag)
      {
        int count = image.Count;
        BootImage.ChangeSegment(image, count, index5, 4);
        List<byte> byteList = new List<byte>((IEnumerable<byte>) ProjectParts[index4].Image);
        int num3 = BootImage.JoinIntoValue(byteList, 8, 4) + count;
        BootImage.ChangeSegment(byteList, num3, 8, 4);
        int num4 = (BootImage.JoinIntoValue(byteList, 6, 2) - 6) / 7;
        for (int index6 = 0; index6 < num4; ++index6)
        {
          int index7 = 15 + index6 * 7;
          int num5 = BootImage.JoinIntoValue(byteList, index7, 4) + count;
          BootImage.ChangeSegment(byteList, num5, index7, 4);
        }
        image.AddRange((IEnumerable<byte>) byteList);
      }
      else
      {
        int num6 = 13 + (index3 - 1) * 9 + 1;
        for (int index8 = 0; index8 < 4; ++index8)
          image[index5 + index8] = image[num6 + index8];
      }
    }
    BootImage.ChangeSegment(image, image.Count, 0, 4);
  }

  public static bool MakeForProject(UIElementCollection Schema, out List<byte> image)
  {
    image = new List<byte>();
    image.AddRange((IEnumerable<byte>) new byte[14]);
    image[6] = (byte) 6;
    image[8] = (byte) 14;
    image[9] = (byte) 0;
    byte[] numArray;
    if (!BootImage.ControllerConfig(Schema, out numArray))
      return false;
    BootImage.ChangeSegment(image, numArray.Length, 12, 2);
    image.AddRange((IEnumerable<byte>) numArray);
    int ItemsCount = 0;
    if (BootImage.GetCommonPixelConfig(Schema, out numArray))
    {
      BootImage.RearrangeMap(image, numArray, 2, ItemsCount);
      ++ItemsCount;
    }
    if (BootImage.GetCECConfig(Schema, out numArray))
    {
      BootImage.RearrangeMap(image, numArray, 3, ItemsCount);
      ++ItemsCount;
    }
    foreach (SchemaBlock_DSP DSP in ((IEnumerable<SchemaBlock_DSP>) Schema.GetDSPs(Schema)).Where<SchemaBlock_DSP>((Func<SchemaBlock_DSP, bool>) (d => !d.IsSelfBooted)).ToArray<SchemaBlock_DSP>())
    {
      BootImage.RearrangeMap(image, BootImage.GetDSPConfig(Schema, DSP), 0, ItemsCount);
      ++ItemsCount;
    }
    List<byte[]> AllLinesConfig;
    BootImage.GetLinesConfig(Schema, out AllLinesConfig);
    foreach (byte[] NewConfig in AllLinesConfig)
    {
      BootImage.RearrangeMap(image, NewConfig, 1, ItemsCount);
      ++ItemsCount;
    }
    if (BootImage.GetAllReadConfig(Schema, out numArray))
    {
      BootImage.RearrangeMap(image, numArray, 4, ItemsCount);
      ++ItemsCount;
    }
    if (BootImage.GetAllComparatorConfig(Schema, out numArray))
    {
      BootImage.RearrangeMap(image, numArray, 5, ItemsCount);
      ++ItemsCount;
    }
    if (BootImage.GetAllCLIConfig(Schema, out numArray))
    {
      BootImage.RearrangeMap(image, numArray, 6, ItemsCount);
      ++ItemsCount;
    }
    if (BootImage.GetCtrlMuteConfig(Schema, out numArray))
    {
      BootImage.RearrangeMap(image, numArray, 7, ItemsCount);
      int num = ItemsCount + 1;
    }
    BootImage.ChangeSegment(image, image.Count, 0, 4);
    return true;
  }

  public static List<byte> MakeForUSBSettings(USBDeviceInfo USBSettings)
  {
    int num1 = 27 + USBSettings.DeviceNames.Length * 41;
    List<byte> byteList = new List<byte>()
    {
      (byte) (num1 & (int) byte.MaxValue),
      (byte) (num1 >> 8)
    };
    ushort num2;
    try
    {
      num2 = Convert.ToUInt16(USBSettings.VID, 16 /*0x10*/);
    }
    catch (FormatException ex)
    {
      num2 = (ushort) 1155;
    }
    byteList.Add((byte) num2);
    byteList.Add((byte) ((uint) num2 >> 8));
    ushort num3;
    try
    {
      num3 = Convert.ToUInt16(USBSettings.PID, 16 /*0x10*/);
    }
    catch (FormatException ex)
    {
      num3 = (ushort) 41488;
    }
    byteList.Add((byte) num3);
    byteList.Add((byte) ((uint) num3 >> 8));
    int count1 = byteList.Count;
    for (int index = 0; index < 21; ++index)
      byteList.Add((byte) 0);
    if (USBSettings.Manufacturer != null)
    {
      byteList[count1] = (byte) USBSettings.Manufacturer.Length;
      byte[] bytes = Encoding.ASCII.GetBytes(USBSettings.Manufacturer);
      for (int index = 0; index < bytes.Length; ++index)
        byteList[count1 + 1 + index] = bytes[index];
    }
    for (int index1 = 0; index1 < USBSettings.DeviceNames.Length; ++index1)
    {
      int count2 = byteList.Count;
      for (int index2 = 0; index2 < 41; ++index2)
        byteList.Add((byte) 0);
      if (USBSettings.DeviceNames[index1] != null)
      {
        byteList[count2] = (byte) USBSettings.DeviceNames[index1].Length;
        byte[] bytes = Encoding.ASCII.GetBytes(USBSettings.DeviceNames[index1]);
        for (int index3 = 0; index3 < bytes.Length; ++index3)
          byteList[count2 + 1 + index3] = bytes[index3];
      }
    }
    return byteList;
  }

  private static bool ProjectsEqual(List<byte> Proj1, List<byte> Proj2)
  {
    if (Proj1.Count != Proj2.Count)
      return false;
    for (int index = 0; index < Proj1.Count; ++index)
    {
      if ((int) Proj1[index] != (int) Proj2[index])
        return false;
    }
    return true;
  }

  private static void RearrangeMap(
    List<byte> WholeMap,
    byte[] NewConfig,
    int ConfigID,
    int ItemsCount)
  {
    int num1 = BootImage.JoinIntoValue(WholeMap[6], WholeMap[7]) + 7;
    BootImage.ChangeSegment(WholeMap, num1, 6, 2);
    int num2 = BootImage.JoinIntoValue(WholeMap[8], WholeMap[9]) + 7;
    BootImage.ChangeSegment(WholeMap, num2, 8, 4);
    for (int index1 = 0; index1 < ItemsCount; ++index1)
    {
      int index2 = 15 + index1 * 7;
      int num3 = BootImage.JoinIntoValue(WholeMap, index2, 4) + 7;
      BootImage.ChangeSegment(WholeMap, num3, index2, 4);
    }
    List<byte> byteList = new List<byte>();
    for (int index = 0; index < 7; ++index)
      byteList.Add((byte) 0);
    byteList[0] = (byte) ConfigID;
    BootImage.ChangeSegment(byteList, WholeMap.Count + 7, 1, 4);
    BootImage.ChangeSegment(byteList, NewConfig.Length, 5, 2);
    int index3 = 14;
    for (int index4 = 0; index4 < ItemsCount; ++index4)
      index3 += 7;
    WholeMap.InsertRange(index3, (IEnumerable<byte>) byteList);
    WholeMap.AddRange((IEnumerable<byte>) NewConfig);
  }

  private static void GetLinesConfig(
    UIElementCollection SchemaElements,
    out List<byte[]> AllLinesConfig)
  {
    AllLinesConfig = new List<byte[]>();
    SchemaBlock_Controller controller = Schema.GetController(SchemaElements);
    SchemaBlock_PixelLED[] pixelLeDs = Schema.GetPixelLEDs(SchemaElements);
    int[] blocksStartIndex = pixelLeDs.Length != 0 ? BootImage.GetPixelBlocksStartIndex(SchemaElements) : (int[]) null;
    bool[] gpiOsActivity = controller.GetGPIOsActivity();
    for (int AnchorNumber = 0; AnchorNumber < gpiOsActivity.Length; ++AnchorNumber)
    {
      if (gpiOsActivity[AnchorNumber])
      {
        List<byte> config1 = new List<byte>()
        {
          (byte) 0,
          (byte) AnchorNumber,
          byte.MaxValue,
          byte.MaxValue
        };
        ConnectionNode anchorConnectionNode = controller.GetAnchorConnectionNode(AnchorNumber);
        if (BootImage.GetLineDSPCellsConfig(SchemaElements, anchorConnectionNode, config1))
        {
          foreach (SchemaBlock lineLed in BootImage.GetLineLeds(SchemaElements, anchorConnectionNode))
          {
            List<byte> config2;
            if (lineLed.BlockType == SchemaBlock.SchemaBlockTypes.LED)
            {
              if (!BootImage.GetLEDConfig(lineLed as SchemaBlock_LED, Schema.GetConnections(SchemaElements), out config2))
                continue;
            }
            else if (blocksStartIndex != null)
            {
              SchemaBlock_PixelLED Pixel = lineLed as SchemaBlock_PixelLED;
              config2 = BootImage.GetPixelConfig(Pixel, controller.PixelSettings.PixelType, blocksStartIndex[Array.IndexOf<SchemaBlock_PixelLED>(pixelLeDs, Pixel)]);
            }
            else
              continue;
            ++config1[4];
            for (int index = 0; index < 3; ++index)
              config1.Add((byte) (config2.Count >> index * 8));
            config1.AddRange((IEnumerable<byte>) config2);
          }
          AllLinesConfig.Add(config1.ToArray());
        }
      }
    }
  }

  private static bool GetLineDSPCellsConfig(
    UIElementCollection SchemaElements,
    ConnectionNode LineNode,
    List<byte> config)
  {
    config.Add((byte) 0);
    Connection[] connections = Schema.GetConnections(SchemaElements);
    int connectindex;
    for (ConnectionNode oppositeNode1 = BootImage.GetOppositeNode(connections, LineNode, 0, out connectindex); oppositeNode1 != null; oppositeNode1 = BootImage.GetOppositeNode(connections, LineNode, connectindex + 1, out connectindex))
    {
      foreach (SchemaBlock_DSPCell dspCell in Schema.GetDSPCells(SchemaElements, oppositeNode1.BlockName))
      {
        int count = config.Count;
        config.AddRange((IEnumerable<byte>) new byte[3]);
        List<byte> config1;
        if (!BootImage.GetDSPCellConfig(SchemaElements, dspCell, oppositeNode1.AnchorNumber, out config1))
          return false;
        config.AddRange((IEnumerable<byte>) config1);
        if (dspCell.IsBypassable && oppositeNode1.AnchorNumber == 0)
        {
          ConnectionNode anchorConnectionNode = dspCell.GetAnchorConnectionNode(1);
          if (anchorConnectionNode != null)
          {
            ConnectionNode oppositeNode2 = BootImage.GetOppositeNode(connections, anchorConnectionNode, 0, out int _);
            if (oppositeNode2 != null)
              config[2] = (byte) oppositeNode2.AnchorNumber;
          }
        }
        int num = config.Count - (count + 3);
        for (int index = 0; index < 3; ++index)
          config[count + index] = (byte) (num >> index * 8);
        ++config[4];
      }
    }
    return true;
  }

  private static bool GetDSPCellConfig(
    UIElementCollection SchemaElements,
    SchemaBlock_DSPCell DSPCell,
    int ActiveAnchorNum,
    out List<byte> config)
  {
    config = new List<byte>();
    SchemaBlock_DSP dsp = Schema.GetDSP(SchemaElements, DSPCell.DSPTitle);
    if (dsp == null)
    {
      int num = (int) MessageBox.Show($"<{DSPCell.DSPTitle}> is not in the project.", "", MessageBoxButton.OK, MessageBoxImage.Hand);
      return false;
    }
    config.AddRange((IEnumerable<byte>) BootImage.GetDSPDescriptor(SchemaElements, dsp));
    if (DSPCell.IsBypassable && ActiveAnchorNum == 1)
    {
      ConnectionNode anchorConnectionNode = DSPCell.GetAnchorConnectionNode(0);
      if (BootImage.GetOppositeNode(Schema.GetConnections(SchemaElements), anchorConnectionNode, 0, out int _) != null)
        config.Add((byte) 1);
      else
        config.Add(byte.MaxValue);
    }
    else
      config.Add(byte.MaxValue);
    config.Add(byte.MaxValue);
    config.AddRange((IEnumerable<byte>) new byte[8]);
    config.Add((byte) DSPCell.WriteType);
    config.Add((byte) DSPCell.ValueSize);
    config.Add((byte) ((uint) DSPCell.ValueSize >> 8));
    if (DSPCell.IsBypassable && ActiveAnchorNum == 1)
      config.Add((byte) DSPCell.EnValuesCount);
    else
      config.Add((byte) DSPCell.ValuesCount);
    config.Add((byte) DSPCell.ParametersCount);
    config.Add((byte) ((uint) DSPCell.ParametersCount >> 8));
    for (int ParamIndex = 0; ParamIndex < (int) DSPCell.ParametersCount; ++ParamIndex)
    {
      int address;
      ushort size;
      DSPCell.ParamAddressAndSize(ParamIndex, out address, out size);
      for (int index = 0; index < 4; ++index)
        config.Add((byte) (address >> index * 8));
      config.Add((byte) size);
      config.Add((byte) ((uint) size >> 8));
    }
    if (DSPCell.IsBypassable && ActiveAnchorNum == 1)
      config.AddRange((IEnumerable<byte>) DSPCell.GetEnData());
    else
      config.AddRange((IEnumerable<byte>) DSPCell.GetData());
    return true;
  }

  private static bool GetLEDConfig(
    SchemaBlock_LED LEDBlock,
    Connection[] Connections,
    out List<byte> config)
  {
    config = new List<byte>() { (byte) 0 };
    ConnectionNode oppositeNode = BootImage.GetOppositeNode(Connections, LEDBlock.GetAnchorConnectionNode(0), 0, out int _);
    if (oppositeNode == null)
    {
      int num = (int) MessageBox.Show($"Block <{LEDBlock.Title}> is not connected to controller", "", MessageBoxButton.OK, MessageBoxImage.Exclamation);
      return false;
    }
    config.Add((byte) oppositeNode.AnchorNumber);
    config.AddRange((IEnumerable<byte>) new byte[3]);
    config.Add((byte) 2);
    config.Add(byte.MaxValue);
    config.Add((byte) 0);
    byte[] data = LEDBlock.GetData();
    config.Add((byte) data.Length);
    config.AddRange((IEnumerable<byte>) data);
    return true;
  }

  private static byte[] GetDSPConfig(UIElementCollection SchemaElements, SchemaBlock_DSP DSP)
  {
    List<byte> byteList = new List<byte>();
    byteList.AddRange((IEnumerable<byte>) BootImage.GetDSPDescriptor(SchemaElements, DSP));
    List<DataTransfer> boot = DSP.GetBoot();
    int count1 = boot.Count;
    int count2 = byteList.Count;
    byteList.Add((byte) boot.Count);
    byteList.Add((byte) (boot.Count >> 8));
    foreach (DataTransfer dataTransfer in boot)
    {
      if (dataTransfer.Size <= (int) ushort.MaxValue)
      {
        byteList.Add((byte) dataTransfer.Type);
        byteList.AddRange((IEnumerable<byte>) BootImage.SplitToBytes((int) dataTransfer.Address, 4));
        byteList.Add(dataTransfer.AddressIncrement);
        byteList.AddRange((IEnumerable<byte>) BootImage.SplitToBytes(dataTransfer.Size, 2));
        if (dataTransfer.Type == DataTransfer.TransferTypes.Write || dataTransfer.Type == DataTransfer.TransferTypes.Poll)
          byteList.AddRange((IEnumerable<byte>) dataTransfer.Data);
      }
      else
      {
        ++count1;
        for (int index = 0; index < 2; ++index)
        {
          int length = index == 0 ? 65520 : dataTransfer.Size - 65520;
          byteList.Add((byte) dataTransfer.Type);
          byteList.AddRange((IEnumerable<byte>) BootImage.SplitToBytes((int) dataTransfer.Address + index * (65520 / (int) dataTransfer.AddressIncrement), 4));
          byteList.Add(dataTransfer.AddressIncrement);
          byteList.AddRange((IEnumerable<byte>) BootImage.SplitToBytes(length, 2));
          byte[] numArray = new byte[length];
          Array.Copy((Array) dataTransfer.Data, index * 65520, (Array) numArray, 0, length);
          if (dataTransfer.Type == DataTransfer.TransferTypes.Write || dataTransfer.Type == DataTransfer.TransferTypes.Poll)
            byteList.AddRange((IEnumerable<byte>) numArray);
        }
      }
    }
    byteList[count2] = (byte) count1;
    byteList[count2 + 1] = (byte) (count1 >> 8);
    return byteList.ToArray();
  }

  private static byte[] GetDSPDescriptor(UIElementCollection SchemaElements, SchemaBlock_DSP DSP)
  {
    byte[] dspDescriptor = new byte[5]
    {
      DSP.CoreID,
      DSP.GetBusAddress(),
      (byte) 0,
      (byte) 0,
      (byte) 0
    };
    Connection[] connections = Schema.GetConnections(SchemaElements);
    byte AnchorNumber;
    dspDescriptor[2] = !DSP.IsChipSelectable ? byte.MaxValue : (BootImage.GetOppositeNodeAnchorNumber(connections, DSP.GetAnchorConnectionNode(1), out AnchorNumber) ? AnchorNumber : byte.MaxValue);
    dspDescriptor[3] = DSP.Interface;
    BootImage.GetOppositeNodeAnchorNumber(connections, DSP.GetAnchorConnectionNode(0), out AnchorNumber);
    dspDescriptor[4] = Schema.GetController(SchemaElements).GetInterfaceNum(AnchorNumber);
    return dspDescriptor;
  }

  private static bool ControllerConfig(UIElementCollection SchemaElements, out byte[] config)
  {
    config = (byte[]) null;
    SchemaBlock_Controller controller = Schema.GetController(SchemaElements);
    if (controller == null)
      return false;
    List<byte> byteList = new List<byte>()
    {
      controller.CoreID
    };
    byteList.AddRange((IEnumerable<byte>) controller.GetGPIOFunctions());
    bool IsDelayActive;
    controller.GetStartDelayParams(out IsDelayActive, out int _);
    if (IsDelayActive)
    {
      byteList.Add((byte) 1);
      byteList.Add((byte) 0);
      int TimPSC;
      int TimARR;
      controller.GetStartDelay(out TimPSC, out TimARR);
      byteList.Add((byte) TimPSC);
      byteList.Add((byte) (TimPSC >> 8));
      byteList.Add((byte) TimARR);
      byteList.Add((byte) (TimARR >> 8));
    }
    else
      byteList.AddRange((IEnumerable<byte>) new byte[6]);
    ushort num = controller.Options != null ? controller.Options.Get() : (ushort) 0;
    byteList.Add((byte) num);
    byteList.Add((byte) ((uint) num >> 8));
    byteList.AddRange((IEnumerable<byte>) new byte[4]);
    config = byteList.ToArray();
    return true;
  }

  private static bool GetCommonPixelConfig(
    UIElementCollection SchemaElements,
    out byte[] CommonPixelconfig)
  {
    CommonPixelconfig = (byte[]) null;
    PixelModule pixelSettings = Schema.GetController(SchemaElements).PixelSettings;
    SchemaBlock_PixelLED[] pixelLeDs = Schema.GetPixelLEDs(SchemaElements);
    if (pixelSettings == null || !pixelSettings.IsEnabled || pixelLeDs.Length == 0)
      return false;
    int[] blocksStartIndex = BootImage.GetPixelBlocksStartIndex(SchemaElements);
    if (blocksStartIndex == null)
      return false;
    List<byte> byteList = new List<byte>();
    if (pixelSettings.IsEnabled)
      byteList.Add((byte) 1);
    else
      byteList.Add((byte) 0);
    if (pixelSettings.PixelType == PixelModule.PixelTypes.RGB)
      byteList.Add((byte) 0);
    else
      byteList.Add((byte) 1);
    byteList.Add((byte) ((IEnumerable<int>) ((IEnumerable<SchemaBlock_PixelLED>) pixelLeDs).Select<SchemaBlock_PixelLED, int>((Func<SchemaBlock_PixelLED, int>) (p => p.Settings.LEDsCount)).ToArray<int>()).Sum());
    if (pixelSettings.IsPwrOnEnabled)
      byteList.Add((byte) 1);
    else
      byteList.Add((byte) 0);
    byteList.AddRange((IEnumerable<byte>) new byte[3]);
    SchemaBlock_PixelLED[] array = ((IEnumerable<SchemaBlock_PixelLED>) pixelLeDs).Where<SchemaBlock_PixelLED>((Func<SchemaBlock_PixelLED, bool>) (p => p.Settings.IndicationType == PixelLEDBlock.IndicationTypes.Project)).ToArray<SchemaBlock_PixelLED>();
    byteList.Add((byte) array.Length);
    foreach (SchemaBlock_PixelLED Pixel in array)
    {
      byte[] pixelProjGroupConfig = BootImage.GetPixelProjGroupConfig(Pixel, pixelSettings.PixelType, blocksStartIndex[Array.IndexOf<SchemaBlock_PixelLED>(pixelLeDs, Pixel)]);
      byteList.Add((byte) pixelProjGroupConfig.Length);
      byteList.AddRange((IEnumerable<byte>) pixelProjGroupConfig);
    }
    CommonPixelconfig = byteList.ToArray();
    return true;
  }

  private static bool GetCECConfig(UIElementCollection SchemaElements, out byte[] CECConfig)
  {
    CECConfig = new byte[33];
    SchemaBlock_Controller controller = Schema.GetController(SchemaElements);
    CEC cecSettings = controller.CECSettings;
    if (cecSettings == null || !cecSettings.IsEnabled)
      return false;
    CECConfig[0] = (byte) 1;
    CECConfig[1] = (byte) cecSettings.PortNumber;
    CECConfig[2] = (byte) cecSettings.Name.Length;
    byte[] bytes = Encoding.ASCII.GetBytes(cecSettings.Name);
    for (int index = 0; index < bytes.Length; ++index)
      CECConfig[3 + index] = bytes[index];
    CECConfig[17] = cecSettings.Options();
    CECConfig[21] = (byte) cecSettings.VolumeGpio;
    int dspCellValuesCount = BootImage.GetLineDSPCellValuesCount(SchemaElements, controller.GetAnchorConnectionNode((int) CECConfig[21]));
    CECConfig[22] = dspCellValuesCount > 0 ? (byte) dspCellValuesCount : (byte) 50;
    CECConfig[23] = (byte) cecSettings.MuteGpio;
    return true;
  }

  private static byte[] GetPixelProjGroupConfig(
    SchemaBlock_PixelLED Pixel,
    PixelModule.PixelTypes PixelType,
    int StartIndex)
  {
    List<byte> byteList = new List<byte>()
    {
      (byte) 0,
      (byte) 0,
      (byte) StartIndex,
      (byte) Pixel.Settings.LEDsCount
    };
    foreach (string color in Pixel.GetColors())
      byteList.AddRange((IEnumerable<byte>) BootImage.ColorStringToByteArray(color, PixelType));
    return byteList.ToArray();
  }

  private static List<byte> GetPixelConfig(
    SchemaBlock_PixelLED Pixel,
    PixelModule.PixelTypes PixelType,
    int StartIndex)
  {
    List<byte> pixelConfig = new List<byte>()
    {
      (byte) 0,
      (byte) StartIndex,
      (byte) Pixel.Settings.LEDsCount
    };
    if (Pixel.Settings.IndicationMode == PixelLEDBlock.IndicationModes.DataTable)
      pixelConfig.Add((byte) 0);
    else
      pixelConfig.Add((byte) 1);
    pixelConfig.Add((byte) 0);
    pixelConfig.Add((byte) 3);
    pixelConfig.Add(byte.MaxValue);
    pixelConfig.Add((byte) 0);
    pixelConfig.Add((byte) Pixel.Settings.StatesCount);
    foreach (string color in Pixel.GetColors())
      pixelConfig.AddRange((IEnumerable<byte>) BootImage.ColorStringToByteArray(color, PixelType));
    return pixelConfig;
  }

  private static bool GetAllReadConfig(UIElementCollection SchemaElements, out byte[] config)
  {
    config = (byte[]) null;
    List<byte> byteList = new List<byte>();
    SchemaBlock_Read[] array = ((IEnumerable<SchemaBlock_Read>) Schema.GetReads(SchemaElements)).Where<SchemaBlock_Read>((Func<SchemaBlock_Read, bool>) (r => r.DSP != null)).ToArray<SchemaBlock_Read>();
    if (array.Length == 0)
      return false;
    byteList.Add((byte) array.Length);
    byteList.AddRange((IEnumerable<byte>) new byte[3]);
    foreach (SchemaBlock_Read schemaBlockRead in array)
    {
      byteList.AddRange((IEnumerable<byte>) BootImage.GetDSPDescriptor(SchemaElements, Schema.GetDSP(SchemaElements, schemaBlockRead.DSP)));
      byteList.Add((byte) schemaBlockRead.GetAddressValue());
      byteList.Add((byte) ((uint) schemaBlockRead.GetAddressValue() >> 8));
      byteList.AddRange((IEnumerable<byte>) new byte[2]);
      byteList.Add(schemaBlockRead.GetBytesCountValue());
      byteList.Add((byte) schemaBlockRead.PeriodIndex);
      byteList.AddRange((IEnumerable<byte>) new byte[3]);
    }
    config = byteList.ToArray();
    return true;
  }

  private static bool GetAllComparatorConfig(UIElementCollection SchemaElements, out byte[] config)
  {
    config = (byte[]) null;
    List<byte> byteList = new List<byte>();
    SchemaBlock_Comparator[] array = ((IEnumerable<SchemaBlock_Comparator>) Schema.GetComparators(SchemaElements)).ToArray<SchemaBlock_Comparator>();
    if (array.Length == 0)
      return false;
    byteList.Add((byte) 0);
    byteList.AddRange((IEnumerable<byte>) new byte[3]);
    foreach (SchemaBlock_Comparator comp in array)
    {
      List<byte> Config;
      if (BootImage.GetComparatorConfig(SchemaElements, comp, out Config))
      {
        ++byteList[0];
        for (int index = 0; index < 3; ++index)
          byteList.Add((byte) (Config.Count >> index * 8));
        byteList.AddRange((IEnumerable<byte>) Config);
      }
    }
    config = byteList.ToArray();
    return byteList[0] > (byte) 0;
  }

  private static bool GetComparatorConfig(
    UIElementCollection SchemaElements,
    SchemaBlock_Comparator comp,
    out List<byte> Config)
  {
    Config = new List<byte>();
    for (int index = 0; index < 8; ++index)
      Config.Add((byte) (comp.GetMaskValue() >> index * 8));
    for (int index = 0; index < 8; ++index)
      Config.Add((byte) (comp.GetValueValue() >> index * 8));
    int comparatorReadBlockIndex = BootImage.GetComparatorReadBlockIndex(SchemaElements, comp);
    if (comparatorReadBlockIndex == -1)
      return false;
    Config.Add((byte) comparatorReadBlockIndex);
    Config.Add((byte) comp.Mode);
    Config.AddRange((IEnumerable<byte>) new byte[10]);
    Config.Add((byte) 0);
    SchemaBlock[] comparatorUsers = BootImage.GetComparatorUsers(SchemaElements, comp);
    if (comparatorUsers.Length == 0)
    {
      int num = (int) MessageBox.Show($"Comparator <{comp.Title}> is not used by any block", "", MessageBoxButton.OK, MessageBoxImage.Exclamation);
      return false;
    }
    PixelModule.PixelTypes pixelType = Schema.GetController(SchemaElements).PixelSettings.PixelType;
    SchemaBlock_PixelLED[] pixelLeDs = Schema.GetPixelLEDs(SchemaElements);
    int[] blocksStartIndex = pixelLeDs.Length != 0 ? BootImage.GetPixelBlocksStartIndex(SchemaElements) : (int[]) null;
    foreach (SchemaBlock LEDBlock in comparatorUsers)
    {
      List<byte> config;
      switch (LEDBlock.BlockType)
      {
        case SchemaBlock.SchemaBlockTypes.LED:
          if (BootImage.GetLEDConfig(LEDBlock as SchemaBlock_LED, Schema.GetConnections(SchemaElements), out config))
            break;
          continue;
        case SchemaBlock.SchemaBlockTypes.PixelLED:
          if (blocksStartIndex != null)
          {
            SchemaBlock_PixelLED Pixel = LEDBlock as SchemaBlock_PixelLED;
            config = BootImage.GetPixelConfig(Pixel, pixelType, blocksStartIndex[Array.IndexOf<SchemaBlock_PixelLED>(pixelLeDs, Pixel)]);
            break;
          }
          continue;
        default:
          continue;
      }
      ++Config[28];
      for (int index = 0; index < 3; ++index)
        Config.Add((byte) (config.Count >> index * 8));
      Config.AddRange((IEnumerable<byte>) config);
    }
    return Config[28] > (byte) 0;
  }

  private static int GetComparatorReadBlockIndex(
    UIElementCollection SchemaElements,
    SchemaBlock_Comparator comp)
  {
    SchemaBlock_Read[] array = ((IEnumerable<SchemaBlock_Read>) Schema.GetReads(SchemaElements)).Where<SchemaBlock_Read>((Func<SchemaBlock_Read, bool>) (r => r.DSP != null)).ToArray<SchemaBlock_Read>();
    if (array.Length == 0)
      return -1;
    for (int comparatorReadBlockIndex = 0; comparatorReadBlockIndex < array.Length; ++comparatorReadBlockIndex)
    {
      if (Schema.GetConnections(SchemaElements, comp.GetAnchorConnectionNode(0), array[comparatorReadBlockIndex].GetAnchorConnectionNode(0)).Length != 0)
        return comparatorReadBlockIndex;
    }
    int num = (int) MessageBox.Show($"Comparator <{comp.Title}> is not connected to any Read block", "", MessageBoxButton.OK, MessageBoxImage.Exclamation);
    return -1;
  }

  private static SchemaBlock[] GetComparatorUsers(
    UIElementCollection SchemaElements,
    SchemaBlock_Comparator comp)
  {
    return SchemaElements.OfType<SchemaBlock>().Where<SchemaBlock>((Func<SchemaBlock, bool>) (b => b is IComparatorDependent && (b as IComparatorDependent).ActiveComparator == comp.Title)).ToArray<SchemaBlock>();
  }

  private static bool GetAllCLIConfig(UIElementCollection SchemaElements, out byte[] config)
  {
    config = (byte[]) null;
    List<byte> byteList = new List<byte>();
    SchemaBlock_Controller controller = Schema.GetController(SchemaElements);
    if (controller.CLISettings == null || !controller.CLISettings.IsEnabled)
      return false;
    byteList.Add((byte) 0);
    byteList.AddRange((IEnumerable<byte>) new byte[3]);
    SchemaBlock_DSPCell[] dspCells = Schema.GetDSPCells(SchemaElements);
    if (dspCells.Length != 0)
    {
      ConnectionNode cliConnectionNode = controller.GetCLIConnectionNode();
      foreach (SchemaBlock_DSPCell DSPCell in dspCells)
      {
        for (int index1 = 0; index1 < 2; ++index1)
        {
          List<byte> Config;
          if ((index1 != 1 || DSPCell.IsBypassable) && Schema.GetConnections(SchemaElements, cliConnectionNode, DSPCell.GetAnchorConnectionNode(index1)).Length != 0 && BootImage.GetDSPCellConfigForCLI(SchemaElements, DSPCell, index1, out Config))
          {
            ++byteList[0];
            for (int index2 = 0; index2 < 3; ++index2)
              byteList.Add((byte) (Config.Count >> index2 * 8));
            byteList.AddRange((IEnumerable<byte>) Config);
          }
        }
      }
    }
    config = byteList.ToArray();
    return true;
  }

  private static bool GetDSPCellConfigForCLI(
    UIElementCollection SchemaElements,
    SchemaBlock_DSPCell DSPCell,
    int ActiveAnchorNum,
    out List<byte> Config)
  {
    Config = new List<byte>();
    byte[] bytes = Encoding.ASCII.GetBytes(DSPCell.Title);
    Config.AddRange((IEnumerable<byte>) new byte[17]);
    int index1 = bytes.Length < 17 ? bytes.Length : 16 /*0x10*/;
    for (int index2 = 0; index2 < index1; ++index2)
      Config[index2] = bytes[index2];
    Config[index1] = (byte) 0;
    Config.AddRange((IEnumerable<byte>) new byte[11]);
    List<byte> config1;
    if (!BootImage.GetDSPCellConfig(SchemaElements, DSPCell, ActiveAnchorNum, out config1))
      return false;
    for (int index3 = 0; index3 < 3; ++index3)
      Config.Add((byte) (config1.Count >> index3 * 8));
    Config.AddRange((IEnumerable<byte>) config1);
    int count = Config.Count;
    Config.Add((byte) 0);
    SchemaBlock[] array = SchemaElements.OfType<SchemaBlock>().Where<SchemaBlock>((Func<SchemaBlock, bool>) (b => b is ILed && (b as ILed).DSPBlockConnectionNode != null && (b as ILed).DSPBlockConnectionNode.BlockName == DSPCell.FullName && (b as ILed).DSPBlockConnectionNode.AnchorNumber == ActiveAnchorNum)).ToArray<SchemaBlock>();
    PixelModule.PixelTypes pixelType = Schema.GetController(SchemaElements).PixelSettings.PixelType;
    SchemaBlock_PixelLED[] pixelLeDs = Schema.GetPixelLEDs(SchemaElements);
    int[] blocksStartIndex = pixelLeDs.Length != 0 ? BootImage.GetPixelBlocksStartIndex(SchemaElements) : (int[]) null;
    foreach (SchemaBlock LEDBlock in array)
    {
      List<byte> config2;
      switch (LEDBlock.BlockType)
      {
        case SchemaBlock.SchemaBlockTypes.LED:
          if (BootImage.GetLEDConfig(LEDBlock as SchemaBlock_LED, Schema.GetConnections(SchemaElements), out config2))
            break;
          continue;
        case SchemaBlock.SchemaBlockTypes.PixelLED:
          if (blocksStartIndex != null)
          {
            SchemaBlock_PixelLED Pixel = LEDBlock as SchemaBlock_PixelLED;
            config2 = BootImage.GetPixelConfig(Pixel, pixelType, blocksStartIndex[Array.IndexOf<SchemaBlock_PixelLED>(pixelLeDs, Pixel)]);
            break;
          }
          continue;
        default:
          continue;
      }
      Config[count]++;
      for (int index4 = 0; index4 < 3; ++index4)
        Config.Add((byte) (config2.Count >> index4 * 8));
      Config.AddRange((IEnumerable<byte>) config2);
    }
    return true;
  }

  private static bool GetCtrlMuteConfig(UIElementCollection SchemaElements, out byte[] config)
  {
    config = new byte[8];
    SchemaBlock_Controller controller = Schema.GetController(SchemaElements);
    if (controller == null || controller.MuteIndex == -1)
      return false;
    int TimPSC;
    int TimARR;
    controller.GetMuteTimParams(out TimPSC, out TimARR);
    for (int index = 0; index < 2; ++index)
      config[index] = (byte) (TimPSC >> 8 * index);
    for (int index = 0; index < 2; ++index)
      config[2 + index] = (byte) (TimARR >> 8 * index);
    config[4] = (byte) controller.MuteLevel;
    return true;
  }

  private static SchemaBlock[] GetLineLeds(
    UIElementCollection SchemaElements,
    ConnectionNode LineNode)
  {
    List<SchemaBlock> schemaBlockList = new List<SchemaBlock>();
    foreach (SchemaBlock schemaBlock in SchemaElements.OfType<SchemaBlock>().Where<SchemaBlock>((Func<SchemaBlock, bool>) (b => b is ILed)).ToArray<SchemaBlock>())
    {
      ConnectionNode blockConnectionNode = (schemaBlock as ILed).DSPBlockConnectionNode;
      if (blockConnectionNode != null && Schema.GetConnections(SchemaElements, LineNode, blockConnectionNode).Length != 0)
        schemaBlockList.Add(schemaBlock);
    }
    return schemaBlockList.ToArray();
  }

  private static int[] GetPixelBlocksStartIndex(UIElementCollection SchemaElements)
  {
    SchemaBlock_PixelLED[] pixelLeDs = Schema.GetPixelLEDs(SchemaElements);
    Connection[] connections = Schema.GetConnections(SchemaElements);
    string title = Schema.GetController(SchemaElements).Title;
    int[] blocksStartIndex = new int[pixelLeDs.Length];
    int num1 = 0;
    int index1 = 0;
    int connectindex;
    for (int index2 = 0; index2 < pixelLeDs.Length; ++index2)
    {
      ConnectionNode oppositeNode = BootImage.GetOppositeNode(connections, pixelLeDs[index2].GetAnchorConnectionNode(0), 0, out connectindex);
      if (oppositeNode == null)
      {
        int num2 = (int) MessageBox.Show("PixelLEDs are not connected to controller", "", MessageBoxButton.OK, MessageBoxImage.Exclamation);
        return (int[]) null;
      }
      if (oppositeNode.BlockName == title)
      {
        blocksStartIndex[index2] = num1;
        num1 += pixelLeDs[index2].Settings.LEDsCount;
        index1 = index2;
        break;
      }
    }
    ConnectionNode anchorConnectionNode = pixelLeDs[index1].GetAnchorConnectionNode(1);
    for (ConnectionNode oppositeNode = BootImage.GetOppositeNode(connections, anchorConnectionNode, 0, out connectindex); oppositeNode != null; oppositeNode = BootImage.GetOppositeNode(connections, anchorConnectionNode, 0, out connectindex))
    {
      for (int index3 = 0; index3 < pixelLeDs.Length; ++index3)
      {
        if (oppositeNode.BlockName == pixelLeDs[index3].Title)
        {
          blocksStartIndex[index3] = num1;
          num1 += pixelLeDs[index3].Settings.LEDsCount;
          anchorConnectionNode = pixelLeDs[index3].GetAnchorConnectionNode(1);
          break;
        }
      }
    }
    return blocksStartIndex;
  }

  private static byte[] ColorStringToByteArray(string ColorString, PixelModule.PixelTypes LEDType)
  {
    uint num = uint.Parse(ColorString.Substring(1), NumberStyles.HexNumber);
    byte[] byteArray = new byte[4]
    {
      (byte) ((uint) byte.MaxValue - (num >> 24)),
      (byte) num,
      (byte) (num >> 16 /*0x10*/),
      (byte) (num >> 8)
    };
    if (LEDType == PixelModule.PixelTypes.RGB)
    {
      byteArray[0] = byteArray[1];
      byteArray[1] = byteArray[2];
      byteArray[2] = byteArray[3];
      byteArray[3] = (byte) 0;
    }
    return byteArray;
  }

  private static byte[] SplitToBytes(int value, int BytesCount)
  {
    byte[] bytes = new byte[BytesCount];
    for (int index = 0; index < BytesCount; ++index)
      bytes[index] = (byte) (value >> index * 8);
    return bytes;
  }

  private static int JoinIntoValue(params byte[] input)
  {
    int num = 0;
    for (int index = 0; index < input.Length && index != 4; ++index)
      num |= (int) input[index] << index * 8;
    return num;
  }

  private static int JoinIntoValue(List<byte> list, int index, int size)
  {
    int num = 0;
    for (int index1 = 0; index1 < size && index1 != 4; ++index1)
      num |= (int) list[index + index1] << index1 * 8;
    return num;
  }

  private static void ChangeSegment(List<byte> list, int value, int index, int size)
  {
    byte[] bytes = BootImage.SplitToBytes(value, size);
    for (int index1 = 0; index1 < size; ++index1)
      list[index + index1] = bytes[index1];
  }

  private static ConnectionNode GetOppositeNode(
    Connection[] Connections,
    ConnectionNode Node,
    int startindex,
    out int connectindex)
  {
    connectindex = -1;
    for (int index1 = startindex; index1 < Connections.Length; ++index1)
    {
      for (int index2 = 0; index2 < Connections[index1].Nodes.Count; ++index2)
      {
        if (Connections[index1].Nodes[index2].BlockName == Node.BlockName && Connections[index1].Nodes[index2].AnchorNumber == Node.AnchorNumber)
        {
          connectindex = index1;
          return index2 != 0 ? Connections[index1].Nodes[0] : Connections[index1].Nodes[1];
        }
      }
    }
    return (ConnectionNode) null;
  }

  private static bool GetOppositeNodeAnchorNumber(
    Connection[] Connections,
    ConnectionNode Node,
    out byte AnchorNumber)
  {
    AnchorNumber = (byte) 0;
    Connection[] array = ((IEnumerable<Connection>) Connections).Where<Connection>((Func<Connection, bool>) (c =>
    {
      if (c.Nodes[0].BlockName == Node.BlockName && c.Nodes[0].AnchorNumber == Node.AnchorNumber)
        return true;
      return c.Nodes[1].BlockName == Node.BlockName && c.Nodes[1].AnchorNumber == Node.AnchorNumber;
    })).ToArray<Connection>();
    if (array.Length == 0)
      return false;
    AnchorNumber = !(array[0].Nodes[0].BlockName == Node.BlockName) || array[0].Nodes[0].AnchorNumber != Node.AnchorNumber ? (byte) array[0].Nodes[0].AnchorNumber : (byte) array[0].Nodes[1].AnchorNumber;
    return true;
  }

  private static int GetLineDSPCellValuesCount(
    UIElementCollection SchemaElements,
    ConnectionNode LineNode)
  {
    int dspCellValuesCount = -1;
    Connection[] connections = Schema.GetConnections(SchemaElements);
    int connectindex;
    for (ConnectionNode oppositeNode = BootImage.GetOppositeNode(connections, LineNode, 0, out connectindex); oppositeNode != null; oppositeNode = BootImage.GetOppositeNode(connections, LineNode, connectindex + 1, out connectindex))
    {
      SchemaBlock_DSPCell[] dspCells = Schema.GetDSPCells(SchemaElements, oppositeNode.BlockName);
      int index = 0;
      if (index < dspCells.Length)
      {
        SchemaBlock_DSPCell schemaBlockDspCell = dspCells[index];
        dspCellValuesCount = !schemaBlockDspCell.IsBypassable || oppositeNode.AnchorNumber != 1 ? schemaBlockDspCell.ValuesCount : schemaBlockDspCell.EnValuesCount;
      }
    }
    return dspCellValuesCount;
  }
}
