﻿// Decompiled with JetBrains decompiler
// Type: ChipStudio.SchemaBlock_PixelLED
// Assembly: ChipStudio, Version=1.2.9.0, Culture=neutral, PublicKeyToken=null
// MVID: 334E3BEA-37C7-4274-8118-535AAEFA1546
// Assembly location: D:\DocAndSec\Desktop\AUDIO\ChipDip\ChipStudio_soft_v1.2.9\ChipStudio_v1.2.9.exe

using System;
using System.CodeDom.Compiler;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Diagnostics;
using System.Linq;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Controls.Primitives;
using System.Windows.Input;
using System.Windows.Markup;

#nullable disable
namespace ChipStudio;

public partial class SchemaBlock_PixelLED : 
  SchemaBlock,
  ILed,
  IComparatorDependent,
  IComponentConnector
{
  private static readonly Anchor.AnchorTypes[] PointAnchors = new Anchor.AnchorTypes[2]
  {
    Anchor.AnchorTypes.FromPixel,
    Anchor.AnchorTypes.ToPixel
  };
  public const int TO_PIXEL_OUTPUT_POINT_INDEX = 0;
  public const int TO_PIXEL_INPUT_POINT_INDEX = 1;
  private const double PixelDiameter = 15.0;
  private const int SCALE_FOREGROUND_LEDS_COUNT = 1;
  private const int SCALE_BACKGROUND_LEDS_COUNT = 1;
  private const int SCALE_LEDS_COUNT = 2;
  private const int COMPARATOR_STATES_COUNT = 2;
  private int pixelcount = 1;
  private PixelLEDBlock _Settings = new PixelLEDBlock();
  internal ItemsControl ConnectPoints;
  internal Label ProjIndicatorLabel;
  internal DSPBlockSelector BlockList;
  internal Selector CompSelector;
  internal StackPanel StatesPanel;
  internal Label ScaleLabel;
  internal ItemsControl PixelItems;
  private bool _contentLoaded;

  public override SchemaBlock.SchemaBlockTypes BlockType => SchemaBlock.SchemaBlockTypes.PixelLED;

  public string ActiveComparator
  {
    get
    {
      return this.Settings.IndicationType != PixelLEDBlock.IndicationTypes.Comparator ? (string) null : this.CompSelector.SelectedItem;
    }
  }

  public int PixelCount
  {
    get => this.pixelcount;
    set
    {
      if (this.pixelcount == value)
        return;
      this.pixelcount = value;
      this.NotifyPropertyChanged(nameof (PixelCount));
    }
  }

  public int StateCount
  {
    get => this._Settings.StatesCount;
    set
    {
      if (this._Settings.StatesCount == value)
        return;
      this._Settings.StatesCount = value;
      this.NotifyPropertyChanged(nameof (StateCount));
    }
  }

  public PixelLEDBlock Settings
  {
    get => this._Settings;
    set
    {
      this._Settings = value;
      this.ApplySettings();
    }
  }

  public ConnectionNode DSPBlockConnectionNode
  {
    get
    {
      return this.Settings.IndicationType != PixelLEDBlock.IndicationTypes.DSPBlock ? (ConnectionNode) null : this.BlockList.ActiveConnectionNode();
    }
  }

  public List<Pixel> Pixels { get; private set; } = new List<Pixel>();

  public SchemaBlock_PixelLED()
  {
    this.InitializeComponent();
    this.DataContext = (object) this;
    this.BlockList.SelectionChanged += new DSPBlockSelector.SelectionChangedEventHandler(this.BlockChanged);
    this.InitConnectionPoints(SchemaBlock_PixelLED.PointAnchors);
    this.ConnectionPoints[1].Margin = new Thickness(30.0, 0.0, 0.0, 0.0);
    this.ConnectPoints.ItemsSource = (IEnumerable) this.ConnectionPoints;
    this.UpdatePixelList();
    this.Loaded += new RoutedEventHandler(this.PixelLEDBlock_Loaded);
  }

  public void UpdateBlockList(SchemaBlock_DSPCell[] Blocks, Schema.UpdateOptions Option)
  {
    this.BlockList.Update(Blocks, Option);
  }

  public void UpdateComparatorList(string[] ComparatorTitles, Schema.UpdateOptions Option)
  {
    this.CompSelector.Update(ComparatorTitles, Option);
  }

  public string[] GetColors()
  {
    return this.Pixels.Select<Pixel, string>((Func<Pixel, string>) (p => p.Color)).ToArray<string>();
  }

  public void SetColors(string[] Colors)
  {
    if (Colors.Length >= this.Pixels.Count)
    {
      for (int index = 0; index < this.Pixels.Count; ++index)
        this.Pixels[index].Color = Colors[index];
    }
    else
    {
      int num = (int) MessageBox.Show($"Colors are not defined.\n\r<{this.Title}>", "", MessageBoxButton.OK, MessageBoxImage.Exclamation);
    }
  }

  public int GetDefaultBlockIndex()
  {
    return this.Settings.IndicationType == PixelLEDBlock.IndicationTypes.Comparator ? this.CompSelector.SelectedIndex : this.BlockList.DefaultBlock;
  }

  public void SetDefaultBlockIndex(int BlockIndex)
  {
    if (this.Settings.IndicationType != PixelLEDBlock.IndicationTypes.Comparator)
      this.BlockList.DefaultBlock = BlockIndex;
    else
      this.CompSelector.SelectedIndex = BlockIndex;
  }

  private void UpdatePixelList()
  {
    this.PixelItems.ItemsSource = (IEnumerable) null;
    int index1 = this.PixelCount;
    if (this.Settings.IndicationType == PixelLEDBlock.IndicationTypes.DSPBlock)
      index1 = this.Settings.IndicationMode == PixelLEDBlock.IndicationModes.DataTable ? this.StateCount : 2;
    else if (this.Settings.IndicationType == PixelLEDBlock.IndicationTypes.Comparator)
      index1 = this.StateCount;
    if (this.Pixels.Count < index1)
    {
      int num = index1 - this.Pixels.Count;
      for (int index2 = 0; index2 < num; ++index2)
        this.Pixels.Add(new Pixel() { Diameter = 15.0 });
    }
    else if (this.Pixels.Count > index1)
    {
      int count = this.Pixels.Count - index1;
      this.Pixels.RemoveRange(index1, count);
    }
    this.PixelItems.ItemsSource = (IEnumerable) this.Pixels;
  }

  private void UpdateStatesCount()
  {
    if (this.Settings.IndicationType == PixelLEDBlock.IndicationTypes.Comparator)
    {
      this.StateCount = 2;
    }
    else
    {
      if (!this.BlockList.IsLoaded)
        return;
      this.StateCount = 0;
      int num = this.BlockList.ActiveValuesCount();
      if (num == -1)
        return;
      this.StateCount = num;
    }
  }

  private void ApplySettings()
  {
    switch (this.Settings.IndicationType)
    {
      case PixelLEDBlock.IndicationTypes.Project:
        this.ProjIndicatorLabel.Visibility = Visibility.Visible;
        this.BlockList.Visibility = Visibility.Hidden;
        this.CompSelector.Visibility = Visibility.Hidden;
        this.StatesPanel.Visibility = Visibility.Hidden;
        this.ScaleLabel.Visibility = Visibility.Hidden;
        break;
      case PixelLEDBlock.IndicationTypes.DSPBlock:
        this.ProjIndicatorLabel.Visibility = Visibility.Hidden;
        this.BlockList.Visibility = Visibility.Visible;
        this.CompSelector.Visibility = Visibility.Hidden;
        if (this.Settings.IndicationMode == PixelLEDBlock.IndicationModes.DataTable)
        {
          this.ScaleLabel.Visibility = Visibility.Hidden;
          this.StatesPanel.Visibility = Visibility.Visible;
          this.UpdateStatesCount();
          break;
        }
        this.ScaleLabel.Visibility = Visibility.Visible;
        this.StatesPanel.Visibility = Visibility.Hidden;
        break;
      case PixelLEDBlock.IndicationTypes.Comparator:
        this.ProjIndicatorLabel.Visibility = Visibility.Hidden;
        this.BlockList.Visibility = Visibility.Hidden;
        this.CompSelector.Visibility = Visibility.Visible;
        this.Settings.IndicationMode = PixelLEDBlock.IndicationModes.DataTable;
        this.ScaleLabel.Visibility = Visibility.Hidden;
        this.StatesPanel.Visibility = Visibility.Visible;
        this.UpdateStatesCount();
        break;
    }
    this.PixelCount = this.Settings.LEDsCount;
    this.UpdatePixelList();
  }

  private void PixelLEDBlock_Loaded(object sender, RoutedEventArgs e) => this.UpdateStatesCount();

  private void BlockChanged(int ValuesCount)
  {
    this.UpdateStatesCount();
    if (this.Settings.IndicationType != PixelLEDBlock.IndicationTypes.DSPBlock || this.Settings.IndicationMode != PixelLEDBlock.IndicationModes.DataTable)
      return;
    this.UpdatePixelList();
  }

  private void Edit_Click(object sender, RoutedEventArgs e)
  {
    PixelLEDSettings pixelLedSettings = new PixelLEDSettings(this.Settings);
    bool? nullable = pixelLedSettings.ShowDialog();
    bool flag = true;
    if (!(nullable.GetValueOrDefault() == flag & nullable.HasValue))
      return;
    this.Settings = pixelLedSettings.Settings;
  }

  [DebuggerNonUserCode]
  [GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
  public void InitializeComponent()
  {
    if (this._contentLoaded)
      return;
    this._contentLoaded = true;
    Application.LoadComponent((object) this, new Uri("/ChipStudio;component/schemablock_pixelled.xaml", UriKind.Relative));
  }

  [DebuggerNonUserCode]
  [GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
  internal Delegate _CreateDelegate(Type delegateType, string handler)
  {
    return Delegate.CreateDelegate(delegateType, (object) this, handler);
  }

  [DebuggerNonUserCode]
  [GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
  [EditorBrowsable(EditorBrowsableState.Never)]
  void IComponentConnector.Connect(int connectionId, object target)
  {
    switch (connectionId)
    {
      case 1:
        ((UIElement) target).MouseLeftButtonDown += new MouseButtonEventHandler(((SchemaBlock) this).Border_MouseLeftButtonDown);
        break;
      case 2:
        this.ConnectPoints = (ItemsControl) target;
        break;
      case 3:
        this.ProjIndicatorLabel = (Label) target;
        break;
      case 4:
        this.BlockList = (DSPBlockSelector) target;
        break;
      case 5:
        this.CompSelector = (Selector) target;
        break;
      case 6:
        this.StatesPanel = (StackPanel) target;
        break;
      case 7:
        this.ScaleLabel = (Label) target;
        break;
      case 8:
        ((ButtonBase) target).Click += new RoutedEventHandler(this.Edit_Click);
        break;
      case 9:
        this.PixelItems = (ItemsControl) target;
        break;
      default:
        this._contentLoaded = true;
        break;
    }
  }
}
