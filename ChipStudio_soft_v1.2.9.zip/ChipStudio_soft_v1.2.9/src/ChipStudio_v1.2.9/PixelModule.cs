﻿// Decompiled with JetBrains decompiler
// Type: ChipStudio.PixelModule
// Assembly: ChipStudio, Version=1.2.9.0, Culture=neutral, PublicKeyToken=null
// MVID: 334E3BEA-37C7-4274-8118-535AAEFA1546
// Assembly location: D:\DocAndSec\Desktop\AUDIO\ChipDip\ChipStudio_soft_v1.2.9\ChipStudio_v1.2.9.exe

using System;

#nullable disable
namespace ChipStudio;

public class PixelModule
{
  public bool IsEnabled { get; set; }

  public PixelModule.PixelTypes PixelType { get; set; }

  public bool IsPwrOnEnabled { get; set; }

  public static bool TryParse(string value, out PixelModule.PixelTypes result)
  {
    result = PixelModule.PixelTypes.RGB;
    foreach (PixelModule.PixelTypes pixelTypes in Enum.GetValues(typeof (PixelModule.PixelTypes)))
    {
      if (pixelTypes.ToString() == value)
      {
        result = pixelTypes;
        return true;
      }
    }
    return false;
  }

  public enum PixelTypes : byte
  {
    RGB,
    RGBW,
  }
}
