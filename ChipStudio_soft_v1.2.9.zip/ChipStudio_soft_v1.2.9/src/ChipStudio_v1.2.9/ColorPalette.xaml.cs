﻿// Decompiled with JetBrains decompiler
// Type: ChipStudio.ColorPalette
// Assembly: ChipStudio, Version=1.2.9.0, Culture=neutral, PublicKeyToken=null
// MVID: 334E3BEA-37C7-4274-8118-535AAEFA1546
// Assembly location: D:\DocAndSec\Desktop\AUDIO\ChipDip\ChipStudio_soft_v1.2.9\ChipStudio_v1.2.9.exe

using System;
using System.CodeDom.Compiler;
using System.ComponentModel;
using System.Diagnostics;
using System.Windows;
using System.Windows.Controls.Primitives;
using System.Windows.Markup;
using Xceed.Wpf.Toolkit;

#nullable disable
namespace ChipStudio;

public partial class ColorPalette : Window, IComponentConnector
{
  internal ColorCanvas Palette;
  private bool _contentLoaded;

  public string Color => this.Palette.HexadecimalString;

  public ColorPalette(string InitColor)
  {
    this.InitializeComponent();
    this.Palette.HexadecimalString = InitColor;
  }

  private void OKButton_Click(object sender, RoutedEventArgs e)
  {
    this.DialogResult = new bool?(true);
  }

  private void CancelButton_Click(object sender, RoutedEventArgs e)
  {
    this.DialogResult = new bool?(false);
  }

  [DebuggerNonUserCode]
  [GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
  public void InitializeComponent()
  {
    if (this._contentLoaded)
      return;
    this._contentLoaded = true;
    Application.LoadComponent((object) this, new Uri("/ChipStudio;component/colorpalette.xaml", UriKind.Relative));
  }

  [DebuggerNonUserCode]
  [GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
  [EditorBrowsable(EditorBrowsableState.Never)]
  void IComponentConnector.Connect(int connectionId, object target)
  {
    switch (connectionId)
    {
      case 1:
        this.Palette = (ColorCanvas) target;
        break;
      case 2:
        ((ButtonBase) target).Click += new RoutedEventHandler(this.OKButton_Click);
        break;
      case 3:
        ((ButtonBase) target).Click += new RoutedEventHandler(this.CancelButton_Click);
        break;
      default:
        this._contentLoaded = true;
        break;
    }
  }
}
