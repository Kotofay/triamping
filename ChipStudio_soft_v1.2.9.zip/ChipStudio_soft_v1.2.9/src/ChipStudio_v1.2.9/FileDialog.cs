﻿// Decompiled with JetBrains decompiler
// Type: ChipStudio.FileDialog
// Assembly: ChipStudio, Version=1.2.9.0, Culture=neutral, PublicKeyToken=null
// MVID: 334E3BEA-37C7-4274-8118-535AAEFA1546
// Assembly location: D:\DocAndSec\Desktop\AUDIO\ChipDip\ChipStudio_soft_v1.2.9\ChipStudio_v1.2.9.exe

using Microsoft.Win32;

#nullable disable
namespace ChipStudio;

public class FileDialog
{
  public static string Save(string Filter)
  {
    SaveFileDialog saveFileDialog1 = new SaveFileDialog();
    saveFileDialog1.Filter = Filter;
    SaveFileDialog saveFileDialog2 = saveFileDialog1;
    bool? nullable = saveFileDialog2.ShowDialog();
    bool flag = true;
    return nullable.GetValueOrDefault() == flag & nullable.HasValue ? saveFileDialog2.FileName : (string) null;
  }

  public static string Open(string Filter)
  {
    OpenFileDialog openFileDialog1 = new OpenFileDialog();
    openFileDialog1.Filter = Filter;
    OpenFileDialog openFileDialog2 = openFileDialog1;
    bool? nullable = openFileDialog2.ShowDialog();
    bool flag = true;
    return nullable.GetValueOrDefault() == flag & nullable.HasValue ? openFileDialog2.FileName : (string) null;
  }
}
