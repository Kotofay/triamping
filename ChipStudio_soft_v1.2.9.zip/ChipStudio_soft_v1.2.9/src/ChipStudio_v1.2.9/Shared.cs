﻿// Decompiled with JetBrains decompiler
// Type: ChipStudio.Shared
// Assembly: ChipStudio, Version=1.2.9.0, Culture=neutral, PublicKeyToken=null
// MVID: 334E3BEA-37C7-4274-8118-535AAEFA1546
// Assembly location: D:\DocAndSec\Desktop\AUDIO\ChipDip\ChipStudio_soft_v1.2.9\ChipStudio_v1.2.9.exe

using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Windows;

#nullable disable
namespace ChipStudio;

public class Shared
{
  private const string XmlFileStart = "<?xml";
  public static readonly string ElementTypeBlock = (string) Application.Current.FindResource((object) nameof (ElementTypeBlock));
  public static readonly string ElementTypeConnection = (string) Application.Current.FindResource((object) nameof (ElementTypeConnection));
  public static readonly string FilePathSlash = (string) Application.Current.FindResource((object) nameof (FilePathSlash));
  public static readonly string DeviceDescriptionFolder = (string) Application.Current.FindResource((object) nameof (DeviceDescriptionFolder));
  public static readonly string ControllersFolder = (string) Application.Current.FindResource((object) nameof (ControllersFolder));
  public static readonly string DSPCodecFolder = (string) Application.Current.FindResource((object) nameof (DSPCodecFolder));
  public static readonly string DDFileExt = (string) Application.Current.FindResource((object) nameof (DDFileExt));
  public static readonly string DoesNotExistString = (string) Application.Current.FindResource((object) nameof (DoesNotExistString));
  public static readonly string ApplicationPath = Path.GetDirectoryName(Assembly.GetEntryAssembly().Location);
  public static readonly string ApplicationDataPath = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.CommonApplicationData), "ChipStudio");
  public static readonly string DDControllerFolder = Shared.FilePathSlash + Shared.DeviceDescriptionFolder + Shared.FilePathSlash + Shared.ControllersFolder;
  public static readonly string DDControllerPath = Shared.ApplicationPath + Shared.DDControllerFolder;
  public static readonly string DDdspFolder = Shared.FilePathSlash + Shared.DeviceDescriptionFolder + Shared.FilePathSlash + Shared.DSPCodecFolder;
  public static readonly string DDdspPath = Shared.ApplicationPath + Shared.DDdspFolder;
  public const string FolderString = "Folder";
  public const string DeviceDescriptionFileString = "Device description file";
  public const string NoConfigInFile = "File does not contain DSP configuration";
  public const string NoControllerInfo = "Controller is not connected";
  public const string WrongDDFormat = "Wrong device description format";
  public const string BackupAddition = "_backup";
  public const string WrongInputInField = "Wrong input in field ";
  public const string InBlockString = "in block ";
  public const string MoreSign = ">";
  public const string LessSign = "<";
  public const string NewLineString = "\n\r";
  public const string XML_FIELD_FIRST_SIGN_OPEN = "<";
  public const string XML_FIELD_SECOND_SIGN = ">";
  public const string TitleString = "Title";
  public const string DotSign = ".";
  public const string MultipleDots = "...";
  public const string StudioDataSeparator = ",";
  public const string ValueSplitter = ";";
  public const string Space = " ";
  public const string HexStartString = "0x";
  public const string EmptyString = "";
  public const string TabSign = "\t";
  public const string UnderLineSign = "_";
  public const string MaskString = "Mask";
  public const string VersionElement = "Version";
  public const string ValueString = "Value";
  public const string PathString = "Path";
  public const string RegulationAnchorTitle = "REG";
  public const string EnableAnchorTitle = "EN";
  public const string BlockTitleSeparator = "_";
  public const string LEDPart = "LED";
  public const string PixelLEDPart = "PixelLED";
  public const string ReadPart = "Read";
  public const string ComparatorPart = "Comparator";
  public const string CommentPart = "Comment";
  public const string Interace_I2C = "I2C";
  public const string Interace_SPI = "SPI";
  public const string Interace_CS = "CS";
  public const string GpioTypeReg = "RegGPIOs";
  public const string GpioTypeGPIOI = "GPIOI";
  public const string GpioTypeDSPI = "DSPI";
  public const string ADAU1701_Module = "ADAU1701";
  public const string ADAU1761_Module = "ADAU1761";
  public const string ADAU145x_Module = "ADAU145x";
  public const string ADAU146x_Module = "ADAU146x";
  public const string RDC2_0050_Module = "RDC2_0050";
  public const string TAS3251_Module = "TAS3251";
  public const string AD1933_Module = "AD1933";
  public const string AD1934_Module = "AD1934";
  public const string AD1938_Module = "AD1938";
  public const string RDC2_0059_Module = "RDC2_0059";
  public const string SSM3582_Module = "SSM3582";
  public const string PCM5142_Module = "PCM5142";
  public const string PCM5242_Module = "PCM5242";
  public const string ES9038Q2M_Module = "ES9038Q2M";
  public const string PCM5122_Module = "PCM5122";
  public const int OneKByte = 1024 /*0x0400*/;
  public const int CLI_GPIO_COUNT = 2;

  public static void ConcatByAddress(List<DataTransfer> TXs, int ValueSize = 1)
  {
    List<DataTransfer> collection = new List<DataTransfer>()
    {
      new DataTransfer(TXs[0].Address, TXs[0].Size, TXs[0].AddressIncrement, TXs[0].Type)
    };
    int index1 = 0;
    int num = 0;
    for (int index2 = 1; index2 < TXs.Count; ++index2)
    {
      if ((int) collection[index1].Address + collection[index1].Size / ValueSize == (int) TXs[index2].Address)
      {
        collection[index1].Size += TXs[index2].Size;
      }
      else
      {
        List<byte> byteList = new List<byte>();
        for (int index3 = num; index3 < index2; ++index3)
          byteList.AddRange((IEnumerable<byte>) TXs[index3].Data);
        collection[collection.Count - 1].Data = byteList.ToArray();
        collection.Add(new DataTransfer(TXs[index2].Address, TXs[index2].Size, TXs[index2].AddressIncrement, TXs[index2].Type));
        TXs[index2].Data.CopyTo((Array) collection[collection.Count - 1].Data, 0);
        ++index1;
        num = index2;
      }
    }
    TXs.Clear();
    TXs.AddRange((IEnumerable<DataTransfer>) collection);
  }

  public static bool TryParseDSPCellDataGeneric(string InputFile, out byte[] Result)
  {
    return Shared.TryParseHEXMany(((IEnumerable<string[]>) ((IEnumerable<string>) File.ReadAllLines(InputFile)).Where<string>((Func<string, bool>) (s => s.StartsWith("0x"))).Select<string, string[]>((Func<string, string[]>) (s => s.Replace(" ", "").Replace("\t", "").Replace("0x", "").Split(","[0]))).ToArray<string[]>()).SelectMany<string[], string>((Func<string[], IEnumerable<string>>) (s => (IEnumerable<string>) s)).Where<string>((Func<string, bool>) (sd => sd.Length != 0)).ToArray<string>(), out Result);
  }

  public static bool TryParseHEX(string input, out uint result)
  {
    result = 0U;
    if (input.Length == 0)
      return false;
    try
    {
      result = Convert.ToUInt32(input, 16 /*0x10*/);
    }
    catch (FormatException ex)
    {
      return false;
    }
    return true;
  }

  public static bool TryParseHEXMany(string[] DataStrings, out byte[] Result)
  {
    Result = new byte[DataStrings.Length];
    for (int index = 0; index < DataStrings.Length; ++index)
    {
      uint result;
      if (!Shared.TryParseHEX(DataStrings[index], out result))
        return false;
      Result[index] = (byte) result;
    }
    return true;
  }

  public static bool TryParseToValue(string input, out uint result)
  {
    return !Shared.IsHexNumberString(input) ? uint.TryParse(input, out result) : Shared.TryParseHEX(input.Replace("0x", ""), out result);
  }

  public static string[] GetFolderFiles(string FolderName)
  {
    string path = " ";
    if (FolderName == Shared.ControllersFolder)
      path = Shared.DDControllerPath;
    else if (FolderName == Shared.DSPCodecFolder)
      path = Shared.DDdspPath;
    return Directory.Exists(path) ? ((IEnumerable<string>) Directory.GetFiles(path, "*.xml")).Select<string, string>((Func<string, string>) (n => Path.GetFileNameWithoutExtension(n))).ToArray<string>() : (string[]) null;
  }

  public static bool IsXMLFile(string Path)
  {
    string[] array = ((IEnumerable<string>) File.ReadAllLines(Path)).Where<string>((Func<string, bool>) (s => s.StartsWith("<"))).ToArray<string>();
    return array != null && array.Length != 0 && array[0].StartsWith("<?xml");
  }

  public static string[] ConvertFileFieldToValues(string Input)
  {
    Input = Input.Remove(0, 1);
    Input = Input.Remove(Input.Length - 1, 1);
    return Input.Split(";"[0]);
  }

  private static bool IsHexNumberString(string input) => input.StartsWith("0x");
}
