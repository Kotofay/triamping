﻿// Decompiled with JetBrains decompiler
// Type: ChipStudio.SchemaBlock_DSP
// Assembly: ChipStudio, Version=1.2.9.0, Culture=neutral, PublicKeyToken=null
// MVID: 334E3BEA-37C7-4274-8118-535AAEFA1546
// Assembly location: D:\DocAndSec\Desktop\AUDIO\ChipDip\ChipStudio_soft_v1.2.9\ChipStudio_v1.2.9.exe

using System;
using System.CodeDom.Compiler;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Diagnostics;
using System.Linq;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Markup;

#nullable disable
namespace ChipStudio;

public partial class SchemaBlock_DSP : SchemaBlock, IComponentConnector
{
  private static readonly string FileParseQuestion = "Do you want to update DSP project?\n\r- press 'Yes' to update project and save common blocks\n\r- press 'No' to replace project and delete all blocks\n\r- press 'Cancel' to cancel operation";
  private List<DataTransfer> BootSequence;
  private List<DSPCell> Cells;
  private readonly DSP DSPDev;
  internal DataFileSelector FileSelector;
  internal CheckBox SelfBootCheck;
  internal StackPanel AdrSelectView;
  internal ComboBox Adr0ComboBox;
  internal ComboBox Adr1ComboBox;
  internal ItemsControl ConnectPoints;
  private bool _contentLoaded;

  public string Module { get; }

  public bool IsReady => this.DSPDev.IsLoaded;

  public override byte CoreID => this.DSPDev.ID;

  public override SchemaBlock.SchemaBlockTypes BlockType => SchemaBlock.SchemaBlockTypes.DSP;

  public bool IsChipSelectable => this.DSPDev.IsSelectable;

  public byte Interface => this.DSPDev.HWInterface;

  public bool IsSelfBooted
  {
    get => this.SelfBootCheck.IsChecked.Value;
    set => this.SelfBootCheck.IsChecked = new bool?(value);
  }

  public SchemaBlock_DSP(string moduletype)
  {
    this.InitializeComponent();
    this.DataContext = (object) this;
    this.Module = moduletype;
    this.DSPDev = new DSP((IDDdsp) new DDdspXml(this.Module));
    if (!this.DSPDev.IsLoaded)
      return;
    if (this.DSPDev.IsSelfBootable)
      this.SelfBootCheck.Visibility = Visibility.Visible;
    if (this.DSPDev.IsAddressSelectable)
    {
      this.AdrSelectView.Visibility = Visibility.Visible;
      this.Adr0ComboBox.ItemsSource = (IEnumerable) this.DSPDev.AddressLineStates;
      this.Adr0ComboBox.SelectedIndex = 0;
      this.Adr1ComboBox.ItemsSource = (IEnumerable) this.DSPDev.AddressLineStates;
      this.Adr1ComboBox.SelectedIndex = 0;
      if (this.DSPDev.AddressLineCount == 1)
        this.Adr1ComboBox.IsEnabled = false;
    }
    this.BootSequence = new List<DataTransfer>();
    this.Cells = new List<DSPCell>();
    this.InitConnectionPoints(this.DSPDev.ActivePointAnchors());
    string[] strArray = this.DSPDev.ActivePointTitles();
    for (int index = 0; index < this.ConnectionPoints.Length; ++index)
      this.ConnectionPoints[index].Title = strArray[index];
    if (this.ConnectionPoints.Length == 2)
      this.ConnectionPoints[1].Margin = new Thickness(0.0, 10.0, 0.0, 0.0);
    this.ConnectPoints.ItemsSource = (IEnumerable) this.ConnectionPoints;
    this.FileSelector.Filter = this.DSPDev.ProjectFileFormat;
    this.FileSelector.FileProcessingSet(new Func<string, DataFileSelector.ProcessResult>(this.ParseProjectFile));
  }

  public byte GetBusAddress()
  {
    return this.DSPDev.BusAddress(this.Adr0ComboBox.SelectedIndex, this.Adr1ComboBox.SelectedIndex);
  }

  public void SetBusAddress(byte Address)
  {
    int AdrState_0;
    int AdrState_1;
    this.DSPDev.SetAdrLines(Address, out AdrState_0, out AdrState_1);
    this.Adr0ComboBox.SelectedIndex = AdrState_0;
    this.Adr1ComboBox.SelectedIndex = AdrState_1;
  }

  private DataFileSelector.ProcessResult ParseProjectFile(string ProjectFile)
  {
    List<DataTransfer> BootSequence;
    List<DSPCell> Cells;
    if (this.DSPDev.ParseProject(ProjectFile, out BootSequence, out Cells))
      return this.Update(BootSequence, Cells);
    return this.BootSequence.Count != 0 ? DataFileSelector.ProcessResult.FailedAndSave : DataFileSelector.ProcessResult.FailedAndClear;
  }

  public List<DataTransfer> GetBoot()
  {
    return new List<DataTransfer>((IEnumerable<DataTransfer>) this.BootSequence);
  }

  public List<DSPCell> GetCells() => new List<DSPCell>((IEnumerable<DSPCell>) this.Cells);

  public void SetBoot(DataTransfer[] DSPBoot)
  {
    this.BootSequence.Clear();
    this.BootSequence.AddRange((IEnumerable<DataTransfer>) DSPBoot);
    if (this.BootSequence.Count == 0)
      return;
    this.FileSelector.IsDataSet = true;
  }

  public void SetCells(DSPCell[] DSPCells)
  {
    this.DSPDev.CorrectDefaultCellsWriteType(DSPCells);
    this.Cells.Clear();
    this.Cells.AddRange((IEnumerable<DSPCell>) DSPCells);
    foreach (DSPCell cell in this.Cells)
    {
      if (cell.ParamsFromFile.Count == 0)
        cell.ParamsFromFile.AddRange(cell.ParamsUsed.Select<DSPCellParameter, DSPCellParameter>((Func<DSPCellParameter, DSPCellParameter>) (p => DSPCellParameter.Clone(p))));
    }
  }

  public void AddConstantCells() => this.DSPDev.AddDefaultCells(this.Cells);

  public void SetDSPTitleToCells()
  {
    foreach (DSPCell cell in this.Cells)
      cell.DSPTitle = this.Title;
  }

  public void UpdateBootAndCells(List<DataTransfer> NewBoot, List<DSPCell> NewCells)
  {
    if (NewBoot.Count == 0 || this.Update(NewBoot, NewCells) != DataFileSelector.ProcessResult.Success)
      return;
    this.FileSelector.IsDataSet = true;
  }

  private DataFileSelector.ProcessResult Update(List<DataTransfer> NewBoot, List<DSPCell> NewCells)
  {
    this.BootSequence = NewBoot;
    if (this.DSPDev.AreCellsConstant)
    {
      if (this.Cells.Count == 0)
      {
        if (NewCells.Count != 0)
          this.Cells = NewCells;
        else
          this.DSPDev.AddDefaultCells(this.Cells);
        this.SetDSPTitleToCells();
        SchemaBlock_DSP.FileParseEndEventHandler fileParseEnd = this.FileParseEnd;
        if (fileParseEnd != null)
          fileParseEnd(this.Cells, SchemaBlock_DSP.FileParseOption.Replace);
      }
    }
    else
    {
      SchemaBlock_DSP.FileParseOption Option = this.Cells.Count == 0 ? SchemaBlock_DSP.FileParseOption.Replace : this.AskForPraseOption();
      switch (Option)
      {
        case SchemaBlock_DSP.FileParseOption.Cancel:
          return DataFileSelector.ProcessResult.FailedAndSave;
        case SchemaBlock_DSP.FileParseOption.Update:
          using (List<DSPCell>.Enumerator enumerator1 = this.Cells.GetEnumerator())
          {
            while (enumerator1.MoveNext())
            {
              DSPCell current1 = enumerator1.Current;
              foreach (DSPCell newCell in NewCells)
              {
                if (current1.Title == newCell.Title)
                {
                  newCell.ParamsUsed = current1.ParamsUsed;
                  using (List<DSPCellParameter>.Enumerator enumerator2 = newCell.ParamsUsed.GetEnumerator())
                  {
                    while (enumerator2.MoveNext())
                    {
                      DSPCellParameter current2 = enumerator2.Current;
                      foreach (DSPCellParameter dspCellParameter in newCell.ParamsFromFile)
                      {
                        if (current2.Name == dspCellParameter.Name)
                        {
                          current2.Address = dspCellParameter.Address;
                          break;
                        }
                      }
                    }
                    break;
                  }
                }
              }
            }
            break;
          }
      }
      this.Cells = NewCells;
      if (this.Cells.Count != 0)
      {
        this.SetDSPTitleToCells();
        foreach (DSPCell cell in this.Cells)
        {
          if (cell.ParamsUsed.Count == 0)
            cell.CloneParamsFromFileToParamsUsed();
        }
        SchemaBlock_DSP.FileParseEndEventHandler fileParseEnd = this.FileParseEnd;
        if (fileParseEnd != null)
          fileParseEnd(this.Cells, Option);
      }
    }
    return DataFileSelector.ProcessResult.Success;
  }

  public event SchemaBlock_DSP.FileParseEndEventHandler FileParseEnd;

  private SchemaBlock_DSP.FileParseOption AskForPraseOption()
  {
    switch (MessageBox.Show($"<{this.Title}>\n\r{SchemaBlock_DSP.FileParseQuestion}", "", MessageBoxButton.YesNoCancel, MessageBoxImage.Question))
    {
      case MessageBoxResult.Yes:
        return SchemaBlock_DSP.FileParseOption.Update;
      case MessageBoxResult.No:
        return SchemaBlock_DSP.FileParseOption.Replace;
      default:
        return SchemaBlock_DSP.FileParseOption.Cancel;
    }
  }

  protected override void Dispose(bool disposing)
  {
    if (!disposing)
      return;
    this.FileParseEnd = (SchemaBlock_DSP.FileParseEndEventHandler) null;
    base.Dispose(disposing);
  }

  [DebuggerNonUserCode]
  [GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
  public void InitializeComponent()
  {
    if (this._contentLoaded)
      return;
    this._contentLoaded = true;
    Application.LoadComponent((object) this, new Uri("/ChipStudio;component/schemablock_dsp.xaml", UriKind.Relative));
  }

  [DebuggerNonUserCode]
  [GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
  internal Delegate _CreateDelegate(Type delegateType, string handler)
  {
    return Delegate.CreateDelegate(delegateType, (object) this, handler);
  }

  [DebuggerNonUserCode]
  [GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
  [EditorBrowsable(EditorBrowsableState.Never)]
  void IComponentConnector.Connect(int connectionId, object target)
  {
    switch (connectionId)
    {
      case 1:
        ((UIElement) target).MouseLeftButtonDown += new MouseButtonEventHandler(((SchemaBlock) this).Border_MouseLeftButtonDown);
        break;
      case 2:
        this.FileSelector = (DataFileSelector) target;
        break;
      case 3:
        this.SelfBootCheck = (CheckBox) target;
        break;
      case 4:
        this.AdrSelectView = (StackPanel) target;
        break;
      case 5:
        this.Adr0ComboBox = (ComboBox) target;
        break;
      case 6:
        this.Adr1ComboBox = (ComboBox) target;
        break;
      case 7:
        this.ConnectPoints = (ItemsControl) target;
        break;
      default:
        this._contentLoaded = true;
        break;
    }
  }

  public enum FileParseOption
  {
    Cancel,
    Update,
    Replace,
  }

  public delegate void FileParseEndEventHandler(
    List<DSPCell> CellList,
    SchemaBlock_DSP.FileParseOption Option);
}
