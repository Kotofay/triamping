﻿// Decompiled with JetBrains decompiler
// Type: ChipStudio.OldFormatProject
// Assembly: ChipStudio, Version=1.2.9.0, Culture=neutral, PublicKeyToken=null
// MVID: 334E3BEA-37C7-4274-8118-535AAEFA1546
// Assembly location: D:\DocAndSec\Desktop\AUDIO\ChipDip\ChipStudio_soft_v1.2.9\ChipStudio_v1.2.9.exe

using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Windows;

#nullable disable
namespace ChipStudio;

public class OldFormatProject
{
  private const string TypeSchemaBlock_RDC2_0051 = "SchemaBlock_RDC2_0051";
  private const string TypeSchemaBlock_RDC2_0051Rev2 = "SchemaBlock_RDC2_0051Rev2";
  private const string TypeSchemaBlock_RDC2_0032 = "SchemaBlock_RDC2_0032";
  private const string TypeSchemaBlock_REFLEX = "SchemaBlock_Reflex";
  private const string TypeSchemaBlock_REFLEX_2_0 = "SchemaBlock_Reflex_2_0";
  private const string TypeSchemaBlock_REFLEX_3_0 = "SchemaBlock_Reflex_3_0";
  private const string TypeSchemaBlock_DSP = "SchemaBlock_DSP";
  private const string TypeSchemaBlock_Control = "SchemaBlock_Control";
  private const string TypeSchemaBlock_DSPCell = "SchemaBlock_DSPCell";
  private const string TypeSchemaBlock_LED = "SchemaBlock_LED";
  private const string TypeSchemaBlock_PixelLED = "SchemaBlock_PixelLED";
  private const string DSPPropertyTransfer = "Transfer";
  private const string DSPPropertyCell = "Cell";
  private const string DSPPropertyParameter = "Parameter";
  private const string DSPPropertyXMLParameter = "XMLParameter";
  private const string DSPPropertyAddress = "BusAddress";
  private const string DSPPropertySelfBoot = "SelfBoot";
  private const string DSPCellPropertyRegData = "RegData";
  private const string DSPCellPropertyEnData = "EnData";
  private const string DSPCellPropertyPaths = "Paths";
  private const string StartUpDelayProperty = "StartUpDelay";
  private const string PixelModuleProperty = "PixelModule";
  private const string CECModuleProperty = "CECModule";
  private const string OptionsProperty = "Options";
  private const string PixelBlockSetsProperty = "Settings";
  private const string PixelBlockColorsProperty = "Colors";
  private const string IsNotSupported = " is not supported.";
  private const int RegionHeaderLineIndex = 0;
  private const int BlockDescriptionLineIndex = 1;
  private const int BlockFirstComponentLineIndex = 2;
  private const int UITypeIndex = 0;
  private const int BlockModuleTypeIndex = 1;
  private const int BlockTitleIndex = 2;
  private const int BlockSubTitleIndex = 3;
  private const int BlockBlockTypeIndex = 4;
  private const int BlockPointXIndex = 5;
  private const int BlockPointYIndex = 6;
  private const int BlockParamsCount = 7;
  private const int PropertyTypeIndex = 0;
  private const int GPIOsStartIndex = 1;
  private const int StartDelayActiveIndex = 1;
  private const int StartDelayIndexIndex = 2;
  private const int StartDelayParamsCount = 3;
  private const int PixelModuleActiveIndex = 1;
  private const int PixelModulePixelTypeIndex = 2;
  private const int PixelModulePowerOnIndex = 3;
  private const int PixelModuleParamsCount = 4;
  private const int PixelBlockLEDsCountIndex = 1;
  private const int PixelBlockStatesCountIndex = 2;
  private const int PixelBlockIndicationTypeIndex = 3;
  private const int PixelBlockIndicationModeIndex = 4;
  private const int PixelBlockDefaultBlockIndex = 5;
  private const int PixelBlockSetsCount = 6;
  private const int CECActiveIndex = 1;
  private const int CECPortIndex = 2;
  private const int CECNameIndex = 3;
  private const int CECVolGpioIndex = 4;
  private const int CECMuteGpioIndex = 5;
  private const int CECOptTVonIndex = 6;
  private const int CECOptTVoffIndex = 7;
  private const int CECOptDeviceOnIndex = 8;
  private const int CECOptDeviceOffIndex = 9;
  private const int CECOptAudioStatusIndex = 10;
  private const int CECSetsCount = 11;
  private const int OptGenSelIndex = 1;
  private const int OptFreqIndIndex = 2;
  private const int OptResIndIndex = 3;
  private const int OptPwrByKeyIndex = 4;
  private const int OptUSBStdWakeIndex = 5;
  private const int OptFixProjIndex = 6;
  private const int OptCount = 7;
  private const int NodeNameIndex = 0;
  private const int NodeAnchorNumberIndex = 1;
  private const int NodeAnchorTypeIndex = 2;
  private const int NodeAnchorXIndex = 3;
  private const int NodeAnchorYIndex = 4;
  private const int ConNodeParamsCount = 5;
  private const int DSPPropertyTypeIndex = 0;
  private const int TransferTypeIndex = 1;
  private const int TransferAddressIndex = 2;
  private const int TransferAdrIncrIndex = 3;
  private const int TransferSizeIndex = 4;
  private const int TransferDataStartIndex = 5;
  private const int TransferParamsCount = 5;
  private const int CellTitleIndex = 1;
  private const int CellDSPTitleIndex = 2;
  private const int CellTypeIndex = 3;
  private const int CellIsControllableIndex = 4;
  private const int CellIsBypassableIndex = 5;
  private const int CellParamsCount = 6;
  private const int ParamNameIndex = 1;
  private const int ParamAddressIndex = 2;
  private const int ParamSizeIndex = 3;
  private const int ParamDataIndex = 4;
  private const int ParamParamsCount = 4;
  private const int AddressBusAddressIndex = 1;
  private const int SelfBootValueIndex = 1;
  private const int CellPropertyNameIndex = 0;
  private const int LEDDataIndex = 1;
  private const string FromMasterToSlave_I2C = "FromMasterToSlave_I2C";
  private const string FromSlaveToMaster_I2C = "FromSlaveToMaster_I2C";
  private const string FromMasterToSlave_SPI = "FromMasterToSlave_SPI";
  private const string FromSlaveToMaster_SPI = "FromSlaveToMaster_SPI";
  private const string FromMasterToSlave_CS = "FromMasterToSlave_CS";
  private const string FromSlaveToMaster_CS = "FromSlaveToMaster_CS";
  private const string FromADCToPOT = "FromADCToPOT";
  private const string FromPOTToADC = "FromPOTToADC";
  private const string FromPOTKeySwitchToDSPCell = "FromPOTKeySwitchToDSPCell";
  private const string FromDSPCellToPOTKeySwitch = "FromDSPCellToPOTKeySwitch";
  private const string FromControllerToKey = "FromControllerToKey";
  private const string FromKeyToController = "FromKeyToController";
  private const string FromControllerToSwitch = "FromControllerToSwitch";
  private const string FromSwitchToController = "FromSwitchToController";
  private const string FromControllerToLED = "FromControllerToLED";
  private const string FromLEDToController = "FromLEDToController";
  private const string FromControllerToEncoderA = "FromControllerToEncoderA";
  private const string FromEncoderAToController = "FromEncoderAToController";
  private const string FromControllerToEncoderB = "FromControllerToEncoderB";
  private const string FromEncoderBToController = "FromEncoderBToController";
  private const string FromControllerToPMButtonP = "FromControllerToPMButtonP";
  private const string FromPMButtonPToController = "FromPMButtonPToController";
  private const string FromControllerToPMButtonM = "FromControllerToPMButtonM";
  private const string FromPMButtonMToController = "FromPMButtonMToController";
  private const string FromPixel = "FromPixel";
  private const string ToPixel = "ToPixel";
  private static readonly string[] OldControlBlocks = new string[5]
  {
    "Resistor",
    "Button",
    "Switch",
    "Encoder",
    "PMButton"
  };

  public static bool Open(string FilePath, out List<ISchemaElement> Elements)
  {
    Elements = new List<ISchemaElement>();
    List<Connection> connectionList = new List<Connection>();
    using (StreamReader streamReader = File.OpenText(FilePath))
    {
      string str1 = streamReader.ReadLine();
      while (streamReader.Peek() >= 0 && str1.IndexOf("#End FileDescription") == -1)
        str1 = streamReader.ReadLine();
      while (streamReader.Peek() >= 0)
      {
        string str2 = streamReader.ReadLine();
        if (str2.IndexOf("#Begin ") != -1)
        {
          List<string> FileRegion = new List<string>();
          for (; str2.IndexOf("#End ") == -1; str2 = streamReader.ReadLine())
            FileRegion.Add(str2);
          FileRegion.Add(str2);
          if (!FileRegion[0].Contains(Shared.ElementTypeConnection))
          {
            if (!FileRegion[1].Contains("SchemaBlock_Control"))
            {
              ISchemaElement schemaBlock = OldFormatProject.ConvertFileRegionToSchemaBlock(FileRegion);
              if (schemaBlock == null)
                return false;
              Elements.Add(schemaBlock);
            }
          }
          else
          {
            Connection schemaConnection = OldFormatProject.ConvertFileRegionToSchemaConnection(FileRegion);
            if (schemaConnection == null)
              return false;
            connectionList.Add(schemaConnection);
          }
        }
      }
    }
    if (connectionList.Count != 0)
    {
      OldFormatProject.UpdateConnections(connectionList);
      Elements.AddRange((IEnumerable<ISchemaElement>) connectionList);
    }
    return true;
  }

  private static ISchemaElement ConvertFileRegionToSchemaBlock(List<string> FileRegion)
  {
    string[] values1 = Shared.ConvertFileFieldToValues(FileRegion[1]);
    double Result1;
    if (!OldFormatProject.TryParseFracValue(values1[5], out Result1))
      return (ISchemaElement) null;
    double Result2;
    if (!OldFormatProject.TryParseFracValue(values1[6], out Result2))
      return (ISchemaElement) null;
    switch (values1[0])
    {
      case "SchemaBlock_DSP":
        SchemaBlock_DSP Block1 = new SchemaBlock_DSP(values1[1]);
        if (!Block1.IsReady)
          return (ISchemaElement) null;
        Block1.Title = values1[2];
        Block1.UpperLeftPoint = new Point(Result1, Result2);
        if (Block1.Title.IndexOf("TAS3251") != -1)
        {
          int num1 = (int) MessageBox.Show("Old format block <TAS3251> is not supported.", "", MessageBoxButton.OK, MessageBoxImage.Exclamation);
        }
        return !OldFormatProject.ConvertFileRegionToDSP(FileRegion, Block1) ? (ISchemaElement) null : (ISchemaElement) Block1;
      case "SchemaBlock_DSPCell":
        SchemaBlock_DSPCell Block2 = new SchemaBlock_DSPCell();
        Block2.Title = values1[2];
        Block2.UpperLeftPoint = new Point(Result1, Result2);
        Block2.DSPTitle = values1[3];
        return !OldFormatProject.ConvertFileRegionToDSPCell(FileRegion, Block2) ? (ISchemaElement) null : (ISchemaElement) Block2;
      case "SchemaBlock_LED":
        SchemaBlock_LED Block3 = new SchemaBlock_LED();
        Block3.Title = values1[2];
        Block3.UpperLeftPoint = new Point(Result1, Result2);
        return !OldFormatProject.ConvertFileRegionToLED(FileRegion, Block3) ? (ISchemaElement) null : (ISchemaElement) Block3;
      case "SchemaBlock_PixelLED":
        SchemaBlock_PixelLED Block4 = new SchemaBlock_PixelLED();
        Block4.Title = values1[2];
        Block4.UpperLeftPoint = new Point(Result1, Result2);
        return !OldFormatProject.ConvertFileRegionToPixelLED(FileRegion, Block4) ? (ISchemaElement) null : (ISchemaElement) Block4;
      case "SchemaBlock_RDC2_0032":
      case "SchemaBlock_RDC2_0051":
        int num2 = (int) MessageBox.Show($"Controller <{values1[1]}> is not supported.", "", MessageBoxButton.OK, MessageBoxImage.Hand);
        return (ISchemaElement) null;
      case "SchemaBlock_RDC2_0051Rev2":
      case "SchemaBlock_Reflex":
      case "SchemaBlock_Reflex_2_0":
      case "SchemaBlock_Reflex_3_0":
        SchemaBlock_Controller schemaBlock = new SchemaBlock_Controller(values1[1]);
        if (!schemaBlock.IsReady)
          return (ISchemaElement) null;
        schemaBlock.Title = values1[2];
        schemaBlock.UpperLeftPoint = new Point(Result1, Result2);
        schemaBlock.SetGPIOFunctions(OldFormatProject.GetControllerGpioFuncs(FileRegion));
        int propertyIndex1 = OldFormatProject.FindPropertyIndex(FileRegion, "StartUpDelay");
        if (propertyIndex1 != -1)
        {
          string[] values2 = Shared.ConvertFileFieldToValues(FileRegion[propertyIndex1]);
          bool result1 = bool.TryParse(values2[1], out result1) && result1;
          int result2;
          int DelayIndex = int.TryParse(values2[2], out result2) ? result2 : 0;
          schemaBlock.SetStartDelayParams(result1, DelayIndex);
        }
        int propertyIndex2 = OldFormatProject.FindPropertyIndex(FileRegion, "PixelModule");
        if (propertyIndex2 != -1)
        {
          string[] values3 = Shared.ConvertFileFieldToValues(FileRegion[propertyIndex2]);
          bool result3;
          PixelModule.PixelTypes result4;
          bool result5;
          schemaBlock.PixelSettings = new PixelModule()
          {
            IsEnabled = bool.TryParse(values3[1], out result3) && result3,
            PixelType = PixelModule.TryParse(values3[2], out result4) ? result4 : PixelModule.PixelTypes.RGB,
            IsPwrOnEnabled = bool.TryParse(values3[3], out result5) && result5
          };
        }
        int propertyIndex3 = OldFormatProject.FindPropertyIndex(FileRegion, "CECModule");
        if (propertyIndex3 != -1)
        {
          string[] values4 = Shared.ConvertFileFieldToValues(FileRegion[propertyIndex3]);
          bool result6;
          int result7;
          schemaBlock.CECSettings = new CEC()
          {
            IsEnabled = bool.TryParse(values4[1], out result6) && result6,
            PortNumber = int.TryParse(values4[2], out result7) ? result7 : 1,
            Name = values4[3],
            VolumeGpio = int.TryParse(values4[4], out result7) ? result7 : 0,
            MuteGpio = int.TryParse(values4[5], out result7) ? result7 : 0,
            IsTVonEnabled = bool.TryParse(values4[6], out result6) && result6,
            IsTVoffEnabled = bool.TryParse(values4[7], out result6) && result6,
            IsAudioStatusEnabled = bool.TryParse(values4[10], out result6) && result6
          };
        }
        int propertyIndex4 = OldFormatProject.FindPropertyIndex(FileRegion, "Options");
        if (propertyIndex4 != -1)
        {
          string[] values5 = Shared.ConvertFileFieldToValues(FileRegion[propertyIndex4]);
          bool result;
          schemaBlock.Options = new ControllerOptions()
          {
            IsGenSelectionEnabled = bool.TryParse(values5[1], out result) && result,
            IsFreqIndicationEnabled = bool.TryParse(values5[2], out result) && result,
            IsResIndicationEnabled = bool.TryParse(values5[3], out result) && result,
            IsPwrKeyEnabled = bool.TryParse(values5[4], out result) && result,
            IsFixProjectEnabled = false
          };
          if (6 < values5.Length)
            schemaBlock.Options.IsFixProjectEnabled = bool.TryParse(values5[6], out result) && result;
        }
        return (ISchemaElement) schemaBlock;
      default:
        return (ISchemaElement) null;
    }
  }

  private static Connection ConvertFileRegionToSchemaConnection(List<string> FileRegion)
  {
    Connection schemaConnection = new Connection();
    for (int index = 0; index < 2; ++index)
    {
      string[] values = Shared.ConvertFileFieldToValues(FileRegion[1 + index]);
      int result;
      if (!int.TryParse(values[1], out result))
        return (Connection) null;
      Anchor.AnchorTypes anchorTypes = OldFormatProject.ChangeAnchorType(values[2]);
      double Result1;
      if (!OldFormatProject.TryParseFracValue(values[3], out Result1))
        return (Connection) null;
      double Result2;
      if (!OldFormatProject.TryParseFracValue(values[4], out Result2))
        return (Connection) null;
      string blockname = values[0];
      int anchornumber = result;
      LinePoint anchorpoint = new LinePoint();
      anchorpoint.X = Result1;
      anchorpoint.Y = Result2;
      int anchortype = (int) anchorTypes;
      ConnectionNode NewNode = new ConnectionNode(blockname, anchornumber, anchorpoint, (Anchor.AnchorTypes) anchortype);
      schemaConnection.AddNode(NewNode);
    }
    return schemaConnection;
  }

  private static void UpdateConnections(List<Connection> Connections)
  {
    List<Connection> collection1 = new List<Connection>();
    string OldBlockName;
    int OldNodeNumber;
    Anchor.AnchorTypes OldAnchorType;
    foreach (Connection connection1 in Connections)
    {
      if (OldFormatProject.IsConnectedToOldBlock(connection1, out OldBlockName, out OldNodeNumber, out OldAnchorType))
      {
        Connection connection2 = new Connection();
        connection2.AddNode(OldFormatProject.CloneNode(connection1.Nodes[OldNodeNumber == 0 ? 1 : 0]));
        ConnectionNode correspondingNode = OldFormatProject.FindCorrespondingNode(Connections, OldBlockName, connection2.Nodes[0].AnchorType);
        if (correspondingNode != null)
        {
          connection2.AddNode(OldFormatProject.CloneNode(correspondingNode));
          collection1.Add(connection2);
        }
      }
    }
    List<Connection> collection2 = new List<Connection>();
    if (collection1.Count != 0)
    {
      collection2.Add(collection1[0]);
      for (int index = 1; index < collection1.Count; ++index)
      {
        bool flag = true;
        foreach (Connection connection in collection2)
        {
          if (OldFormatProject.AreNodesTheSame(collection1[index].Nodes[0], connection.Nodes[0]) && OldFormatProject.AreNodesTheSame(collection1[index].Nodes[1], connection.Nodes[1]) || OldFormatProject.AreNodesTheSame(collection1[index].Nodes[0], connection.Nodes[1]) && OldFormatProject.AreNodesTheSame(collection1[index].Nodes[1], connection.Nodes[0]))
          {
            flag = false;
            break;
          }
        }
        if (flag)
          collection2.Add(collection1[index]);
      }
      collection1.Clear();
      collection1.AddRange((IEnumerable<Connection>) collection2);
    }
    List<Connection> list = Connections.Where<Connection>((Func<Connection, bool>) (l => !OldFormatProject.IsConnectedToOldBlock(l, out OldBlockName, out OldNodeNumber, out OldAnchorType))).ToList<Connection>();
    Connections.Clear();
    Connections.AddRange((IEnumerable<Connection>) list);
    Connections.AddRange((IEnumerable<Connection>) collection1);
  }

  private static bool IsConnectedToOldBlock(
    Connection line,
    out string BlockName,
    out int NodeNumber,
    out Anchor.AnchorTypes AnchorType)
  {
    BlockName = "";
    NodeNumber = -1;
    AnchorType = Anchor.AnchorTypes.EMPTY;
    for (int index = 0; index < line.Nodes.Count; ++index)
    {
      if (((IEnumerable<string>) OldFormatProject.OldControlBlocks).Contains<string>(line.Nodes[index].BlockName.Split('_')[0]))
      {
        BlockName = line.Nodes[index].BlockName;
        NodeNumber = index;
        AnchorType = line.Nodes[index].AnchorType;
        return true;
      }
    }
    return false;
  }

  private static ConnectionNode FindCorrespondingNode(
    List<Connection> Connections,
    string BlockName,
    Anchor.AnchorTypes AnchorType)
  {
    foreach (Connection connection in Connections)
    {
      for (int index1 = 0; index1 < connection.Nodes.Count; ++index1)
      {
        if (connection.Nodes[index1].BlockName == BlockName)
        {
          int index2 = index1 == 0 ? 1 : 0;
          if (connection.Nodes[index2].AnchorType != AnchorType)
            return connection.Nodes[index2];
        }
      }
    }
    return (ConnectionNode) null;
  }

  private static bool AreNodesTheSame(ConnectionNode Node1, ConnectionNode Node2)
  {
    return !(Node1.BlockName != Node2.BlockName) && Node1.AnchorNumber == Node2.AnchorNumber;
  }

  private static ConnectionNode CloneNode(ConnectionNode Node)
  {
    string blockName = Node.BlockName;
    int anchorNumber = Node.AnchorNumber;
    LinePoint anchorpoint = new LinePoint();
    anchorpoint.X = Node.AnchorPoint.X;
    anchorpoint.Y = Node.AnchorPoint.Y;
    int anchorType = (int) Node.AnchorType;
    return new ConnectionNode(blockName, anchorNumber, anchorpoint, (Anchor.AnchorTypes) anchorType);
  }

  private static int[] GetControllerGpioFuncs(List<string> FileRegion)
  {
    List<int> intList = new List<int>();
    for (int index = 2; FileRegion[index].IndexOf("#End ") == -1; ++index)
    {
      string[] values = Shared.ConvertFileFieldToValues(FileRegion[index]);
      int result;
      intList.Add(int.TryParse(values[0], out result) ? result : 0);
    }
    return intList.ToArray();
  }

  private static bool ConvertFileRegionToDSP(List<string> FileRegion, SchemaBlock_DSP Block)
  {
    List<DataTransfer> dataTransferList = new List<DataTransfer>();
    List<DSPCell> dspCellList = new List<DSPCell>();
    for (int index = 2; FileRegion[index].IndexOf("#End ") == -1; ++index)
    {
      string[] values = Shared.ConvertFileFieldToValues(FileRegion[index]);
      switch (values[0])
      {
        case "Transfer":
          DataTransfer trasferFromString = OldFormatProject.GetDSPTrasferFromString(values);
          if (trasferFromString == null)
            return false;
          dataTransferList.Add(trasferFromString);
          break;
        case "Cell":
          DSPCell dspCellFromString = OldFormatProject.GetDSPCellFromString(values);
          if (dspCellFromString == null)
            return false;
          dspCellList.Add(dspCellFromString);
          break;
        case "Parameter":
          DSPCellParameter cellParamFromString1 = OldFormatProject.GetDSPCellParamFromString(values);
          if (cellParamFromString1 == null || dspCellList.Count == 0)
            return false;
          dspCellList[dspCellList.Count - 1].ParamsUsed.Add(cellParamFromString1);
          break;
        case "XMLParameter":
          DSPCellParameter cellParamFromString2 = OldFormatProject.GetDSPCellParamFromString(values);
          if (cellParamFromString2 == null || dspCellList.Count == 0)
            return false;
          dspCellList[dspCellList.Count - 1].ParamsFromFile.Add(cellParamFromString2);
          break;
        case "BusAddress":
          byte result1;
          Block.SetBusAddress(byte.TryParse(values[1], out result1) ? result1 : (byte) 0);
          break;
        case "SelfBoot":
          bool result2;
          Block.IsSelfBooted = bool.TryParse(values[1], out result2) && result2;
          break;
        default:
          return false;
      }
    }
    Block.SetBoot(dataTransferList.ToArray());
    Block.SetCells(dspCellList.ToArray());
    return true;
  }

  private static bool ConvertFileRegionToDSPCell(List<string> FileRegion, SchemaBlock_DSPCell Block)
  {
    if (FileRegion[2].IndexOf("#End ") == -1)
    {
      for (int index1 = 2; FileRegion[index1].IndexOf("#End ") == -1; ++index1)
      {
        string[] values = Shared.ConvertFileFieldToValues(FileRegion[index1]);
        if (values[0] == "RegData" || values[0] == "EnData")
        {
          List<byte> byteList = new List<byte>();
          for (int index2 = 1; index2 < values.Length; ++index2)
          {
            byte result;
            if (!byte.TryParse(values[index2], out result))
              return false;
            byteList.Add(result);
          }
          if (values[0] == "RegData")
            Block.SetData(byteList.ToArray());
          else if (values[0] == "EnData")
            Block.SetEnData(byteList.ToArray());
        }
      }
    }
    return true;
  }

  private static bool ConvertFileRegionToLED(List<string> FileRegion, SchemaBlock_LED Block)
  {
    string[] values = Shared.ConvertFileFieldToValues(FileRegion[2]);
    List<byte> byteList = new List<byte>();
    for (int index = 1; index < values.Length; ++index)
    {
      byte result;
      if (!byte.TryParse(values[index], out result))
        return false;
      byteList.Add(result);
    }
    int result1;
    if (!int.TryParse(values[0], out result1))
      return false;
    Block.SetDefaultBlockIndex(result1);
    Block.SetData(byteList.ToArray());
    return true;
  }

  private static bool ConvertFileRegionToPixelLED(
    List<string> FileRegion,
    SchemaBlock_PixelLED Block)
  {
    for (int index = 2; FileRegion[index].IndexOf("#End ") == -1; ++index)
    {
      string[] values = Shared.ConvertFileFieldToValues(FileRegion[index]);
      switch (values[0])
      {
        case "Settings":
          PixelLEDBlock ledBlockFromString = OldFormatProject.GetPixelLEDBlockFromString(values);
          if (ledBlockFromString == null)
            return false;
          Block.Settings = ledBlockFromString;
          int result;
          if (!int.TryParse(values[5], out result))
            return false;
          Block.SetDefaultBlockIndex(result);
          break;
        case "Colors":
          string[] strArray = new string[values.Length - 1];
          Array.Copy((Array) values, 1, (Array) strArray, 0, strArray.Length);
          Block.SetColors(strArray);
          break;
        default:
          return false;
      }
    }
    return true;
  }

  private static DataTransfer GetDSPTrasferFromString(params string[] Input)
  {
    ushort result1;
    if (!ushort.TryParse(Input[2], out result1))
      return (DataTransfer) null;
    byte result2;
    if (!byte.TryParse(Input[3], out result2))
      return (DataTransfer) null;
    int result3;
    if (!int.TryParse(Input[4], out result3))
      return (DataTransfer) null;
    DataTransfer.TransferTypes result4;
    if (!DataTransfer.TryParseType(Input[1], out result4))
      return (DataTransfer) null;
    DataTransfer trasferFromString = new DataTransfer(result1, result3, result2, result4);
    if (result4 == DataTransfer.TransferTypes.Write || result4 == DataTransfer.TransferTypes.Poll)
    {
      for (int index = 0; index < result3; ++index)
      {
        byte result5;
        if (!byte.TryParse(Input[5 + index], out result5))
          return (DataTransfer) null;
        trasferFromString.Data[index] = result5;
      }
    }
    return trasferFromString;
  }

  private static DSPCell GetDSPCellFromString(params string[] Input)
  {
    DSPCell dspCellFromString = new DSPCell(Input[1]);
    dspCellFromString.DSPTitle = Input[2];
    bool result;
    if (!bool.TryParse(Input[4], out result))
      return (DSPCell) null;
    dspCellFromString.IsControllable = result;
    if (!bool.TryParse(Input[5], out result))
      return (DSPCell) null;
    dspCellFromString.IsBypassable = result;
    return dspCellFromString;
  }

  private static DSPCellParameter GetDSPCellParamFromString(params string[] Input)
  {
    DSPCellParameter cellParamFromString = new DSPCellParameter();
    cellParamFromString.Name = Input[1];
    ushort result1;
    if (!ushort.TryParse(Input[2], out result1))
      return (DSPCellParameter) null;
    cellParamFromString.Address = result1;
    ushort result2;
    if (!ushort.TryParse(Input[3], out result2))
      return (DSPCellParameter) null;
    cellParamFromString.Size = result2;
    cellParamFromString.Data = new byte[(int) result2];
    for (int index = 0; index < (int) result2; ++index)
    {
      byte result3;
      if (!byte.TryParse(Input[4 + index], out result3))
        return (DSPCellParameter) null;
      cellParamFromString.Data[index] = result3;
    }
    return cellParamFromString;
  }

  private static PixelLEDBlock GetPixelLEDBlockFromString(params string[] Input)
  {
    PixelLEDBlock ledBlockFromString = new PixelLEDBlock();
    int result1;
    if (!int.TryParse(Input[1], out result1))
      return (PixelLEDBlock) null;
    ledBlockFromString.LEDsCount = result1;
    if (!int.TryParse(Input[2], out result1))
      return (PixelLEDBlock) null;
    ledBlockFromString.StatesCount = result1;
    PixelLEDBlock.IndicationTypes result2;
    if (!PixelLEDBlock.TryParseIndicationType(Input[3], out result2))
      return (PixelLEDBlock) null;
    ledBlockFromString.IndicationType = result2;
    PixelLEDBlock.IndicationModes result3;
    if (!PixelLEDBlock.TryParseIndicationMode(Input[4], out result3))
      return (PixelLEDBlock) null;
    ledBlockFromString.IndicationMode = result3;
    return ledBlockFromString;
  }

  private static Anchor.AnchorTypes ChangeAnchorType(string OldAnchor)
  {
    switch (OldAnchor)
    {
      case "FromADCToPOT":
      case "FromControllerToEncoderA":
      case "FromControllerToEncoderB":
      case "FromControllerToKey":
      case "FromControllerToPMButtonM":
      case "FromControllerToPMButtonP":
      case "FromControllerToSwitch":
      case "FromPOTKeySwitchToDSPCell":
        return Anchor.AnchorTypes.ToDSPCell;
      case "FromControllerToLED":
        return Anchor.AnchorTypes.ToLED;
      case "FromDSPCellToPOTKeySwitch":
      case "FromEncoderAToController":
      case "FromEncoderBToController":
      case "FromKeyToController":
      case "FromPMButtonMToController":
      case "FromPMButtonPToController":
      case "FromPOTToADC":
      case "FromSwitchToController":
        return Anchor.AnchorTypes.FromDSPCell;
      case "FromLEDToController":
        return Anchor.AnchorTypes.FromLED;
      case "FromMasterToSlave_CS":
        return Anchor.AnchorTypes.ToSlave_CS;
      case "FromMasterToSlave_I2C":
        return Anchor.AnchorTypes.ToSlave_I2C;
      case "FromMasterToSlave_SPI":
        return Anchor.AnchorTypes.ToSlave_SPI;
      case "FromPixel":
        return Anchor.AnchorTypes.FromPixel;
      case "FromSlaveToMaster_CS":
        return Anchor.AnchorTypes.FromSlave_CS;
      case "FromSlaveToMaster_I2C":
        return Anchor.AnchorTypes.FromSlave_I2C;
      case "FromSlaveToMaster_SPI":
        return Anchor.AnchorTypes.FromSlave_SPI;
      case "ToPixel":
        return Anchor.AnchorTypes.ToPixel;
      default:
        return Anchor.AnchorTypes.EMPTY;
    }
  }

  private static bool TryParseFracValue(string Input, out double Result)
  {
    return double.TryParse(Input, NumberStyles.Float, (IFormatProvider) CultureInfo.GetCultureInfo("ru-RU"), out Result) || double.TryParse(Input, NumberStyles.Float, (IFormatProvider) CultureInfo.InvariantCulture, out Result);
  }

  private static int FindPropertyIndex(List<string> PropertyList, string PropertyName)
  {
    int propertyIndex = -1;
    for (int index = 0; index < PropertyList.Count; ++index)
    {
      if (PropertyList[index].IndexOf(PropertyName) != -1)
      {
        propertyIndex = index;
        break;
      }
    }
    return propertyIndex;
  }
}
