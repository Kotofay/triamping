﻿// Decompiled with JetBrains decompiler
// Type: ChipStudio.SchemaBlock_Comparator
// Assembly: ChipStudio, Version=1.2.9.0, Culture=neutral, PublicKeyToken=null
// MVID: 334E3BEA-37C7-4274-8118-535AAEFA1546
// Assembly location: D:\DocAndSec\Desktop\AUDIO\ChipDip\ChipStudio_soft_v1.2.9\ChipStudio_v1.2.9.exe

using System;
using System.CodeDom.Compiler;
using System.Collections;
using System.ComponentModel;
using System.Diagnostics;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Markup;

#nullable disable
namespace ChipStudio;

public partial class SchemaBlock_Comparator : SchemaBlock, IComponentConnector
{
  private static readonly Anchor.AnchorTypes[] PointAnchors = new Anchor.AnchorTypes[1]
  {
    Anchor.AnchorTypes.ToRead
  };
  private static readonly string[] ComparisonOperations = new string[3]
  {
    "<",
    "=",
    ">"
  };
  private const int DEFAULT_COMPARE_OPERATION = 1;
  internal ItemsControl ConnectPoints;
  internal ValueInput Mask;
  internal ComboBox ModeSelector;
  internal ValueInput Value;
  private bool _contentLoaded;

  public override SchemaBlock.SchemaBlockTypes BlockType => SchemaBlock.SchemaBlockTypes.Comparator;

  public int Mode
  {
    get => this.ModeSelector.SelectedIndex;
    set => this.ModeSelector.SelectedIndex = value;
  }

  public SchemaBlock_Comparator()
  {
    this.InitializeComponent();
    this.DataContext = (object) this;
    this.Mask.SetFormat("HEX");
    this.Value.SetFormat("HEX");
    this.ModeSelector.ItemsSource = (IEnumerable) SchemaBlock_Comparator.ComparisonOperations;
    this.Mode = 1;
    this.InitConnectionPoints(SchemaBlock_Comparator.PointAnchors);
    this.ConnectPoints.ItemsSource = (IEnumerable) this.ConnectionPoints;
  }

  public string GetMaskInput() => this.Mask.GetInput();

  public string GetValueInput() => this.Value.GetInput();

  public ulong GetMaskValue() => this.Mask.GetValue();

  public ulong GetValueValue() => this.Value.GetValue();

  public void SetMask(string MaskInput) => this.Mask.SetInput(MaskInput);

  public void SetValue(string ValueInput) => this.Value.SetInput(ValueInput);

  [DebuggerNonUserCode]
  [GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
  public void InitializeComponent()
  {
    if (this._contentLoaded)
      return;
    this._contentLoaded = true;
    Application.LoadComponent((object) this, new Uri("/ChipStudio;component/schemablock_comparator.xaml", UriKind.Relative));
  }

  [DebuggerNonUserCode]
  [GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
  internal Delegate _CreateDelegate(Type delegateType, string handler)
  {
    return Delegate.CreateDelegate(delegateType, (object) this, handler);
  }

  [DebuggerNonUserCode]
  [GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
  [EditorBrowsable(EditorBrowsableState.Never)]
  void IComponentConnector.Connect(int connectionId, object target)
  {
    switch (connectionId)
    {
      case 1:
        ((UIElement) target).MouseLeftButtonDown += new MouseButtonEventHandler(((SchemaBlock) this).Border_MouseLeftButtonDown);
        break;
      case 2:
        this.ConnectPoints = (ItemsControl) target;
        break;
      case 3:
        this.Mask = (ValueInput) target;
        break;
      case 4:
        this.ModeSelector = (ComboBox) target;
        break;
      case 5:
        this.Value = (ValueInput) target;
        break;
      default:
        this._contentLoaded = true;
        break;
    }
  }
}
