﻿// Decompiled with JetBrains decompiler
// Type: ChipStudio.SigmaStudio
// Assembly: ChipStudio, Version=1.2.9.0, Culture=neutral, PublicKeyToken=null
// MVID: 334E3BEA-37C7-4274-8118-535AAEFA1546
// Assembly location: D:\DocAndSec\Desktop\AUDIO\ChipDip\ChipStudio_soft_v1.2.9\ChipStudio_v1.2.9.exe

using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Windows;
using System.Xml.Linq;

#nullable disable
namespace ChipStudio;

public class SigmaStudio
{
  private const string FileMustNotContain = "File name must not contain ";
  private const string WrongFile = "Wrong File";
  private const string WRONG_XML_FILE = "NetList";
  private const string WRONG_DAT_FILE = "NumBytes";
  private const string FREQUENCY_WORD = "Frequency";
  private const string SchematicString = "Schematic";
  private const string ICString = "IC";
  private const string PartNumber = "PartNumber";
  private const string RegisterString = "Register";
  private const string ProgramString = "Program";
  private const string ClearString = "Clear";
  private const string ModuleString = "Module";
  private const string CellNameString = "CellName";
  private const string AlgorithmString = "Algorithm";
  private const string ModuleParameterString = "ModuleParameter";
  private const string NameString = "Name";
  private const string SizeString = "Size";
  private const string DataString = "Data";
  private const string DescriptionString = "Description";
  private const string SigmaStudioDataSeparator = ",";
  private const string DATFileExt = ".dat";
  private const string SigmaStudioDescSeparator = ":";
  private const string MultiChannelString = "Multi-Channel";
  private const int AddressStringIndex = 1;
  private const int DataStringIndex = 0;
  private const int DataStringLength = 2;
  private const int ParamDataSize = 1;
  private const int ParamAddrInc = 0;
  private const ushort ADAU1761_CLK_CTRL_REG_ADR = 16384 /*0x4000*/;
  private const byte ADAU1761_CLKSRC_PLL = 8;
  private const ushort ADAU1761_PLL_CTRL_REG_ADR = 16386;
  private const byte ADAU1761_PLL_LOCKED = 2;
  private static readonly byte[] ADAU1761_PLL_CTRL_REG_POLL_DATA = new byte[6]
  {
    (byte) 0,
    (byte) 0,
    (byte) 0,
    (byte) 0,
    (byte) 0,
    (byte) 2
  };
  private static readonly string[] UnCtrlCellDescription = new string[2]
  {
    "Blocking",
    "Mixer"
  };
  private static readonly string[] AnalogCellDescription = new string[1]
  {
    "Gain"
  };

  public static bool TryParseXML(
    string XMLFile,
    out List<string> Parts,
    out List<DataTransfer[]> Boot,
    out List<DSPCell[]> Cells)
  {
    Boot = new List<DataTransfer[]>();
    Cells = new List<DSPCell[]>();
    Parts = new List<string>();
    if (!SigmaStudio.CheckXmlFileName(XMLFile))
      return false;
    string[] PartNumbers;
    XDocument[] ICsXDoc;
    SigmaStudio.GetPartNumbersAndICsXDoc(XMLFile, out PartNumbers, out ICsXDoc);
    if (PartNumbers == null || PartNumbers.Length == 0)
      return false;
    for (int index = 0; index < PartNumbers.Length; ++index)
    {
      if (PartNumbers[index] != null)
      {
        List<DataTransfer> BootSequence;
        if (!SigmaStudio.TryParseXMLBoot(ICsXDoc[index], out BootSequence))
          return false;
        switch (PartNumbers[index])
        {
          case "ADAU1761":
            SigmaStudio.ADAU1761_AddPllPoll(BootSequence);
            break;
          case "SSM3582":
            Shared.ConcatByAddress(BootSequence);
            break;
        }
        List<DSPCell> Cells1;
        if (!SigmaStudio.TryParseXMLCells(ICsXDoc[index], out Cells1))
          return false;
        Parts.Add(PartNumbers[index]);
        Boot.Add(BootSequence.ToArray());
        Cells.Add(Cells1.ToArray());
      }
    }
    return true;
  }

  public static bool TryParseCodecBoot(
    string ProjectFile,
    string Codec,
    out List<DataTransfer> BootSequence)
  {
    BootSequence = (List<DataTransfer>) null;
    if (SigmaStudio.IsDATFile(ProjectFile))
      return SigmaStudio.TryParseDatBoot(ProjectFile, out BootSequence);
    if (!SigmaStudio.CheckXmlFileName(ProjectFile))
      return false;
    XDocument xdocByPartNumber = SigmaStudio.GetXDocByPartNumber(ProjectFile, Codec);
    return xdocByPartNumber != null && SigmaStudio.TryParseXMLBoot(xdocByPartNumber, out BootSequence);
  }

  public static bool TryParseXMLBoot(XDocument XDoc, out List<DataTransfer> BootSequence)
  {
    BootSequence = new List<DataTransfer>();
    XElement xelement1 = XDoc.Element((XName) "Schematic");
    \u003C\u003Ef__AnonymousType3<DataTransfer.TransferTypes, ushort, byte, int, string[]>[] dataArray1;
    if (xelement1 == null)
    {
      dataArray1 = null;
    }
    else
    {
      XElement xelement2 = xelement1.Element((XName) "IC");
      if (xelement2 == null)
      {
        dataArray1 = null;
      }
      else
      {
        IEnumerable<XElement> source1 = xelement2.Elements();
        if (source1 == null)
        {
          dataArray1 = null;
        }
        else
        {
          IEnumerable<XElement> source2 = source1.Where<XElement>((Func<XElement, bool>) (e => e.Name == (XName) "Register" || e.Name == (XName) "Program"));
          dataArray1 = source2 != null ? source2.Select(t =>
          {
            XElement xelement3 = t.Element((XName) "Name");
            int num1 = (xelement3 != null ? (xelement3.Value.IndexOf("Clear") == -1 ? 1 : 0) : 0) != 0 ? 0 : 2;
            ushort result1;
            int num2 = ushort.TryParse(t.Element((XName) "Address")?.Value, out result1) ? (int) result1 : 0;
            byte result2;
            int num3 = byte.TryParse(t.Element((XName) "AddrIncr")?.Value, out result2) ? (int) result2 : 0;
            int result3;
            int num4 = int.TryParse(t.Element((XName) "Size")?.Value, out result3) ? result3 : 0;
            XElement xelement4 = t.Element((XName) "Data");
            string[] strArray;
            if (xelement4 == null)
            {
              strArray = (string[]) null;
            }
            else
            {
              string str = xelement4.Value;
              if (str == null)
                strArray = (string[]) null;
              else
                strArray = str.Replace(" ", "").Replace("0x", "").Split(","[0]);
            }
            return new
            {
              Type = (DataTransfer.TransferTypes) num1,
              Address = (ushort) num2,
              AddrIncr = (byte) num3,
              Size = num4,
              Data = strArray
            };
          }).ToArray() : null;
        }
      }
    }
    \u003C\u003Ef__AnonymousType3<DataTransfer.TransferTypes, ushort, byte, int, string[]>[] dataArray2 = dataArray1;
    if (dataArray2 == null)
    {
      int num = (int) MessageBox.Show("File does not contain DSP configuration", "", MessageBoxButton.OK, MessageBoxImage.Hand);
      return false;
    }
    foreach (var data in dataArray2)
    {
      DataTransfer dataTransfer = new DataTransfer(data.Address, data.Size, data.AddrIncr, data.Type);
      if (data.Type != DataTransfer.TransferTypes.Clear)
      {
        string[] array = ((IEnumerable<string>) data.Data).Take<string>(data.Size).ToArray<string>();
        uint result;
        dataTransfer.Data = ((IEnumerable<string>) array).Select<string, byte>((Func<string, byte>) (x => !Shared.TryParseHEX(x, out result) ? (byte) 0 : (byte) result)).ToArray<byte>();
      }
      BootSequence.Add(dataTransfer);
    }
    if (BootSequence.Count != 0)
      return true;
    int num5 = (int) MessageBox.Show("File does not contain DSP configuration", "", MessageBoxButton.OK, MessageBoxImage.Hand);
    return false;
  }

  public static bool TryParseXMLCells(XDocument XDoc, out List<DSPCell> Cells)
  {
    Cells = new List<DSPCell>();
    XElement xelement1 = XDoc.Element((XName) "Schematic");
    \u003C\u003Ef__AnonymousType6<string, string, \u003C\u003Ef__AnonymousType5<string, ushort, ushort, string[]>[]>[] dataArray1;
    if (xelement1 == null)
    {
      dataArray1 = null;
    }
    else
    {
      XElement xelement2 = xelement1.Element((XName) "IC");
      if (xelement2 == null)
      {
        dataArray1 = null;
      }
      else
      {
        IEnumerable<XElement> source1 = xelement2.Elements();
        if (source1 == null)
        {
          dataArray1 = null;
        }
        else
        {
          IEnumerable<XElement> source2 = source1.Where<XElement>((Func<XElement, bool>) (e => e.Name == (XName) "Module"));
          dataArray1 = source2 != null ? source2.Select(m =>
          {
            string str3 = m.Element((XName) "CellName")?.Value;
            string str4 = m.Element((XName) "Algorithm")?.Element((XName) "Description")?.Value?.Replace(" ", "");
            IEnumerable<XElement> source3 = m.Elements((XName) "Algorithm");
            \u003C\u003Ef__AnonymousType5<string, ushort, ushort, string[]>[] dataArray2;
            if (source3 == null)
            {
              dataArray2 = null;
            }
            else
            {
              IEnumerable<XElement> source4 = source3.Elements<XElement>((XName) "ModuleParameter");
              dataArray2 = source4 != null ? source4.Select(p =>
              {
                string str5 = p.Element((XName) "Name")?.Value;
                ushort result3;
                int num3 = ushort.TryParse(p.Element((XName) "Address")?.Value, out result3) ? (int) result3 : 0;
                ushort result4;
                int num4 = ushort.TryParse(p.Element((XName) "Size")?.Value, out result4) ? (int) result4 : 0;
                XElement xelement4 = p.Element((XName) "Data");
                string[] strArray;
                if (xelement4 == null)
                {
                  strArray = (string[]) null;
                }
                else
                {
                  string str6 = xelement4.Value;
                  if (str6 == null)
                    strArray = (string[]) null;
                  else
                    strArray = str6.Replace(" ", "").Replace("0x", "").Split(","[0]);
                }
                return new
                {
                  Name = str5,
                  Address = (ushort) num3,
                  Size = (ushort) num4,
                  Data = strArray
                };
              }).ToArray() : null;
            }
            return new
            {
              Title = str3,
              Description = str4,
              Parameters = dataArray2
            };
          }).ToArray() : null;
        }
      }
    }
    foreach (var data in dataArray1)
    {
      var cell = data;
      DSPCell dspCell = new DSPCell(cell.Title)
      {
        IsControllable = Array.FindIndex<string>(SigmaStudio.UnCtrlCellDescription, (Predicate<string>) (s => cell.Description.IndexOf(s) != -1)) == -1
      };
      if (dspCell.IsControllable)
      {
        foreach (var parameter in cell.Parameters)
        {
          DSPCellParameter dspCellParameter = new DSPCellParameter()
          {
            Name = parameter.Name,
            Address = parameter.Address,
            Size = parameter.Size,
            Data = new byte[(int) parameter.Size]
          };
          string[] array = ((IEnumerable<string>) parameter.Data).Take<string>((int) parameter.Size).ToArray<string>();
          uint result;
          dspCellParameter.Data = ((IEnumerable<string>) array).Select<string, byte>((Func<string, byte>) (x => !Shared.TryParseHEX(x, out result) ? (byte) 0 : (byte) result)).ToArray<byte>();
          dspCell.ParamsFromFile.Add(dspCellParameter);
        }
        dspCell.IsBypassable = cell.Description.IndexOf("Frequency") != -1;
        int CellParts;
        if (SigmaStudio.IsCompositeCell(cell.Description, out CellParts))
        {
          Cells.AddRange((IEnumerable<DSPCell>) SigmaStudio.SplitCompositeCell(cell.Description, cell.Title, dspCell.ParamsFromFile, CellParts));
        }
        else
        {
          if (Array.FindIndex<string>(SigmaStudio.AnalogCellDescription, (Predicate<string>) (s => cell.Description.IndexOf(s) != -1)) != -1)
            dspCell.IsBypassable = true;
          Cells.Add(dspCell);
        }
      }
    }
    return true;
  }

  public static bool TryParseDatBoot(string ProjectFile, out List<DataTransfer> BootSequence)
  {
    BootSequence = new List<DataTransfer>();
    if (ProjectFile.IndexOf("NumBytes") != -1)
    {
      int num = (int) MessageBox.Show("Choose TxBuffer_xx.dat file", "Wrong File", MessageBoxButton.OK, MessageBoxImage.Exclamation);
      return false;
    }
    string[][] array1 = ((IEnumerable<string>) File.ReadAllLines(ProjectFile)).Select<string, string[]>((Func<string, string[]>) (s => s.Split(","[0]))).ToArray<string[]>();
    uint result1;
    ushort[] array2 = ((IEnumerable<string[]>) array1).Where<string[]>((Func<string[], bool>) (i => i.Length > 2)).Select<string[], ushort>((Func<string[], ushort>) (x => !Shared.TryParseHEX(x[1].Replace(" ", "").Replace("0x", ""), out result1) ? (ushort) 0 : (ushort) result1)).ToArray<ushort>();
    uint result2;
    byte[] array3 = ((IEnumerable<string[]>) array1).Where<string[]>((Func<string[], bool>) (i => i.Length == 2)).Select<string[], byte>((Func<string[], byte>) (x => !Shared.TryParseHEX(x[0].Replace(" ", "").Replace("0x", ""), out result2) ? (byte) 0 : (byte) result2)).ToArray<byte>();
    if (array2.Length != array3.Length)
    {
      int num = (int) MessageBox.Show("Addresses count is not equal to values count", "", MessageBoxButton.OK, MessageBoxImage.Hand);
      return false;
    }
    for (int index = 0; index < array2.Length; ++index)
    {
      DataTransfer dataTransfer = new DataTransfer(array2[index], 1, (byte) 0, DataTransfer.TransferTypes.Write);
      dataTransfer.Data[0] = array3[index];
      BootSequence.Add(dataTransfer);
    }
    return true;
  }

  public static void ADAU1761_AddPllPoll(List<DataTransfer> Boot)
  {
    int index1 = Boot.FindIndex((Predicate<DataTransfer>) (e => e.Address == (ushort) 16384 /*0x4000*/));
    if (index1 == -1 || ((int) Boot[index1].Data[0] & 8) != 8)
      return;
    List<DataTransfer> collection = new List<DataTransfer>();
    int index2 = Boot.FindIndex((Predicate<DataTransfer>) (e => e.Address == (ushort) 16386));
    collection.Add(Boot[index2]);
    Boot.RemoveAt(index2);
    DataTransfer dataTransfer = new DataTransfer((ushort) 16386, (int) (ushort) SigmaStudio.ADAU1761_PLL_CTRL_REG_POLL_DATA.Length, (byte) 0, DataTransfer.TransferTypes.Poll);
    SigmaStudio.ADAU1761_PLL_CTRL_REG_POLL_DATA.CopyTo((Array) dataTransfer.Data, 0);
    collection.Add(dataTransfer);
    collection.Add(Boot[index1]);
    Boot.RemoveAt(index1);
    Boot.InsertRange(0, (IEnumerable<DataTransfer>) collection);
  }

  public static XDocument GetXDocByPartNumber(string ProjectFile, string PartNumber)
  {
    string[] PartNumbers;
    XDocument[] ICsXDoc;
    SigmaStudio.GetPartNumbersAndICsXDoc(ProjectFile, out PartNumbers, out ICsXDoc);
    if (PartNumbers == null || PartNumbers.Length == 0)
      return (XDocument) null;
    if (PartNumber == "AD1933" || PartNumber == "AD1934")
      PartNumber = "AD1938";
    for (int index = 0; index < PartNumbers.Length; ++index)
    {
      if (PartNumbers[index] == PartNumber)
        return ICsXDoc[index];
    }
    int num = (int) MessageBox.Show($"There is no configuration for {PartNumber} in file\n\r{ProjectFile}", "", MessageBoxButton.OK, MessageBoxImage.Hand);
    return (XDocument) null;
  }

  public static bool CheckXmlFileName(string FileName)
  {
    if (FileName.IndexOf("NetList") == -1)
      return true;
    int num = (int) MessageBox.Show("File name must not contain NetList", "Wrong File", MessageBoxButton.OK, MessageBoxImage.Exclamation);
    return false;
  }

  public static bool IsDATFile(string FileName) => FileName.EndsWith(".dat");

  private static void GetPartNumbersAndICsXDoc(
    string XMLFile,
    out string[] PartNumbers,
    out XDocument[] ICsXDoc)
  {
    XDocument xdocument = XDocument.Load(XMLFile);
    ref string[] local1 = ref PartNumbers;
    XElement xelement1 = xdocument.Element((XName) "Schematic");
    string[] strArray;
    if (xelement1 == null)
    {
      strArray = (string[]) null;
    }
    else
    {
      IEnumerable<XElement> source = xelement1.Elements((XName) "IC");
      strArray = source != null ? source.Select<XElement, string>((Func<XElement, string>) (p => p.Element((XName) "PartNumber")?.Value)).ToArray<string>() : (string[]) null;
    }
    local1 = strArray;
    if (PartNumbers != null)
    {
      SigmaStudio.CorrectPartNumbers(PartNumbers);
    }
    else
    {
      int num = (int) MessageBox.Show("There are no IC descriptions in chosen file", "Wrong File", MessageBoxButton.OK, MessageBoxImage.Hand);
    }
    ref XDocument[] local2 = ref ICsXDoc;
    XElement xelement2 = xdocument.Element((XName) "Schematic");
    XDocument[] xdocumentArray;
    if (xelement2 == null)
    {
      xdocumentArray = (XDocument[]) null;
    }
    else
    {
      IEnumerable<XElement> source = xelement2.Elements((XName) "IC");
      xdocumentArray = source != null ? source.Select<XElement, XDocument>((Func<XElement, XDocument>) (x => new XDocument(new object[1]
      {
        (object) new XElement((XName) "Schematic", (object) x)
      }))).ToArray<XDocument>() : (XDocument[]) null;
    }
    local2 = xdocumentArray;
  }

  private static void CorrectPartNumbers(string[] PartNumbers)
  {
    for (int index = 0; index < PartNumbers.Length; ++index)
    {
      if (PartNumbers[index] != null)
      {
        if (PartNumbers[index].IndexOf("ADAU145") != -1)
          PartNumbers[index] = "ADAU145x";
        else if (PartNumbers[index].IndexOf("ADAU146") != -1)
          PartNumbers[index] = "ADAU146x";
        else if (PartNumbers[index].IndexOf("Sigma100") != -1)
          PartNumbers[index] = "ADAU1701";
        else if (PartNumbers[index].IndexOf("DSPSigmaLP1") != -1)
          PartNumbers[index] = "ADAU1761";
      }
    }
  }

  private static DSPCell[] SplitCompositeCell(
    string Description,
    string BaseTitle,
    List<DSPCellParameter> Params,
    int CellPartsCount)
  {
    DSPCell[] dspCellArray = new DSPCell[CellPartsCount];
    string[] strArray = Description.Split(new string[1]
    {
      "Frequency1"
    }, StringSplitOptions.None);
    DSPCellParameter[] array = Params.Where<DSPCellParameter>((Func<DSPCellParameter, bool>) (p => !char.IsDigit(p.Name[p.Name.Length - 1]))).ToArray<DSPCellParameter>();
    for (int i = 0; i < CellPartsCount; i++)
    {
      string str1;
      if (i + 1 >= strArray.Length)
        str1 = i.ToString();
      else
        str1 = strArray[i + 1].Split(","[0])[0];
      string str2 = str1;
      dspCellArray[i] = new DSPCell(BaseTitle + str2)
      {
        IsControllable = true,
        IsBypassable = true
      };
      dspCellArray[i].ParamsFromFile = Params.Where<DSPCellParameter>((Func<DSPCellParameter, bool>) (p => p.Name.EndsWith((i + 1).ToString()))).ToList<DSPCellParameter>();
      if (array.Length != 0)
      {
        dspCellArray[i].ParamsFromFile.AddRange(((IEnumerable<DSPCellParameter>) array).Select<DSPCellParameter, DSPCellParameter>((Func<DSPCellParameter, DSPCellParameter>) (p => DSPCellParameter.Clone(p))));
        dspCellArray[i].WriteType = DSPCell.WriteTypes.BlockWrite;
      }
      dspCellArray[i].ParamsFromFile.Sort((Comparison<DSPCellParameter>) ((x, y) => x.Address.CompareTo(y.Address)));
    }
    return dspCellArray;
  }

  private static bool IsCompositeCell(string Description, out int CellParts)
  {
    CellParts = 1;
    string str = Description.Split(":"[0])[0].Replace(" ", "");
    return str.IndexOf("Multi-Channel") != -1 && int.TryParse(str.Substring(str.LastIndexOf("(") + 1).Replace(")", ""), out CellParts) && CellParts > 1;
  }
}
