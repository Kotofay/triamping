﻿// Decompiled with JetBrains decompiler
// Type: ChipStudio.DSPCellADAUxxxx
// Assembly: ChipStudio, Version=1.2.9.0, Culture=neutral, PublicKeyToken=null
// MVID: 334E3BEA-37C7-4274-8118-535AAEFA1546
// Assembly location: D:\DocAndSec\Desktop\AUDIO\ChipDip\ChipStudio_soft_v1.2.9\ChipStudio_v1.2.9.exe

using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Windows;

#nullable disable
namespace ChipStudio;

public class DSPCellADAUxxxx : IDSPCellModifiable, IDSPCellSpecific
{
  private static readonly string SigmaStudioParamName = "Param Name:";
  private static readonly string SigmaStudioParamAddress = "Param Address:";
  private static readonly string SigmaStudioBytes = "Bytes:";
  private const uint ADAU1761_PARAM_ADDRESS_MAX = 1023 /*0x03FF*/;
  private const byte ADAU_PARAM_SIZE = 4;
  private const int ALLOWED_PARAM_NAME_DIF = 2;

  public DSPCellADAUxxxx(DSPCell InCell)
  {
    InCell.AreParamsFixed = false;
    if (InCell.DSPTitle.IndexOf("ADAU1761") == -1)
      return;
    foreach (DSPCellParameter dspCellParameter in InCell.ParamsUsed)
    {
      if (dspCellParameter.Address > (ushort) 1023 /*0x03FF*/)
      {
        InCell.WriteType = DSPCell.WriteTypes.BlockWrite;
        break;
      }
    }
  }

  public int OneValueSize(DSPCell Cell) => Cell.ValueSize;

  public bool TryParseData(string FileName, out byte[] Result, DSPCell Cell)
  {
    Result = (byte[]) null;
    List<DSPCellParameter> FileParams;
    if (!DSPCellADAUxxxx.GetParamsFromFile(FileName, out FileParams))
      return false;
    if (FileParams.Count != 0)
    {
      List<byte> byteList = new List<byte>();
      while (FileParams.Count != 0)
      {
        List<DSPCellParameter> oneValueParams = DSPCellADAUxxxx.GetOneValueParams(FileParams);
        FileParams.RemoveRange(0, oneValueParams.Count);
        oneValueParams.Sort((Comparison<DSPCellParameter>) ((x, y) => x.Address.CompareTo(y.Address)));
        DSPCellADAUxxxx.OptimizeParams(oneValueParams);
        if (!DSPCellADAUxxxx.AreParamsOfSameBlocks(Cell.ParamsUsed, oneValueParams, 2))
        {
          int num = (int) MessageBox.Show("Block parameters mismatch", "", MessageBoxButton.OK, MessageBoxImage.Hand);
          return false;
        }
        foreach (DSPCellParameter dspCellParameter in oneValueParams)
          byteList.AddRange((IEnumerable<byte>) dspCellParameter.Data);
      }
      Result = byteList.ToArray();
    }
    else if (!Shared.TryParseDSPCellDataGeneric(FileName, out Result) || Result.Length % Cell.BytesPerValue != 0)
    {
      int num = (int) MessageBox.Show("Wrong data bytes count", "", MessageBoxButton.OK, MessageBoxImage.Hand);
      return false;
    }
    return true;
  }

  public bool TryUpdateCellParams(string FileName, DSPCell Cell)
  {
    return DSPCellADAUxxxx.TryModifyCellParams(FileName, Cell, DSPCellADAUxxxx.ParamsModifyOption.Reconfig);
  }

  public bool TryAddCellParam(string FileName, DSPCell Cell)
  {
    return DSPCellADAUxxxx.TryModifyCellParams(FileName, Cell, DSPCellADAUxxxx.ParamsModifyOption.Add);
  }

  private static bool TryModifyCellParams(
    string FileName,
    DSPCell Cell,
    DSPCellADAUxxxx.ParamsModifyOption Option)
  {
    Cell.ParamsUsed.Clear();
    List<DSPCellParameter> FileParams;
    if (!DSPCellADAUxxxx.GetParamsFromFile(FileName, out FileParams))
    {
      if (FileParams.Count == 0)
      {
        int num = (int) MessageBox.Show("Data file does not contain parameters", "", MessageBoxButton.OK, MessageBoxImage.Hand);
      }
      return false;
    }
    List<DSPCellParameter> oneValueParams = DSPCellADAUxxxx.GetOneValueParams(FileParams);
    if (DSPCellADAUxxxx.AreParamsSame(Cell.ParamsFromFile, oneValueParams))
    {
      Cell.CloneParamsFromFileToParamsUsed();
    }
    else
    {
      foreach (DSPCellParameter dspCellParameter in oneValueParams)
      {
        DSPCellParameter NewParam = dspCellParameter;
        DSPCellParameter[] array = Cell.ParamsFromFile.Where<DSPCellParameter>((Func<DSPCellParameter, bool>) (p => DSPCellADAUxxxx.CompareStrings(p.Name, NewParam.Name) == 0)).ToArray<DSPCellParameter>();
        if (array.Length == 0)
          array = Cell.ParamsFromFile.Where<DSPCellParameter>((Func<DSPCellParameter, bool>) (p => DSPCellADAUxxxx.CompareStrings(p.Name, NewParam.Name) <= 2)).ToArray<DSPCellParameter>();
        if (array.Length != 0)
          Cell.ParamsUsed.Add(DSPCellParameter.Clone(array[0]));
        else if (Option == DSPCellADAUxxxx.ParamsModifyOption.Reconfig)
          Cell.ParamsUsed.Add(NewParam);
      }
    }
    Cell.BytesPerValue = Cell.ValueSize;
    if (Cell.ParamsUsed.Count != 0)
    {
      Cell.ParamsUsed.Sort((Comparison<DSPCellParameter>) ((x, y) => x.Address.CompareTo(y.Address)));
      DSPCellADAUxxxx.OptimizeParams(Cell.ParamsUsed);
    }
    return true;
  }

  private static bool GetParamsFromFile(string DataFile, out List<DSPCellParameter> FileParams)
  {
    FileParams = new List<DSPCellParameter>();
    string[] source = File.ReadAllLines(DataFile);
    string[] array1 = ((IEnumerable<string>) source).Where<string>((Func<string, bool>) (s => s.IndexOf(DSPCellADAUxxxx.SigmaStudioParamName) != -1)).Select<string, string>((Func<string, string>) (s => s.Substring(DSPCellADAUxxxx.SigmaStudioParamName.Length).Replace(" ", ""))).ToArray<string>();
    string[] array2 = ((IEnumerable<string>) source).Where<string>((Func<string, bool>) (s => s.IndexOf(DSPCellADAUxxxx.SigmaStudioParamAddress) != -1)).Select<string, string>((Func<string, string>) (s => s.Substring(DSPCellADAUxxxx.SigmaStudioParamAddress.Length).Replace(" ", ""))).ToArray<string>();
    string[] array3 = ((IEnumerable<string>) source).Where<string>((Func<string, bool>) (s => s.IndexOf(DSPCellADAUxxxx.SigmaStudioBytes) != -1)).Select<string, string>((Func<string, string>) (s => s.Substring(DSPCellADAUxxxx.SigmaStudioBytes.Length).Replace(" ", ""))).ToArray<string>();
    byte[] Result;
    if (array1.Length != array2.Length || array1.Length != array3.Length || !Shared.TryParseDSPCellDataGeneric(DataFile, out Result))
      return false;
    int sourceIndex = 0;
    for (int index = 0; index < array1.Length; ++index)
    {
      uint result1;
      int result2;
      if (!Shared.TryParseToValue(array2[index], out result1) || !int.TryParse(array3[index], out result2) || sourceIndex + result2 > Result.Length)
        return false;
      byte[] destinationArray = new byte[result2];
      Array.Copy((Array) Result, sourceIndex, (Array) destinationArray, 0, result2);
      sourceIndex += result2;
      FileParams.Add(new DSPCellParameter()
      {
        Name = array1[index],
        Address = (ushort) result1,
        Size = (ushort) result2,
        Data = destinationArray
      });
    }
    return true;
  }

  private static List<DSPCellParameter> GetOneValueParams(List<DSPCellParameter> FileParams)
  {
    string[] Names = FileParams.Select<DSPCellParameter, string>((Func<DSPCellParameter, string>) (p => p.Name)).ToArray<string>();
    int count = Array.FindIndex<string>(Names, 1, (Predicate<string>) (a => a == Names[0]));
    if (count == -1)
      count = Names.Length;
    return FileParams.Take<DSPCellParameter>(count).ToList<DSPCellParameter>();
  }

  private static bool AreParamsSame(List<DSPCellParameter> list1, List<DSPCellParameter> list2)
  {
    List<DSPCellParameter> dspCellParameterList1 = new List<DSPCellParameter>((IEnumerable<DSPCellParameter>) list1);
    List<DSPCellParameter> dspCellParameterList2 = new List<DSPCellParameter>((IEnumerable<DSPCellParameter>) list2);
    dspCellParameterList1.Sort((Comparison<DSPCellParameter>) ((x, y) => x.Address.CompareTo(y.Address)));
    dspCellParameterList2.Sort((Comparison<DSPCellParameter>) ((x, y) => x.Address.CompareTo(y.Address)));
    if (dspCellParameterList1.Count != dspCellParameterList2.Count)
      return false;
    for (int index = 0; index < dspCellParameterList1.Count; ++index)
    {
      if ((int) dspCellParameterList1[index].Size != (int) dspCellParameterList2[index].Size || dspCellParameterList1[index].Name != dspCellParameterList2[index].Name)
        return false;
    }
    return true;
  }

  private static bool AreParamsOfSameBlocks(
    List<DSPCellParameter> list1,
    List<DSPCellParameter> list2,
    int DifChars)
  {
    List<DSPCellParameter> dspCellParameterList1 = new List<DSPCellParameter>((IEnumerable<DSPCellParameter>) list1);
    List<DSPCellParameter> dspCellParameterList2 = new List<DSPCellParameter>((IEnumerable<DSPCellParameter>) list2);
    dspCellParameterList1.Sort((Comparison<DSPCellParameter>) ((x, y) => x.Address.CompareTo(y.Address)));
    dspCellParameterList2.Sort((Comparison<DSPCellParameter>) ((x, y) => x.Address.CompareTo(y.Address)));
    if (dspCellParameterList1.Count != dspCellParameterList2.Count)
      return false;
    for (int index = 0; index < dspCellParameterList1.Count; ++index)
    {
      if ((int) dspCellParameterList1[index].Size != (int) dspCellParameterList2[index].Size || DSPCellADAUxxxx.CompareStrings(dspCellParameterList1[index].Name, dspCellParameterList2[index].Name) > DifChars)
        return false;
    }
    return true;
  }

  private static int CompareStrings(string string1, string string2)
  {
    int length1 = string1.Length;
    int length2 = string2.Length;
    int num1;
    int num2;
    if (length1 > length2)
    {
      num1 = length1 - length2;
      num2 = length2;
    }
    else
    {
      num1 = length2 - length1;
      num2 = length1;
    }
    for (int index = 0; index < num2; ++index)
    {
      if ((int) string1[index] != (int) string2[index])
        ++num1;
    }
    return num1;
  }

  private static void OptimizeParams(List<DSPCellParameter> InParams)
  {
    List<DSPCellParameter> collection = new List<DSPCellParameter>()
    {
      InParams[0]
    };
    List<byte> byteList = new List<byte>();
    foreach (DSPCellParameter inParam in InParams)
      byteList.AddRange((IEnumerable<byte>) inParam.Data);
    int index1 = 0;
    for (int index2 = 1; index2 < InParams.Count; ++index2)
    {
      if ((int) collection[index1].Address + (int) collection[index1].Size / 4 == (int) InParams[index2].Address)
      {
        collection[index1].Size += InParams[index2].Size;
        collection[index1].Data = new byte[(int) collection[index1].Size];
      }
      else
      {
        collection.Add(InParams[index2]);
        ++index1;
      }
    }
    if (InParams.Count != collection.Count)
    {
      InParams.Clear();
      InParams.AddRange((IEnumerable<DSPCellParameter>) collection);
    }
    int sourceIndex = 0;
    byte[] array = byteList.ToArray();
    for (int index3 = 0; index3 < InParams.Count; ++index3)
    {
      Array.Copy((Array) array, sourceIndex, (Array) InParams[index3].Data, 0, (int) InParams[index3].Size);
      sourceIndex += (int) InParams[index3].Size;
    }
  }

  private enum ParamsModifyOption : byte
  {
    Reconfig,
    Add,
  }
}
