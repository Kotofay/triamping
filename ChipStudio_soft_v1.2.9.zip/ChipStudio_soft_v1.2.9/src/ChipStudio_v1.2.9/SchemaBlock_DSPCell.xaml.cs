﻿// Decompiled with JetBrains decompiler
// Type: ChipStudio.SchemaBlock_DSPCell
// Assembly: ChipStudio, Version=1.2.9.0, Culture=neutral, PublicKeyToken=null
// MVID: 334E3BEA-37C7-4274-8118-535AAEFA1546
// Assembly location: D:\DocAndSec\Desktop\AUDIO\ChipDip\ChipStudio_soft_v1.2.9\ChipStudio_v1.2.9.exe

using System;
using System.CodeDom.Compiler;
using System.Collections;
using System.ComponentModel;
using System.Diagnostics;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Controls.Primitives;
using System.Windows.Input;
using System.Windows.Markup;
using System.Windows.Media;
using System.Windows.Media.Imaging;

#nullable disable
namespace ChipStudio;

public partial class SchemaBlock_DSPCell : SchemaBlock, IComponentConnector
{
  private static readonly string ImageWarning = (string) Application.Current.FindResource((object) nameof (ImageWarning));
  private static readonly string ImageApply = (string) Application.Current.FindResource((object) nameof (ImageApply));
  internal const int REG_POINT_INDEX = 0;
  internal const int EN_POINT_INDEX = 1;
  private static readonly string[] ConnectTitles = new string[2]
  {
    "REG",
    "EN"
  };
  private static readonly Anchor.AnchorTypes[] PointAnchors = new Anchor.AnchorTypes[2]
  {
    Anchor.AnchorTypes.FromDSPCell,
    Anchor.AnchorTypes.FromDSPCell
  };
  private int valuescount;
  private int envaluescount;
  private readonly DSPCellDescription CellDesc = new DSPCellDescription();
  internal ItemsControl ConnectPoints;
  internal StackPanel CommonView;
  internal Image RegDataImage;
  internal StackPanel EnPanel;
  internal Image EnDataImage;
  private bool _contentLoaded;

  public ushort ParametersCount => this.CellDesc.ParamsCount;

  public ushort ValueSize => this.CellDesc.ValueSize;

  public DSPCell.WriteTypes WriteType => this.CellDesc.WriteType;

  public bool IsBypassable => this.CellDesc.IsBypassable;

  public string DSPTitle { get; set; }

  public override string FullName => this.Title + this.DSPTitle;

  public override SchemaBlock.SchemaBlockTypes BlockType => SchemaBlock.SchemaBlockTypes.DSPCell;

  public int ValuesCount
  {
    get => this.valuescount;
    private set
    {
      if (this.valuescount == value)
        return;
      this.valuescount = value;
      this.NotifyPropertyChanged(nameof (ValuesCount));
    }
  }

  public int EnValuesCount
  {
    get => this.envaluescount;
    private set
    {
      if (this.envaluescount == value)
        return;
      this.envaluescount = value;
      this.NotifyPropertyChanged(nameof (EnValuesCount));
    }
  }

  public SchemaBlock_DSPCell()
  {
    this.InitializeComponent();
    this.DataContext = (object) this;
    this.RegDataImage.Source = (ImageSource) new BitmapImage(new Uri(SchemaBlock_DSPCell.ImageWarning, UriKind.Relative));
    this.EnDataImage.Source = (ImageSource) new BitmapImage(new Uri(SchemaBlock_DSPCell.ImageWarning, UriKind.Relative));
  }

  public void Initialize(DSPCell cell)
  {
    this.CellDesc.Initialize(cell);
    this.InitConnectionPoints(this.ActivePointAnchors());
    for (int index = 0; index < this.ConnectionPoints.Length; ++index)
      this.ConnectionPoints[index].Title = SchemaBlock_DSPCell.ConnectTitles[index];
    if (this.ConnectionPoints.Length == 2)
      this.ConnectionPoints[1].Margin = new Thickness(0.0, 10.0, 0.0, 0.0);
    this.ConnectPoints.ItemsSource = (IEnumerable) this.ConnectionPoints;
    this.ValuesCount = this.CellDesc.UpdateRegData();
    if (this.ValuesCount != 0)
      this.RegDataImage.Source = (ImageSource) new BitmapImage(new Uri(SchemaBlock_DSPCell.ImageApply, UriKind.Relative));
    if (!this.CellDesc.IsBypassable)
      return;
    this.EnPanel.Visibility = Visibility.Visible;
    this.EnValuesCount = this.CellDesc.UpdateEnData();
    if (this.EnValuesCount == 0)
      return;
    this.EnDataImage.Source = (ImageSource) new BitmapImage(new Uri(SchemaBlock_DSPCell.ImageApply, UriKind.Relative));
  }

  public void Update(DSPCell cell) => this.CellDesc.UpdateParamsAddresses(cell);

  public byte[] GetData() => this.CellDesc.GetRegulatorData().ToArray();

  public void SetData(byte[] NewData) => this.CellDesc.SetRegulatorData(NewData);

  public byte[] GetEnData() => this.CellDesc.GetEnableData().ToArray();

  public void SetEnData(byte[] NewData) => this.CellDesc.SetEnableData(NewData);

  public void ParamAddressAndSize(int ParamIndex, out int address, out ushort size)
  {
    this.CellDesc.ParameterAddressAndSize(ParamIndex, out address, out size);
  }

  private Anchor.AnchorTypes[] ActivePointAnchors()
  {
    if (this.IsBypassable)
      return SchemaBlock_DSPCell.PointAnchors;
    return new Anchor.AnchorTypes[1]
    {
      SchemaBlock_DSPCell.PointAnchors[0]
    };
  }

  private void RegEditButton_Click(object sender, RoutedEventArgs e)
  {
    this.CellDesc.SetParamsModifiabilityForReg();
    new DSPCellSettings(this.CellDesc, this.CellDesc.GetRegulatorData()).ShowDialog();
    this.ValuesCount = this.CellDesc.UpdateRegData();
    this.RegDataImage.Source = this.ValuesCount > 0 ? (ImageSource) new BitmapImage(new Uri(SchemaBlock_DSPCell.ImageApply, UriKind.Relative)) : (ImageSource) new BitmapImage(new Uri(SchemaBlock_DSPCell.ImageWarning, UriKind.Relative));
  }

  private void EnEditButton_Click(object sender, RoutedEventArgs e)
  {
    this.CellDesc.SetParamsModifiabilityForEn();
    new DSPCellSettings(this.CellDesc, this.CellDesc.GetEnableData()).ShowDialog();
    this.EnValuesCount = this.CellDesc.UpdateEnData();
    this.EnDataImage.Source = this.EnValuesCount > 0 ? (ImageSource) new BitmapImage(new Uri(SchemaBlock_DSPCell.ImageApply, UriKind.Relative)) : (ImageSource) new BitmapImage(new Uri(SchemaBlock_DSPCell.ImageWarning, UriKind.Relative));
  }

  private void BandwidthSelect_SelectionChanged(object sender, SelectionChangedEventArgs e)
  {
  }

  [DebuggerNonUserCode]
  [GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
  public void InitializeComponent()
  {
    if (this._contentLoaded)
      return;
    this._contentLoaded = true;
    Application.LoadComponent((object) this, new Uri("/ChipStudio;component/schemablock_dspcell.xaml", UriKind.Relative));
  }

  [DebuggerNonUserCode]
  [GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
  [EditorBrowsable(EditorBrowsableState.Never)]
  void IComponentConnector.Connect(int connectionId, object target)
  {
    switch (connectionId)
    {
      case 1:
        ((UIElement) target).MouseLeftButtonDown += new MouseButtonEventHandler(((SchemaBlock) this).Border_MouseLeftButtonDown);
        break;
      case 2:
        this.ConnectPoints = (ItemsControl) target;
        break;
      case 3:
        this.CommonView = (StackPanel) target;
        break;
      case 4:
        this.RegDataImage = (Image) target;
        break;
      case 5:
        ((ButtonBase) target).Click += new RoutedEventHandler(this.RegEditButton_Click);
        break;
      case 6:
        this.EnPanel = (StackPanel) target;
        break;
      case 7:
        this.EnDataImage = (Image) target;
        break;
      case 8:
        ((ButtonBase) target).Click += new RoutedEventHandler(this.EnEditButton_Click);
        break;
      default:
        this._contentLoaded = true;
        break;
    }
  }
}
