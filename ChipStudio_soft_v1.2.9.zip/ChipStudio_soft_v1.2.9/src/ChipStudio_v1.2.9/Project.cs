﻿// Decompiled with JetBrains decompiler
// Type: ChipStudio.Project
// Assembly: ChipStudio, Version=1.2.9.0, Culture=neutral, PublicKeyToken=null
// MVID: 334E3BEA-37C7-4274-8118-535AAEFA1546
// Assembly location: D:\DocAndSec\Desktop\AUDIO\ChipDip\ChipStudio_soft_v1.2.9\ChipStudio_v1.2.9.exe

using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Windows;
using System.Windows.Controls;
using System.Xml.Linq;

#nullable disable
namespace ChipStudio;

public class Project
{
  private static readonly string SoftwareVersion = (string) Application.Current.FindResource((object) nameof (SoftwareVersion));
  private const string RootElement = "Project";
  private const string ModuleTypeElement = "Module";
  private const string CtrlGpioFuncsElement = "GpioFuncs";
  private const string DSPBootElement = "Boot";
  private const string TransferElement = "Transfer";
  private const string AudioStatusString = "AudioStatus";
  private const string BlockString = "Block";
  private const string ColorsString = "Colors";
  private const string ConnectionsString = "Connections";
  private const string DSPCellsString = "DSPCells";
  private const string DSPCellIndexString = "DSPCellIndex";
  private const string DSPModeString = "DSPMode";
  private const string EnableDataString = "EnableData";
  private const string FixProjectString = "FixProject";
  private const string FreqIndicationString = "FreqIndication";
  private const string GenSelectString = "GenSelect";
  private const string IndexString = "Index";
  private const string LevelString = "Level";
  private const string IndicationTypeString = "IndicationType";
  private const string IndicationModeString = "IndicationMode";
  private const string IsPwrOnString = "IsPwrOn";
  private const string IsSelfBootedString = "SelfBooted";
  private const string LEDsString = "LEDs";
  private const string LEDsCountString = "LEDsCount";
  private const string BytesCountString = "BytesCount";
  private const string PeriodString = "Period";
  private const string LocationString = "Location";
  private const string LocationX = "X";
  private const string LocationY = "Y";
  private const string MuteGpioString = "MuteGpio";
  private const string NodeString = "Node";
  private const string NumberString = "Number";
  private const string ParamsFromFileString = "ParamsFromFile";
  private const string ParamsUsedString = "ParamsUsed";
  private const string PortString = "Port";
  private const string PwrKeyString = "PwrKey";
  private const string RegulationDataString = "RegulationData";
  private const string ResIndicationString = "ResIndication";
  private const string StatesCountString = "StatesCount";
  private const string TvOffString = "TvOff";
  private const string TvOnString = "TvOn";
  private const string VolGpioString = "VolGpio";
  private const string ModeString = "Mode";
  private const string ChipStudioProjectExt = ".cspro";
  private static readonly CultureInfo NumericStringCulture = CultureInfo.InvariantCulture;

  public string Path { get; }

  public Project(string path) => this.Path = path;

  public bool Open(out ISchemaElement[] Elements)
  {
    return !Project.IsNewFormatFile(this.Path) ? Project.OpenOldFormat(this.Path, out Elements) : Project.OpenNewFormat(XDocument.Load(this.Path), out Elements);
  }

  public void Save(UIElementCollection Schema)
  {
    XDocument xdocument = new XDocument(new object[1]
    {
      (object) new XElement((XName) nameof (Project), (object) new XElement((XName) "Version", (object) Project.SoftwareVersion))
    });
    ISchemaElement[] Blocks;
    if (Project.ExtractBlocks(Schema, SchemaBlock.SchemaBlockTypes.Controller, out Blocks))
      xdocument.Root.Add((object) Project.Controller(Blocks[0]));
    Func<ISchemaElement[], XElement>[] funcArray = new Func<ISchemaElement[], XElement>[7]
    {
      new Func<ISchemaElement[], XElement>(Project.DSPGroup),
      new Func<ISchemaElement[], XElement>(Project.DSPCellGroup),
      new Func<ISchemaElement[], XElement>(Project.LEDsGroup),
      new Func<ISchemaElement[], XElement>(Project.PixelLEDsGroup),
      new Func<ISchemaElement[], XElement>(Project.ReadsGroup),
      new Func<ISchemaElement[], XElement>(Project.ComparatorsGroup),
      new Func<ISchemaElement[], XElement>(Project.CommentsGroup)
    };
    SchemaBlock.SchemaBlockTypes[] schemaBlockTypesArray = new SchemaBlock.SchemaBlockTypes[7]
    {
      SchemaBlock.SchemaBlockTypes.DSP,
      SchemaBlock.SchemaBlockTypes.DSPCell,
      SchemaBlock.SchemaBlockTypes.LED,
      SchemaBlock.SchemaBlockTypes.PixelLED,
      SchemaBlock.SchemaBlockTypes.Read,
      SchemaBlock.SchemaBlockTypes.Comparator,
      SchemaBlock.SchemaBlockTypes.Comment
    };
    for (int index = 0; index < schemaBlockTypesArray.Length; ++index)
    {
      if (Project.ExtractBlocks(Schema, schemaBlockTypesArray[index], out Blocks))
        xdocument.Root.Add((object) funcArray[index](Blocks));
    }
    if (Project.ExtractConnections(Schema, out Blocks))
      xdocument.Root.Add((object) Project.ConnectionsGroup(Blocks));
    xdocument.Save(this.Path);
  }

  private static bool IsNewFormatFile(string FilePath) => Shared.IsXMLFile(FilePath);

  private static bool OpenNewFormat(XDocument ProjFile, out ISchemaElement[] SchElements)
  {
    SchElements = (ISchemaElement[]) null;
    Func<XElement, ISchemaElement>[] funcArray = new Func<XElement, ISchemaElement>[9]
    {
      new Func<XElement, ISchemaElement>(Project.TryParseController),
      new Func<XElement, ISchemaElement>(Project.TryParseDSP),
      new Func<XElement, ISchemaElement>(Project.TryParseDSPCellBlock),
      new Func<XElement, ISchemaElement>(Project.TryParseLED),
      new Func<XElement, ISchemaElement>(Project.TryParsePixelLED),
      new Func<XElement, ISchemaElement>(Project.TryParseRead),
      new Func<XElement, ISchemaElement>(Project.TryParseComparator),
      new Func<XElement, ISchemaElement>(Project.TryParseComment),
      new Func<XElement, ISchemaElement>(Project.TryParseConnection)
    };
    string[] strArray = new string[9]
    {
      "Controller",
      "DSP",
      "DSPCells",
      "LEDs",
      "PixelLED",
      "Read",
      "Comparator",
      "Comment",
      "Connections"
    };
    List<ISchemaElement> schemaElementList = new List<ISchemaElement>();
    for (int index = 0; index < strArray.Length; ++index)
    {
      XElement ElementGroup = ProjFile.Element((XName) nameof (Project)).Element((XName) strArray[index]);
      if (ElementGroup != null)
      {
        ISchemaElement[] SchemaElements;
        if (!Project.TryParseSchemaElements(ElementGroup, funcArray[index], out SchemaElements))
          return false;
        schemaElementList.AddRange((IEnumerable<ISchemaElement>) SchemaElements);
      }
    }
    SchElements = schemaElementList.ToArray();
    return true;
  }

  private static bool TryParseSchemaElements(
    XElement ElementGroup,
    Func<XElement, ISchemaElement> TryParse,
    out ISchemaElement[] SchemaElements)
  {
    SchemaElements = ElementGroup.Elements((XName) "Block").Select<XElement, ISchemaElement>((Func<XElement, ISchemaElement>) (e => TryParse(e))).ToArray<ISchemaElement>();
    return ((IEnumerable<ISchemaElement>) SchemaElements).Where<ISchemaElement>((Func<ISchemaElement, bool>) (b => b == null)).ToArray<ISchemaElement>().Length == 0;
  }

  private static ISchemaElement TryParseController(XElement Element)
  {
    SchemaBlock_Controller controller = new SchemaBlock_Controller(Element.Element((XName) "Module")?.Value);
    if (!controller.IsReady)
      return (ISchemaElement) null;
    Func<XElement, SchemaBlock_Controller, bool>[] funcArray = new Func<XElement, SchemaBlock_Controller, bool>[7]
    {
      new Func<XElement, SchemaBlock_Controller, bool>(Project.CommonProperties),
      new Func<XElement, SchemaBlock_Controller, bool>(Project.TryParseCtrlDelay),
      new Func<XElement, SchemaBlock_Controller, bool>(Project.TryParseCtrlPixel),
      new Func<XElement, SchemaBlock_Controller, bool>(Project.TryParseCtrlCLI),
      new Func<XElement, SchemaBlock_Controller, bool>(Project.TryParseCtrlCEC),
      new Func<XElement, SchemaBlock_Controller, bool>(Project.TryParseCtrlOptions),
      new Func<XElement, SchemaBlock_Controller, bool>(Project.TryParseCtrlMute)
    };
    foreach (Func<XElement, SchemaBlock_Controller, bool> func in funcArray)
    {
      if (!func(Element, controller))
        return (ISchemaElement) null;
    }
    SchemaBlock_Controller schemaBlockController = controller;
    XElement xelement = Element.Element((XName) "GpioFuncs");
    int[] FuncList;
    if (xelement == null)
    {
      FuncList = (int[]) null;
    }
    else
    {
      int result;
      FuncList = ((IEnumerable<string>) xelement.Value.Split(";"[0])).Select<string, int>((Func<string, int>) (s => !int.TryParse(s, out result) ? 0 : result)).ToArray<int>();
    }
    schemaBlockController.SetGPIOFunctions(FuncList);
    return (ISchemaElement) controller;
  }

  private static ISchemaElement TryParseDSP(XElement Element)
  {
    SchemaBlock_DSP dsp = new SchemaBlock_DSP(Element.Element((XName) "Module")?.Value);
    if (!dsp.IsReady)
      return (ISchemaElement) null;
    Func<XElement, SchemaBlock_DSP, bool>[] funcArray = new Func<XElement, SchemaBlock_DSP, bool>[3]
    {
      new Func<XElement, SchemaBlock_DSP, bool>(Project.CommonProperties),
      new Func<XElement, SchemaBlock_DSP, bool>(Project.TryParseDSPBoot),
      new Func<XElement, SchemaBlock_DSP, bool>(Project.TryParseDSPCells)
    };
    foreach (Func<XElement, SchemaBlock_DSP, bool> func in funcArray)
    {
      if (!func(Element, dsp))
        return (ISchemaElement) null;
    }
    int result1;
    dsp.SetBusAddress(int.TryParse(Element.Element((XName) "BusAddress")?.Value, out result1) ? (byte) result1 : (byte) 0);
    bool result2;
    dsp.IsSelfBooted = bool.TryParse(Element.Element((XName) "SelfBooted")?.Value, out result2) && result2;
    return (ISchemaElement) dsp;
  }

  private static ISchemaElement TryParseDSPCellBlock(XElement Element)
  {
    SchemaBlock_DSPCell Block = new SchemaBlock_DSPCell();
    if (!Project.CommonProperties(Element, (SchemaBlock) Block))
      return (ISchemaElement) null;
    Block.DSPTitle = Element.Element((XName) "DSP")?.Value;
    string str1 = Element.Element((XName) "RegulationData")?.Value;
    SchemaBlock_DSPCell schemaBlockDspCell1 = Block;
    byte[] NewData1;
    if (!(str1 != ""))
    {
      NewData1 = (byte[]) null;
    }
    else
    {
      int result;
      NewData1 = ((IEnumerable<string>) ((IEnumerable<string>) str1.Split(";"[0])).ToArray<string>()).Select<string, byte>((Func<string, byte>) (d => !int.TryParse(d, out result) ? (byte) 0 : (byte) result)).ToArray<byte>();
    }
    schemaBlockDspCell1.SetData(NewData1);
    string str2 = Element.Element((XName) "EnableData")?.Value;
    SchemaBlock_DSPCell schemaBlockDspCell2 = Block;
    byte[] NewData2;
    if (!(str2 != ""))
    {
      NewData2 = (byte[]) null;
    }
    else
    {
      int result;
      NewData2 = ((IEnumerable<string>) ((IEnumerable<string>) str2.Split(";"[0])).ToArray<string>()).Select<string, byte>((Func<string, byte>) (d => !int.TryParse(d, out result) ? (byte) 0 : (byte) result)).ToArray<byte>();
    }
    schemaBlockDspCell2.SetEnData(NewData2);
    return (ISchemaElement) Block;
  }

  private static ISchemaElement TryParseLED(XElement Element)
  {
    SchemaBlock_LED Block = new SchemaBlock_LED();
    if (!Project.CommonProperties(Element, (SchemaBlock) Block))
      return (ISchemaElement) null;
    bool result1;
    Block.SetMode(!bool.TryParse(Element.Element((XName) "DSPMode")?.Value, out result1) || result1);
    int result2;
    Block.SetDefaultBlockIndex(int.TryParse(Element.Element((XName) "DSPCellIndex")?.Value, out result2) ? result2 : 0);
    SchemaBlock_LED schemaBlockLed = Block;
    XElement xelement = Element.Element((XName) "Data");
    byte[] Data;
    if (xelement == null)
    {
      Data = (byte[]) null;
    }
    else
    {
      string str = xelement.Value;
      if (str == null)
      {
        Data = (byte[]) null;
      }
      else
      {
        int result3;
        Data = ((IEnumerable<string>) ((IEnumerable<string>) str.Split(";"[0])).ToArray<string>()).Select<string, byte>((Func<string, byte>) (d => !int.TryParse(d, out result3) ? (byte) 0 : (byte) result3)).ToArray<byte>();
      }
    }
    schemaBlockLed.SetData(Data);
    return (ISchemaElement) Block;
  }

  private static ISchemaElement TryParsePixelLED(XElement Element)
  {
    SchemaBlock_PixelLED pixelLed = new SchemaBlock_PixelLED();
    Func<XElement, SchemaBlock_PixelLED, bool>[] funcArray = new Func<XElement, SchemaBlock_PixelLED, bool>[2]
    {
      new Func<XElement, SchemaBlock_PixelLED, bool>(Project.CommonProperties),
      new Func<XElement, SchemaBlock_PixelLED, bool>(Project.TryParsePixelSettings)
    };
    foreach (Func<XElement, SchemaBlock_PixelLED, bool> func in funcArray)
    {
      if (!func(Element, pixelLed))
        return (ISchemaElement) null;
    }
    int result;
    if (!int.TryParse(Element.Element((XName) "DSPCellIndex")?.Value, out result))
      return (ISchemaElement) null;
    pixelLed.SetDefaultBlockIndex(result);
    SchemaBlock_PixelLED schemaBlockPixelLed = pixelLed;
    XElement xelement = Element.Element((XName) "Colors");
    string[] Colors;
    if (xelement == null)
      Colors = (string[]) null;
    else
      Colors = xelement.Value.Split(";"[0]);
    schemaBlockPixelLed.SetColors(Colors);
    return (ISchemaElement) pixelLed;
  }

  private static ISchemaElement TryParseRead(XElement Element)
  {
    SchemaBlock_Read Block = new SchemaBlock_Read();
    if (!Project.CommonProperties(Element, (SchemaBlock) Block))
      return (ISchemaElement) null;
    int result;
    Block.DSPIndex = int.TryParse(Element.Element((XName) "DSP")?.Value, out result) ? result : 0;
    Block.SetAddress(Element.Element((XName) "Address")?.Value);
    Block.SetBytesCount(Element.Element((XName) "BytesCount")?.Value);
    Block.PeriodIndex = int.TryParse(Element.Element((XName) "Period")?.Value, out result) ? result : 3;
    return (ISchemaElement) Block;
  }

  private static ISchemaElement TryParseComparator(XElement Element)
  {
    SchemaBlock_Comparator Block = new SchemaBlock_Comparator();
    if (!Project.CommonProperties(Element, (SchemaBlock) Block))
      return (ISchemaElement) null;
    Block.SetMask(Element.Element((XName) "Mask")?.Value);
    Block.SetValue(Element.Element((XName) "Value")?.Value);
    int result;
    Block.Mode = int.TryParse(Element.Element((XName) "Mode")?.Value, out result) ? result : 1;
    return (ISchemaElement) Block;
  }

  private static ISchemaElement TryParseComment(XElement Element)
  {
    SchemaBlock_Comment Block = new SchemaBlock_Comment();
    if (!Project.CommonProperties(Element, (SchemaBlock) Block))
      return (ISchemaElement) null;
    Block.Comment = Element.Element((XName) "Value")?.Value;
    return (ISchemaElement) Block;
  }

  private static ISchemaElement TryParseConnection(XElement Element)
  {
    Connection connection = new Connection();
    IEnumerable<XElement> source = Element.Elements((XName) "Node");
    foreach (ConnectionNode NewNode in source != null ? source.Select<XElement, ConnectionNode>((Func<XElement, ConnectionNode>) (n => Project.TryParseNode(n))).ToArray<ConnectionNode>() : (ConnectionNode[]) null)
    {
      if (NewNode == null)
        return (ISchemaElement) null;
      connection.AddNode(NewNode);
    }
    return (ISchemaElement) connection;
  }

  private static ConnectionNode TryParseNode(XElement Element)
  {
    int result1;
    if (!int.TryParse(Element.Element((XName) "Number")?.Value, out result1))
      return (ConnectionNode) null;
    Anchor.AnchorTypes result2;
    if (!Anchor.TryParseAnchorType(Element.Element((XName) "Type")?.Value, out result2))
      return (ConnectionNode) null;
    double Result1;
    if (!Project.TryParseStringToDouble(Element.Element((XName) "Location")?.Attribute((XName) "X")?.Value, out Result1))
      return (ConnectionNode) null;
    double Result2;
    if (!Project.TryParseStringToDouble(Element.Element((XName) "Location")?.Attribute((XName) "Y")?.Value, out Result2))
      return (ConnectionNode) null;
    string blockname = Element.Element((XName) "Name")?.Value;
    int anchornumber = result1;
    LinePoint anchorpoint = new LinePoint();
    anchorpoint.X = Result1;
    anchorpoint.Y = Result2;
    int anchortype = (int) result2;
    return new ConnectionNode(blockname, anchornumber, anchorpoint, (Anchor.AnchorTypes) anchortype);
  }

  private static bool TryParsePixelSettings(XElement Element, SchemaBlock_PixelLED Block)
  {
    int result1;
    int result2;
    PixelLEDBlock.IndicationTypes result3;
    PixelLEDBlock.IndicationModes result4;
    if (!int.TryParse(Element.Element((XName) "LEDsCount")?.Value, out result1) || !int.TryParse(Element.Element((XName) "StatesCount")?.Value, out result2) || !PixelLEDBlock.TryParseIndicationType(Element.Element((XName) "IndicationType")?.Value, out result3) || !PixelLEDBlock.TryParseIndicationMode(Element.Element((XName) "IndicationMode")?.Value, out result4))
      return false;
    Block.Settings = new PixelLEDBlock()
    {
      LEDsCount = result1,
      StatesCount = result2,
      IndicationType = result3,
      IndicationMode = result4
    };
    return true;
  }

  private static bool TryParseDSPBoot(XElement Element, SchemaBlock_DSP Block)
  {
    XElement xelement1 = Element.Element((XName) "Boot");
    \u003C\u003Ef__AnonymousType3<string, string, string, string, string[]>[] dataArray1;
    if (xelement1 == null)
    {
      dataArray1 = null;
    }
    else
    {
      IEnumerable<XElement> source = xelement1.Elements((XName) "Transfer");
      dataArray1 = source != null ? source.Select(t =>
      {
        string str1 = t.Element((XName) "Type")?.Value;
        string str2 = t.Element((XName) "Address")?.Value;
        string str3 = t.Element((XName) "AddrIncr")?.Value;
        string str4 = t.Element((XName) "Size")?.Value;
        XElement xelement2 = t.Element((XName) "Data");
        string[] strArray;
        if (xelement2 == null)
        {
          strArray = (string[]) null;
        }
        else
        {
          string str5 = xelement2.Value;
          if (str5 == null)
            strArray = (string[]) null;
          else
            strArray = ((IEnumerable<string>) str5.Split(";"[0])).ToArray<string>();
        }
        return new
        {
          Type = str1,
          Address = str2,
          AddrIncr = str3,
          Size = str4,
          Data = strArray
        };
      }).ToArray() : null;
    }
    \u003C\u003Ef__AnonymousType3<string, string, string, string, string[]>[] dataArray2 = dataArray1;
    DataTransfer[] DSPBoot = new DataTransfer[dataArray2.Length];
    for (int index = 0; index < dataArray2.Length; ++index)
    {
      int result1;
      int result2;
      int result3;
      DataTransfer.TransferTypes result4;
      if (!int.TryParse(dataArray2[index].Address, out result1) || !int.TryParse(dataArray2[index].Size, out result2) || !int.TryParse(dataArray2[index].AddrIncr, out result3) || !DataTransfer.TryParseType(dataArray2[index].Type, out result4))
        return false;
      int result5;
      DSPBoot[index] = new DataTransfer((ushort) result1, (int) (ushort) result2, (byte) result3, result4)
      {
        Data = ((IEnumerable<string>) dataArray2[index].Data).Select<string, byte>((Func<string, byte>) (d => !int.TryParse(d, out result5) ? (byte) 0 : (byte) result5)).ToArray<byte>()
      };
    }
    Block.SetBoot(DSPBoot);
    return true;
  }

  private static bool TryParseDSPCells(XElement Element, SchemaBlock_DSP Block)
  {
    XElement xelement1 = Element.Element((XName) "Cells");
    \u003C\u003Ef__AnonymousType4<string, string, string, string, XElement[], XElement[]>[] dataArray1;
    if (xelement1 == null)
    {
      dataArray1 = null;
    }
    else
    {
      IEnumerable<XElement> source = xelement1.Elements((XName) "Cell");
      dataArray1 = source != null ? source.Select(t =>
      {
        string str1 = t.Element((XName) "Title")?.Value;
        string str2 = t.Element((XName) "DSP")?.Value;
        string str3 = t.Element((XName) "IsControllable")?.Value;
        string str4 = t.Element((XName) "IsBypassable")?.Value;
        XElement xelement2 = t.Element((XName) "ParamsUsed");
        XElement[] array1 = xelement2 != null ? xelement2.Elements((XName) "Parameter").ToArray<XElement>() : (XElement[]) null;
        XElement xelement3 = t.Element((XName) "ParamsFromFile");
        XElement[] array2 = xelement3 != null ? xelement3.Elements((XName) "Parameter").ToArray<XElement>() : (XElement[]) null;
        return new
        {
          Title = str1,
          DSPTitle = str2,
          IsControllable = str3,
          IsBypassable = str4,
          ParamsUsed = array1,
          ParamsFromFile = array2
        };
      }).ToArray() : null;
    }
    \u003C\u003Ef__AnonymousType4<string, string, string, string, XElement[], XElement[]>[] dataArray2 = dataArray1;
    DSPCell[] DSPCells = new DSPCell[dataArray2.Length];
    for (int index = 0; index < dataArray2.Length; ++index)
    {
      DSPCells[index] = new DSPCell(dataArray2[index].Title)
      {
        DSPTitle = dataArray2[index].DSPTitle
      };
      bool result;
      if (!bool.TryParse(dataArray2[index].IsControllable, out result))
        return false;
      DSPCells[index].IsControllable = result;
      if (!bool.TryParse(dataArray2[index].IsBypassable, out result))
        return false;
      DSPCells[index].IsBypassable = result;
      DSPCellParameter[] Params;
      if (!Project.TryParseParams(dataArray2[index].ParamsUsed, out Params))
        return false;
      DSPCells[index].ParamsUsed = new List<DSPCellParameter>((IEnumerable<DSPCellParameter>) Params);
      if (!Project.TryParseParams(dataArray2[index].ParamsFromFile, out Params))
        return false;
      DSPCells[index].ParamsFromFile = new List<DSPCellParameter>((IEnumerable<DSPCellParameter>) Params);
    }
    Block.SetCells(DSPCells);
    return true;
  }

  private static bool TryParseParams(XElement[] ParamElements, out DSPCellParameter[] Params)
  {
    \u003C\u003Ef__AnonymousType5<string, string, string, string[]>[] array = ((IEnumerable<XElement>) ParamElements).Select(t =>
    {
      string str1 = t.Element((XName) "Name")?.Value;
      string str2 = t.Element((XName) "Address")?.Value;
      string str3 = t.Element((XName) "Size")?.Value;
      XElement xelement = t.Element((XName) "Data");
      string[] strArray;
      if (xelement == null)
      {
        strArray = (string[]) null;
      }
      else
      {
        string str4 = xelement.Value;
        if (str4 == null)
          strArray = (string[]) null;
        else
          strArray = ((IEnumerable<string>) str4.Split(";"[0])).ToArray<string>();
      }
      return new
      {
        Name = str1,
        Address = str2,
        Size = str3,
        Data = strArray
      };
    }).ToArray();
    Params = new DSPCellParameter[array.Length];
    for (int index = 0; index < array.Length; ++index)
    {
      Params[index] = new DSPCellParameter()
      {
        Name = array[index].Name
      };
      int Value;
      if (!int.TryParse(array[index].Address, out Value))
        return false;
      Params[index].Address = (ushort) Value;
      if (!int.TryParse(array[index].Size, out Value))
        return false;
      Params[index].Size = (ushort) Value;
      Params[index].Data = ((IEnumerable<string>) array[index].Data).Select<string, byte>((Func<string, byte>) (d => !int.TryParse(d, out Value) ? (byte) 0 : (byte) Value)).ToArray<byte>();
    }
    return true;
  }

  private static bool TryParseCtrlDelay(XElement Element, SchemaBlock_Controller Block)
  {
    bool result1;
    int result2;
    if (!bool.TryParse(Element.Element((XName) "Delay")?.Attribute((XName) "IsEnabled")?.Value, out result1) || !int.TryParse(Element.Element((XName) "Delay")?.Attribute((XName) "Index")?.Value, out result2))
      return false;
    Block.SetStartDelayParams(result1, result2);
    return true;
  }

  private static bool TryParseCtrlPixel(XElement Element, SchemaBlock_Controller Block)
  {
    XElement xelement = Element.Element((XName) "PixelLED");
    if (xelement != null)
    {
      bool result1;
      PixelModule.PixelTypes result2;
      bool result3;
      Block.PixelSettings = new PixelModule()
      {
        IsEnabled = bool.TryParse(xelement.Attribute((XName) "IsEnabled")?.Value, out result1) && result1,
        PixelType = PixelModule.TryParse(xelement.Attribute((XName) "Type")?.Value, out result2) ? result2 : PixelModule.PixelTypes.RGB,
        IsPwrOnEnabled = bool.TryParse(xelement.Attribute((XName) "IsPwrOn")?.Value, out result3) && result3
      };
    }
    return true;
  }

  private static bool TryParseCtrlCLI(XElement Element, SchemaBlock_Controller Block)
  {
    XElement xelement = Element.Element((XName) "CLI");
    if (xelement != null)
    {
      bool result;
      Block.CLISettings = new CLIModule()
      {
        IsEnabled = bool.TryParse(xelement.Attribute((XName) "IsEnabled")?.Value, out result) && result
      };
    }
    return true;
  }

  private static bool TryParseCtrlCEC(XElement Element, SchemaBlock_Controller Block)
  {
    XElement xelement = Element.Element((XName) "CEC");
    if (xelement != null)
    {
      bool result1;
      int result2;
      Block.CECSettings = new CEC()
      {
        IsEnabled = bool.TryParse(xelement.Element((XName) "IsEnabled")?.Value, out result1) && result1,
        PortNumber = int.TryParse(xelement.Element((XName) "Port")?.Value, out result2) ? result2 : 1,
        Name = xelement.Element((XName) "Name")?.Value,
        VolumeGpio = int.TryParse(xelement.Element((XName) "VolGpio")?.Value, out result2) ? result2 : 0,
        MuteGpio = int.TryParse(xelement.Element((XName) "MuteGpio")?.Value, out result2) ? result2 : 0,
        IsTVonEnabled = bool.TryParse(xelement.Element((XName) "TvOn")?.Value, out result1) && result1,
        IsTVoffEnabled = bool.TryParse(xelement.Element((XName) "TvOff")?.Value, out result1) && result1,
        IsAudioStatusEnabled = bool.TryParse(xelement.Element((XName) "AudioStatus")?.Value, out result1) && result1
      };
    }
    return true;
  }

  private static bool TryParseCtrlOptions(XElement Element, SchemaBlock_Controller Block)
  {
    XElement xelement = Element.Element((XName) "Options");
    if (xelement != null)
    {
      bool result;
      Block.Options = new ControllerOptions()
      {
        IsGenSelectionEnabled = bool.TryParse(xelement.Element((XName) "GenSelect")?.Value, out result) && result,
        IsFreqIndicationEnabled = bool.TryParse(xelement.Element((XName) "FreqIndication")?.Value, out result) && result,
        IsResIndicationEnabled = bool.TryParse(xelement.Element((XName) "ResIndication")?.Value, out result) && result,
        IsPwrKeyEnabled = bool.TryParse(xelement.Element((XName) "PwrKey")?.Value, out result) && result,
        IsFixProjectEnabled = bool.TryParse(xelement.Element((XName) "FixProject")?.Value, out result) && result
      };
    }
    return true;
  }

  private static bool TryParseCtrlMute(XElement Element, SchemaBlock_Controller Block)
  {
    XElement xelement = Element.Element((XName) "Mute");
    if (xelement != null)
    {
      int result1;
      Block.MuteIndex = int.TryParse(xelement.Attribute((XName) "Index")?.Value, out result1) ? result1 : 0;
      int result2;
      Block.MuteLevel = int.TryParse(xelement.Attribute((XName) "Level")?.Value, out result2) ? result2 : 0;
    }
    return true;
  }

  private static bool CommonProperties(XElement Element, SchemaBlock Block)
  {
    Block.Title = Element.Element((XName) "Title")?.Value;
    double Result1;
    double Result2;
    if (!Project.TryParseStringToDouble(Element.Element((XName) "Location")?.Attribute((XName) "X")?.Value, out Result1) || !Project.TryParseStringToDouble(Element.Element((XName) "Location")?.Attribute((XName) "Y")?.Value, out Result2))
      return false;
    Block.UpperLeftPoint = new System.Windows.Point(Result1, Result2);
    return true;
  }

  private static bool ExtractBlocks(
    UIElementCollection Schema,
    SchemaBlock.SchemaBlockTypes Type,
    out ISchemaElement[] Blocks)
  {
    Blocks = (ISchemaElement[]) Schema.OfType<SchemaBlock>().Where<SchemaBlock>((Func<SchemaBlock, bool>) (b => b.BlockType == Type)).ToArray<SchemaBlock>();
    return Blocks.Length != 0;
  }

  private static bool ExtractConnections(UIElementCollection Schema, out ISchemaElement[] Connects)
  {
    Connects = Schema.OfType<ISchemaElement>().Where<ISchemaElement>((Func<ISchemaElement, bool>) (e => e.ElementType == Shared.ElementTypeConnection)).ToArray<ISchemaElement>();
    return Connects.Length != 0;
  }

  private static XElement Controller(ISchemaElement Block)
  {
    return new XElement((XName) nameof (Controller), (object) new XElement((XName) nameof (Block), new object[2]
    {
      (object) Project.CommonElements((SchemaBlock) (Block as SchemaBlock_Controller)),
      (object) Project.ControllerSpecific(Block as SchemaBlock_Controller)
    }));
  }

  private static XElement DSPGroup(ISchemaElement[] Blocks)
  {
    return new XElement((XName) "DSP", (object[]) ((IEnumerable<ISchemaElement>) Blocks).Select<ISchemaElement, XElement>((Func<ISchemaElement, XElement>) (b => Project.DSPElement(b as SchemaBlock_DSP))).ToArray<XElement>());
  }

  private static XElement DSPElement(SchemaBlock_DSP Block)
  {
    return new XElement((XName) nameof (Block), new object[2]
    {
      (object) Project.CommonElements((SchemaBlock) Block),
      (object) Project.DSPSpecific(Block)
    });
  }

  private static XElement DSPCellGroup(ISchemaElement[] Blocks)
  {
    return new XElement((XName) "DSPCells", (object[]) ((IEnumerable<ISchemaElement>) Blocks).Select<ISchemaElement, XElement>((Func<ISchemaElement, XElement>) (b => Project.DSPCellElement(b as SchemaBlock_DSPCell))).ToArray<XElement>());
  }

  private static XElement DSPCellElement(SchemaBlock_DSPCell Block)
  {
    return new XElement((XName) nameof (Block), new object[2]
    {
      (object) Project.CommonElements((SchemaBlock) Block),
      (object) Project.DSPCellSpecific(Block)
    });
  }

  private static XElement LEDsGroup(ISchemaElement[] Blocks)
  {
    return new XElement((XName) "LEDs", (object[]) ((IEnumerable<ISchemaElement>) Blocks).Select<ISchemaElement, XElement>((Func<ISchemaElement, XElement>) (b => Project.LEDElement(b as SchemaBlock_LED))).ToArray<XElement>());
  }

  private static XElement LEDElement(SchemaBlock_LED Block)
  {
    return new XElement((XName) nameof (Block), new object[2]
    {
      (object) Project.CommonElements((SchemaBlock) Block),
      (object) Project.LEDSpecific(Block)
    });
  }

  private static XElement PixelLEDsGroup(ISchemaElement[] Blocks)
  {
    return new XElement((XName) "PixelLED", (object[]) ((IEnumerable<ISchemaElement>) Blocks).Select<ISchemaElement, XElement>((Func<ISchemaElement, XElement>) (b => Project.PexelLEDElement(b as SchemaBlock_PixelLED))).ToArray<XElement>());
  }

  private static XElement PexelLEDElement(SchemaBlock_PixelLED Block)
  {
    return new XElement((XName) nameof (Block), new object[2]
    {
      (object) Project.CommonElements((SchemaBlock) Block),
      (object) Project.PixelLEDSpecific(Block)
    });
  }

  private static XElement ReadsGroup(ISchemaElement[] Blocks)
  {
    return new XElement((XName) "Read", (object[]) ((IEnumerable<ISchemaElement>) Blocks).Select<ISchemaElement, XElement>((Func<ISchemaElement, XElement>) (b => Project.ReadElement(b as SchemaBlock_Read))).ToArray<XElement>());
  }

  private static XElement ReadElement(SchemaBlock_Read Block)
  {
    return new XElement((XName) nameof (Block), new object[2]
    {
      (object) Project.CommonElements((SchemaBlock) Block),
      (object) Project.ReadSpecific(Block)
    });
  }

  private static XElement ComparatorsGroup(ISchemaElement[] Blocks)
  {
    return new XElement((XName) "Comparator", (object[]) ((IEnumerable<ISchemaElement>) Blocks).Select<ISchemaElement, XElement>((Func<ISchemaElement, XElement>) (b => Project.ComparatorElement(b as SchemaBlock_Comparator))).ToArray<XElement>());
  }

  private static XElement CommentsGroup(ISchemaElement[] Blocks)
  {
    return new XElement((XName) "Comment", (object[]) ((IEnumerable<ISchemaElement>) Blocks).Select<ISchemaElement, XElement>((Func<ISchemaElement, XElement>) (b => Project.CommentElement(b as SchemaBlock_Comment))).ToArray<XElement>());
  }

  private static XElement ComparatorElement(SchemaBlock_Comparator Block)
  {
    return new XElement((XName) nameof (Block), new object[2]
    {
      (object) Project.CommonElements((SchemaBlock) Block),
      (object) Project.ComparatorSpecific(Block)
    });
  }

  private static XElement CommentElement(SchemaBlock_Comment Block)
  {
    return new XElement((XName) nameof (Block), new object[2]
    {
      (object) Project.CommonElements((SchemaBlock) Block),
      (object) Project.CommentSpecific(Block)
    });
  }

  private static XElement ConnectionsGroup(ISchemaElement[] Blocks)
  {
    return new XElement((XName) "Connections", (object[]) ((IEnumerable<ISchemaElement>) Blocks).Select<ISchemaElement, XElement>((Func<ISchemaElement, XElement>) (b => Project.ConnectionElement(b as Connection))).ToArray<XElement>());
  }

  private static XElement ConnectionElement(Connection Element)
  {
    return new XElement((XName) "Block", (object[]) Element.Nodes.Select<ConnectionNode, XElement>((Func<ConnectionNode, XElement>) (n => Project.NodeElement(n))).ToArray<XElement>());
  }

  private static XElement[] ControllerSpecific(SchemaBlock_Controller Block)
  {
    bool IsDelayActive;
    int DelayIndex;
    Block.GetStartDelayParams(out IsDelayActive, out DelayIndex);
    return new XElement[8]
    {
      new XElement((XName) "Module", (object) Block.Module),
      Project.CtrlGpioFuncs(Block.GetGPIOFunctions()),
      Project.CtrlDelay(IsDelayActive, DelayIndex),
      Project.CtrlPixel(Block.PixelSettings),
      Project.CtrlCLI(Block.CLISettings),
      Project.CtrlCEC(Block.CECSettings),
      Project.CtrlOptions(Block.Options),
      Project.CtrlMute(Block.MuteIndex, Block.MuteLevel)
    };
  }

  private static XElement[] DSPSpecific(SchemaBlock_DSP Block)
  {
    return new XElement[5]
    {
      new XElement((XName) "Module", (object) Block.Module),
      new XElement((XName) "BusAddress", (object) Block.GetBusAddress().ToString()),
      new XElement((XName) "SelfBooted", (object) Block.IsSelfBooted.ToString()),
      Project.DSPBoot(Block.GetBoot()),
      Project.DSPCells(Block.GetCells())
    };
  }

  private static XElement[] DSPCellSpecific(SchemaBlock_DSPCell Block)
  {
    return new XElement[3]
    {
      new XElement((XName) "DSP", (object) Block.DSPTitle),
      new XElement((XName) "RegulationData", (object) string.Join(";", ((IEnumerable<byte>) Block.GetData()).Select<byte, string>((Func<byte, string>) (d => d.ToString())))),
      new XElement((XName) "EnableData", (object) string.Join(";", ((IEnumerable<byte>) Block.GetEnData()).Select<byte, string>((Func<byte, string>) (d => d.ToString()))))
    };
  }

  private static XElement[] LEDSpecific(SchemaBlock_LED Block)
  {
    return new XElement[3]
    {
      new XElement((XName) "DSPMode", (object) Block.DSPMode.ToString()),
      new XElement((XName) "DSPCellIndex", (object) Block.GetDefaultBlockIndex().ToString()),
      new XElement((XName) "Data", (object) string.Join(";", ((IEnumerable<byte>) Block.GetData()).Select<byte, string>((Func<byte, string>) (d => d.ToString()))))
    };
  }

  private static XElement[] PixelLEDSpecific(SchemaBlock_PixelLED Block)
  {
    PixelLEDBlock settings = Block.Settings;
    return new XElement[6]
    {
      new XElement((XName) "LEDsCount", (object) settings.LEDsCount.ToString()),
      new XElement((XName) "StatesCount", (object) settings.StatesCount.ToString()),
      new XElement((XName) "IndicationType", (object) settings.IndicationType.ToString()),
      new XElement((XName) "IndicationMode", (object) settings.IndicationMode.ToString()),
      new XElement((XName) "DSPCellIndex", (object) Block.GetDefaultBlockIndex().ToString()),
      new XElement((XName) "Colors", (object) string.Join(";", Block.GetColors()))
    };
  }

  private static XElement[] ReadSpecific(SchemaBlock_Read Block)
  {
    return new XElement[4]
    {
      new XElement((XName) "DSP", (object) Block.DSPIndex.ToString()),
      new XElement((XName) "Address", (object) Block.GetAddressInput()),
      new XElement((XName) "BytesCount", (object) Block.GetBytesCountInput()),
      new XElement((XName) "Period", (object) Block.PeriodIndex.ToString())
    };
  }

  private static XElement[] ComparatorSpecific(SchemaBlock_Comparator Block)
  {
    return new XElement[3]
    {
      new XElement((XName) "Mask", (object) Block.GetMaskInput()),
      new XElement((XName) "Value", (object) Block.GetValueInput()),
      new XElement((XName) "Mode", (object) Block.Mode)
    };
  }

  private static XElement[] CommentSpecific(SchemaBlock_Comment Block)
  {
    return new XElement[1]
    {
      new XElement((XName) "Value", (object) Block.Comment)
    };
  }

  private static XElement CtrlGpioFuncs(byte[] Funcs)
  {
    return new XElement((XName) "GpioFuncs", (object) string.Join(";", ((IEnumerable<byte>) Funcs).Select<byte, string>((Func<byte, string>) (v => v.ToString()))));
  }

  private static XElement CtrlDelay(bool IsActive, int Index)
  {
    return new XElement((XName) "Delay", new object[2]
    {
      (object) new XAttribute((XName) "IsEnabled", (object) IsActive.ToString()),
      (object) new XAttribute((XName) nameof (Index), (object) Index.ToString())
    });
  }

  private static XElement CtrlPixel(PixelModule Settings)
  {
    if (Settings == null)
      return (XElement) null;
    return new XElement((XName) "PixelLED", new object[3]
    {
      (object) new XAttribute((XName) "IsEnabled", (object) Settings.IsEnabled.ToString()),
      (object) new XAttribute((XName) "Type", (object) Settings.PixelType.ToString()),
      (object) new XAttribute((XName) "IsPwrOn", (object) Settings.IsPwrOnEnabled.ToString())
    });
  }

  private static XElement CtrlCLI(CLIModule Settings)
  {
    return Settings == null ? (XElement) null : new XElement((XName) "CLI", (object) new XAttribute((XName) "IsEnabled", (object) Settings.IsEnabled.ToString()));
  }

  private static XElement CtrlCEC(CEC Settings)
  {
    if (Settings == null)
      return (XElement) null;
    return new XElement((XName) "CEC", new object[8]
    {
      (object) new XElement((XName) "IsEnabled", (object) Settings.IsEnabled.ToString()),
      (object) new XElement((XName) "Port", (object) Settings.PortNumber.ToString()),
      (object) new XElement((XName) "Name", (object) Settings.Name),
      (object) new XElement((XName) "VolGpio", (object) Settings.VolumeGpio.ToString()),
      (object) new XElement((XName) "MuteGpio", (object) Settings.MuteGpio.ToString()),
      (object) new XElement((XName) "TvOn", (object) Settings.IsTVonEnabled.ToString()),
      (object) new XElement((XName) "TvOff", (object) Settings.IsTVoffEnabled.ToString()),
      (object) new XElement((XName) "AudioStatus", (object) Settings.IsAudioStatusEnabled.ToString())
    });
  }

  private static XElement CtrlOptions(ControllerOptions Settings)
  {
    if (Settings == null)
      return (XElement) null;
    return new XElement((XName) "Options", new object[5]
    {
      (object) new XElement((XName) "GenSelect", (object) Settings.IsGenSelectionEnabled.ToString()),
      (object) new XElement((XName) "FreqIndication", (object) Settings.IsFreqIndicationEnabled.ToString()),
      (object) new XElement((XName) "ResIndication", (object) Settings.IsResIndicationEnabled.ToString()),
      (object) new XElement((XName) "PwrKey", (object) Settings.IsPwrKeyEnabled.ToString()),
      (object) new XElement((XName) "FixProject", (object) Settings.IsFixProjectEnabled.ToString())
    });
  }

  private static XElement CtrlMute(int Index, int Level)
  {
    if (Index == -1)
      return (XElement) null;
    return new XElement((XName) "Mute", new object[2]
    {
      (object) new XAttribute((XName) nameof (Index), (object) Index.ToString()),
      (object) new XAttribute((XName) nameof (Level), (object) Level.ToString())
    });
  }

  private static XElement DSPBoot(List<DataTransfer> TXs)
  {
    return new XElement((XName) "Boot", (object[]) TXs.Select<DataTransfer, XElement>((Func<DataTransfer, XElement>) (t => Project.TxElement(t))).ToArray<XElement>());
  }

  private static XElement DSPCells(List<DSPCell> Cells)
  {
    return new XElement((XName) nameof (Cells), (object[]) Cells.Select<DSPCell, XElement>((Func<DSPCell, XElement>) (s => Project.CellElement(s))).ToArray<XElement>());
  }

  private static XElement TxElement(DataTransfer TX)
  {
    return new XElement((XName) "Transfer", new object[5]
    {
      (object) new XElement((XName) "Type", (object) TX.Type.ToString()),
      (object) new XElement((XName) "Address", (object) TX.Address.ToString()),
      (object) new XElement((XName) "AddrIncr", (object) TX.AddressIncrement.ToString()),
      (object) new XElement((XName) "Size", (object) TX.Size.ToString()),
      (object) new XElement((XName) "Data", (object) string.Join(";", ((IEnumerable<byte>) TX.Data).Select<byte, string>((Func<byte, string>) (d => d.ToString()))))
    });
  }

  private static XElement CellElement(DSPCell Cell)
  {
    return new XElement((XName) nameof (Cell), new object[6]
    {
      (object) new XElement((XName) "Title", (object) Cell.Title),
      (object) new XElement((XName) "DSP", (object) Cell.DSPTitle),
      (object) new XElement((XName) "IsControllable", (object) Cell.IsControllable.ToString()),
      (object) new XElement((XName) "IsBypassable", (object) Cell.IsBypassable.ToString()),
      (object) new XElement((XName) "ParamsUsed", (object[]) Cell.ParamsUsed.Select<DSPCellParameter, XElement>((Func<DSPCellParameter, XElement>) (p => Project.ParamElement(p))).ToArray<XElement>()),
      (object) new XElement((XName) "ParamsFromFile", (object[]) Cell.ParamsFromFile.Select<DSPCellParameter, XElement>((Func<DSPCellParameter, XElement>) (p => Project.ParamElement(p))).ToArray<XElement>())
    });
  }

  private static XElement ParamElement(DSPCellParameter Param)
  {
    return new XElement((XName) "Parameter", new object[4]
    {
      (object) new XElement((XName) "Name", (object) Param.Name),
      (object) new XElement((XName) "Address", (object) Param.Address.ToString()),
      (object) new XElement((XName) "Size", (object) Param.Size.ToString()),
      (object) new XElement((XName) "Data", (object) string.Join(";", ((IEnumerable<byte>) Param.Data).Select<byte, string>((Func<byte, string>) (d => d.ToString()))))
    });
  }

  private static XElement NodeElement(ConnectionNode Node)
  {
    return new XElement((XName) nameof (Node), new object[4]
    {
      (object) new XElement((XName) "Name", (object) Node.BlockName),
      (object) new XElement((XName) "Number", (object) Node.AnchorNumber.ToString()),
      (object) new XElement((XName) "Type", (object) Node.AnchorType.ToString()),
      (object) new XElement((XName) "Location", new object[2]
      {
        (object) new XAttribute((XName) "X", (object) Project.ParseDoubleToString(Node.AnchorPoint.X)),
        (object) new XAttribute((XName) "Y", (object) Project.ParseDoubleToString(Node.AnchorPoint.Y))
      })
    });
  }

  private static XElement[] CommonElements(SchemaBlock Block)
  {
    return new XElement[2]
    {
      new XElement((XName) "Title", (object) Block.Title),
      new XElement((XName) "Location", new object[2]
      {
        (object) new XAttribute((XName) "X", (object) Project.ParseDoubleToString(Block.UpperLeftPoint.X)),
        (object) new XAttribute((XName) "Y", (object) Project.ParseDoubleToString(Block.UpperLeftPoint.Y))
      })
    };
  }

  private static bool TryParseStringToDouble(string Input, out double Result)
  {
    return double.TryParse(Input, NumberStyles.Float, (IFormatProvider) Project.NumericStringCulture, out Result);
  }

  private static string ParseDoubleToString(double Value)
  {
    return Value.ToString((IFormatProvider) Project.NumericStringCulture);
  }

  private static bool OpenOldFormat(string FilePath, out ISchemaElement[] SchElements)
  {
    SchElements = (ISchemaElement[]) null;
    List<ISchemaElement> Elements;
    if (!OldFormatProject.Open(FilePath, out Elements))
      return false;
    SchElements = Elements.ToArray();
    Project.SaveBackupCopy(FilePath);
    return true;
  }

  private static void SaveBackupCopy(string FilePath)
  {
    string destFileName = FilePath.Insert(FilePath.IndexOf(".cspro"), "_backup");
    File.Copy(FilePath, destFileName, true);
  }
}
