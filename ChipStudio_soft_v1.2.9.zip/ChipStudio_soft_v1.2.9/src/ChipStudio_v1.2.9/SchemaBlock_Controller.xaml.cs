﻿// Decompiled with JetBrains decompiler
// Type: ChipStudio.SchemaBlock_Controller
// Assembly: ChipStudio, Version=1.2.9.0, Culture=neutral, PublicKeyToken=null
// MVID: 334E3BEA-37C7-4274-8118-535AAEFA1546
// Assembly location: D:\DocAndSec\Desktop\AUDIO\ChipDip\ChipStudio_soft_v1.2.9\ChipStudio_v1.2.9.exe

using System;
using System.CodeDom.Compiler;
using System.Collections;
using System.ComponentModel;
using System.Diagnostics;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Controls.Primitives;
using System.Windows.Input;
using System.Windows.Markup;
using System.Windows.Media;

#nullable disable
namespace ChipStudio;

public partial class SchemaBlock_Controller : SchemaBlock, IComponentConnector
{
  private static readonly string[] MUTE_ACTIVE_LEVELS = new string[2]
  {
    "LOW",
    "HIGH"
  };
  private const int DELAY_INDEX_DEFAULT = 3;
  private const int MUTE_INDEX_DEFAULT = 1;
  private const int MUTE_LEVEL_INDEX_DEFAULT = 0;
  private readonly Controller CtrlDev;
  internal GroupBox GpioIBox;
  internal ItemsControl GPIOInterfacesItems;
  internal ItemsControl DSPInterfacesItems;
  internal CheckBox StartDelayCheck;
  internal ComboBox StartDelaySelector;
  internal GroupBox MutePanel;
  internal ComboBox MuteSelector;
  internal ComboBox MuteLevelSelector;
  internal Button CECButton;
  internal Button OptionsButton;
  internal ItemsControl GPIOsItems;
  internal StackPanel PixelPanel;
  internal ItemsControl PixelsItems;
  internal StackPanel CLIPanel;
  internal ItemsControl CLIItems;
  internal TextBlock BlockName;
  private bool _contentLoaded;

  public bool IsReady => this.CtrlDev.IsLoaded;

  public string Module { get; }

  public ushort USBPacketSize => this.CtrlDev.USBPacketSize;

  public override byte CoreID => this.CtrlDev.ID;

  public byte DownLoadAPI => this.CtrlDev.DownLoadAPI;

  public int ProjectMemorySize => this.CtrlDev.ProjectMemorySize;

  public override SchemaBlock.SchemaBlockTypes BlockType => SchemaBlock.SchemaBlockTypes.Controller;

  public PixelModule PixelSettings
  {
    get => this.CtrlDev.GetPixelSettings();
    set => this.CtrlDev.SetPixelSettings(value);
  }

  public CLIModule CLISettings
  {
    get => this.CtrlDev.GetCLISettings();
    set => this.CtrlDev.SetCLISettings(value);
  }

  public CEC CECSettings
  {
    get => this.CtrlDev.GetCECSettings();
    set => this.CtrlDev.SetCECSettings(value);
  }

  public ControllerOptions Options
  {
    get => this.CtrlDev.GetOptions();
    set => this.CtrlDev.SetOptions(value);
  }

  public int MuteIndex
  {
    get => this.MuteSelector.SelectedIndex;
    set
    {
      if (this.CtrlDev.MuteValues != null)
        this.MuteSelector.SelectedIndex = value < this.CtrlDev.MuteValues.Length ? value : 0;
      else
        this.MuteSelector.SelectedIndex = -1;
    }
  }

  public int MuteLevel
  {
    get => this.MuteLevelSelector.SelectedIndex;
    set
    {
      this.MuteLevelSelector.SelectedIndex = value < SchemaBlock_Controller.MUTE_ACTIVE_LEVELS.Length ? value : 0;
    }
  }

  public bool AreUSBSetsSupported => this.CtrlDev.AreUSBSetsSupported;

  public string[] AudioDescription => this.CtrlDev.GetAudioConfiguration();

  public SchemaBlock_Controller(string moduletype)
  {
    this.InitializeComponent();
    this.DataContext = (object) this;
    this.Module = moduletype;
    this.CtrlDev = new Controller((IDDController) new DDControllerXml(this.Module));
    if (!this.CtrlDev.IsLoaded)
      return;
    this.GPIOsItems.ItemsSource = (IEnumerable) this.CtrlDev.GPIOsGroup;
    this.GPIOInterfacesItems.ItemsSource = (IEnumerable) this.CtrlDev.GPIOIGroup;
    this.DSPInterfacesItems.ItemsSource = (IEnumerable) this.CtrlDev.DSPIGroup;
    if (this.CtrlDev.IsPixelSupported)
    {
      this.PixelPanel.Visibility = Visibility.Visible;
      this.PixelsItems.ItemsSource = (IEnumerable) this.CtrlDev.PixelGroup;
    }
    if (this.CtrlDev.IsCLISupported)
    {
      this.CLIPanel.Visibility = Visibility.Visible;
      this.CLIItems.ItemsSource = (IEnumerable) this.CtrlDev.CLIGroup;
    }
    if (this.CtrlDev.IsCECSupported)
      this.CECButton.Visibility = Visibility.Visible;
    if (this.CtrlDev.AreOptionsSupported)
      this.OptionsButton.Visibility = Visibility.Visible;
    this.CtrlDev.SetGpioClickAction(new Anchor.AnchorConnectionEventHandler(((SchemaBlock) this).ConnectionPoint_LeftButtonDown));
    this.StartDelaySelector.ItemsSource = (IEnumerable) this.CtrlDev.DelayValues;
    this.StartDelaySelector.SelectedIndex = 3;
    if (this.CtrlDev.MuteValues == null)
      return;
    this.MuteSelector.ItemsSource = (IEnumerable) this.CtrlDev.MuteValues;
    this.MuteSelector.SelectedIndex = 1;
    this.MuteLevelSelector.ItemsSource = (IEnumerable) SchemaBlock_Controller.MUTE_ACTIVE_LEVELS;
    this.MuteLevelSelector.SelectedIndex = 0;
    this.MutePanel.Visibility = Visibility.Visible;
  }

  public override void UpdateConnectionPoints()
  {
    if (!(this.Parent is Visual parent))
      return;
    this.CtrlDev.UpdateGpioPoints(parent);
  }

  public override ConnectionNode GetAnchorConnectionNode(int AnchorNumber)
  {
    GPIO line = this.CtrlDev.GetLine(AnchorNumber);
    return line == null ? (ConnectionNode) null : new ConnectionNode(this.FullName, AnchorNumber, line.ConnectionPoint.RelativeCenter, line.ConnectionPoint.Type);
  }

  public ConnectionNode GetCLIConnectionNode()
  {
    GPIO cliLine = this.CtrlDev.GetCLILine();
    return cliLine == null ? (ConnectionNode) null : new ConnectionNode(this.FullName, cliLine.ConnectionPoint.Number, cliLine.ConnectionPoint.RelativeCenter, cliLine.ConnectionPoint.Type);
  }

  public override void ApplyFilter(ConnectionNode Node)
  {
    if (this.FullName != Node.BlockName)
      this.CtrlDev.ApplyGpioFilter(Node.AnchorType);
    else
      this.CtrlDev.ApplyGpioFilter(Node.AnchorNumber);
  }

  public override void DiscardFilter() => this.CtrlDev.DiscardGpioFilter();

  public byte[] GetGPIOFunctions() => this.CtrlDev.GPIOsFunctionsGet();

  public void SetGPIOFunctions(int[] FuncList) => this.CtrlDev.GPIOsFunctionsSet(FuncList);

  public bool[] GetGPIOsActivity() => this.CtrlDev.GetActiveRegGPIOs();

  public byte GetInterfaceNum(byte GpioNum) => this.CtrlDev.InterfaceNumber(GpioNum);

  public void SetBootGpios(int BootType, int BootGpioCount)
  {
  }

  public void GetStartDelay(out int TimPSC, out int TimARR)
  {
    TimPSC = this.CtrlDev.DelayTimPSC(this.StartDelaySelector.SelectedIndex);
    TimARR = this.CtrlDev.DelayTimARR(this.StartDelaySelector.SelectedIndex);
  }

  public void GetStartDelayParams(out bool IsDelayActive, out int DelayIndex)
  {
    DelayIndex = this.StartDelaySelector.SelectedIndex;
    bool? isChecked = this.StartDelayCheck.IsChecked;
    bool flag = true;
    if (isChecked.GetValueOrDefault() == flag & isChecked.HasValue)
      IsDelayActive = true;
    else
      IsDelayActive = false;
  }

  public void SetStartDelayParams(bool IsDelayActive, int DelayIndex)
  {
    this.StartDelaySelector.SelectedIndex = DelayIndex;
    this.StartDelayCheck.IsChecked = new bool?(IsDelayActive);
  }

  public void GetMuteTimParams(out int TimPSC, out int TimARR)
  {
    TimPSC = this.CtrlDev.MuteTimPSC(this.MuteSelector.SelectedIndex);
    TimARR = this.CtrlDev.MuteTimARR(this.MuteSelector.SelectedIndex);
  }

  private void EnableStreamLR()
  {
  }

  private void EnableStreamBCLK()
  {
  }

  protected override void Dispose(bool disposing)
  {
  }

  private void EditPixelModule_Click(object sender, RoutedEventArgs e)
  {
    PixelModuleSettings pixelModuleSettings = new PixelModuleSettings(this.PixelSettings);
    bool? nullable = pixelModuleSettings.ShowDialog();
    bool flag = true;
    if (!(nullable.GetValueOrDefault() == flag & nullable.HasValue))
      return;
    this.PixelSettings = pixelModuleSettings.Settings;
  }

  private void EditCLIModule_Click(object sender, RoutedEventArgs e)
  {
    CLIModuleSettings cliModuleSettings = new CLIModuleSettings(this.CLISettings);
    bool? nullable = cliModuleSettings.ShowDialog();
    bool flag = true;
    if (!(nullable.GetValueOrDefault() == flag & nullable.HasValue))
      return;
    this.CLISettings = cliModuleSettings.Settings;
  }

  private void CECButton_Click(object sender, RoutedEventArgs e)
  {
    CECModuleSettings cecModuleSettings = new CECModuleSettings(this.CECSettings, this.CtrlDev.GPIOsGroup.Length);
    bool? nullable = cecModuleSettings.ShowDialog();
    bool flag = true;
    if (!(nullable.GetValueOrDefault() == flag & nullable.HasValue))
      return;
    this.CECSettings = cecModuleSettings.Settings;
  }

  private void OptionsButton_Click(object sender, RoutedEventArgs e)
  {
    ControllerOptionSettings controllerOptionSettings = new ControllerOptionSettings(this.Options, this.CtrlDev.SupportedOptions);
    bool? nullable = controllerOptionSettings.ShowDialog();
    bool flag = true;
    if (!(nullable.GetValueOrDefault() == flag & nullable.HasValue))
      return;
    this.Options = controllerOptionSettings.Settings;
  }

  [DebuggerNonUserCode]
  [GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
  public void InitializeComponent()
  {
    if (this._contentLoaded)
      return;
    this._contentLoaded = true;
    Application.LoadComponent((object) this, new Uri("/ChipStudio;component/schemablock_controller.xaml", UriKind.Relative));
  }

  [DebuggerNonUserCode]
  [GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
  [EditorBrowsable(EditorBrowsableState.Never)]
  void IComponentConnector.Connect(int connectionId, object target)
  {
    switch (connectionId)
    {
      case 1:
        ((UIElement) target).MouseLeftButtonDown += new MouseButtonEventHandler(((SchemaBlock) this).Border_MouseLeftButtonDown);
        break;
      case 2:
        this.GpioIBox = (GroupBox) target;
        break;
      case 3:
        this.GPIOInterfacesItems = (ItemsControl) target;
        break;
      case 4:
        this.DSPInterfacesItems = (ItemsControl) target;
        break;
      case 5:
        this.StartDelayCheck = (CheckBox) target;
        break;
      case 6:
        this.StartDelaySelector = (ComboBox) target;
        break;
      case 7:
        this.MutePanel = (GroupBox) target;
        break;
      case 8:
        this.MuteSelector = (ComboBox) target;
        break;
      case 9:
        this.MuteLevelSelector = (ComboBox) target;
        break;
      case 10:
        this.CECButton = (Button) target;
        this.CECButton.Click += new RoutedEventHandler(this.CECButton_Click);
        break;
      case 11:
        this.OptionsButton = (Button) target;
        this.OptionsButton.Click += new RoutedEventHandler(this.OptionsButton_Click);
        break;
      case 12:
        this.GPIOsItems = (ItemsControl) target;
        break;
      case 13:
        this.PixelPanel = (StackPanel) target;
        break;
      case 14:
        ((ButtonBase) target).Click += new RoutedEventHandler(this.EditPixelModule_Click);
        break;
      case 15:
        this.PixelsItems = (ItemsControl) target;
        break;
      case 16 /*0x10*/:
        this.CLIPanel = (StackPanel) target;
        break;
      case 17:
        ((ButtonBase) target).Click += new RoutedEventHandler(this.EditCLIModule_Click);
        break;
      case 18:
        this.CLIItems = (ItemsControl) target;
        break;
      case 19:
        this.BlockName = (TextBlock) target;
        break;
      default:
        this._contentLoaded = true;
        break;
    }
  }
}
