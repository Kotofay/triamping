﻿// Decompiled with JetBrains decompiler
// Type: ChipStudio.MainWindow
// Assembly: ChipStudio, Version=1.2.9.0, Culture=neutral, PublicKeyToken=null
// MVID: 334E3BEA-37C7-4274-8118-535AAEFA1546
// Assembly location: D:\DocAndSec\Desktop\AUDIO\ChipDip\ChipStudio_soft_v1.2.9\ChipStudio_v1.2.9.exe

using System;
using System.CodeDom.Compiler;
using System.Collections.Generic;
using System.ComponentModel;
using System.Diagnostics;
using System.IO;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Controls.Primitives;
using System.Windows.Input;
using System.Windows.Markup;
using System.Windows.Threading;

#nullable disable
namespace ChipStudio;

public partial class MainWindow : Window, INotifyPropertyChanged, IComponentConnector
{
  private static readonly string FileFilter = (string) Application.Current.FindResource((object) "StudioFileFilter");
  private static readonly string ComboProjFilter = (string) Application.Current.FindResource((object) "StudioComboProjFilter");
  private static readonly string WindowBaseTitle = (string) Application.Current.FindResource((object) nameof (WindowBaseTitle));
  private const string FileReadingError = "Error reading file";
  private const string FileDoesnotExistInfoHeader = "File does not exist";
  private const string RecentProjectsString = "RecentProjects";
  private const string ProjectIgnoredString = "Project will be ignored.";
  private const string BuildingProcess = "Building projects...";
  private const string DownloadingProcess = "Downloading...";
  private Project UserProject;
  private ComboProject UserComboProject;
  private readonly ProgressWindow ProgressBar;
  private bool combomode;
  private readonly DispatcherTimer ProgressBarTimer = new DispatcherTimer();
  private readonly RecentFiles RecentProjects = new RecentFiles(nameof (RecentProjects));
  internal MenuItem RecentProjMenu;
  internal ModulePanel HWModules;
  internal Schema SchemaField;
  internal TreeView DSPCellsTree;
  internal ComboProjectSettings ComboProjView;
  private bool _contentLoaded;

  public bool ComboMode
  {
    get => this.combomode;
    set
    {
      if (this.combomode == value)
        return;
      this.combomode = value;
      this.NotifyPropertyChanged(nameof (ComboMode));
    }
  }

  public MainWindow()
  {
    this.InitializeComponent();
    this.DataContext = (object) this;
    this.ProgressBar = new ProgressWindow()
    {
      Minimum = 0.0,
      Maximum = 100.0,
      Progress = 0.0
    };
    this.ProgressBarTimer.Interval = TimeSpan.FromMilliseconds(1.0);
    this.SchemaField.SetDSPCellsView(this.DSPCellsTree);
    this.SchemaField.SetControllerAddedCallback(new Action(this.ControllerAddedToSchema));
    this.ComboProjView.SetChangeComboPartCallBack(new Func<string, string>(this.OpenComboPartProject));
    this.ComboProjView.SetClearComboPartCallBack(new Action(this.NewProjectPrepare));
    this.HWModules.SetDragDropAction(new MouseButtonEventHandler(this.ModuleItem_MouseLeftButtonDown));
    ControllerDriver.SetDownLoadActions(new Action<double>(this.ShowProcessProgress), new Action<bool>(this.ProcessFinished), new Action<string>(this.SetProcessDescription));
    this.UpdateRecentProjects();
  }

  private void ModuleItem_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
  {
    this.SchemaField.DragDropBlock(e);
  }

  private void ControllerAddedToSchema() => this.UpdateControllerBootGpios();

  private void UpdateRecentProjects()
  {
    this.RecentProjMenu.Items.Clear();
    foreach (string str in this.RecentProjects.Get())
    {
      MenuItem menuItem = new MenuItem();
      menuItem.Header = (object) str;
      MenuItem newItem = menuItem;
      newItem.Click += new RoutedEventHandler(this.OpenRecentProject_Click);
      this.RecentProjMenu.Items.Add((object) newItem);
    }
  }

  private void SaveProject_Click(object sender, ExecutedRoutedEventArgs e) => this.SaveProject();

  private void SaveProjectAs_Click(object sender, RoutedEventArgs e)
  {
    this.UserProject = (Project) null;
    this.SaveProject();
  }

  private void OpenProject_Click(object sender, ExecutedRoutedEventArgs e)
  {
    this.OpenProject_Action();
  }

  private void OpenRecentProject_Click(object sender, RoutedEventArgs e)
  {
    string str = (sender as MenuItem).Header.ToString();
    if (File.Exists(str))
    {
      this.OpenProject(str);
    }
    else
    {
      int num = (int) MessageBox.Show("File was deleted or replaced", "", MessageBoxButton.OK, MessageBoxImage.Hand);
      this.RecentProjects.Delete(str);
      this.UpdateRecentProjects();
    }
  }

  private bool OpenProject_Action()
  {
    string str = FileDialog.Open(MainWindow.FileFilter);
    if (str == null)
      return false;
    this.OpenProject(str);
    if (this.ComboMode)
    {
      this.ComboProjView.SetComboPart(str);
      this.ComboProjView.CurrentPartProject = str;
    }
    return true;
  }

  private void OpenProject(string ProjectName)
  {
    this.UserProject = new Project(ProjectName);
    ISchemaElement[] Elements;
    if (this.UserProject.Open(out Elements))
    {
      this.ChangeWindowTitle(ProjectName);
      this.ClearProjectField();
      this.SchemaField.AddElements(Elements);
      this.UpdateControllerBootGpios();
      this.RecentProjects.Add(ProjectName);
      this.UpdateRecentProjects();
    }
    else
    {
      int num = (int) MessageBox.Show("Error reading file", "", MessageBoxButton.OK, MessageBoxImage.Hand);
    }
  }

  private void ImportComboProject_Click(object sender, RoutedEventArgs e)
  {
    string path = FileDialog.Open(MainWindow.ComboProjFilter);
    if (path == null)
      return;
    this.UserComboProject = new ComboProject(path);
    ComboProjectParameters projectParameters = new ComboProjectParameters();
    List<ComboProjectPart> comboProjectPartList = new List<ComboProjectPart>();
    if (this.UserComboProject.Open(projectParameters, comboProjectPartList))
    {
      int startIndex = path.LastIndexOf(Shared.FilePathSlash);
      string[] files = Directory.GetFiles(path.Remove(startIndex), "*.cspro");
      for (int index = 0; index < comboProjectPartList.Count; ++index)
      {
        if (comboProjectPartList[index].Name != null)
        {
          int num1 = comboProjectPartList[index].Name.LastIndexOf(Shared.FilePathSlash);
          string str1 = comboProjectPartList[index].Name.Substring(num1 + 1);
          foreach (string str2 in files)
          {
            int num2 = str2.LastIndexOf(Shared.FilePathSlash);
            string str3 = str2.Substring(num2 + 1);
            if (str1 == str3)
            {
              comboProjectPartList[index].Name = str2;
              break;
            }
          }
        }
      }
      this.ComboMode = true;
      this.ComboProjView.Init(projectParameters, comboProjectPartList);
      this.ComboProjView.ComboProject = path;
      this.UserComboProject.Save(projectParameters, comboProjectPartList);
      int num = (int) MessageBox.Show("ComboProject has been opened successfully", "", MessageBoxButton.OK, MessageBoxImage.Asterisk);
    }
    else
    {
      int num3 = (int) MessageBox.Show("Error reading file", "", MessageBoxButton.OK, MessageBoxImage.Hand);
    }
  }

  private void NewProject_Click(object sender, ExecutedRoutedEventArgs e)
  {
    this.NewProjectPrepare();
  }

  private void NewComboProject_Click(object sender, RoutedEventArgs e)
  {
    this.ComboProjView.Reset();
    this.ComboMode = true;
    this.NewProjectPrepare();
  }

  private void NewProjectPrepare()
  {
    this.Title = MainWindow.WindowBaseTitle;
    this.UserProject = (Project) null;
    this.ClearProjectField();
  }

  private void SaveProject()
  {
    if (this.UserProject == null)
      this.CreateNewProject();
    if (this.UserProject == null)
      return;
    this.UserProject.Save(this.SchemaField.GetElements());
    this.RecentProjects.Add(this.UserProject.Path);
    this.UpdateRecentProjects();
    if (!this.ComboMode)
      return;
    this.ComboProjView.SetComboPart(this.UserProject.Path);
    this.ComboProjView.CurrentPartProject = this.UserProject.Path;
  }

  private void SaveComboProject_Click(object sender, RoutedEventArgs e) => this.SaveComboProject();

  private void SaveComboProjectAs_Click(object sender, RoutedEventArgs e)
  {
    this.UserComboProject = (ComboProject) null;
    this.SaveComboProject();
  }

  private void SaveComboProject()
  {
    if (this.UserComboProject == null)
      this.CreateNewComboProject();
    if (this.UserComboProject == null)
      return;
    this.UserComboProject.Save(this.ComboProjView.GetParams(), this.ComboProjView.Projects);
  }

  private void ClearProjectField()
  {
    this.SchemaField.Clear();
    if (!this.ComboMode)
      return;
    this.ComboProjView.CurrentPartProject = "";
  }

  private void DownloadButton_Click(object sender, RoutedEventArgs e)
  {
    this.SetProcessDescription("Building projects...");
    this.ShowProcessInit();
    this.ProgressBarTimer.Tick += new EventHandler(this.ProgressBarTimer_DownloadProject);
    this.ProgressBarTimer.Start();
  }

  private void ProgressBarTimer_DownloadProject(object sender, EventArgs e)
  {
    this.ProgressBarTimer.Stop();
    this.ProgressBarTimer.Tick -= new EventHandler(this.ProgressBarTimer_DownloadProject);
    List<byte> image = new List<byte>();
    int PacketSize;
    int ApiVersion;
    if (this.CanDownloadBeStarted(out PacketSize, out ApiVersion) && BootImage.MakeForProject(this.SchemaField.GetElements(), out image) && this.CheckImageSize((double) image.Count) && ControllerDriver.DownloadStart(image, PacketSize, 0, ApiVersion))
      return;
    this.ProcessFinished(false);
  }

  private void ShowProcessInit()
  {
    this.ProgressBar.Progress = 0.0;
    this.ProgressBar.Owner = (Window) this;
    this.ProgressBar.Show();
  }

  private void ShowProcessProgress(double progress) => this.ProgressBar.Progress = progress;

  private void ProcessFinished(bool Result)
  {
    this.ProgressBar.Hide();
    ControllerDriver.CloseDevice();
    if (!Result)
      return;
    int num = (int) MessageBox.Show("Download has been completed successfully", "", MessageBoxButton.OK, MessageBoxImage.Asterisk);
  }

  private void SetProcessDescription(string description)
  {
    this.ProgressBar.Description = description;
  }

  private void CreateNewProject()
  {
    string str = FileDialog.Save(MainWindow.FileFilter);
    if (str == null)
      return;
    this.UserProject = new Project(str);
    this.ChangeWindowTitle(str);
  }

  private void CreateNewComboProject()
  {
    string path = FileDialog.Save(MainWindow.ComboProjFilter);
    if (path == null)
      return;
    this.UserComboProject = new ComboProject(path);
  }

  private void ChangeWindowTitle(string ProjectTitle)
  {
    this.Title = $"{ProjectTitle} - {MainWindow.WindowBaseTitle}";
  }

  private void WindowIsClosing(object sender, CancelEventArgs e)
  {
    this.ProgressBar.Close();
    this.RecentProjects.Save();
  }

  private void About_Click(object sender, RoutedEventArgs e) => new AboutWindow().ShowDialog();

  private void ComboModeButton_Checked(object sender, RoutedEventArgs e)
  {
    if (this.SchemaField.GetController() == null || this.UserProject == null)
      return;
    this.OpenProject(this.UserProject.Path);
  }

  private string OpenComboPartProject(string ProjectPath)
  {
    if (this.ComboMode)
    {
      bool flag = false;
      if (ProjectPath != null)
      {
        if (File.Exists(ProjectPath))
        {
          this.OpenProject(ProjectPath);
          this.ComboProjView.CurrentPartProject = ProjectPath;
          flag = true;
        }
        else
        {
          switch (MessageBox.Show("File does not exist. Do you want to replace project?\n\r" + ProjectPath, "File does not exist", MessageBoxButton.YesNo, MessageBoxImage.Hand))
          {
            case MessageBoxResult.Yes:
              if (this.OpenProject_Action())
              {
                flag = true;
                break;
              }
              ProjectPath = (string) null;
              break;
            case MessageBoxResult.No:
              ProjectPath = (string) null;
              break;
          }
          this.SaveComboProject();
        }
      }
      if (!flag)
      {
        this.NewProjectPrepare();
        this.ComboProjView.CurrentPartProject = "";
      }
    }
    return ProjectPath;
  }

  private void UpdateControllerBootGpios()
  {
    SchemaBlock_Controller controller = this.SchemaField.GetController();
    if (controller == null || !this.ComboMode)
      return;
    controller.SetBootGpios(this.ComboProjView.ComboType, this.ComboProjView.BootLinesCount);
  }

  private void DownLoadComboButton_Click(object sender, RoutedEventArgs e)
  {
    this.SetProcessDescription("Building projects...");
    this.ShowProcessInit();
    this.ProgressBarTimer.Tick += new EventHandler(this.ProgressBarTimer_DownloadCombo);
    this.ProgressBarTimer.Start();
  }

  private void ProgressBarTimer_DownloadCombo(object sender, EventArgs e)
  {
    this.ProgressBarTimer.Stop();
    this.ProgressBarTimer.Tick -= new EventHandler(this.ProgressBarTimer_DownloadCombo);
    ComboBox comboPartSelector = this.ComboProjView.GetActiveComboPartSelector();
    comboPartSelector.SelectedIndex = -1;
    List<byte> image;
    for (int index = 0; index < this.ComboProjView.Projects.Count; ++index)
    {
      if (this.ComboProjView.Projects[index].Name != null)
      {
        this.ComboProjView.Projects[index].Image.Clear();
        comboPartSelector.SelectedIndex = index;
        SchemaBlock_Controller controller = this.SchemaField.GetController();
        if (controller != null)
        {
          if (controller.Module.IndexOf(this.ComboProjView.Controller) != -1)
          {
            if (BootImage.MakeForProject(this.SchemaField.GetElements(), out image))
            {
              this.ComboProjView.Projects[index].Image.AddRange((IEnumerable<byte>) image);
            }
            else
            {
              int num1 = (int) MessageBox.Show($"Error has been detected in project <{this.ComboProjView.Projects[index].Name}>\n\rProject will be ignored.", "", MessageBoxButton.OK, MessageBoxImage.Exclamation);
            }
          }
          else
          {
            int num2 = (int) MessageBox.Show($"Controller in project\n\r<{this.ComboProjView.Projects[index].Name}>\n\rdoes not correspond to ComboProject settings.\n\rProject will be ignored.", "", MessageBoxButton.OK, MessageBoxImage.Exclamation);
          }
        }
      }
    }
    BootImage.CombineProjects(this.ComboProjView.ComboType, this.ComboProjView.ComboSubType(), this.ComboProjView.ReconfigType, this.ComboProjView.Projects, out image);
    int PacketSize;
    int ApiVersion;
    if (this.CanDownloadBeStarted(out PacketSize, out ApiVersion) && this.CheckImageSize((double) image.Count) && ControllerDriver.DownloadStart(image, PacketSize, 0, ApiVersion))
      return;
    this.ProcessFinished(false);
  }

  public event PropertyChangedEventHandler PropertyChanged;

  public void NotifyPropertyChanged(string PropertyName)
  {
    PropertyChangedEventHandler propertyChanged = this.PropertyChanged;
    if (propertyChanged == null)
      return;
    propertyChanged((object) this, new PropertyChangedEventArgs(PropertyName));
  }

  private void USBSettings_Click(object sender, RoutedEventArgs e)
  {
    SchemaBlock_Controller controller = this.SchemaField.GetController();
    if (controller == null)
      return;
    if (controller.AreUSBSetsSupported)
    {
      USBSettings usbSettings = new USBSettings(controller.AudioDescription);
      bool? nullable = usbSettings.ShowDialog();
      bool flag = true;
      if (!(nullable.GetValueOrDefault() == flag & nullable.HasValue))
        return;
      this.SetProcessDescription("Downloading...");
      this.ShowProcessInit();
      int PacketSize;
      int ApiVersion;
      if (this.CanDownloadBeStarted(out PacketSize, out ApiVersion) && ControllerDriver.DownloadStart(BootImage.MakeForUSBSettings(usbSettings.Settings), PacketSize, 1, ApiVersion))
        return;
      this.ProcessFinished(false);
    }
    else
    {
      int num = (int) MessageBox.Show("Controller does not support USB settings feature", "", MessageBoxButton.OK, MessageBoxImage.Asterisk);
    }
  }

  private bool CanDownloadBeStarted(out int PacketSize, out int ApiVersion)
  {
    PacketSize = 0;
    ApiVersion = 1;
    bool flag = true;
    if (ControllerDriver.IsDeviceConnected())
    {
      SchemaBlock_Controller controller = this.SchemaField.GetController();
      if (controller != null)
      {
        ControllerDriver.OpenDevice();
        ControllerInfo deviceInfo = ControllerDriver.GetDeviceInfo();
        if (deviceInfo.ID == (int) controller.CoreID)
        {
          PacketSize = deviceInfo.USBPacketSize != -1 ? deviceInfo.USBPacketSize : (int) controller.USBPacketSize;
          ApiVersion = deviceInfo.DownLoadAPIVersion != -1 ? deviceInfo.DownLoadAPIVersion : (int) controller.DownLoadAPI;
          goto label_6;
        }
        flag = false;
        goto label_6;
      }
    }
    flag = false;
label_6:
    if (flag)
      return true;
    ControllerDriver.CloseDevice();
    int num = (int) MessageBox.Show("Controller is not connected", "", MessageBoxButton.OK, MessageBoxImage.Hand);
    return false;
  }

  private bool CheckImageSize(double Size)
  {
    if (Size == 0.0)
    {
      int num = (int) MessageBox.Show("Project image is empty", "", MessageBoxButton.OK, MessageBoxImage.Exclamation);
      return false;
    }
    SchemaBlock_Controller controller = this.SchemaField.GetController();
    if (controller.ProjectMemorySize <= 0)
    {
      int num1 = (int) MessageBox.Show("Controller project memory size value is not set.", "", MessageBoxButton.OK, MessageBoxImage.Exclamation);
    }
    else if (Size > (double) controller.ProjectMemorySize)
    {
      int num2 = (int) MessageBox.Show($"Image size is too big\n\rImage size = {(Size / 1024.0).ToString("f2")} kB\n\rController project memory size = {(controller.ProjectMemorySize / 1024 /*0x0400*/).ToString()} kB", "", MessageBoxButton.OK, MessageBoxImage.Hand);
      return false;
    }
    return true;
  }

  private void DeleteKey_Pressed(object sender, ExecutedRoutedEventArgs e)
  {
    this.SchemaField.DeleteElement();
  }

  private void ImportSigmaStudioProject_Click(object sender, RoutedEventArgs e)
  {
    string XMLFile = FileDialog.Open("SigmaStudio XML file (*.xml)|*.xml");
    if (XMLFile == null)
      return;
    List<string> Parts;
    List<DataTransfer[]> Boot;
    List<DSPCell[]> Cells;
    if (SigmaStudio.TryParseXML(XMLFile, out Parts, out Boot, out Cells))
    {
      this.SchemaField.ImportDSP(Parts, Boot, Cells);
    }
    else
    {
      int num = (int) MessageBox.Show("Error reading file", "", MessageBoxButton.OK, MessageBoxImage.Hand);
    }
  }

  private void ControllerInfo_Click(object sender, RoutedEventArgs e)
  {
    new ControllerInfoDialog().ShowDialog();
  }

  [DebuggerNonUserCode]
  [GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
  public void InitializeComponent()
  {
    if (this._contentLoaded)
      return;
    this._contentLoaded = true;
    Application.LoadComponent((object) this, new Uri("/ChipStudio;component/mainwindow.xaml", UriKind.Relative));
  }

  [DebuggerNonUserCode]
  [GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
  internal Delegate _CreateDelegate(Type delegateType, string handler)
  {
    return Delegate.CreateDelegate(delegateType, (object) this, handler);
  }

  [DebuggerNonUserCode]
  [GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
  [EditorBrowsable(EditorBrowsableState.Never)]
  void IComponentConnector.Connect(int connectionId, object target)
  {
    switch (connectionId)
    {
      case 1:
        ((Window) target).Closing += new CancelEventHandler(this.WindowIsClosing);
        break;
      case 2:
        ((CommandBinding) target).Executed += new ExecutedRoutedEventHandler(this.DeleteKey_Pressed);
        break;
      case 3:
        ((CommandBinding) target).Executed += new ExecutedRoutedEventHandler(this.NewProject_Click);
        break;
      case 4:
        ((CommandBinding) target).Executed += new ExecutedRoutedEventHandler(this.OpenProject_Click);
        break;
      case 5:
        ((CommandBinding) target).Executed += new ExecutedRoutedEventHandler(this.SaveProject_Click);
        break;
      case 6:
        ((MenuItem) target).Click += new RoutedEventHandler(this.NewComboProject_Click);
        break;
      case 7:
        ((MenuItem) target).Click += new RoutedEventHandler(this.ImportComboProject_Click);
        break;
      case 8:
        ((MenuItem) target).Click += new RoutedEventHandler(this.ImportSigmaStudioProject_Click);
        break;
      case 9:
        ((MenuItem) target).Click += new RoutedEventHandler(this.SaveProjectAs_Click);
        break;
      case 10:
        ((MenuItem) target).Click += new RoutedEventHandler(this.SaveComboProject_Click);
        break;
      case 11:
        ((MenuItem) target).Click += new RoutedEventHandler(this.SaveComboProjectAs_Click);
        break;
      case 12:
        this.RecentProjMenu = (MenuItem) target;
        break;
      case 13:
        ((MenuItem) target).Click += new RoutedEventHandler(this.DownloadButton_Click);
        break;
      case 14:
        ((MenuItem) target).Click += new RoutedEventHandler(this.DownLoadComboButton_Click);
        break;
      case 15:
        ((MenuItem) target).Click += new RoutedEventHandler(this.USBSettings_Click);
        break;
      case 16 /*0x10*/:
        ((MenuItem) target).Click += new RoutedEventHandler(this.ControllerInfo_Click);
        break;
      case 17:
        ((MenuItem) target).Click += new RoutedEventHandler(this.About_Click);
        break;
      case 18:
        ((ButtonBase) target).Click += new RoutedEventHandler(this.DownloadButton_Click);
        break;
      case 19:
        ((ToggleButton) target).Checked += new RoutedEventHandler(this.ComboModeButton_Checked);
        ((ToggleButton) target).Unchecked += new RoutedEventHandler(this.ComboModeButton_Checked);
        break;
      case 20:
        ((ButtonBase) target).Click += new RoutedEventHandler(this.DownLoadComboButton_Click);
        break;
      case 21:
        this.HWModules = (ModulePanel) target;
        break;
      case 22:
        this.SchemaField = (Schema) target;
        break;
      case 23:
        this.DSPCellsTree = (TreeView) target;
        break;
      case 24:
        this.ComboProjView = (ComboProjectSettings) target;
        break;
      default:
        this._contentLoaded = true;
        break;
    }
  }
}
