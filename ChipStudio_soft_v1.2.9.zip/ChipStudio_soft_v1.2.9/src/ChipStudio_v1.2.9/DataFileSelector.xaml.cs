﻿// Decompiled with JetBrains decompiler
// Type: ChipStudio.DataFileSelector
// Assembly: ChipStudio, Version=1.2.9.0, Culture=neutral, PublicKeyToken=null
// MVID: 334E3BEA-37C7-4274-8118-535AAEFA1546
// Assembly location: D:\DocAndSec\Desktop\AUDIO\ChipDip\ChipStudio_soft_v1.2.9\ChipStudio_v1.2.9.exe

using Microsoft.Win32;
using System;
using System.CodeDom.Compiler;
using System.ComponentModel;
using System.Diagnostics;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Markup;
using System.Windows.Media;
using System.Windows.Media.Imaging;

#nullable disable
namespace ChipStudio;

public partial class DataFileSelector : UserControl, IComponentConnector
{
  private static readonly string ImageWarning = (string) Application.Current.FindResource((object) nameof (ImageWarning));
  private static readonly string ImageApply = (string) Application.Current.FindResource((object) nameof (ImageApply));
  private Func<string, DataFileSelector.ProcessResult> ProcessFile;
  private bool isdataset;
  internal Image Image;
  internal Button SelectFile;
  private bool _contentLoaded;

  public string Title { get; set; }

  public string Filter { get; set; }

  public string ButtonTitle { get; set; }

  public bool IsDataSet
  {
    set
    {
      if (this.isdataset == value)
        return;
      this.isdataset = value;
      this.Image.Source = this.isdataset ? (ImageSource) new BitmapImage(new Uri(DataFileSelector.ImageApply, UriKind.Relative)) : (ImageSource) new BitmapImage(new Uri(DataFileSelector.ImageWarning, UriKind.Relative));
    }
  }

  public DataFileSelector()
  {
    this.InitializeComponent();
    this.DataContext = (object) this;
    this.Image.Source = (ImageSource) new BitmapImage(new Uri(DataFileSelector.ImageWarning, UriKind.Relative));
  }

  public void FileProcessingSet(
    Func<string, DataFileSelector.ProcessResult> NewAction)
  {
    this.ProcessFile = NewAction;
  }

  private void SelectFile_Click(object sender, RoutedEventArgs e)
  {
    OpenFileDialog openFileDialog1 = new OpenFileDialog();
    openFileDialog1.Filter = this.Filter;
    OpenFileDialog openFileDialog2 = openFileDialog1;
    bool? nullable = openFileDialog2.ShowDialog();
    bool flag = true;
    if (!(nullable.GetValueOrDefault() == flag & nullable.HasValue))
      return;
    Func<string, DataFileSelector.ProcessResult> processFile = this.ProcessFile;
    DataFileSelector.ProcessResult processResult = (processFile != null ? new DataFileSelector.ProcessResult?(processFile(openFileDialog2.FileName)) : new DataFileSelector.ProcessResult?()).Value;
    this.IsDataSet = processResult == DataFileSelector.ProcessResult.Success || processResult == DataFileSelector.ProcessResult.FailedAndSave;
  }

  [DebuggerNonUserCode]
  [GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
  public void InitializeComponent()
  {
    if (this._contentLoaded)
      return;
    this._contentLoaded = true;
    Application.LoadComponent((object) this, new Uri("/ChipStudio;component/datafileselector.xaml", UriKind.Relative));
  }

  [DebuggerNonUserCode]
  [GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
  [EditorBrowsable(EditorBrowsableState.Never)]
  void IComponentConnector.Connect(int connectionId, object target)
  {
    if (connectionId != 1)
    {
      if (connectionId == 2)
      {
        this.SelectFile = (Button) target;
        this.SelectFile.Click += new RoutedEventHandler(this.SelectFile_Click);
      }
      else
        this._contentLoaded = true;
    }
    else
      this.Image = (Image) target;
  }

  public enum ProcessResult : byte
  {
    Success,
    FailedAndClear,
    FailedAndSave,
  }
}
