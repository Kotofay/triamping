﻿// Decompiled with JetBrains decompiler
// Type: ChipStudio.ValueInput
// Assembly: ChipStudio, Version=1.2.9.0, Culture=neutral, PublicKeyToken=null
// MVID: 334E3BEA-37C7-4274-8118-535AAEFA1546
// Assembly location: D:\DocAndSec\Desktop\AUDIO\ChipDip\ChipStudio_soft_v1.2.9\ChipStudio_v1.2.9.exe

using System;
using System.CodeDom.Compiler;
using System.ComponentModel;
using System.Diagnostics;
using System.Text.RegularExpressions;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Markup;

#nullable disable
namespace ChipStudio;

public partial class ValueInput : UserControl, IComponentConnector
{
  public const string HEX = "HEX";
  public const string DEC = "DEC";
  private const string DecFilter = "\\d";
  private const string HexFilter = "[0-9aAbBcCdDeEfF]";
  private string InputFilter = "[0-9aAbBcCdDeEfF]";
  private ValueInput.TryParseValue TryParse = new ValueInput.TryParseValue(ValueInput.TryParseHEX);
  internal TextBox ValueBox;
  private bool _contentLoaded;

  public string Title { get; set; }

  public int ValueFieldWidth { get; set; }

  public int ValueMaxLength { get; set; } = 4;

  public string Format { get; set; } = nameof (HEX);

  public ValueInput()
  {
    this.InitializeComponent();
    this.DataContext = (object) this;
  }

  public string GetInput() => this.ValueBox.Text;

  public void SetInput(string Input) => this.ValueBox.Text = Input;

  public ulong GetValue()
  {
    ulong Result;
    return !this.TryParse(this.ValueBox.Text, out Result) ? 0UL : Result;
  }

  public void SetFormat(string NewFormat)
  {
    this.Format = NewFormat;
    switch (this.Format)
    {
      case "DEC":
        this.TryParse = new ValueInput.TryParseValue(ulong.TryParse);
        this.InputFilter = "\\d";
        break;
      case "HEX":
        this.TryParse = new ValueInput.TryParseValue(ValueInput.TryParseHEX);
        this.InputFilter = "[0-9aAbBcCdDeEfF]";
        break;
    }
  }

  private static bool TryParseHEX(string input, out ulong result)
  {
    result = 0UL;
    if (input.Length == 0)
      return false;
    try
    {
      result = Convert.ToUInt64(input, 16 /*0x10*/);
    }
    catch (FormatException ex)
    {
      return false;
    }
    return true;
  }

  private void PreviewTextInput_Event(object sender, TextCompositionEventArgs e)
  {
    if (Regex.IsMatch(e.Text, this.InputFilter))
      return;
    e.Handled = true;
  }

  private void PreviewKeyDown_Event(object sender, KeyEventArgs e)
  {
    if (e.Key != Key.Space)
      return;
    e.Handled = true;
  }

  [DebuggerNonUserCode]
  [GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
  public void InitializeComponent()
  {
    if (this._contentLoaded)
      return;
    this._contentLoaded = true;
    Application.LoadComponent((object) this, new Uri("/ChipStudio;component/valueinput.xaml", UriKind.Relative));
  }

  [DebuggerNonUserCode]
  [GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
  [EditorBrowsable(EditorBrowsableState.Never)]
  void IComponentConnector.Connect(int connectionId, object target)
  {
    if (connectionId == 1)
    {
      this.ValueBox = (TextBox) target;
      this.ValueBox.PreviewTextInput += new TextCompositionEventHandler(this.PreviewTextInput_Event);
      this.ValueBox.PreviewKeyDown += new KeyEventHandler(this.PreviewKeyDown_Event);
    }
    else
      this._contentLoaded = true;
  }

  private delegate bool TryParseValue(string Input, out ulong Result);
}
