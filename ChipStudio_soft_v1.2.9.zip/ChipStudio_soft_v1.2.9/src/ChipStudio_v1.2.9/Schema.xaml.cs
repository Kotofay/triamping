﻿// Decompiled with JetBrains decompiler
// Type: ChipStudio.Schema
// Assembly: ChipStudio, Version=1.2.9.0, Culture=neutral, PublicKeyToken=null
// MVID: 334E3BEA-37C7-4274-8118-535AAEFA1546
// Assembly location: D:\DocAndSec\Desktop\AUDIO\ChipDip\ChipStudio_soft_v1.2.9\ChipStudio_v1.2.9.exe

using System;
using System.CodeDom.Compiler;
using System.Collections.Generic;
using System.ComponentModel;
using System.Diagnostics;
using System.Linq;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Markup;

#nullable disable
namespace ChipStudio;

public partial class Schema : UserControl, IComponentConnector
{
  private const string BlockDuplicateInfo = "Schema already contains selected block";
  private const string BlockDuplicateInfoHeader = "Block duplicate";
  private const string ControllerDuplicateInfo = "Schema can contain only one controller";
  private const string ControllerDuplicateInfoHeader = "Controller duplicate";
  private static readonly Cursor PROJECT_FIELD_CURSOR_MAIN = Cursors.Arrow;
  private static readonly Cursor PROJECT_FIELD_CURSOR_CONNECTION_ACTIVE = Cursors.Cross;
  private const int ZIndex_ActiveConnection = -2;
  private const int ZIndex_NormalElement = -1;
  private const int ZIndex_ActiveElement = 0;
  private const int ZIndex_NormalConnection = 0;
  private const int BlockMoveStep = 5;
  private const double StartX = 50.0;
  private const double StartY = 50.0;
  private const double BlockStep = 75.0;
  private Action ControllerAdded;
  private int ActiveSchemaElementIndex = -1;
  private bool IsConnectionActive;
  private readonly List<DSPCellsList> DSPCells = new List<DSPCellsList>();
  private TreeView DSPCellsView;
  private bool IsMovingPending;
  internal Canvas ProjectSchema;
  private bool _contentLoaded;

  public Schema()
  {
    this.InitializeComponent();
    this.DataContext = (object) this;
  }

  public SchemaBlock_Controller GetController()
  {
    return Schema.GetController(this.ProjectSchema.Children);
  }

  public void ImportDSP(List<string> Parts, List<DataTransfer[]> Boot, List<DSPCell[]> DSPCells)
  {
    List<SchemaBlock_DSP> list = this.ProjectSchema.Children.OfType<SchemaBlock_DSP>().ToList<SchemaBlock_DSP>();
    for (int i = 0; i < Parts.Count; i++)
    {
      SchemaBlock_DSP[] array = list.Where<SchemaBlock_DSP>((Func<SchemaBlock_DSP, bool>) (b => b.Title.IndexOf(Parts[i]) != -1)).ToArray<SchemaBlock_DSP>();
      if (array.Length == 0)
      {
        SchemaBlock_DSP dspBlock = this.CreateDSPBlock(Parts[i], Boot[i], DSPCells[i]);
        if (dspBlock != null)
        {
          dspBlock.UpperLeftPoint = new System.Windows.Point(50.0, 50.0 + (double) i * 75.0);
          this.ImportDSPBlock(dspBlock);
        }
      }
      else
      {
        array[0].UpdateBootAndCells(((IEnumerable<DataTransfer>) Boot[i]).ToList<DataTransfer>(), ((IEnumerable<DSPCell>) DSPCells[i]).ToList<DSPCell>());
        list.Remove(array[0]);
      }
    }
  }

  public void AddElements(ISchemaElement[] Elements)
  {
    foreach (ISchemaElement element in Elements)
      this.AddElement(element);
    this.DSPCellsSetChanged(Schema.UpdateOptions.Init);
    this.DSPSetChanged(Schema.UpdateOptions.Init);
    this.ComparatorSetChanged(Schema.UpdateOptions.Init);
  }

  public void ImportDSPBlock(SchemaBlock_DSP DSP)
  {
    DSP.Title = this.SetBlockTitle(DSP.Title);
    DSP.SetDSPTitleToCells();
    this.AddElement((ISchemaElement) DSP);
    this.DSPCellsSetChanged(Schema.UpdateOptions.Init);
    this.DSPSetChanged(Schema.UpdateOptions.Init);
  }

  public void AddElement(ISchemaElement Element)
  {
    if (Element.ElementType == Shared.ElementTypeBlock)
    {
      SchemaBlock element = Element as SchemaBlock;
      element.AddConnectionEventHandler(new Action<ConnectionNode>(this.AddConnectionNode));
      switch (element.BlockType)
      {
        case SchemaBlock.SchemaBlockTypes.DSP:
          (element as SchemaBlock_DSP).FileParseEnd += new SchemaBlock_DSP.FileParseEndEventHandler(this.DSPFileParseEnd);
          List<DSPCell> cells = (element as SchemaBlock_DSP).GetCells();
          if (cells.Count != 0)
          {
            this.DSPFileParseEnd(cells, SchemaBlock_DSP.FileParseOption.Replace);
            break;
          }
          break;
        case SchemaBlock.SchemaBlockTypes.DSPCell:
          int indexInListByName = this.GetDSPIndexInListByName((element as SchemaBlock_DSPCell).DSPTitle);
          int indexInDspListByName = this.GetDSPCellIndexInDSPListByName(indexInListByName, element.Title.ToString());
          (element as SchemaBlock_DSPCell).Initialize(this.DSPCells[indexInListByName].DSPBlocks[indexInDspListByName]);
          break;
      }
      this.ProjectSchema.Children.Add((UIElement) element);
    }
    else
    {
      if (!(Element.ElementType == Shared.ElementTypeConnection))
        return;
      this.ProjectSchema.Children.Add((UIElement) (Element as Connection));
    }
  }

  public void SetDSPCellsView(TreeView View) => this.DSPCellsView = View;

  public void DragDropBlock(MouseButtonEventArgs e)
  {
    if (!(e.Source is TreeViewItem source))
      return;
    int num = (int) DragDrop.DoDragDrop((DependencyObject) source, (object) source, DragDropEffects.Copy);
  }

  public void Clear()
  {
    this.ProjectSchema.Children.Clear();
    this.DSPCells.Clear();
    this.DSPCellsView.Items.Clear();
    this.ActiveSchemaElementIndex = -1;
    this.IsMovingPending = false;
  }

  public UIElementCollection GetElements() => this.ProjectSchema.Children;

  public void DeleteElement()
  {
    if (!this.ProjectSchema.IsMouseOver || this.ActiveSchemaElementIndex == -1)
      return;
    ISchemaElement child = this.ProjectSchema.Children[this.ActiveSchemaElementIndex] as ISchemaElement;
    bool flag1 = false;
    bool flag2 = false;
    bool flag3 = false;
    if (child.ElementType == Shared.ElementTypeBlock)
    {
      SchemaBlock schemaBlock = child as SchemaBlock;
      if (schemaBlock.BlockType == SchemaBlock.SchemaBlockTypes.DSP)
      {
        flag2 = true;
        this.DeleteDSPCellsFromSchematic(schemaBlock.Title);
        for (int index = 0; index < this.DSPCells.Count; ++index)
        {
          if (this.DSPCells[index].Name == schemaBlock.Title)
          {
            this.DSPCells.RemoveAt(index);
            this.DSPCellsView.Items.RemoveAt(index);
          }
        }
      }
      this.DeleteBlockConnections(schemaBlock.FullName);
      switch (schemaBlock)
      {
        case SchemaBlock_DSPCell _:
          flag1 = true;
          break;
        case SchemaBlock_Comparator _:
          flag3 = true;
          break;
      }
      schemaBlock.Dispose();
    }
    this.ProjectSchema.Children.RemoveAt(this.ActiveSchemaElementIndex);
    if (flag1)
      this.DSPCellsSetChanged(Schema.UpdateOptions.Remove);
    else if (flag2)
      this.DSPSetChanged(Schema.UpdateOptions.Remove);
    else if (flag3)
      this.ComparatorSetChanged(Schema.UpdateOptions.Remove);
    this.ActiveSchemaElementIndex = -1;
  }

  public void SetControllerAddedCallback(Action Callback) => this.ControllerAdded = Callback;

  public static SchemaBlock_Controller GetController(UIElementCollection Schema)
  {
    SchemaBlock_Controller[] array = Schema.OfType<SchemaBlock_Controller>().ToArray<SchemaBlock_Controller>();
    return array.Length == 0 ? (SchemaBlock_Controller) null : array[0];
  }

  public static SchemaBlock_DSP[] GetDSPs(UIElementCollection Schema)
  {
    return Schema.OfType<SchemaBlock_DSP>().ToArray<SchemaBlock_DSP>();
  }

  public static SchemaBlock_DSP GetDSP(UIElementCollection Schema, string Title)
  {
    SchemaBlock_DSP[] array = ((IEnumerable<SchemaBlock_DSP>) Schema.GetDSPs(Schema)).Where<SchemaBlock_DSP>((Func<SchemaBlock_DSP, bool>) (d => d.Title == Title)).ToArray<SchemaBlock_DSP>();
    return array.Length == 0 ? (SchemaBlock_DSP) null : array[0];
  }

  public static SchemaBlock_DSPCell[] GetDSPCells(UIElementCollection Schema)
  {
    return Schema.OfType<SchemaBlock_DSPCell>().ToArray<SchemaBlock_DSPCell>();
  }

  public static SchemaBlock_DSPCell[] GetDSPCells(UIElementCollection Schema, string FullName)
  {
    return ((IEnumerable<SchemaBlock_DSPCell>) Schema.GetDSPCells(Schema)).Where<SchemaBlock_DSPCell>((Func<SchemaBlock_DSPCell, bool>) (d => d.FullName == FullName)).ToArray<SchemaBlock_DSPCell>();
  }

  public static SchemaBlock_LED[] GetLEDs(UIElementCollection Schema)
  {
    return Schema.OfType<SchemaBlock_LED>().ToArray<SchemaBlock_LED>();
  }

  public static SchemaBlock_PixelLED[] GetPixelLEDs(UIElementCollection Schema)
  {
    return Schema.OfType<SchemaBlock_PixelLED>().ToArray<SchemaBlock_PixelLED>();
  }

  public static SchemaBlock_Read[] GetReads(UIElementCollection Schema)
  {
    return Schema.OfType<SchemaBlock_Read>().ToArray<SchemaBlock_Read>();
  }

  public static SchemaBlock_Comparator[] GetComparators(UIElementCollection Schema)
  {
    return Schema.OfType<SchemaBlock_Comparator>().ToArray<SchemaBlock_Comparator>();
  }

  public static Connection[] GetConnections(UIElementCollection Schema)
  {
    return Schema.OfType<Connection>().ToArray<Connection>();
  }

  public static Connection[] GetConnections(
    UIElementCollection Schema,
    ConnectionNode Node1,
    ConnectionNode Node2)
  {
    return ((IEnumerable<Connection>) Schema.GetConnections(Schema)).Where<Connection>((Func<Connection, bool>) (c =>
    {
      if (c.Nodes[0].BlockName == Node1.BlockName && c.Nodes[0].AnchorNumber == Node1.AnchorNumber && c.Nodes[1].BlockName == Node2.BlockName && c.Nodes[1].AnchorNumber == Node2.AnchorNumber)
        return true;
      return c.Nodes[0].BlockName == Node2.BlockName && c.Nodes[0].AnchorNumber == Node2.AnchorNumber && c.Nodes[1].BlockName == Node1.BlockName && c.Nodes[1].AnchorNumber == Node1.AnchorNumber;
    })).ToArray<Connection>();
  }

  private SchemaBlock_DSP CreateDSPBlock(string Part, DataTransfer[] Boot, DSPCell[] Cells)
  {
    SchemaBlock_DSP dspBlock = new SchemaBlock_DSP(Part);
    if (!dspBlock.IsReady)
      return (SchemaBlock_DSP) null;
    dspBlock.Title = Part;
    dspBlock.SetBoot(Boot);
    dspBlock.SetCells(Cells);
    dspBlock.AddConstantCells();
    return dspBlock;
  }

  private string SetBlockTitle(string ModuleType)
  {
    return $"{ModuleType}_{this.FindBlockIndex(ModuleType).ToString()}";
  }

  private int FindBlockIndex(string ModuleType)
  {
    int[] array = this.ProjectSchema.Children.OfType<SchemaBlock>().Where<SchemaBlock>((Func<SchemaBlock, bool>) (b => b.Title.IndexOf(ModuleType) != -1)).Select<SchemaBlock, int>((Func<SchemaBlock, int>) (b => b.SchemaIndex)).ToArray<int>();
    int blockIndex = 0;
    while (blockIndex < int.MaxValue && Array.IndexOf<int>(array, blockIndex) != -1)
      ++blockIndex;
    return blockIndex;
  }

  private void AddConnectionNode(ConnectionNode Node)
  {
    if (!this.IsConnectionActive)
    {
      Connection element = new Connection();
      element.AddNode(Node);
      this.ApplyNodeFilterToAllBlocks(Node);
      element.AddNode(new ConnectionNode((string) null, Node.AnchorNumber, Node.AnchorPoint, Anchor.AnchorTypes.EMPTY));
      this.ProjectSchema.Children.Add((UIElement) element);
      Panel.SetZIndex((UIElement) element, -2);
      this.IsConnectionActive = true;
      this.ProjectSchema.MouseRightButtonDown += new MouseButtonEventHandler(this.Schema_MouseRightButtonDown);
      this.Schema_ChangeCursor(Schema.PROJECT_FIELD_CURSOR_CONNECTION_ACTIVE);
    }
    else
    {
      Connection child = this.ProjectSchema.Children[this.ProjectSchema.Children.Count - 1] as Connection;
      child.RemoveNodeAt(1);
      child.AddNode(Node);
      this.DiscardNodeFilterInAllBlocks();
      Panel.SetZIndex((UIElement) child, 0);
      this.IsConnectionActive = false;
      this.ProjectSchema.MouseRightButtonDown -= new MouseButtonEventHandler(this.Schema_MouseRightButtonDown);
      this.Schema_ChangeCursor(Schema.PROJECT_FIELD_CURSOR_MAIN);
    }
  }

  private void ApplyNodeFilterToAllBlocks(ConnectionNode Node)
  {
    for (int index = 0; index < this.ProjectSchema.Children.Count; ++index)
    {
      if (this.ProjectSchema.Children[index] is SchemaBlock child)
        child.ApplyFilter(Node);
    }
  }

  private void DiscardNodeFilterInAllBlocks()
  {
    for (int index = 0; index < this.ProjectSchema.Children.Count; ++index)
    {
      if (this.ProjectSchema.Children[index] is SchemaBlock child)
        child.DiscardFilter();
    }
  }

  private void DSPFileParseEnd(List<DSPCell> CellList, SchemaBlock_DSP.FileParseOption Option)
  {
    string dspTitle = CellList[0].DSPTitle;
    bool flag1 = true;
    int index1 = 0;
    for (int index2 = 0; index2 < this.DSPCells.Count; ++index2)
    {
      if (this.DSPCells[index2].Name == dspTitle)
      {
        flag1 = false;
        index1 = index2;
        break;
      }
    }
    if (flag1)
    {
      this.DSPCells.Add(new DSPCellsList()
      {
        Name = dspTitle
      });
      ItemCollection items = this.DSPCellsView.Items;
      TreeViewItem newItem = new TreeViewItem();
      newItem.Header = (object) dspTitle;
      newItem.IsExpanded = true;
      items.Add((object) newItem);
      index1 = this.DSPCells.Count - 1;
    }
    else
    {
      (this.DSPCellsView.Items[index1] as TreeViewItem).Items.Clear();
      switch (Option)
      {
        case SchemaBlock_DSP.FileParseOption.Update:
          for (int index3 = this.DSPCells[index1].DSPBlocks.Count - 1; index3 >= 0; --index3)
          {
            bool flag2 = false;
            int index4;
            for (index4 = 0; index4 < CellList.Count; ++index4)
            {
              if (this.DSPCells[index1].DSPBlocks[index3].Title == CellList[index4].Title)
              {
                flag2 = true;
                break;
              }
            }
            for (int index5 = this.ProjectSchema.Children.Count - 1; index5 >= 0; --index5)
            {
              if (this.ProjectSchema.Children[index5] is SchemaBlock_DSPCell child && child.DSPTitle == dspTitle && child.Title == this.DSPCells[index1].DSPBlocks[index3].Title)
              {
                if (!flag2)
                {
                  this.DeleteBlockConnections(child.FullName);
                  this.ProjectSchema.Children.RemoveAt(index5);
                  this.DSPCellsSetChanged(Schema.UpdateOptions.Remove);
                  break;
                }
                child.Update(CellList[index4]);
                break;
              }
            }
            this.DSPCells[index1].DSPBlocks.RemoveAt(index3);
          }
          break;
        case SchemaBlock_DSP.FileParseOption.Replace:
          this.DSPCells[index1].DSPBlocks.Clear();
          this.DeleteDSPCellsFromSchematic(dspTitle);
          break;
      }
    }
    this.DSPCells[index1].DSPBlocks.AddRange((IEnumerable<DSPCell>) CellList);
    foreach (DSPCell cell in CellList)
    {
      TreeViewItem treeViewItem = new TreeViewItem();
      treeViewItem.Header = (object) cell.Title;
      TreeViewItem newItem = treeViewItem;
      if (cell.IsControllable)
        newItem.PreviewMouseLeftButtonDown += new MouseButtonEventHandler(this.DSPCell_PreviewMouseLeftButtonDown);
      (this.DSPCellsView.Items[index1] as TreeViewItem).Items.Add((object) newItem);
    }
  }

  private void DeleteDSPCellsFromSchematic(string DSPTitle)
  {
    foreach (SchemaBlock_DSPCell element in this.ProjectSchema.Children.OfType<SchemaBlock_DSPCell>().Where<SchemaBlock_DSPCell>((Func<SchemaBlock_DSPCell, bool>) (b => b.DSPTitle == DSPTitle)).ToArray<SchemaBlock_DSPCell>())
    {
      this.DeleteBlockConnections(element.FullName);
      this.ProjectSchema.Children.Remove((UIElement) element);
      this.DSPCellsSetChanged(Schema.UpdateOptions.Remove);
    }
  }

  private void DeleteBlockConnections(string BlockTitle)
  {
    foreach (UIElement element in this.ProjectSchema.Children.OfType<Connection>().Where<Connection>((Func<Connection, bool>) (c => c.Nodes[0].BlockName.IndexOf(BlockTitle) != -1 || c.Nodes[1].BlockName.IndexOf(BlockTitle) != -1)).ToArray<Connection>())
      this.ProjectSchema.Children.Remove(element);
  }

  private void DSPCellsSetChanged(Schema.UpdateOptions Option)
  {
    ILed[] array = this.ProjectSchema.Children.OfType<ILed>().ToArray<ILed>();
    if (array.Length == 0)
      return;
    SchemaBlock_DSPCell[] dspCells = this.GetDSPCells();
    foreach (ILed led in array)
      led.UpdateBlockList(dspCells, Option);
  }

  private void DSPSetChanged(Schema.UpdateOptions Option)
  {
    IDSPDependent[] array = this.ProjectSchema.Children.OfType<IDSPDependent>().ToArray<IDSPDependent>();
    if (array.Length == 0)
      return;
    string[] dspTitles = this.GetDSPTitles();
    foreach (IDSPDependent dspDependent in array)
      dspDependent.UpdateDSPList(dspTitles, Option);
  }

  private void ComparatorSetChanged(Schema.UpdateOptions Option)
  {
    IComparatorDependent[] array = this.ProjectSchema.Children.OfType<IComparatorDependent>().ToArray<IComparatorDependent>();
    if (array.Length == 0)
      return;
    string[] comparatorTitles = this.GetComparatorTitles();
    foreach (IComparatorDependent comparatorDependent in array)
      comparatorDependent.UpdateComparatorList(comparatorTitles, Option);
  }

  private SchemaBlock_DSPCell[] GetDSPCells()
  {
    return this.ProjectSchema.Children.OfType<SchemaBlock_DSPCell>().ToArray<SchemaBlock_DSPCell>();
  }

  private string[] GetDSPTitles()
  {
    return ((IEnumerable<SchemaBlock_DSP>) Schema.GetDSPs(this.ProjectSchema.Children)).Select<SchemaBlock_DSP, string>((Func<SchemaBlock_DSP, string>) (d => d.Title)).ToArray<string>();
  }

  private string[] GetComparatorTitles()
  {
    return ((IEnumerable<SchemaBlock_Comparator>) Schema.GetComparators(this.ProjectSchema.Children)).Select<SchemaBlock_Comparator, string>((Func<SchemaBlock_Comparator, string>) (d => d.Title)).ToArray<string>();
  }

  private int GetDSPIndexInListByName(string DSPTitle)
  {
    int indexInListByName = -1;
    for (int index = 0; index < this.DSPCells.Count; ++index)
    {
      if (this.DSPCells[index].Name == DSPTitle)
      {
        indexInListByName = index;
        break;
      }
    }
    return indexInListByName;
  }

  private int GetDSPCellIndexInDSPListByName(int DSPIndex, string CellTitle)
  {
    int indexInDspListByName = -1;
    for (int index = 0; index < this.DSPCells[DSPIndex].DSPBlocks.Count; ++index)
    {
      if (this.DSPCells[DSPIndex].DSPBlocks[index].Title == CellTitle)
      {
        indexInDspListByName = index;
        break;
      }
    }
    return indexInDspListByName;
  }

  private void SelectElement(ISchemaElement Element)
  {
    if (this.ActiveSchemaElementIndex != -1)
      this.DeselectElement();
    if (Element == null)
      return;
    if (Element.ElementType == Shared.ElementTypeBlock)
    {
      this.ActiveSchemaElementIndex = this.ProjectSchema.Children.IndexOf((UIElement) (Element as SchemaBlock));
      this.IsMovingPending = true;
    }
    else if (Element.ElementType == Shared.ElementTypeConnection)
      this.ActiveSchemaElementIndex = this.ProjectSchema.Children.IndexOf((UIElement) (Element as Connection));
    (this.ProjectSchema.Children[this.ActiveSchemaElementIndex] as ISchemaElement).IsSelected = true;
    Panel.SetZIndex(this.ProjectSchema.Children[this.ActiveSchemaElementIndex], 0);
  }

  private void DeselectElement()
  {
    (this.ProjectSchema.Children[this.ActiveSchemaElementIndex] as ISchemaElement).IsSelected = false;
    Panel.SetZIndex(this.ProjectSchema.Children[this.ActiveSchemaElementIndex], -1);
    this.ActiveSchemaElementIndex = -1;
    this.IsMovingPending = false;
  }

  private void Schema_ChangeCursor(Cursor NewCursor) => this.ProjectSchema.Cursor = NewCursor;

  private static double RoundCoordinate(double value)
  {
    int num1 = (int) Math.Round(value);
    int num2 = num1 % 5;
    if (num2 != 0)
      num1 += 5 - num2;
    return (double) num1;
  }

  private void Schema_Drop(object sender, DragEventArgs e)
  {
    TreeViewItem data = (TreeViewItem) e.Data.GetData(e.Data.GetFormats()[0]);
    if (data == null)
      return;
    System.Windows.Point position = e.GetPosition((IInputElement) this.ProjectSchema);
    position.X = Schema.RoundCoordinate(position.X);
    position.Y = Schema.RoundCoordinate(position.Y);
    string str1 = data.Header.ToString();
    string str2 = (data.Parent as TreeViewItem).Header.ToString();
    string str3 = this.SetBlockTitle(str1);
    if (str2 == Shared.ControllersFolder)
    {
      if (Schema.GetController(this.ProjectSchema.Children) != null)
      {
        int num1 = (int) MessageBox.Show("Schema can contain only one controller", "Controller duplicate", MessageBoxButton.OK, MessageBoxImage.Asterisk);
      }
      else
      {
        SchemaBlock_Controller schemaBlockController = new SchemaBlock_Controller(str1);
        schemaBlockController.Title = str3;
        schemaBlockController.UpperLeftPoint = position;
        SchemaBlock_Controller element = schemaBlockController;
        if (!element.IsReady)
          return;
        element.AddConnectionEventHandler(new Action<ConnectionNode>(this.AddConnectionNode));
        this.ProjectSchema.Children.Add((UIElement) element);
        Panel.SetZIndex((UIElement) element, -1);
        Action controllerAdded = this.ControllerAdded;
        if (controllerAdded == null)
          return;
        controllerAdded();
      }
    }
    else if (str2 == Shared.DSPCodecFolder)
    {
      SchemaBlock_DSP schemaBlockDsp = new SchemaBlock_DSP(str1);
      schemaBlockDsp.Title = str3;
      schemaBlockDsp.UpperLeftPoint = position;
      SchemaBlock_DSP element = schemaBlockDsp;
      if (!element.IsReady)
        return;
      element.FileParseEnd += new SchemaBlock_DSP.FileParseEndEventHandler(this.DSPFileParseEnd);
      element.AddConnectionEventHandler(new Action<ConnectionNode>(this.AddConnectionNode));
      this.ProjectSchema.Children.Add((UIElement) element);
      Panel.SetZIndex((UIElement) element, -1);
      this.DSPSetChanged(Schema.UpdateOptions.Add);
    }
    else
    {
      switch (str1)
      {
        case "LED":
          SchemaBlock_LED schemaBlockLed = new SchemaBlock_LED();
          schemaBlockLed.Title = str3;
          schemaBlockLed.UpperLeftPoint = position;
          SchemaBlock_LED element1 = schemaBlockLed;
          element1.AddConnectionEventHandler(new Action<ConnectionNode>(this.AddConnectionNode));
          element1.UpdateBlockList(this.GetDSPCells(), Schema.UpdateOptions.Init);
          element1.UpdateComparatorList(this.GetComparatorTitles(), Schema.UpdateOptions.Init);
          this.ProjectSchema.Children.Add((UIElement) element1);
          Panel.SetZIndex((UIElement) element1, -1);
          break;
        case "PixelLED":
          SchemaBlock_PixelLED schemaBlockPixelLed = new SchemaBlock_PixelLED();
          schemaBlockPixelLed.Title = str3;
          schemaBlockPixelLed.UpperLeftPoint = position;
          SchemaBlock_PixelLED element2 = schemaBlockPixelLed;
          element2.AddConnectionEventHandler(new Action<ConnectionNode>(this.AddConnectionNode));
          element2.UpdateBlockList(this.GetDSPCells(), Schema.UpdateOptions.Init);
          element2.UpdateComparatorList(this.GetComparatorTitles(), Schema.UpdateOptions.Init);
          this.ProjectSchema.Children.Add((UIElement) element2);
          Panel.SetZIndex((UIElement) element2, -1);
          break;
        case "Read":
          SchemaBlock_Read schemaBlockRead = new SchemaBlock_Read();
          schemaBlockRead.Title = str3;
          schemaBlockRead.UpperLeftPoint = position;
          SchemaBlock_Read element3 = schemaBlockRead;
          element3.AddConnectionEventHandler(new Action<ConnectionNode>(this.AddConnectionNode));
          element3.UpdateDSPList(this.GetDSPTitles(), Schema.UpdateOptions.Init);
          this.ProjectSchema.Children.Add((UIElement) element3);
          Panel.SetZIndex((UIElement) element3, -1);
          break;
        case "Comparator":
          SchemaBlock_Comparator schemaBlockComparator = new SchemaBlock_Comparator();
          schemaBlockComparator.Title = str3;
          schemaBlockComparator.UpperLeftPoint = position;
          SchemaBlock_Comparator element4 = schemaBlockComparator;
          element4.AddConnectionEventHandler(new Action<ConnectionNode>(this.AddConnectionNode));
          this.ProjectSchema.Children.Add((UIElement) element4);
          Panel.SetZIndex((UIElement) element4, -1);
          this.ComparatorSetChanged(Schema.UpdateOptions.Add);
          break;
        case "Comment":
          SchemaBlock_Comment schemaBlockComment = new SchemaBlock_Comment();
          schemaBlockComment.Title = str3;
          schemaBlockComment.UpperLeftPoint = position;
          SchemaBlock_Comment element5 = schemaBlockComment;
          this.ProjectSchema.Children.Add((UIElement) element5);
          Panel.SetZIndex((UIElement) element5, -1);
          break;
        default:
          int indexInListByName = this.GetDSPIndexInListByName((data.Parent as TreeViewItem).Header.ToString());
          int indexInDspListByName = this.GetDSPCellIndexInDSPListByName(indexInListByName, data.Header.ToString());
          string DSPTitle = this.DSPCells[indexInListByName].DSPBlocks[indexInDspListByName].DSPTitle;
          string CellTitle = this.DSPCells[indexInListByName].DSPBlocks[indexInDspListByName].Title;
          SchemaBlock_DSPCell[] array = this.ProjectSchema.Children.OfType<SchemaBlock_DSPCell>().Where<SchemaBlock_DSPCell>((Func<SchemaBlock_DSPCell, bool>) (b => b.Title == CellTitle && b.DSPTitle == DSPTitle)).ToArray<SchemaBlock_DSPCell>();
          if (array.Length != 0)
          {
            int num2 = (int) MessageBox.Show("Schema already contains selected block", "Block duplicate", MessageBoxButton.OK, MessageBoxImage.Asterisk);
            this.ActiveSchemaElementIndex = this.ProjectSchema.Children.IndexOf((UIElement) array[0]);
            (this.ProjectSchema.Children[this.ActiveSchemaElementIndex] as ISchemaElement).IsSelected = true;
            break;
          }
          SchemaBlock_DSPCell schemaBlockDspCell = new SchemaBlock_DSPCell();
          schemaBlockDspCell.Title = CellTitle;
          schemaBlockDspCell.DSPTitle = DSPTitle;
          schemaBlockDspCell.UpperLeftPoint = position;
          SchemaBlock_DSPCell element6 = schemaBlockDspCell;
          element6.AddConnectionEventHandler(new Action<ConnectionNode>(this.AddConnectionNode));
          element6.Initialize(this.DSPCells[indexInListByName].DSPBlocks[indexInDspListByName]);
          this.ProjectSchema.Children.Add((UIElement) element6);
          Panel.SetZIndex((UIElement) element6, -1);
          this.DSPCellsSetChanged(Schema.UpdateOptions.Add);
          break;
      }
    }
  }

  private void Schema_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
  {
    if (this.IsConnectionActive)
      return;
    this.SelectElement(e.Source as ISchemaElement);
  }

  private void Schema_MouseRightButtonDown(object sender, MouseButtonEventArgs e)
  {
    if (!this.IsConnectionActive)
      return;
    this.ProjectSchema.Children.RemoveAt(this.ProjectSchema.Children.Count - 1);
    this.DiscardNodeFilterInAllBlocks();
    this.IsConnectionActive = false;
    this.ProjectSchema.MouseRightButtonDown -= new MouseButtonEventHandler(this.Schema_MouseRightButtonDown);
    this.Schema_ChangeCursor(Schema.PROJECT_FIELD_CURSOR_MAIN);
  }

  private void Schema_MouseMove(object sender, MouseEventArgs e)
  {
    System.Windows.Point position = e.GetPosition((IInputElement) this.ProjectSchema);
    if (!this.IsConnectionActive)
    {
      if (this.ActiveSchemaElementIndex == -1 || !this.IsMovingPending || !(this.ProjectSchema.Children[this.ActiveSchemaElementIndex] is SchemaBlock child1))
        return;
      position.X = Schema.RoundCoordinate(position.X);
      position.Y = Schema.RoundCoordinate(position.Y);
      System.Windows.Point point = child1.ClickPoint();
      point.X = Schema.RoundCoordinate(point.X);
      point.Y = Schema.RoundCoordinate(point.Y);
      position.X -= point.X;
      position.Y -= point.Y;
      child1.UpperLeftPoint = position;
      for (int index = 0; index < this.ProjectSchema.Children.Count; ++index)
      {
        if (this.ProjectSchema.Children[index] is Connection child2)
        {
          int anchorNumberInBlock = child2.GetAnchorNumberInBlock(child1.FullName);
          if (anchorNumberInBlock != -1)
            child2.Update(child1.GetAnchorConnectionNode(anchorNumberInBlock));
        }
      }
    }
    else
    {
      if (!(this.ProjectSchema.Children[this.ProjectSchema.Children.Count - 1] is Connection child))
        return;
      LinePoint anchorpoint = new LinePoint()
      {
        X = position.X,
        Y = position.Y
      };
      child.Update(new ConnectionNode((string) null, 0, anchorpoint, Anchor.AnchorTypes.EMPTY));
    }
  }

  private void DSPCell_PreviewMouseLeftButtonDown(object sender, MouseButtonEventArgs e)
  {
    this.DragDropBlock(e);
  }

  private void Schema_MouseLeftButtonUp(object sender, MouseButtonEventArgs e)
  {
    this.IsMovingPending = false;
  }

  [DebuggerNonUserCode]
  [GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
  public void InitializeComponent()
  {
    if (this._contentLoaded)
      return;
    this._contentLoaded = true;
    Application.LoadComponent((object) this, new Uri("/ChipStudio;component/schema.xaml", UriKind.Relative));
  }

  [DebuggerNonUserCode]
  [GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
  [EditorBrowsable(EditorBrowsableState.Never)]
  void IComponentConnector.Connect(int connectionId, object target)
  {
    if (connectionId == 1)
    {
      this.ProjectSchema = (Canvas) target;
      this.ProjectSchema.Drop += new DragEventHandler(this.Schema_Drop);
      this.ProjectSchema.MouseLeftButtonDown += new MouseButtonEventHandler(this.Schema_MouseLeftButtonDown);
      this.ProjectSchema.MouseMove += new MouseEventHandler(this.Schema_MouseMove);
      this.ProjectSchema.MouseLeftButtonUp += new MouseButtonEventHandler(this.Schema_MouseLeftButtonUp);
    }
    else
      this._contentLoaded = true;
  }

  public enum UpdateOptions : byte
  {
    Init,
    Add,
    Remove,
  }
}
