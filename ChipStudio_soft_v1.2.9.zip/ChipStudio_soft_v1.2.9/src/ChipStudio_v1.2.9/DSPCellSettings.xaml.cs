﻿// Decompiled with JetBrains decompiler
// Type: ChipStudio.DSPCellSettings
// Assembly: ChipStudio, Version=1.2.9.0, Culture=neutral, PublicKeyToken=null
// MVID: 334E3BEA-37C7-4274-8118-535AAEFA1546
// Assembly location: D:\DocAndSec\Desktop\AUDIO\ChipDip\ChipStudio_soft_v1.2.9\ChipStudio_v1.2.9.exe

using Microsoft.Win32;
using System;
using System.CodeDom.Compiler;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Diagnostics;
using System.Linq;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Controls.Primitives;
using System.Windows.Markup;

#nullable disable
namespace ChipStudio;

public partial class DSPCellSettings : Window, IComponentConnector
{
  private const string DataFileFilter = "Data file (*.txt)|*.txt";
  private const string AddressStringFormat = "X4";
  private const string DataStringFormat = "X2";
  private readonly List<byte> Data;
  private readonly DSPCellDescription CellDesc;
  public List<string> DataList = new List<string>();
  internal StackPanel AddressPanel;
  internal ItemsControl CellAddresses;
  internal StackPanel DataPanel;
  internal ItemsControl CellData;
  private bool _contentLoaded;

  public DSPCellSettings(DSPCellDescription cell, List<byte> data)
  {
    this.CellDesc = cell;
    this.Data = data;
    this.InitializeComponent();
    this.DataContext = (object) this;
    if (this.CellDesc.AreParamsUpdated)
      this.UpdateAddressList();
    this.AddNewDataToList(this.Data.ToArray());
  }

  private void UpdateAddressList()
  {
    this.CellAddresses.ItemsSource = (IEnumerable) null;
    this.CellAddresses.ItemsSource = (IEnumerable) ((IEnumerable<ushort>) this.CellDesc.ParamsAddresses()).Select<ushort, string>((Func<ushort, string>) (a => "0x" + a.ToString("X4")));
  }

  private void AddNewDataToList(byte[] NewData)
  {
    string str = " ";
    for (int index = 0; index < NewData.Length; ++index)
    {
      str = $"{str}{NewData[index].ToString("X2")} ";
      if ((index + 1) % 4 == 0)
      {
        this.DataList.Add(str);
        str = " ";
      }
      else if (index + 1 == NewData.Length)
        this.DataList.Add(str);
    }
    this.CellData.ItemsSource = (IEnumerable) null;
    this.CellData.ItemsSource = (IEnumerable) this.DataList;
  }

  private void AddDataButton_Click(object sender, RoutedEventArgs e)
  {
    OpenFileDialog openFileDialog1 = new OpenFileDialog();
    openFileDialog1.Filter = "Data file (*.txt)|*.txt";
    OpenFileDialog openFileDialog2 = openFileDialog1;
    bool? nullable = openFileDialog2.ShowDialog();
    bool flag = true;
    byte[] Result;
    if (!(nullable.GetValueOrDefault() == flag & nullable.HasValue) || !this.CellDesc.TryParseData(openFileDialog2.FileName, out Result))
      return;
    this.Data.AddRange((IEnumerable<byte>) Result);
    this.AddNewDataToList(Result);
    if (this.CellAddresses.Items.Count != 0)
      return;
    this.UpdateAddressList();
  }

  private void ClearDataButton_Click(object sender, RoutedEventArgs e)
  {
    this.Data.Clear();
    this.DataList.Clear();
    this.CellData.ItemsSource = (IEnumerable) null;
    this.CellData.ItemsSource = (IEnumerable) this.DataList;
    if (!this.CellDesc.AreParamsModifiable)
      return;
    this.CellDesc.ResetParams();
    this.CellAddresses.ItemsSource = (IEnumerable) null;
  }

  [DebuggerNonUserCode]
  [GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
  public void InitializeComponent()
  {
    if (this._contentLoaded)
      return;
    this._contentLoaded = true;
    Application.LoadComponent((object) this, new Uri("/ChipStudio;component/dspcellsettings.xaml", UriKind.Relative));
  }

  [DebuggerNonUserCode]
  [GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
  [EditorBrowsable(EditorBrowsableState.Never)]
  void IComponentConnector.Connect(int connectionId, object target)
  {
    switch (connectionId)
    {
      case 1:
        this.AddressPanel = (StackPanel) target;
        break;
      case 2:
        this.CellAddresses = (ItemsControl) target;
        break;
      case 3:
        this.DataPanel = (StackPanel) target;
        break;
      case 4:
        this.CellData = (ItemsControl) target;
        break;
      case 5:
        ((ButtonBase) target).Click += new RoutedEventHandler(this.AddDataButton_Click);
        break;
      case 6:
        ((ButtonBase) target).Click += new RoutedEventHandler(this.ClearDataButton_Click);
        break;
      default:
        this._contentLoaded = true;
        break;
    }
  }
}
