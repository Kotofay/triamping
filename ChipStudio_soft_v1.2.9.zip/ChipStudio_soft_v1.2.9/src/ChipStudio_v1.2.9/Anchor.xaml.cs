﻿// Decompiled with JetBrains decompiler
// Type: ChipStudio.Anchor
// Assembly: ChipStudio, Version=1.2.9.0, Culture=neutral, PublicKeyToken=null
// MVID: 334E3BEA-37C7-4274-8118-535AAEFA1546
// Assembly location: D:\DocAndSec\Desktop\AUDIO\ChipDip\ChipStudio_soft_v1.2.9\ChipStudio_v1.2.9.exe

using System;
using System.CodeDom.Compiler;
using System.ComponentModel;
using System.Diagnostics;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Markup;
using System.Windows.Media;
using System.Windows.Shapes;

#nullable disable
namespace ChipStudio;

public partial class Anchor : UserControl, INotifyPropertyChanged, IComponentConnector
{
  private static readonly Brush AnchorActiveColor = (Brush) Application.Current.FindResource((object) nameof (AnchorActiveColor));
  private static readonly Brush AnchorNotActiveColor = (Brush) Application.Current.FindResource((object) nameof (AnchorNotActiveColor));
  private static readonly string OldAnchorFromPOTToDSPCell = "FromPOTToDSPCell";
  private static readonly string OldAnchorFromDSPCellToPOT = "FromDSPCellToPOT";
  private static readonly string OldAnchorFromKeySwitchToDSPCell = "FromKeySwitchToDSPCell";
  private static readonly string OldAnchorFromDSPCellToKeySwitch = "FromDSPCellToKeySwitch";
  private static readonly Anchor.AnchorTypes[] DirectAnchors = new Anchor.AnchorTypes[17]
  {
    Anchor.AnchorTypes.EMPTY,
    Anchor.AnchorTypes.ToSlave_I2C,
    Anchor.AnchorTypes.ToSlave_SPI,
    Anchor.AnchorTypes.ToSlave_CS,
    Anchor.AnchorTypes.ToDSPCell,
    Anchor.AnchorTypes.ToLED,
    Anchor.AnchorTypes.ToPixel,
    Anchor.AnchorTypes.FromSlave_I2C,
    Anchor.AnchorTypes.FromSlave_SPI,
    Anchor.AnchorTypes.FromSlave_CS,
    Anchor.AnchorTypes.FromDSPCell,
    Anchor.AnchorTypes.FromLED,
    Anchor.AnchorTypes.FromPixel,
    Anchor.AnchorTypes.ToRead,
    Anchor.AnchorTypes.ToComparator,
    Anchor.AnchorTypes.FromRead,
    Anchor.AnchorTypes.FromComparator
  };
  private static readonly Anchor.AnchorTypes[] OppositeAnchors = new Anchor.AnchorTypes[17]
  {
    Anchor.AnchorTypes.EMPTY,
    Anchor.AnchorTypes.FromSlave_I2C,
    Anchor.AnchorTypes.FromSlave_SPI,
    Anchor.AnchorTypes.FromSlave_CS,
    Anchor.AnchorTypes.FromDSPCell,
    Anchor.AnchorTypes.FromLED,
    Anchor.AnchorTypes.FromPixel,
    Anchor.AnchorTypes.ToSlave_I2C,
    Anchor.AnchorTypes.ToSlave_SPI,
    Anchor.AnchorTypes.ToSlave_CS,
    Anchor.AnchorTypes.ToDSPCell,
    Anchor.AnchorTypes.ToLED,
    Anchor.AnchorTypes.ToPixel,
    Anchor.AnchorTypes.FromRead,
    Anchor.AnchorTypes.FromComparator,
    Anchor.AnchorTypes.ToRead,
    Anchor.AnchorTypes.ToComparator
  };
  private Brush color = (Brush) Brushes.LightGray;
  private bool isactivated;
  private System.Windows.Point center;
  private LinePoint relativecenter = new LinePoint();
  private bool isfilteredout;
  private string title;
  internal Ellipse AnchorPoint;
  internal TextBlock AnchorName;
  private bool _contentLoaded;

  public Anchor()
  {
    this.InitializeComponent();
    this.DataContext = (object) this;
    this.Color = Anchor.AnchorNotActiveColor;
  }

  public Brush Color
  {
    get => this.color;
    set
    {
      if (this.color == value)
        return;
      this.color = value;
      this.NotifyPropertyChanged(nameof (Color));
    }
  }

  public bool IsActivated
  {
    get => this.isactivated;
    set
    {
      if (this.isactivated == value)
        return;
      this.isactivated = value;
      if (this.isactivated)
      {
        this.AnchorPoint.Cursor = Cursors.Hand;
        this.AnchorPoint.MouseLeftButtonDown += new MouseButtonEventHandler(this.Anchorpoint_MouseLeftButtonDown);
        this.Color = Anchor.AnchorActiveColor;
      }
      else
      {
        this.AnchorPoint.Cursor = Cursors.Arrow;
        this.AnchorPoint.MouseLeftButtonDown -= new MouseButtonEventHandler(this.Anchorpoint_MouseLeftButtonDown);
        this.Color = Anchor.AnchorNotActiveColor;
      }
    }
  }

  public bool IsFilteredOut
  {
    get => this.isfilteredout;
    set
    {
      if (this.isfilteredout == value)
        return;
      this.isfilteredout = value;
      this.IsActivated = !this.isfilteredout;
    }
  }

  public Anchor.AnchorTypes Type { get; set; }

  public LinePoint RelativeCenter => this.relativecenter;

  public int Number { get; set; }

  public string Title
  {
    get => this.title;
    set
    {
      if (!(this.title != value))
        return;
      this.title = value;
      this.AnchorName.Visibility = Visibility.Visible;
      this.AnchorName.Text = this.title;
    }
  }

  public void UpdateCenterRelativeTo(Visual visual)
  {
    this.center = new System.Windows.Point(this.AnchorPoint.ActualWidth / 2.0, this.AnchorPoint.ActualHeight / 2.0);
    System.Windows.Point point = this.TransformToVisual(visual).Transform(this.center);
    this.relativecenter.X = point.X;
    this.relativecenter.Y = point.Y;
  }

  public static bool TryParseAnchorType(string value, out Anchor.AnchorTypes result)
  {
    result = Anchor.AnchorTypes.EMPTY;
    foreach (Anchor.AnchorTypes anchorTypes in Enum.GetValues(typeof (Anchor.AnchorTypes)))
    {
      if (anchorTypes.ToString() == value)
      {
        result = anchorTypes;
        return true;
      }
    }
    if (value == Anchor.OldAnchorFromPOTToDSPCell || value == Anchor.OldAnchorFromKeySwitchToDSPCell)
    {
      result = Anchor.AnchorTypes.ToDSPCell;
      return true;
    }
    if (!(value == Anchor.OldAnchorFromDSPCellToPOT) && !(value == Anchor.OldAnchorFromDSPCellToKeySwitch))
      return false;
    result = Anchor.AnchorTypes.FromDSPCell;
    return true;
  }

  public static Anchor.AnchorTypes OppositeAnchor(Anchor.AnchorTypes AnchorValue)
  {
    return Anchor.OppositeAnchors[Array.IndexOf<Anchor.AnchorTypes>(Anchor.DirectAnchors, AnchorValue)];
  }

  public event PropertyChangedEventHandler PropertyChanged;

  public void NotifyPropertyChanged(string PropertyName)
  {
    PropertyChangedEventHandler propertyChanged = this.PropertyChanged;
    if (propertyChanged == null)
      return;
    propertyChanged((object) this, new PropertyChangedEventArgs(PropertyName));
  }

  public event Anchor.AnchorConnectionEventHandler AnchorConnection;

  private void Anchorpoint_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
  {
    Anchor.AnchorConnectionEventHandler anchorConnection = this.AnchorConnection;
    if (anchorConnection == null)
      return;
    anchorConnection(this.Number, this.RelativeCenter, this.Type);
  }

  [DebuggerNonUserCode]
  [GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
  public void InitializeComponent()
  {
    if (this._contentLoaded)
      return;
    this._contentLoaded = true;
    Application.LoadComponent((object) this, new Uri("/ChipStudio;component/anchor.xaml", UriKind.Relative));
  }

  [DebuggerNonUserCode]
  [GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
  [EditorBrowsable(EditorBrowsableState.Never)]
  void IComponentConnector.Connect(int connectionId, object target)
  {
    if (connectionId != 1)
    {
      if (connectionId == 2)
        this.AnchorName = (TextBlock) target;
      else
        this._contentLoaded = true;
    }
    else
      this.AnchorPoint = (Ellipse) target;
  }

  public enum AnchorTypes : byte
  {
    EMPTY,
    ToSlave_I2C,
    FromSlave_I2C,
    ToSlave_SPI,
    FromSlave_SPI,
    ToSlave_CS,
    FromSlave_CS,
    ToDSPCell,
    FromDSPCell,
    ToLED,
    FromLED,
    FromPixel,
    ToPixel,
    ToRead,
    FromRead,
    ToComparator,
    FromComparator,
  }

  public delegate void AnchorConnectionEventHandler(
    int AnchorNumber,
    LinePoint AnchorPoint,
    Anchor.AnchorTypes AnchorType);
}
