﻿// Decompiled with JetBrains decompiler
// Type: ChipStudio.SchemaBlock_LED
// Assembly: ChipStudio, Version=1.2.9.0, Culture=neutral, PublicKeyToken=null
// MVID: 334E3BEA-37C7-4274-8118-535AAEFA1546
// Assembly location: D:\DocAndSec\Desktop\AUDIO\ChipDip\ChipStudio_soft_v1.2.9\ChipStudio_v1.2.9.exe

using System;
using System.CodeDom.Compiler;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Diagnostics;
using System.Linq;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Controls.Primitives;
using System.Windows.Input;
using System.Windows.Markup;

#nullable disable
namespace ChipStudio;

public partial class SchemaBlock_LED : SchemaBlock, ILed, IComparatorDependent, IComponentConnector
{
  private static readonly Anchor.AnchorTypes[] PointAnchors = new Anchor.AnchorTypes[1]
  {
    Anchor.AnchorTypes.FromLED
  };
  private const int COMPARATOR_STATES_COUNT = 2;
  private List<LEDStateTemplate> LEDStatesList = new List<LEDStateTemplate>();
  private bool dsp_mode;
  internal ItemsControl ConnectPoints;
  internal DSPBlockSelector BlockList;
  internal Selector CompSelector;
  internal RadioButton DSPModeSel;
  internal RadioButton CompModeSel;
  private bool _contentLoaded;

  public override SchemaBlock.SchemaBlockTypes BlockType => SchemaBlock.SchemaBlockTypes.LED;

  public ConnectionNode DSPBlockConnectionNode => this.BlockList.ActiveConnectionNode();

  public string ActiveComparator => this.DSPMode ? (string) null : this.CompSelector.SelectedItem;

  public bool DSPMode
  {
    get => this.dsp_mode;
    set
    {
      if (this.dsp_mode == value)
        return;
      this.dsp_mode = value;
      this.BlockList.Visibility = this.dsp_mode ? Visibility.Visible : Visibility.Hidden;
      this.CompSelector.Visibility = this.dsp_mode ? Visibility.Hidden : Visibility.Visible;
    }
  }

  public SchemaBlock_LED()
  {
    this.InitializeComponent();
    this.DataContext = (object) this;
    this.BlockList.SelectionChanged += new DSPBlockSelector.SelectionChangedEventHandler(this.BlockChanged);
    this.InitConnectionPoints(SchemaBlock_LED.PointAnchors);
    this.ConnectPoints.ItemsSource = (IEnumerable) this.ConnectionPoints;
    this.DSPModeSel.IsChecked = new bool?(true);
    this.DSPMode = true;
  }

  public void UpdateBlockList(SchemaBlock_DSPCell[] Blocks, Schema.UpdateOptions Option)
  {
    this.BlockList.Update(Blocks, Option);
  }

  public void UpdateComparatorList(string[] ComparatorTitles, Schema.UpdateOptions Option)
  {
    this.CompSelector.Update(ComparatorTitles, Option);
  }

  public byte[] GetData()
  {
    return this.LEDStatesList.Select<LEDStateTemplate, byte>((Func<LEDStateTemplate, byte>) (i => (byte) i.ActiveState)).ToArray<byte>();
  }

  public void SetData(byte[] Data)
  {
    this.LEDStatesList.Clear();
    for (int index = 0; index < Data.Length; ++index)
    {
      this.AddNewLEDStateTemplate(index);
      this.LEDStatesList[index].ActiveState = (int) Data[index];
    }
  }

  public int GetDefaultBlockIndex()
  {
    return !this.DSPMode ? this.CompSelector.SelectedIndex : this.BlockList.DefaultBlock;
  }

  public void SetDefaultBlockIndex(int BlockIndex)
  {
    if (this.DSPMode)
      this.BlockList.DefaultBlock = BlockIndex;
    else
      this.CompSelector.SelectedIndex = BlockIndex;
  }

  public void SetMode(bool Mode)
  {
    if (Mode)
      this.DSPModeSel.IsChecked = new bool?(true);
    else
      this.CompModeSel.IsChecked = new bool?(true);
  }

  private void LEDStatesConfig_Click(object sender, RoutedEventArgs e)
  {
    int num = this.DSPMode ? this.BlockList.ActiveValuesCount() : 2;
    if (num == -1)
      return;
    if (this.LEDStatesList.Count < num)
    {
      while (this.LEDStatesList.Count < num)
        this.AddNewLEDStateTemplate(this.LEDStatesList.Count);
    }
    else if (this.LEDStatesList.Count > num)
    {
      while (this.LEDStatesList.Count > num)
        this.LEDStatesList.RemoveAt(this.LEDStatesList.Count - 1);
    }
    List<LEDStateTemplate> LEDStatesList = new List<LEDStateTemplate>();
    for (int index = 0; index < this.LEDStatesList.Count; ++index)
    {
      LEDStateTemplate ledStateTemplate = new LEDStateTemplate()
      {
        Number = index,
        ActiveState = this.LEDStatesList[index].ActiveState
      };
      LEDStatesList.Add(ledStateTemplate);
    }
    bool? nullable = new LEDStatesWindow(this.Title, LEDStatesList).ShowDialog();
    bool flag = true;
    if (!(nullable.GetValueOrDefault() == flag & nullable.HasValue))
      return;
    this.LEDStatesList = LEDStatesList;
  }

  private void BlockChanged(int ValuesCount)
  {
    this.LEDStatesList.Clear();
    for (int Number = 0; Number < ValuesCount; ++Number)
      this.AddNewLEDStateTemplate(Number);
  }

  private void AddNewLEDStateTemplate(int Number)
  {
    this.LEDStatesList.Add(new LEDStateTemplate()
    {
      Number = Number,
      ActiveState = 0
    });
  }

  private void DSPModeSel_Checked(object sender, RoutedEventArgs e) => this.DSPMode = true;

  private void DSPModeSel_UnChecked(object sender, RoutedEventArgs e) => this.DSPMode = false;

  [DebuggerNonUserCode]
  [GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
  public void InitializeComponent()
  {
    if (this._contentLoaded)
      return;
    this._contentLoaded = true;
    Application.LoadComponent((object) this, new Uri("/ChipStudio;component/schemablock_led.xaml", UriKind.Relative));
  }

  [DebuggerNonUserCode]
  [GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
  internal Delegate _CreateDelegate(Type delegateType, string handler)
  {
    return Delegate.CreateDelegate(delegateType, (object) this, handler);
  }

  [DebuggerNonUserCode]
  [GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
  [EditorBrowsable(EditorBrowsableState.Never)]
  void IComponentConnector.Connect(int connectionId, object target)
  {
    switch (connectionId)
    {
      case 1:
        ((UIElement) target).MouseLeftButtonDown += new MouseButtonEventHandler(((SchemaBlock) this).Border_MouseLeftButtonDown);
        break;
      case 2:
        this.ConnectPoints = (ItemsControl) target;
        break;
      case 3:
        this.BlockList = (DSPBlockSelector) target;
        break;
      case 4:
        this.CompSelector = (Selector) target;
        break;
      case 5:
        this.DSPModeSel = (RadioButton) target;
        this.DSPModeSel.Checked += new RoutedEventHandler(this.DSPModeSel_Checked);
        this.DSPModeSel.Unchecked += new RoutedEventHandler(this.DSPModeSel_UnChecked);
        break;
      case 6:
        this.CompModeSel = (RadioButton) target;
        break;
      case 7:
        ((ButtonBase) target).Click += new RoutedEventHandler(this.LEDStatesConfig_Click);
        break;
      default:
        this._contentLoaded = true;
        break;
    }
  }
}
