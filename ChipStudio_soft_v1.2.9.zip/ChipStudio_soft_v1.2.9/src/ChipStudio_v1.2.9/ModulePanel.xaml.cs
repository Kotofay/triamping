﻿// Decompiled with JetBrains decompiler
// Type: ChipStudio.ModulePanel
// Assembly: ChipStudio, Version=1.2.9.0, Culture=neutral, PublicKeyToken=null
// MVID: 334E3BEA-37C7-4274-8118-535AAEFA1546
// Assembly location: D:\DocAndSec\Desktop\AUDIO\ChipDip\ChipStudio_soft_v1.2.9\ChipStudio_v1.2.9.exe

using System;
using System.CodeDom.Compiler;
using System.Collections;
using System.ComponentModel;
using System.Diagnostics;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Markup;

#nullable disable
namespace ChipStudio;

public partial class ModulePanel : UserControl, IComponentConnector
{
  internal TreeView Modules;
  private bool _contentLoaded;

  public ModulePanel()
  {
    this.InitializeComponent();
    this.DataContext = (object) this;
    this.Initialize();
  }

  public void SetDragDropAction(MouseButtonEventHandler DragDropAction)
  {
    foreach (ItemsControl itemsControl in (IEnumerable) this.Modules.Items)
    {
      foreach (UIElement uiElement in (IEnumerable) itemsControl.Items)
        uiElement.PreviewMouseLeftButtonDown += DragDropAction;
    }
  }

  private void Initialize()
  {
    this.AddGroup(Shared.ControllersFolder);
    this.AddGroup(Shared.DSPCodecFolder);
    TreeViewItem treeViewItem1 = new TreeViewItem();
    treeViewItem1.Header = (object) "Parts";
    treeViewItem1.IsExpanded = true;
    TreeViewItem newItem1 = treeViewItem1;
    ItemCollection items1 = newItem1.Items;
    TreeViewItem newItem2 = new TreeViewItem();
    newItem2.Header = (object) "LED";
    items1.Add((object) newItem2);
    ItemCollection items2 = newItem1.Items;
    TreeViewItem newItem3 = new TreeViewItem();
    newItem3.Header = (object) "PixelLED";
    items2.Add((object) newItem3);
    this.Modules.Items.Add((object) newItem1);
    TreeViewItem treeViewItem2 = new TreeViewItem();
    treeViewItem2.Header = (object) "DSPFunctions";
    treeViewItem2.IsExpanded = true;
    TreeViewItem newItem4 = treeViewItem2;
    ItemCollection items3 = newItem4.Items;
    TreeViewItem newItem5 = new TreeViewItem();
    newItem5.Header = (object) "Read";
    items3.Add((object) newItem5);
    ItemCollection items4 = newItem4.Items;
    TreeViewItem newItem6 = new TreeViewItem();
    newItem6.Header = (object) "Comparator";
    items4.Add((object) newItem6);
    this.Modules.Items.Add((object) newItem4);
    TreeViewItem treeViewItem3 = new TreeViewItem();
    treeViewItem3.Header = (object) "Others";
    treeViewItem3.IsExpanded = true;
    TreeViewItem newItem7 = treeViewItem3;
    ItemCollection items5 = newItem7.Items;
    TreeViewItem newItem8 = new TreeViewItem();
    newItem8.Header = (object) "Comment";
    items5.Add((object) newItem8);
    this.Modules.Items.Add((object) newItem7);
  }

  private void AddGroup(string Header)
  {
    string[] folderFiles = Shared.GetFolderFiles(Header);
    if (folderFiles == null)
      return;
    TreeViewItem treeViewItem = new TreeViewItem();
    treeViewItem.Header = (object) Header;
    treeViewItem.IsExpanded = true;
    TreeViewItem newItem1 = treeViewItem;
    foreach (string str in folderFiles)
    {
      ItemCollection items = newItem1.Items;
      TreeViewItem newItem2 = new TreeViewItem();
      newItem2.Header = (object) str;
      items.Add((object) newItem2);
    }
    this.Modules.Items.Add((object) newItem1);
  }

  [DebuggerNonUserCode]
  [GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
  public void InitializeComponent()
  {
    if (this._contentLoaded)
      return;
    this._contentLoaded = true;
    Application.LoadComponent((object) this, new Uri("/ChipStudio;component/modulepanel.xaml", UriKind.Relative));
  }

  [DebuggerNonUserCode]
  [GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
  [EditorBrowsable(EditorBrowsableState.Never)]
  void IComponentConnector.Connect(int connectionId, object target)
  {
    if (connectionId == 1)
      this.Modules = (TreeView) target;
    else
      this._contentLoaded = true;
  }
}
