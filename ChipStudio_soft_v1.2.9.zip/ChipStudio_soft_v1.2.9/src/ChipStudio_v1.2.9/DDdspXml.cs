﻿// Decompiled with JetBrains decompiler
// Type: ChipStudio.DDdspXml
// Assembly: ChipStudio, Version=1.2.9.0, Culture=neutral, PublicKeyToken=null
// MVID: 334E3BEA-37C7-4274-8118-535AAEFA1546
// Assembly location: D:\DocAndSec\Desktop\AUDIO\ChipDip\ChipStudio_soft_v1.2.9\ChipStudio_v1.2.9.exe

using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Windows;
using System.Xml.Linq;

#nullable disable
namespace ChipStudio;

public class DDdspXml : IDDdsp
{
  private const string InterfaceString = "Interface";
  private const string IsSelfBootableString = "IsSelfBootable";
  private const string AdrLineStatesString = "AdrLineStates";
  private const string AdrValuesString = "AdrValues";
  private const string AreCellsConstantString = "AreCellsConstant";
  private const string ProjectFileFormatString = "ProjectFileFormat";
  private const string ConfigurationFileString = "ConfigurationFile";
  private const string ProjectFileFormatDefault = "(*.txt)|*.txt";
  private const string InternalAddressSizeString = "InternalAddressSize";
  private const byte Dsp_1_ByteAddressId = 254;
  private const byte Dsp_2_ByteAddressId = 253;
  private const byte Dsp_0_ByteAddressId = 252;
  private const byte BusAddressDefault = 255 /*0xFF*/;
  private readonly uint BusAddress;
  private readonly string[] AdrLineStates;
  private readonly uint[] AdrValues;
  private readonly DSPCell[] cells;

  public bool IsLoaded { get; }

  public byte ID { get; }

  public string Interface { get; }

  public bool IsSelfBootable { get; }

  public string FileFormat { get; }

  public DSPCell[] Cells => this.cells;

  public bool AreCellsConstant { get; }

  public DDdspXml(string ModuleType)
  {
    if (!Directory.Exists(Shared.DDdspPath))
    {
      int num1 = (int) MessageBox.Show($"Folder\n\r...{Shared.DSPCodecFolder}\n\r{Shared.DoesNotExistString}", "", MessageBoxButton.OK, MessageBoxImage.Hand);
    }
    else
    {
      string str1 = ModuleType + Shared.DDFileExt;
      string str2 = Shared.DDdspPath + Shared.FilePathSlash + str1;
      string uri = str2;
      if (!File.Exists(str2))
      {
        int num2 = (int) MessageBox.Show($"Device description file\n\r{str1}\n\r{Shared.DoesNotExistString}", "", MessageBoxButton.OK, MessageBoxImage.Hand);
      }
      else
      {
        XDocument DspDoc = XDocument.Load(str2);
        string str3 = DspDoc.Element((XName) "DSP")?.Attribute((XName) "Base")?.Value;
        bool flag = false;
        if (str3 != null)
        {
          if (DspDoc.Element((XName) "DSP")?.Element((XName) nameof (Cells))?.Elements((XName) "Cell") != null)
            flag = true;
          string str4 = str3 + Shared.DDFileExt;
          string str5 = Shared.DDdspPath + Shared.FilePathSlash + str4;
          if (!File.Exists(str5))
          {
            int num3 = (int) MessageBox.Show($"Device description file\n\r{str4}\n\r{Shared.DoesNotExistString}", "", MessageBoxButton.OK, MessageBoxImage.Hand);
            return;
          }
          DspDoc = XDocument.Load(str5);
        }
        int result1;
        this.ID = int.TryParse(DspDoc.Element((XName) "DSP")?.Attribute((XName) nameof (ID))?.Value, out result1) ? (byte) result1 : (byte) 254;
        if (this.ID == (byte) 254)
        {
          string s = DspDoc.Element((XName) "DSP")?.Attribute((XName) "InternalAddressSize")?.Value;
          if (s != null && int.TryParse(s, out result1))
          {
            switch (result1)
            {
              case 0:
                this.ID = (byte) 252;
                break;
              case 2:
                this.ID = (byte) 253;
                break;
              default:
                this.ID = (byte) 254;
                break;
            }
          }
        }
        this.Interface = DspDoc.Element((XName) "DSP")?.Attribute((XName) nameof (Interface))?.Value ?? "SPI";
        bool result2;
        this.IsSelfBootable = bool.TryParse(DspDoc.Element((XName) "DSP")?.Attribute((XName) nameof (IsSelfBootable))?.Value, out result2) && result2;
        string str6 = DspDoc.Element((XName) "DSP")?.Element((XName) nameof (BusAddress))?.Attribute((XName) "Value")?.Value;
        uint result3;
        this.BusAddress = str6 != null ? (Shared.TryParseHEX(str6.Replace("0x", ""), out result3) ? result3 : (uint) byte.MaxValue) : (uint) byte.MaxValue;
        XElement xelement1 = DspDoc.Element((XName) "DSP");
        string[] strArray;
        if (xelement1 == null)
        {
          strArray = (string[]) null;
        }
        else
        {
          XElement xelement2 = xelement1.Element((XName) nameof (BusAddress));
          if (xelement2 == null)
          {
            strArray = (string[]) null;
          }
          else
          {
            XElement xelement3 = xelement2.Element((XName) nameof (AdrLineStates));
            if (xelement3 == null)
              strArray = (string[]) null;
            else
              strArray = xelement3.Value.Split(";"[0]);
          }
        }
        this.AdrLineStates = strArray;
        if (this.AdrLineStates != null)
        {
          XElement xelement4 = DspDoc.Element((XName) "DSP");
          string[] source;
          if (xelement4 == null)
          {
            source = (string[]) null;
          }
          else
          {
            XElement xelement5 = xelement4.Element((XName) nameof (BusAddress));
            if (xelement5 == null)
            {
              source = (string[]) null;
            }
            else
            {
              XElement xelement6 = xelement5.Element((XName) nameof (AdrValues));
              if (xelement6 == null)
                source = (string[]) null;
              else
                source = xelement6.Value.Split(";"[0]);
            }
          }
          uint result4;
          this.AdrValues = ((IEnumerable<string>) source).Select<string, uint>((Func<string, uint>) (p => !Shared.TryParseHEX(p.Replace("0x", ""), out result4) ? this.BusAddress : result4)).ToArray<uint>();
        }
        this.FileFormat = DspDoc.Element((XName) "DSP")?.Element((XName) "ProjectFileFormat")?.Value ?? "(*.txt)|*.txt";
        this.AreCellsConstant = bool.TryParse(DspDoc.Element((XName) "DSP")?.Element((XName) nameof (Cells))?.Attribute((XName) nameof (AreCellsConstant))?.Value, out result2) && result2;
        DSPCell[] XmlCells1;
        if (!this.GetCells(DspDoc, out XmlCells1))
          return;
        if (flag)
        {
          DSPCell[] XmlCells2;
          if (!this.GetCells(XDocument.Load(uri), out XmlCells2))
            return;
          XmlCells1 = ((IEnumerable<DSPCell>) XmlCells1).Concat<DSPCell>((IEnumerable<DSPCell>) XmlCells2).ToArray<DSPCell>();
        }
        this.cells = XmlCells1;
        this.IsLoaded = true;
      }
    }
  }

  public void BusAddressInfo(out uint BusAdr, out string[] AdrLineStates, out uint[] AdrValues)
  {
    BusAdr = this.BusAddress;
    AdrLineStates = this.AdrLineStates;
    AdrValues = this.AdrValues;
  }

  private bool GetCells(XDocument DspDoc, out DSPCell[] XmlCells)
  {
    XmlCells = (DSPCell[]) null;
    XElement xelement1 = DspDoc.Element((XName) "DSP");
    \u003C\u003Ef__AnonymousType1<string, bool, bool, DSPCell.WriteTypes, \u003C\u003Ef__AnonymousType2<string, ushort, ushort>[]>[] dataArray1;
    if (xelement1 == null)
    {
      dataArray1 = null;
    }
    else
    {
      XElement xelement2 = xelement1.Element((XName) "Cells");
      if (xelement2 == null)
      {
        dataArray1 = null;
      }
      else
      {
        IEnumerable<XElement> source1 = xelement2.Elements((XName) "Cell");
        dataArray1 = source1 != null ? source1.Select(p =>
        {
          string str = p.Attribute((XName) "Title")?.Value;
          bool result1;
          int num1 = bool.TryParse(p.Attribute((XName) "IsControllable")?.Value, out result1) ? (result1 ? 1 : 0) : 1;
          bool result2;
          int num2 = bool.TryParse(p.Attribute((XName) "IsBypassable")?.Value, out result2) ? (result2 ? 1 : 0) : 0;
          DSPCell.WriteTypes result3;
          int num3 = DSPCell.TryParse(p.Attribute((XName) "WriteType")?.Value, out result3) ? (int) result3 : 1;
          XElement xelement3 = p.Element((XName) "Parameters");
          \u003C\u003Ef__AnonymousType2<string, ushort, ushort>[] dataArray2;
          if (xelement3 == null)
          {
            dataArray2 = null;
          }
          else
          {
            IEnumerable<XElement> source2 = xelement3.Elements((XName) "Parameter");
            ushort result4;
            ushort result5;
            dataArray2 = source2 != null ? source2.Select(e => new
            {
              Name = e.Element((XName) "Name")?.Value,
              Address = ushort.TryParse(e.Element((XName) "Address")?.Value, out result4) ? result4 : (ushort) 0,
              Size = ushort.TryParse(e.Element((XName) "Size")?.Value, out result5) ? result5 : (ushort) 1
            }).ToArray() : null;
          }
          return new
          {
            Title = str,
            IsControllable = num1 != 0,
            IsBypassable = num2 != 0,
            WriteType = (DSPCell.WriteTypes) num3,
            Parameters = dataArray2
          };
        }).ToArray() : null;
      }
    }
    \u003C\u003Ef__AnonymousType1<string, bool, bool, DSPCell.WriteTypes, \u003C\u003Ef__AnonymousType2<string, ushort, ushort>[]>[] source = dataArray1;
    if (source != null && source.Count() != 0)
    {
      XmlCells = new DSPCell[source.Count()];
      for (int index = 0; index < source.Count(); ++index)
      {
        XmlCells[index] = new DSPCell(source[index].Title)
        {
          IsControllable = source[index].IsControllable,
          IsBypassable = source[index].IsBypassable,
          WriteType = source[index].WriteType
        };
        foreach (var parameter in source[index].Parameters)
          XmlCells[index].ParamsFromFile.Add(new DSPCellParameter(parameter.Name, parameter.Address, parameter.Size));
        XmlCells[index].CloneParamsFromFileToParamsUsed();
      }
    }
    return true;
  }
}
