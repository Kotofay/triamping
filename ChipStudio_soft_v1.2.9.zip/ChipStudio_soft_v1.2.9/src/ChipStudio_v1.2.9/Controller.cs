﻿// Decompiled with JetBrains decompiler
// Type: ChipStudio.Controller
// Assembly: ChipStudio, Version=1.2.9.0, Culture=neutral, PublicKeyToken=null
// MVID: 334E3BEA-37C7-4274-8118-535AAEFA1546
// Assembly location: D:\DocAndSec\Desktop\AUDIO\ChipDip\ChipStudio_soft_v1.2.9\ChipStudio_v1.2.9.exe

using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows;
using System.Windows.Media;

#nullable disable
namespace ChipStudio;

public class Controller
{
  private const string GPIO_BUTTON = "BUTTON";
  private const string GPIO_SWITCH = "SWITCH";
  private const string GPIO_ADC = "RESISTOR";
  private const string GPIO_CHIP_SELECT = "CHIP SELECT";
  private const string GPIO_LED = "LED";
  private const string GPIO_ENCODER = "ENC_";
  private const string ENCODER_B_LINE = "B";
  private const string GPIO_PMBUTTON = "PMB_";
  private const string GPIO_TOUCH = "TOUCH";
  private const string PMBUTTON_M_LINE = "-";
  private const string GPIO_PIXEL_LED = "Pixel LED";
  private const string GPIO_CLI = "CLI";
  private const int GPIO_NOT_ACTIVE_STRING_INDEX = 0;
  private const int GPIO_FUNCTION_LENGTH = 70;
  private const int GPIO_TITLE_LENGTH = 10;
  private const int INTERFACE_TITLE_LENGTH = 20;
  private const int GPIOS_GROUP_INDEX = 0;
  private const int GPIOI_GROUP_INDEX = 1;
  private const int DSPI_GROUP_INDEX = 2;
  private const int PIXEL_GROUP_INDEX = 3;
  private const int CLI_GROUP_INDEX = 4;
  private const int PIXEL_GROUP_GPIO_COUNT = 1;
  private const int CLI_GROUP_GPIO_COUNT = 1;
  private const int INTERFACE_NOT_ACTIVE_INDEX = 0;
  private const int INTERFACE_ACTIVE_INDEX = 1;
  private const int DEFAULT_TIMER_VAL = 1;
  private readonly int PixelGpio = -1;
  private readonly int[] CLIGpio = new int[2]{ -1, -1 };
  private readonly int CLIGroupIndex = 4;
  private readonly int CECGpio = -1;
  private readonly int GpioGroupsCount = 3;
  private readonly int TouchCapGpioNum;
  private readonly int[] DelayTimerPCS;
  private readonly int[] DelayTimerARR;
  private readonly int[] MuteTimerPCS;
  private readonly int[] MuteTimerARR;
  private readonly int[] GPIOI_FunctionIndex;
  private readonly int[][] GPIOI_Lines;
  private readonly string[] AudioConfiguration;
  private PixelModule _Pixel = new PixelModule();
  private CLIModule _CLI = new CLIModule();
  private CEC _CEC = new CEC();
  private ControllerOptions Options = new ControllerOptions();
  private GPIO[][] GPIOLines;
  private readonly GPIO[] GPIOsWithOptions;

  public byte ID { get; }

  public ushort USBPacketSize { get; }

  public byte DownLoadAPI { get; }

  public int ProjectMemorySize { get; }

  public bool IsLoaded { get; }

  public bool IsPixelSupported { get; }

  public bool IsCLISupported { get; }

  public bool IsCECSupported { get; }

  public GPIO[] GPIOsGroup => this.GPIOLines[0];

  public GPIO[] GPIOIGroup => this.GPIOLines[1];

  public GPIO[] DSPIGroup => this.GPIOLines[2];

  public GPIO[] PixelGroup => !this.IsPixelSupported ? (GPIO[]) null : this.GPIOLines[3];

  public GPIO[] CLIGroup
  {
    get => !this.IsCLISupported ? (GPIO[]) null : this.GPIOLines[this.CLIGroupIndex];
  }

  public bool AreOptionsSupported { get; }

  public uint SupportedOptions { get; }

  public bool AreUSBSetsSupported { get; }

  public string[] DelayValues { get; }

  public string[] MuteValues { get; }

  public Controller(IDDController CtrlDescription)
  {
    this.IsLoaded = CtrlDescription.IsLoaded;
    if (!this.IsLoaded)
    {
      int num = (int) MessageBox.Show("Wrong device description format", "", MessageBoxButton.OK, MessageBoxImage.Hand);
    }
    else
    {
      this.ID = CtrlDescription.ID;
      this.USBPacketSize = CtrlDescription.USBPacketSize;
      this.DownLoadAPI = CtrlDescription.DownLoadAPI;
      this.ProjectMemorySize = CtrlDescription.ProjectMemorySize;
      this.IsPixelSupported = CtrlDescription.IsPixelSupported;
      this.PixelGpio = CtrlDescription.PixelGpio;
      if (this.IsPixelSupported)
        ++this.GpioGroupsCount;
      this.IsCLISupported = CtrlDescription.IsCLISupported;
      this.CLIGpio = CtrlDescription.CLIGpio;
      if (this.IsCLISupported)
      {
        this.CLIGroupIndex = this.GpioGroupsCount;
        ++this.GpioGroupsCount;
      }
      this.IsCECSupported = CtrlDescription.IsCECSupported;
      this.CECGpio = CtrlDescription.CECGpio;
      if (CtrlDescription.OptionsMask != 0U)
      {
        this.AreOptionsSupported = true;
        this.SupportedOptions = CtrlDescription.OptionsMask;
      }
      this.AreUSBSetsSupported = CtrlDescription.AreUSBSetsSupported;
      this.AudioConfiguration = CtrlDescription.AudioConfiguration;
      this.DelayValues = CtrlDescription.DelayValues;
      this.DelayTimerPCS = CtrlDescription.DelayTimerPCS;
      this.DelayTimerARR = CtrlDescription.DelayTimerARR;
      this.MuteValues = CtrlDescription.MuteValues;
      this.MuteTimerPCS = CtrlDescription.MuteTimerPCS;
      this.MuteTimerARR = CtrlDescription.MuteTimerARR;
      this.InitGpios(CtrlDescription);
      this.TouchCapGpioNum = CtrlDescription.GetTouchCapGpio();
      CtrlDescription.GetGpioILinesAndFuncIndex(out this.GPIOI_Lines, out this.GPIOI_FunctionIndex);
      if (this.IsPixelSupported)
      {
        this.GPIOLines[3] = new GPIO[1];
        this.GPIOLines[3][0] = new GPIO()
        {
          TitleLength = 40,
          Title = "Pixel LED",
          OwnAnchors = new Anchor.AnchorTypes[1]
          {
            Anchor.AnchorTypes.ToPixel
          },
          OppositeAnchors = new Anchor.AnchorTypes[1]
          {
            Anchor.AnchorTypes.FromPixel
          },
          IsConnectable = false
        };
        this.GPIOLines[3][0].ConnectionPoint.Number = this.GPIOLines[0].Length + this.GPIOLines[1].Length + this.GPIOLines[2].Length;
      }
      if (this.IsCLISupported)
      {
        this.GPIOLines[this.CLIGroupIndex] = new GPIO[1];
        this.GPIOLines[this.CLIGroupIndex][0] = new GPIO()
        {
          TitleLength = 40,
          Title = "CLI",
          OwnAnchors = new Anchor.AnchorTypes[1]
          {
            Anchor.AnchorTypes.ToDSPCell
          },
          OppositeAnchors = new Anchor.AnchorTypes[1]
          {
            Anchor.AnchorTypes.FromDSPCell
          },
          IsConnectable = false,
          Functions = new string[1]{ "CLI" },
          ActiveFuncIndex = 0
        };
        this.GPIOLines[this.CLIGroupIndex][0].ConnectionPoint.Number = this.GPIOLines[0].Length + this.GPIOLines[1].Length + this.GPIOLines[2].Length;
        if (this.IsPixelSupported)
          this.GPIOLines[this.CLIGroupIndex][0].ConnectionPoint.Number += this.GPIOLines[3].Length;
      }
      this.GPIOsWithOptions = ((IEnumerable<GPIO>) this.GPIOLines[0]).Where<GPIO>((Func<GPIO, bool>) (g => g.Option > 0U)).ToArray<GPIO>();
    }
  }

  public void UpdateGpioPoints(Visual visual)
  {
    foreach (GPIO[] gpioLine in this.GPIOLines)
    {
      foreach (GPIO gpio in gpioLine)
        gpio.ConnectionPoint.UpdateCenterRelativeTo(visual);
    }
  }

  public GPIO GetLine(int LineNum)
  {
    GPIO[] array = ((IEnumerable<GPIO[]>) this.GPIOLines).SelectMany<GPIO[], GPIO>((Func<GPIO[], IEnumerable<GPIO>>) (g => (IEnumerable<GPIO>) g)).Where<GPIO>((Func<GPIO, bool>) (l => l.ConnectionPoint.Number == LineNum)).ToArray<GPIO>();
    return array.Length == 0 ? (GPIO) null : array[0];
  }

  public GPIO GetCLILine()
  {
    if (!this.IsCLISupported)
      return (GPIO) null;
    GPIO[] array = ((IEnumerable<GPIO[]>) this.GPIOLines).SelectMany<GPIO[], GPIO>((Func<GPIO[], IEnumerable<GPIO>>) (g => (IEnumerable<GPIO>) g)).Where<GPIO>((Func<GPIO, bool>) (l => l.ConnectionPoint.Number == this.GPIOLines[this.CLIGroupIndex][0].ConnectionPoint.Number)).ToArray<GPIO>();
    return array.Length == 0 ? (GPIO) null : array[0];
  }

  public void ApplyGpioFilter(Anchor.AnchorTypes AnchorType)
  {
    foreach (GPIO[] gpioLine in this.GPIOLines)
    {
      foreach (GPIO gpio in gpioLine)
      {
        if (gpio.IsConnectable && AnchorType != gpio.ActiveOppositeAnchor)
          gpio.ConnectionPoint.IsFilteredOut = true;
      }
    }
  }

  public void ApplyGpioFilter(int AnchorNumber)
  {
    foreach (GPIO[] gpioLine in this.GPIOLines)
    {
      foreach (GPIO gpio in gpioLine)
      {
        if (gpio.IsConnectable && AnchorNumber != gpio.ConnectionPoint.Number)
          gpio.ConnectionPoint.IsFilteredOut = true;
      }
    }
  }

  public void DiscardGpioFilter()
  {
    foreach (GPIO[] gpioLine in this.GPIOLines)
    {
      foreach (GPIO gpio in gpioLine)
      {
        if (gpio.ConnectionPoint.IsFilteredOut)
          gpio.ConnectionPoint.IsFilteredOut = false;
      }
    }
  }

  public byte[] GPIOsFunctionsGet()
  {
    return ((IEnumerable<GPIO>) this.GPIOLines[0]).Concat<GPIO>((IEnumerable<GPIO>) this.GPIOLines[1]).Concat<GPIO>((IEnumerable<GPIO>) this.GPIOLines[2]).Select<GPIO, byte>((Func<GPIO, byte>) (g => (byte) g.ActiveFuncIndex)).ToArray<byte>();
  }

  public void GPIOsFunctionsSet(int[] FuncList)
  {
    foreach (GPIO gpio in ((IEnumerable<GPIO>) this.GPIOLines[0]).Concat<GPIO>((IEnumerable<GPIO>) this.GPIOLines[1]).Concat<GPIO>((IEnumerable<GPIO>) this.GPIOLines[2]))
    {
      gpio.ActiveFuncIndex = FuncList[gpio.ConnectionPoint.Number];
      this.GPIOLineFunction_Changed(gpio.ConnectionPoint.Number, gpio.ActiveFuncIndex);
    }
  }

  public bool[] GetActiveRegGPIOs()
  {
    return ((IEnumerable<GPIO>) this.GPIOLines[0]).Select<GPIO, bool>((Func<GPIO, bool>) (g => this.IsGpioRegulator(g.ActiveFunction))).ToArray<bool>();
  }

  public byte InterfaceNumber(byte GpioNum)
  {
    byte num = 0;
    if ((int) GpioNum >= this.GPIOLines[0].Length && (int) GpioNum < this.GPIOLines[0].Length + this.GPIOLines[1].Length + this.GPIOLines[2].Length)
    {
      GpioNum -= (byte) this.GPIOLines[0].Length;
      int index1 = 1;
      if ((int) GpioNum >= this.GPIOLines[1].Length)
      {
        GpioNum -= (byte) this.GPIOLines[1].Length;
        index1 = 2;
      }
      else
        num = (byte) 1;
      string title = this.GPIOLines[index1][(int) GpioNum].Title;
      string str = title.Substring(0, title.Length - 1);
      for (int index2 = 0; index2 < (int) GpioNum; ++index2)
      {
        if (this.GPIOLines[index1][index2].Title.IndexOf(str) != -1)
          ++num;
      }
    }
    return num;
  }

  public int DelayTimPSC(int DelayIndex)
  {
    return this.DelayTimerPCS == null || DelayIndex >= this.DelayTimerPCS.Length ? 1 : this.DelayTimerPCS[DelayIndex];
  }

  public int DelayTimARR(int DelayIndex)
  {
    return this.DelayTimerARR == null || DelayIndex >= this.DelayTimerARR.Length ? 1 : this.DelayTimerARR[DelayIndex];
  }

  public int MuteTimPSC(int MuteIndex)
  {
    return this.MuteTimerPCS == null || MuteIndex >= this.MuteTimerPCS.Length ? 1 : this.MuteTimerPCS[MuteIndex];
  }

  public int MuteTimARR(int MuteIndex)
  {
    return this.MuteTimerARR == null || MuteIndex >= this.MuteTimerARR.Length ? 1 : this.MuteTimerARR[MuteIndex];
  }

  public void SetGpioClickAction(Anchor.AnchorConnectionEventHandler GpioClick)
  {
    foreach (GPIO[] gpioLine in this.GPIOLines)
    {
      foreach (GPIO gpio in gpioLine)
        gpio.ConnectionPoint.AnchorConnection += GpioClick;
    }
  }

  public PixelModule GetPixelSettings()
  {
    return !this.IsPixelSupported ? (PixelModule) null : this._Pixel;
  }

  public void SetPixelSettings(PixelModule Settings)
  {
    if (!this.IsPixelSupported)
      return;
    this._Pixel = Settings;
    this.ChangePixelGpioState(this._Pixel.IsEnabled);
  }

  public CLIModule GetCLISettings() => !this.IsCLISupported ? (CLIModule) null : this._CLI;

  public void SetCLISettings(CLIModule Settings)
  {
    if (!this.IsCLISupported)
      return;
    this._CLI = Settings;
    this.ChangeCLIGpioState(this._CLI.IsEnabled);
  }

  public CEC GetCECSettings() => !this.IsCECSupported ? (CEC) null : this._CEC;

  public void SetCECSettings(CEC Settings)
  {
    if (!this.IsCECSupported)
      return;
    this._CEC = Settings;
    this.ChangeCECGpioState(this._CEC.IsEnabled);
  }

  public ControllerOptions GetOptions()
  {
    return !this.AreOptionsSupported ? (ControllerOptions) null : this.Options;
  }

  public void SetOptions(ControllerOptions Options)
  {
    if (!this.AreOptionsSupported)
      return;
    this.Options = Options;
    this.ChangeOptionsGpioState();
  }

  public string[] GetAudioConfiguration()
  {
    return !this.AreUSBSetsSupported ? (string[]) null : this.AudioConfiguration;
  }

  private void ChangePixelGpioState(bool IsPixelActivated)
  {
    if (IsPixelActivated)
    {
      this.GPIOLines[3][0].IsConnectable = true;
      if (this.PixelGpio == -1)
        return;
      this.GPIOLines[0][this.PixelGpio].ActiveFuncIndex = 0;
      this.GPIOLines[0][this.PixelGpio].IsActive = false;
    }
    else
    {
      this.GPIOLines[3][0].IsConnectable = false;
      if (this.PixelGpio == -1)
        return;
      this.GPIOLines[0][this.PixelGpio].IsActive = true;
    }
  }

  private void ChangeCLIGpioState(bool IsCLIActivated)
  {
    if (IsCLIActivated)
    {
      this.GPIOLines[this.CLIGroupIndex][0].IsConnectable = true;
      foreach (int index in this.CLIGpio)
      {
        if (index != -1)
        {
          this.GPIOLines[0][index].ActiveFuncIndex = 0;
          this.GPIOLines[0][index].IsActive = false;
        }
      }
    }
    else
    {
      this.GPIOLines[this.CLIGroupIndex][0].IsConnectable = false;
      foreach (int index in this.CLIGpio)
      {
        if (index != -1)
          this.GPIOLines[0][index].IsActive = true;
      }
    }
  }

  private void ChangeCECGpioState(bool IsCECActivated)
  {
    if (IsCECActivated && this.CECGpio != -1)
    {
      this.GPIOLines[0][this.CECGpio].ActiveFuncIndex = 0;
      this.GPIOLines[0][this.CECGpio].IsActive = false;
    }
    else
      this.GPIOLines[0][this.CECGpio].IsActive = true;
  }

  private void ChangeOptionsGpioState()
  {
    if (this.GPIOsWithOptions == null)
      return;
    uint num = (uint) this.Options.Get();
    foreach (GPIO gpiOsWithOption in this.GPIOsWithOptions)
    {
      if (((int) num & (int) gpiOsWithOption.Option) == (int) gpiOsWithOption.Option)
      {
        gpiOsWithOption.ActiveFuncIndex = 0;
        gpiOsWithOption.IsActive = false;
      }
      else
        gpiOsWithOption.IsActive = true;
    }
  }

  private bool IsGpioRegulator(string Function)
  {
    if (Function == "BUTTON" || Function == "SWITCH" || Function == "RESISTOR" || Function.IndexOf("ENC_") != -1 && Function.IndexOf("B") == -1)
      return true;
    return Function.IndexOf("PMB_") != -1 && Function.IndexOf("-") == -1;
  }

  private void InitGpios(IDDController CtrlDescription)
  {
    this.GPIOLines = new GPIO[this.GpioGroupsCount][];
    string[] strArray = new string[3]
    {
      "RegGPIOs",
      "GPIOI",
      "DSPI"
    };
    for (int index1 = 0; index1 < strArray.Length; ++index1)
    {
      string[] GPIOsTitles;
      string[][] GpiosFuncs;
      bool[] IsGpioEnabled;
      CtrlDescription.GetGpioDescription(strArray[index1], out GPIOsTitles, out GpiosFuncs, out IsGpioEnabled);
      int length = GPIOsTitles.Length;
      this.GPIOLines[index1] = new GPIO[length];
      int num1;
      bool flag;
      int num2;
      if (strArray[index1] == "GPIOI")
      {
        num1 = this.GPIOLines[0].Length;
        flag = true;
        num2 = 20;
      }
      else if (strArray[index1] == "DSPI")
      {
        num1 = this.GPIOLines[0].Length + this.GPIOLines[1].Length;
        flag = true;
        num2 = 20;
      }
      else
      {
        num1 = 0;
        flag = false;
        num2 = 10;
      }
      for (int index2 = 0; index2 < length; ++index2)
      {
        this.GPIOLines[index1][index2] = new GPIO();
        this.GPIOLines[index1][index2].FunctionLength = 70;
        this.GPIOLines[index1][index2].TitleLength = num2;
        this.GPIOLines[index1][index2].ConnectionPoint.Number = num1 + index2;
        this.GPIOLines[index1][index2].Title = GPIOsTitles[index2];
        this.GPIOLines[index1][index2].IsActive = IsGpioEnabled[index2];
        this.GPIOLines[index1][index2].Functions = GpiosFuncs[index2];
        this.GPIOLines[index1][index2].ActiveFuncIndex = 0;
        Anchor.AnchorTypes[] source = !(strArray[index1] == "RegGPIOs") ? this.GetAnchorsForInterfaces(GPIOsTitles[index2]) : this.GetAnchorsForGpio(GpiosFuncs[index2]);
        this.GPIOLines[index1][index2].OwnAnchors = source;
        this.GPIOLines[index1][index2].OppositeAnchors = ((IEnumerable<Anchor.AnchorTypes>) source).Select<Anchor.AnchorTypes, Anchor.AnchorTypes>((Func<Anchor.AnchorTypes, Anchor.AnchorTypes>) (a => Anchor.OppositeAnchor(a))).ToArray<Anchor.AnchorTypes>();
        this.GPIOLines[index1][index2].FunctionChanged += new GPIO.FunctionChangedEventHandler(this.GPIOLineFunction_Changed);
        if (flag)
          this.GPIOLines[index1][index2].FlipHorizontal();
      }
      if (strArray[index1] == "RegGPIOs")
      {
        uint[] gpioOptions = CtrlDescription.GetGpioOptions();
        for (int index3 = 0; index3 < length; ++index3)
          this.GPIOLines[index1][index3].Option = gpioOptions[index3];
      }
    }
  }

  private Anchor.AnchorTypes[] GetAnchorsForGpio(string[] Functions)
  {
    Anchor.AnchorTypes[] anchorsForGpio = new Anchor.AnchorTypes[Functions.Length];
    for (int index = 0; index < Functions.Length; ++index)
      anchorsForGpio[index] = Functions[index].IndexOf("BUTTON") != -1 || Functions[index].IndexOf("SWITCH") != -1 || Functions[index].IndexOf("RESISTOR") != -1 || Functions[index].IndexOf("ENC_") != -1 || Functions[index].IndexOf("PMB_") != -1 || Functions[index].IndexOf("TOUCH") != -1 ? Anchor.AnchorTypes.ToDSPCell : (Functions[index].IndexOf("LED") == -1 ? (Functions[index].IndexOf("Pixel LED") == -1 ? (Functions[index].IndexOf("CHIP SELECT") == -1 ? Anchor.AnchorTypes.EMPTY : Anchor.AnchorTypes.ToSlave_CS) : Anchor.AnchorTypes.ToPixel) : Anchor.AnchorTypes.ToLED);
    return anchorsForGpio;
  }

  private Anchor.AnchorTypes[] GetAnchorsForInterfaces(string Interfaces)
  {
    return new Anchor.AnchorTypes[2]
    {
      Anchor.AnchorTypes.EMPTY,
      Interfaces.IndexOf("I2C") == -1 ? (Interfaces.IndexOf("SPI") == -1 ? (Interfaces.IndexOf("CS") == -1 ? Anchor.AnchorTypes.EMPTY : Anchor.AnchorTypes.ToSlave_CS) : Anchor.AnchorTypes.ToSlave_SPI) : Anchor.AnchorTypes.ToSlave_I2C
    };
  }

  private void GPIOLineFunction_Changed(int GPIOIndex, int NewFunctionIndex)
  {
    if (GPIOIndex < this.GPIOLines[0].Length)
      this.GPIOSFunction_Changed(GPIOIndex, NewFunctionIndex);
    else if (GPIOIndex < this.GPIOLines[0].Length + this.GPIOLines[1].Length)
    {
      GPIOIndex -= this.GPIOLines[0].Length;
      this.GPIOIFunction_Changed(GPIOIndex, NewFunctionIndex);
    }
    else
    {
      if (GPIOIndex >= this.GPIOLines[0].Length + this.GPIOLines[1].Length + this.GPIOLines[2].Length)
        return;
      GPIOIndex -= this.GPIOLines[0].Length + this.GPIOLines[1].Length;
      this.DSPIFunction_Changed(GPIOIndex, NewFunctionIndex);
    }
  }

  private void GPIOSFunction_Changed(int GPIOIndex, int NewFunctionIndex)
  {
    this.LineFunction_Changed(this.GPIOLines[0][GPIOIndex], NewFunctionIndex);
    this.ProcessTwoLineFunction(GPIOIndex);
    if (this.TouchCapGpioNum == -1)
      return;
    if (this.GPIOLines[0][GPIOIndex].ActiveFunction.IndexOf("TOUCH") != -1)
    {
      this.GPIOLines[0][this.TouchCapGpioNum].ActiveFuncIndex = 0;
      this.GPIOLines[0][this.TouchCapGpioNum].IsActive = false;
    }
    else
    {
      GPIO[] array = ((IEnumerable<GPIO>) this.GPIOLines[0]).Where<GPIO>((Func<GPIO, bool>) (line => line.ActiveFunction.IndexOf("TOUCH") != -1)).ToArray<GPIO>();
      if ((array != null ? (array.Length == 0 ? 1 : 0) : 0) == 0)
        return;
      this.GPIOLines[0][this.TouchCapGpioNum].IsActive = true;
    }
  }

  private void GPIOIFunction_Changed(int GPIOIndex, int NewFunctionIndex)
  {
    this.LineFunction_Changed(this.GPIOLines[1][GPIOIndex], NewFunctionIndex);
    if (NewFunctionIndex != 0)
    {
      foreach (int index in this.GPIOI_Lines[GPIOIndex])
      {
        this.GPIOLines[0][index].FunctionChanged -= new GPIO.FunctionChangedEventHandler(this.GPIOSFunction_Changed);
        this.GPIOLines[0][index].ActiveFuncIndex = this.GPIOI_FunctionIndex[GPIOIndex];
        this.GPIOLines[0][index].IsActive = false;
      }
    }
    else
    {
      foreach (int index in this.GPIOI_Lines[GPIOIndex])
      {
        if (!this.GPIOLines[0][index].IsActive)
        {
          this.GPIOLines[0][index].FunctionChanged += new GPIO.FunctionChangedEventHandler(this.GPIOSFunction_Changed);
          this.GPIOLines[0][index].IsActive = true;
          this.GPIOLines[0][index].ActiveFuncIndex = 0;
        }
      }
    }
  }

  private void DSPIFunction_Changed(int GPIOIndex, int NewFunctionIndex)
  {
    this.LineFunction_Changed(this.GPIOLines[2][GPIOIndex], NewFunctionIndex);
  }

  private void LineFunction_Changed(GPIO Line, int NewFunctionIndex)
  {
    Line.IsConnectable = NewFunctionIndex != 0;
  }

  private void ProcessTwoLineFunction(int GPIOIndex)
  {
    int LineIndex;
    if (this.IsTwoLineFunction(this.GPIOLines[0][GPIOIndex].ActiveFunction, out LineIndex))
    {
      if (LineIndex == 0)
      {
        this.GPIOLines[0][GPIOIndex + 1].FunctionChanged -= new GPIO.FunctionChangedEventHandler(this.GPIOLineFunction_Changed);
        this.GPIOLines[0][GPIOIndex + 1].ActiveFuncIndex = this.GPIOLines[0][GPIOIndex].ActiveFuncIndex;
        this.GPIOLines[0][GPIOIndex + 1].IsActive = false;
        this.GPIOLines[0][GPIOIndex + 1].IsConnectable = false;
        this.GPIOLines[0][GPIOIndex + 1].FunctionChanged += new GPIO.FunctionChangedEventHandler(this.GPIOLineFunction_Changed);
      }
      else
      {
        this.GPIOLines[0][GPIOIndex - 1].FunctionChanged -= new GPIO.FunctionChangedEventHandler(this.GPIOLineFunction_Changed);
        this.GPIOLines[0][GPIOIndex - 1].ActiveFuncIndex = this.GPIOLines[0][GPIOIndex].ActiveFuncIndex;
        this.GPIOLines[0][GPIOIndex - 1].IsConnectable = true;
        this.GPIOLines[0][GPIOIndex].IsActive = false;
        this.GPIOLines[0][GPIOIndex].IsConnectable = false;
        this.GPIOLines[0][GPIOIndex - 1].FunctionChanged += new GPIO.FunctionChangedEventHandler(this.GPIOLineFunction_Changed);
      }
    }
    else
    {
      if (!this.WasTwoLineFunction(GPIOIndex))
        return;
      this.GPIOLines[0][GPIOIndex + 1].FunctionChanged -= new GPIO.FunctionChangedEventHandler(this.GPIOLineFunction_Changed);
      this.GPIOLines[0][GPIOIndex + 1].ActiveFuncIndex = 0;
      this.GPIOLines[0][GPIOIndex + 1].IsActive = true;
      this.GPIOLines[0][GPIOIndex + 1].FunctionChanged += new GPIO.FunctionChangedEventHandler(this.GPIOLineFunction_Changed);
    }
  }

  private bool IsTwoLineFunction(string Function, out int LineIndex)
  {
    LineIndex = -1;
    if (!this.TwoLineFunction(Function))
      return false;
    LineIndex = 0;
    if (this.SecondLineInFunction(Function))
      LineIndex = 1;
    return true;
  }

  private bool WasTwoLineFunction(int GPIOIndex)
  {
    if (GPIOIndex >= this.GPIOLines[0].Length - 1)
      return false;
    string activeFunction = this.GPIOLines[0][GPIOIndex + 1].ActiveFunction;
    return this.TwoLineFunction(activeFunction) && this.SecondLineInFunction(activeFunction);
  }

  private bool TwoLineFunction(string Function)
  {
    return Function.IndexOf("ENC_") != -1 || Function.IndexOf("PMB_") != -1;
  }

  private bool SecondLineInFunction(string Function)
  {
    string[] strArray = Function.Split("_"[0]);
    return strArray[1].IndexOf("B") != -1 || strArray[1].IndexOf("-") != -1;
  }
}
