﻿// Decompiled with JetBrains decompiler
// Type: ChipStudio.DSPBootParser_SSM3582
// Assembly: ChipStudio, Version=1.2.9.0, Culture=neutral, PublicKeyToken=null
// MVID: 334E3BEA-37C7-4274-8118-535AAEFA1546
// Assembly location: D:\DocAndSec\Desktop\AUDIO\ChipDip\ChipStudio_soft_v1.2.9\ChipStudio_v1.2.9.exe

using System.Collections.Generic;

#nullable disable
namespace ChipStudio;

public class DSPBootParser_SSM3582 : IDSPBootParser
{
  public bool TryParse(string ProjectFile, out List<DataTransfer> BootSequence)
  {
    BootSequence = (List<DataTransfer>) null;
    if (!SigmaStudio.TryParseCodecBoot(ProjectFile, "SSM3582", out BootSequence))
      return false;
    Shared.ConcatByAddress(BootSequence);
    return true;
  }
}
