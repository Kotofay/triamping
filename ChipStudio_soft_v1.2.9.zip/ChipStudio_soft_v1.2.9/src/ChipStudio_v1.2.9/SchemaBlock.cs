﻿// Decompiled with JetBrains decompiler
// Type: ChipStudio.SchemaBlock
// Assembly: ChipStudio, Version=1.2.9.0, Culture=neutral, PublicKeyToken=null
// MVID: 334E3BEA-37C7-4274-8118-535AAEFA1546
// Assembly location: D:\DocAndSec\Desktop\AUDIO\ChipDip\ChipStudio_soft_v1.2.9\ChipStudio_v1.2.9.exe

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Media;

#nullable disable
namespace ChipStudio;

public abstract class SchemaBlock : UserControl, IDisposable, INotifyPropertyChanged, ISchemaElement
{
  private const string ConPointsNotInit = "Connection points are not initialized";
  private Thickness startpoint;
  private System.Windows.Point upperleftpoint = new System.Windows.Point(0.0, 0.0);
  private bool isselected;
  private Action<ConnectionNode> ConnectionEventHandler;
  private System.Windows.Point MouseClickPoint = new System.Windows.Point(0.0, 0.0);
  private int schemaindex;
  private string title;
  private Anchor.AnchorTypes[] OppositeAnchors;

  public string Title
  {
    get => this.title;
    set
    {
      if (!(this.title != value))
        return;
      this.title = value;
      this.NotifyPropertyChanged(nameof (Title));
    }
  }

  public bool IsSelected
  {
    get => this.isselected;
    set
    {
      if (this.isselected == value)
        return;
      this.isselected = value;
      this.NotifyPropertyChanged(nameof (IsSelected));
    }
  }

  public string ElementType => Shared.ElementTypeBlock;

  public virtual string FullName => this.Title;

  public virtual SchemaBlock.SchemaBlockTypes BlockType { get; }

  public virtual byte CoreID => byte.MaxValue;

  public System.Windows.Point UpperLeftPoint
  {
    get => this.upperleftpoint;
    set
    {
      if (!(this.upperleftpoint != value))
        return;
      this.upperleftpoint = value;
      ref Thickness local1 = ref this.startpoint;
      System.Windows.Point upperLeftPoint = this.UpperLeftPoint;
      double x = upperLeftPoint.X;
      local1.Left = x;
      ref Thickness local2 = ref this.startpoint;
      upperLeftPoint = this.UpperLeftPoint;
      double y = upperLeftPoint.Y;
      local2.Top = y;
      this.NotifyPropertyChanged("StartPoint");
      this.UpdateLayout();
      if (!this.IsLoaded)
        return;
      this.UpdateConnectionPoints();
    }
  }

  public Thickness StartPoint => this.startpoint;

  public int SchemaIndex => this.schemaindex;

  public Anchor[] ConnectionPoints { get; private set; }

  public virtual bool IsConnectable => true;

  public SchemaBlock() => this.Loaded += new RoutedEventHandler(this.SchemaBlock_Loaded);

  public void InitConnectionPoints(Anchor.AnchorTypes[] PointAnchors)
  {
    this.ConnectionPoints = new Anchor[PointAnchors.Length];
    for (int index = 0; index < this.ConnectionPoints.Length; ++index)
    {
      this.ConnectionPoints[index] = new Anchor()
      {
        Number = index,
        IsActivated = true,
        Type = PointAnchors[index]
      };
      this.ConnectionPoints[index].AnchorConnection += new Anchor.AnchorConnectionEventHandler(this.ConnectionPoint_LeftButtonDown);
    }
    this.OppositeAnchors = ((IEnumerable<Anchor>) this.ConnectionPoints).Select<Anchor, Anchor.AnchorTypes>((Func<Anchor, Anchor.AnchorTypes>) (p => Anchor.OppositeAnchor(p.Type))).ToArray<Anchor.AnchorTypes>();
  }

  public virtual void UpdateConnectionPoints()
  {
    if (!this.CheckConnectionPoints() || !(this.Parent is Visual parent))
      return;
    foreach (Anchor connectionPoint in this.ConnectionPoints)
      connectionPoint.UpdateCenterRelativeTo(parent);
  }

  public virtual ConnectionNode GetAnchorConnectionNode(int AnchorNumber)
  {
    if (!this.CheckConnectionPoints())
      return (ConnectionNode) null;
    foreach (Anchor connectionPoint in this.ConnectionPoints)
    {
      if (connectionPoint.Number == AnchorNumber)
        return new ConnectionNode(this.FullName, AnchorNumber, connectionPoint.RelativeCenter, connectionPoint.Type);
    }
    return (ConnectionNode) null;
  }

  public virtual void ApplyFilter(ConnectionNode Node)
  {
    if (!this.CheckConnectionPoints())
      return;
    if (this.FullName != Node.BlockName)
    {
      for (int index = 0; index < this.ConnectionPoints.Length; ++index)
      {
        if (Node.AnchorType != this.OppositeAnchors[index])
          this.ConnectionPoints[index].IsFilteredOut = true;
      }
    }
    else
    {
      foreach (Anchor connectionPoint in this.ConnectionPoints)
      {
        if (connectionPoint.Number != Node.AnchorNumber)
          connectionPoint.IsFilteredOut = true;
      }
    }
  }

  public virtual void DiscardFilter()
  {
    if (!this.CheckConnectionPoints())
      return;
    foreach (Anchor connectionPoint in this.ConnectionPoints)
    {
      if (connectionPoint.IsFilteredOut)
        connectionPoint.IsFilteredOut = false;
    }
  }

  public System.Windows.Point ClickPoint() => this.MouseClickPoint;

  public void Dispose() => this.Dispose(true);

  protected virtual void Dispose(bool disposing)
  {
    if (!disposing)
      return;
    if (this.ConnectionPoints != null)
    {
      foreach (Anchor connectionPoint in this.ConnectionPoints)
        connectionPoint.AnchorConnection -= new Anchor.AnchorConnectionEventHandler(this.ConnectionPoint_LeftButtonDown);
    }
    this.ConnectionEventHandler = (Action<ConnectionNode>) null;
  }

  private bool CheckConnectionPoints()
  {
    if (!this.IsConnectable)
      return false;
    if (this.ConnectionPoints != null)
      return true;
    if (this.BlockType != SchemaBlock.SchemaBlockTypes.Comment)
    {
      int num = (int) MessageBox.Show($"Connection points are not initialized\n\r<{this.FullName}>", "", MessageBoxButton.OK, MessageBoxImage.Hand);
    }
    return false;
  }

  private void SetSchemaIndex()
  {
    string title = this.Title;
    string[] strArray1;
    if (title == null)
      strArray1 = (string[]) null;
    else
      strArray1 = title.Split("_"[0]);
    string[] strArray2 = strArray1;
    if (strArray2 != null && strArray2.Length >= 2)
    {
      int result;
      this.schemaindex = int.TryParse(strArray2[1], out result) ? result : 0;
    }
    else
      this.schemaindex = 0;
  }

  private void SchemaBlock_Loaded(object sender, RoutedEventArgs e)
  {
    this.UpdateConnectionPoints();
    this.SetSchemaIndex();
  }

  public event PropertyChangedEventHandler PropertyChanged;

  public void NotifyPropertyChanged(string PropertyName)
  {
    PropertyChangedEventHandler propertyChanged = this.PropertyChanged;
    if (propertyChanged == null)
      return;
    propertyChanged((object) this, new PropertyChangedEventArgs(PropertyName));
  }

  public void AddConnectionEventHandler(Action<ConnectionNode> Handler)
  {
    this.ConnectionEventHandler += Handler;
  }

  public void ConnectionPoint_LeftButtonDown(
    int AnchorNumber,
    LinePoint AnchorPoint,
    Anchor.AnchorTypes AnchorType)
  {
    Action<ConnectionNode> connectionEventHandler = this.ConnectionEventHandler;
    if (connectionEventHandler == null)
      return;
    connectionEventHandler(new ConnectionNode(this.FullName, AnchorNumber, AnchorPoint, AnchorType));
  }

  public void Border_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
  {
    this.MouseClickPoint = e.GetPosition((IInputElement) (sender as Border));
  }

  public enum SchemaBlockTypes : byte
  {
    Common,
    Controller,
    DSP,
    DSPCell,
    LED,
    PixelLED,
    Read,
    Comparator,
    Comment,
  }
}
