﻿// Decompiled with JetBrains decompiler
// Type: ChipStudio.ControllerInfoDialog
// Assembly: ChipStudio, Version=1.2.9.0, Culture=neutral, PublicKeyToken=null
// MVID: 334E3BEA-37C7-4274-8118-535AAEFA1546
// Assembly location: D:\DocAndSec\Desktop\AUDIO\ChipDip\ChipStudio_soft_v1.2.9\ChipStudio_v1.2.9.exe

using System;
using System.CodeDom.Compiler;
using System.ComponentModel;
using System.Diagnostics;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Controls.Primitives;
using System.Windows.Markup;

#nullable disable
namespace ChipStudio;

public partial class ControllerInfoDialog : Window, IComponentConnector
{
  internal Label DeviceName;
  internal Label FWVersion;
  private bool _contentLoaded;

  public ControllerInfoDialog() => this.InitializeComponent();

  private void ControllerInfo_Click(object sender, RoutedEventArgs e)
  {
    if (ControllerDriver.IsDeviceConnected())
    {
      ControllerDriver.OpenDevice();
      ControllerInfo deviceInfo = ControllerDriver.GetDeviceInfo();
      ControllerDriver.CloseDevice();
      this.DeviceName.Content = (object) deviceInfo.Name;
      this.FWVersion.Content = (object) deviceInfo.FirmwareVersion;
    }
    else
    {
      int num = (int) MessageBox.Show("Controller is not connected", "", MessageBoxButton.OK, MessageBoxImage.Hand);
      this.DeviceName.Content = (object) "";
      this.FWVersion.Content = (object) "";
    }
  }

  private void CloseButton_Click(object sender, RoutedEventArgs e)
  {
    this.DialogResult = new bool?(false);
  }

  [DebuggerNonUserCode]
  [GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
  public void InitializeComponent()
  {
    if (this._contentLoaded)
      return;
    this._contentLoaded = true;
    Application.LoadComponent((object) this, new Uri("/ChipStudio;component/controllerinfodialog.xaml", UriKind.Relative));
  }

  [DebuggerNonUserCode]
  [GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
  [EditorBrowsable(EditorBrowsableState.Never)]
  void IComponentConnector.Connect(int connectionId, object target)
  {
    switch (connectionId)
    {
      case 1:
        this.DeviceName = (Label) target;
        break;
      case 2:
        this.FWVersion = (Label) target;
        break;
      case 3:
        ((ButtonBase) target).Click += new RoutedEventHandler(this.ControllerInfo_Click);
        break;
      case 4:
        ((ButtonBase) target).Click += new RoutedEventHandler(this.CloseButton_Click);
        break;
      default:
        this._contentLoaded = true;
        break;
    }
  }
}
