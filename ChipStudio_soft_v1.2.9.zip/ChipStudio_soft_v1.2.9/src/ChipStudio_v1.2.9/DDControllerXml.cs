﻿// Decompiled with JetBrains decompiler
// Type: ChipStudio.DDControllerXml
// Assembly: ChipStudio, Version=1.2.9.0, Culture=neutral, PublicKeyToken=null
// MVID: 334E3BEA-37C7-4274-8118-535AAEFA1546
// Assembly location: D:\DocAndSec\Desktop\AUDIO\ChipDip\ChipStudio_soft_v1.2.9\ChipStudio_v1.2.9.exe

using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Windows;
using System.Xml.Linq;

#nullable disable
namespace ChipStudio;

public class DDControllerXml : IDDController
{
  private const string USBPacketSizeString = "USBPacketSize";
  private const string DownLoadAPIString = "DownLoadAPI";
  private const string GpioNumString = "Gpio";
  private const string ValuesString = "Values";
  private const string TimerPCSString = "TimerPCS";
  private const string TimerARRString = "TimerARR";
  private const string GPIOSString = "GPIOS";
  private const string GpioElement = "gpio";
  private const string RegGPIOsString = "RegGPIOs";
  private const string GPIOInterfacesString = "GPIOInterfaces";
  private const string DSPInterfacesString = "DSPInterfaces";
  private const string TouchCapGpioString = "TouchCapGpio";
  private const string FunctionsString = "Functions";
  private const string LinesString = "Lines";
  private const string FunctionIndexString = "FunctionIndex";
  private const string USBSettingsString = "USBSettings";
  private const string AudioConfigurationString = "AudioConfiguration";
  private const string OptionString = "Option";
  private const string ProjectMemorySizeString = "ProjectMemorySize";
  private static readonly string[] DelayDefaultStrings = new string[8]
  {
    "5",
    "50",
    "100",
    "500",
    "1000",
    "1500",
    "2000",
    "2500"
  };
  private int TouchCapGpioNum = -1;
  private string[] RegGPIOsTitles;
  private string[] GPIOITitles;
  private string[] DSPITitles;
  private string[][] RegGpiosFuncs;
  private string[][] GPIOIFuncs;
  private string[][] DSPIFuncs;
  private bool[] IsRegGpioEnabled;
  private bool[] IsGPIOIEnabled;
  private bool[] IsDSPIEnabled;
  private int[] GPIOI_FunctionIndex;
  private int[][] GPIOI_Lines;
  private uint[] GPIO_Options;

  public bool IsLoaded { get; }

  public byte ID { get; }

  public byte DownLoadAPI { get; }

  public ushort USBPacketSize { get; }

  public int ProjectMemorySize { get; }

  public string[] DelayValues { get; }

  public int[] DelayTimerPCS { get; }

  public int[] DelayTimerARR { get; }

  public string[] MuteValues { get; }

  public int[] MuteTimerPCS { get; }

  public int[] MuteTimerARR { get; }

  public bool IsPixelSupported { get; }

  public bool IsCLISupported { get; }

  public int[] CLIGpio { get; } = new int[2]{ -1, -1 };

  public int PixelGpio { get; } = -1;

  public bool IsCECSupported { get; }

  public int CECGpio { get; } = -1;

  public uint OptionsMask { get; }

  public bool AreUSBSetsSupported { get; }

  public string[] AudioConfiguration { get; }

  public DDControllerXml(string ModuleType)
  {
    if (!Directory.Exists(Shared.DDControllerPath))
    {
      int num1 = (int) MessageBox.Show($"Folder\n\r...{Shared.DDControllerFolder}\n\r{Shared.DoesNotExistString}", "", MessageBoxButton.OK, MessageBoxImage.Hand);
    }
    else
    {
      string str1 = ModuleType + Shared.DDFileExt;
      string str2 = Shared.DDControllerPath + Shared.FilePathSlash + str1;
      if (!File.Exists(str2))
      {
        int num2 = (int) MessageBox.Show($"Device description file\n\r{str1}\n\r{Shared.DoesNotExistString}", "", MessageBoxButton.OK, MessageBoxImage.Hand);
      }
      else
      {
        XDocument xdoc = XDocument.Load(str2);
        int Value;
        if (!int.TryParse(xdoc.Element((XName) "Controller")?.Attribute((XName) nameof (ID))?.Value, out Value))
          return;
        this.ID = (byte) Value;
        if (!int.TryParse(xdoc.Element((XName) "Controller")?.Attribute((XName) nameof (USBPacketSize))?.Value, out Value))
          return;
        this.USBPacketSize = (ushort) Value;
        if (!int.TryParse(xdoc.Element((XName) "Controller")?.Attribute((XName) nameof (DownLoadAPI))?.Value, out Value))
          return;
        this.DownLoadAPI = (byte) Value;
        this.ProjectMemorySize = int.TryParse(xdoc.Element((XName) "Controller")?.Attribute((XName) nameof (ProjectMemorySize))?.Value, out Value) ? Value * 1024 /*0x0400*/ : 0;
        bool result1;
        this.IsPixelSupported = bool.TryParse(xdoc.Element((XName) "Controller")?.Element((XName) "PixelLED")?.Attribute((XName) "IsEnabled")?.Value, out result1) && result1;
        if (this.IsPixelSupported)
        {
          string s = xdoc.Element((XName) "Controller")?.Element((XName) "PixelLED")?.Attribute((XName) "Gpio")?.Value;
          if (s != null)
            this.PixelGpio = int.TryParse(s, out Value) ? Value : -1;
        }
        this.IsCLISupported = bool.TryParse(xdoc.Element((XName) "Controller")?.Element((XName) "CLI")?.Attribute((XName) "IsEnabled")?.Value, out result1) && result1;
        if (this.IsCLISupported)
        {
          string str3 = xdoc.Element((XName) "Controller")?.Element((XName) "CLI")?.Attribute((XName) "Gpio")?.Value;
          if (str3 != null)
            this.CLIGpio = ((IEnumerable<string>) str3.Split(";"[0])).Select<string, int>((Func<string, int>) (p => !int.TryParse(p, out Value) ? -1 : Value)).ToArray<int>();
        }
        this.IsCECSupported = bool.TryParse(xdoc.Element((XName) "Controller")?.Element((XName) "CEC")?.Attribute((XName) "IsEnabled")?.Value, out result1) && result1;
        if (this.IsCECSupported)
          this.CECGpio = int.TryParse(xdoc.Element((XName) "Controller")?.Element((XName) "CEC")?.Attribute((XName) "Gpio")?.Value, out Value) ? Value : -1;
        uint result2;
        this.OptionsMask = uint.TryParse(xdoc.Element((XName) "Controller")?.Element((XName) "Options")?.Attribute((XName) "Mask")?.Value, out result2) ? result2 : 0U;
        bool result3;
        this.AreUSBSetsSupported = bool.TryParse(xdoc.Element((XName) "Controller")?.Element((XName) "USBSettings")?.Attribute((XName) "IsEnabled")?.Value, out result3) && result3;
        if (this.AreUSBSetsSupported)
        {
          XElement xelement1 = xdoc.Element((XName) "Controller");
          string[] strArray;
          if (xelement1 == null)
          {
            strArray = (string[]) null;
          }
          else
          {
            XElement xelement2 = xelement1.Element((XName) "USBSettings");
            if (xelement2 == null)
            {
              strArray = (string[]) null;
            }
            else
            {
              XElement xelement3 = xelement2.Element((XName) nameof (AudioConfiguration));
              if (xelement3 == null)
                strArray = (string[]) null;
              else
                strArray = xelement3.Value.Split(";"[0]);
            }
          }
          this.AudioConfiguration = strArray;
        }
        XElement xelement4 = xdoc.Element((XName) "Controller");
        string[] strArray1;
        if (xelement4 == null)
        {
          strArray1 = (string[]) null;
        }
        else
        {
          XElement xelement5 = xelement4.Element((XName) "Delay");
          if (xelement5 == null)
          {
            strArray1 = (string[]) null;
          }
          else
          {
            XElement xelement6 = xelement5.Element((XName) "Values");
            if (xelement6 == null)
              strArray1 = (string[]) null;
            else
              strArray1 = xelement6.Value.Split(";"[0]);
          }
        }
        this.DelayValues = strArray1;
        if (this.DelayValues == null)
          this.DelayValues = DDControllerXml.DelayDefaultStrings;
        XElement xelement7 = xdoc.Element((XName) "Controller");
        int[] numArray1;
        if (xelement7 == null)
        {
          numArray1 = (int[]) null;
        }
        else
        {
          XElement xelement8 = xelement7.Element((XName) "Delay");
          if (xelement8 == null)
          {
            numArray1 = (int[]) null;
          }
          else
          {
            XElement xelement9 = xelement8.Element((XName) "TimerPCS");
            if (xelement9 == null)
            {
              numArray1 = (int[]) null;
            }
            else
            {
              int result4;
              numArray1 = ((IEnumerable<string>) xelement9.Value.Split(";"[0])).Select<string, int>((Func<string, int>) (p => !int.TryParse(p, out result4) ? 1 : result4)).ToArray<int>();
            }
          }
        }
        this.DelayTimerPCS = numArray1;
        XElement xelement10 = xdoc.Element((XName) "Controller");
        int[] numArray2;
        if (xelement10 == null)
        {
          numArray2 = (int[]) null;
        }
        else
        {
          XElement xelement11 = xelement10.Element((XName) "Delay");
          if (xelement11 == null)
          {
            numArray2 = (int[]) null;
          }
          else
          {
            XElement xelement12 = xelement11.Element((XName) "TimerARR");
            if (xelement12 == null)
            {
              numArray2 = (int[]) null;
            }
            else
            {
              int result5;
              numArray2 = ((IEnumerable<string>) xelement12.Value.Split(";"[0])).Select<string, int>((Func<string, int>) (p => !int.TryParse(p, out result5) ? 1 : result5)).ToArray<int>();
            }
          }
        }
        this.DelayTimerARR = numArray2;
        XElement xelement13 = xdoc.Element((XName) "Controller")?.Element((XName) "Mute");
        if (xelement13 != null)
        {
          XElement xelement14 = xelement13.Element((XName) "Values");
          string[] strArray2;
          if (xelement14 == null)
            strArray2 = (string[]) null;
          else
            strArray2 = xelement14.Value.Split(";"[0]);
          this.MuteValues = strArray2;
          XElement xelement15 = xelement13.Element((XName) "TimerPCS");
          int[] numArray3;
          if (xelement15 == null)
          {
            numArray3 = (int[]) null;
          }
          else
          {
            int result6;
            numArray3 = ((IEnumerable<string>) xelement15.Value.Split(";"[0])).Select<string, int>((Func<string, int>) (p => !int.TryParse(p, out result6) ? 1 : result6)).ToArray<int>();
          }
          this.MuteTimerPCS = numArray3;
          XElement xelement16 = xelement13.Element((XName) "TimerARR");
          int[] numArray4;
          if (xelement16 == null)
          {
            numArray4 = (int[]) null;
          }
          else
          {
            int result7;
            numArray4 = ((IEnumerable<string>) xelement16.Value.Split(";"[0])).Select<string, int>((Func<string, int>) (p => !int.TryParse(p, out result7) ? 1 : result7)).ToArray<int>();
          }
          this.MuteTimerARR = numArray4;
        }
        if (!this.ConfigGpios(xdoc))
          return;
        this.IsLoaded = true;
      }
    }
  }

  public void GetGpioDescription(
    string GpioType,
    out string[] GPIOsTitles,
    out string[][] GpiosFuncs,
    out bool[] IsGpioEnabled)
  {
    switch (GpioType)
    {
      case "GPIOI":
        GPIOsTitles = this.GPIOITitles;
        GpiosFuncs = this.GPIOIFuncs;
        IsGpioEnabled = this.IsGPIOIEnabled;
        break;
      case "DSPI":
        GPIOsTitles = this.DSPITitles;
        GpiosFuncs = this.DSPIFuncs;
        IsGpioEnabled = this.IsDSPIEnabled;
        break;
      default:
        GPIOsTitles = this.RegGPIOsTitles;
        GpiosFuncs = this.RegGpiosFuncs;
        IsGpioEnabled = this.IsRegGpioEnabled;
        break;
    }
  }

  public uint[] GetGpioOptions() => this.GPIO_Options;

  public int GetTouchCapGpio() => this.TouchCapGpioNum;

  public void GetGpioILinesAndFuncIndex(out int[][] Lines, out int[] FuncIndex)
  {
    FuncIndex = this.GPIOI_FunctionIndex;
    Lines = this.GPIOI_Lines;
  }

  private bool ConfigGpios(XDocument xdoc)
  {
    string[] strArray1 = new string[3]
    {
      "RegGPIOs",
      "GPIOInterfaces",
      "DSPInterfaces"
    };
    for (int index1 = 0; index1 < strArray1.Length; ++index1)
    {
      XElement xelement1 = xdoc.Element((XName) "Controller");
      \u003C\u003Ef__AnonymousType0<string, bool, string[], string[], int>[] dataArray;
      if (xelement1 == null)
      {
        dataArray = null;
      }
      else
      {
        XElement xelement2 = xelement1.Element((XName) "GPIOS");
        if (xelement2 == null)
        {
          dataArray = null;
        }
        else
        {
          XElement xelement3 = xelement2.Element((XName) strArray1[index1]);
          dataArray = xelement3 != null ? xelement3.Elements((XName) "gpio").Select(p =>
          {
            string str = p.Attribute((XName) "Title")?.Value;
            bool result1;
            int num1 = bool.TryParse(p.Attribute((XName) "IsEnabled")?.Value, out result1) ? (result1 ? 1 : 0) : 1;
            XElement xelement4 = p.Element((XName) "Functions");
            string[] strArray2;
            if (xelement4 == null)
              strArray2 = (string[]) null;
            else
              strArray2 = xelement4.Value.Split(";"[0]);
            XElement xelement5 = p.Element((XName) "Lines");
            string[] strArray3;
            if (xelement5 == null)
              strArray3 = (string[]) null;
            else
              strArray3 = xelement5.Value.Split(";"[0]);
            int result2;
            int num2 = int.TryParse(p.Element((XName) "FunctionIndex")?.Value, out result2) ? result2 : 0;
            return new
            {
              Title = str,
              IsEnabled = num1 != 0,
              Functions = strArray2,
              Lines = strArray3,
              FunctionIndex = num2
            };
          }).ToArray() : null;
        }
      }
      \u003C\u003Ef__AnonymousType0<string, bool, string[], string[], int>[] source = dataArray;
      if (source == null)
        return false;
      string[][] array1 = source.Select(p => p.Functions).ToArray<string[]>();
      string[] array2 = source.Select(p => p.Title).ToArray<string>();
      bool[] array3 = source.Select(p => p.IsEnabled).ToArray<bool>();
      switch (strArray1[index1])
      {
        case "RegGPIOs":
          this.RegGPIOsTitles = array2;
          this.RegGpiosFuncs = array1;
          this.IsRegGpioEnabled = array3;
          int result3;
          this.TouchCapGpioNum = int.TryParse(xdoc.Element((XName) "Controller")?.Element((XName) "GPIOS")?.Element((XName) "RegGPIOs")?.Attribute((XName) "TouchCapGpio")?.Value, out result3) ? result3 : -1;
          XElement xelement6 = xdoc.Element((XName) "Controller");
          uint[] numArray;
          if (xelement6 == null)
          {
            numArray = (uint[]) null;
          }
          else
          {
            XElement xelement7 = xelement6.Element((XName) "GPIOS");
            if (xelement7 == null)
            {
              numArray = (uint[]) null;
            }
            else
            {
              XElement xelement8 = xelement7.Element((XName) "RegGPIOs");
              uint result4;
              numArray = xelement8 != null ? xelement8.Elements((XName) "gpio").Select<XElement, uint>((Func<XElement, uint>) (p => !uint.TryParse(p.Attribute((XName) "Option")?.Value, out result4) ? 0U : result4)).ToArray<uint>() : (uint[]) null;
            }
          }
          this.GPIO_Options = numArray;
          break;
        case "GPIOInterfaces":
          this.GPIOITitles = array2;
          this.GPIOIFuncs = array1;
          this.IsGPIOIEnabled = array3;
          this.GPIOI_FunctionIndex = source.Select(p => p.FunctionIndex).ToArray<int>();
          string[][] array4 = source.Select(p => p.Lines).ToArray<string[]>();
          if (this.GPIOI_FunctionIndex == null || array4 == null)
            return false;
          int length = source.Count();
          this.GPIOI_Lines = new int[length][];
          for (int index2 = 0; index2 < length; ++index2)
          {
            int result5;
            this.GPIOI_Lines[index2] = ((IEnumerable<string>) array4[index2]).Select<string, int>((Func<string, int>) (p => !int.TryParse(p, out result5) ? 0 : result5)).ToArray<int>();
          }
          break;
        case "DSPInterfaces":
          this.DSPITitles = array2;
          this.DSPIFuncs = array1;
          this.IsDSPIEnabled = array3;
          break;
        default:
          return false;
      }
    }
    return true;
  }
}
