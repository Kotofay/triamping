﻿// Decompiled with JetBrains decompiler
// Type: ChipStudio.USBSettings
// Assembly: ChipStudio, Version=1.2.9.0, Culture=neutral, PublicKeyToken=null
// MVID: 334E3BEA-37C7-4274-8118-535AAEFA1546
// Assembly location: D:\DocAndSec\Desktop\AUDIO\ChipDip\ChipStudio_soft_v1.2.9\ChipStudio_v1.2.9.exe

using System;
using System.CodeDom.Compiler;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Diagnostics;
using System.IO;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Controls.Primitives;
using System.Windows.Markup;

#nullable disable
namespace ChipStudio;

public partial class USBSettings : Window, IComponentConnector
{
  private static readonly string StudioSettingsFilter = (string) Application.Current.FindResource((object) nameof (StudioSettingsFilter));
  private static readonly string USBInfoProperty = "USBInfo";
  private static readonly string ValueStartSign = "[";
  private static readonly string ValueEndSign = "]";
  private const int USBPropertyIndex = 0;
  private const int USBVIDIndex = 1;
  private const int USBPIDIndex = 2;
  private const int USBManufactIndex = 3;
  private const int USBDevName1Index = 4;
  private int USBNameIndex;
  private readonly int SpeakerCount;
  private readonly int USBParamsCount = 4;
  internal TextBox USB_VIDBox;
  internal TextBox USB_PIDBox;
  internal TextBox ManufacturerBox;
  internal ComboBox SpeakerConfSelector;
  internal TextBox DeviceNameBox;
  private bool _contentLoaded;

  public USBDeviceInfo Settings { get; }

  public USBSettings(string[] AudioDescription)
  {
    this.InitializeComponent();
    this.DataContext = (object) this;
    this.SpeakerCount = AudioDescription.Length;
    this.Settings = new USBDeviceInfo(this.SpeakerCount);
    this.USBParamsCount += this.SpeakerCount;
    this.SpeakerConfSelector.ItemsSource = (IEnumerable) AudioDescription;
    this.SpeakerConfSelector.SelectedIndex = this.USBNameIndex;
  }

  private void CheckSettings()
  {
    if (this.USB_VIDBox.Text == null || this.USB_VIDBox.Text == "")
      this.USB_VIDBox.Text = "0483";
    if (this.USB_PIDBox.Text == null || this.USB_PIDBox.Text == "")
      this.USB_PIDBox.Text = "A210";
    if (this.ManufacturerBox.Text != null && !(this.ManufacturerBox.Text == ""))
      return;
    this.ManufacturerBox.Text = "ChipDip";
  }

  private void UpdateLastDeviceName()
  {
    if (this.SpeakerConfSelector.SelectedIndex == -1)
      return;
    this.Settings.DeviceNames[this.USBNameIndex] = this.DeviceNameBox.Text;
    this.DeviceNameBox.Text = this.Settings.DeviceNames[this.SpeakerConfSelector.SelectedIndex];
    this.USBNameIndex = this.SpeakerConfSelector.SelectedIndex;
  }

  private void SpeakerConfSelector_SelectionChanged(object sender, SelectionChangedEventArgs e)
  {
    this.UpdateLastDeviceName();
  }

  private void DownloadButton_Click(object sender, RoutedEventArgs e)
  {
    this.UpdateLastDeviceName();
    this.CheckSettings();
    this.Settings.VID = this.USB_VIDBox.Text;
    this.Settings.PID = this.USB_PIDBox.Text;
    this.Settings.Manufacturer = this.ManufacturerBox.Text;
    this.DialogResult = new bool?(true);
  }

  private void CloseButton_Click(object sender, RoutedEventArgs e)
  {
    this.DialogResult = new bool?(false);
  }

  private void OpenButton_Click(object sender, RoutedEventArgs e)
  {
    string path = FileDialog.Open(USBSettings.StudioSettingsFilter);
    if (path == null)
      return;
    List<string> PropertyList = new List<string>();
    using (StreamReader streamReader = File.OpenText(path))
    {
      while (streamReader.Peek() >= 0)
        PropertyList.Add(streamReader.ReadLine());
    }
    int propertyIndex = USBSettings.FindPropertyIndex(PropertyList, USBSettings.USBInfoProperty);
    if (propertyIndex == -1)
      return;
    string[] values = Shared.ConvertFileFieldToValues(PropertyList[propertyIndex]);
    this.USB_VIDBox.Text = values[1];
    this.USB_PIDBox.Text = values[2];
    this.ManufacturerBox.Text = values[3];
    int num1 = values.Length - 4;
    int num2 = this.SpeakerCount <= num1 ? this.SpeakerCount : num1;
    for (int index = 0; index < num2; ++index)
      this.Settings.DeviceNames[index] = values[4 + index];
    this.USBNameIndex = 0;
    this.DeviceNameBox.Text = this.Settings.DeviceNames[this.USBNameIndex];
    this.SpeakerConfSelector.SelectedIndex = this.USBNameIndex;
  }

  private void SaveButton_Click(object sender, RoutedEventArgs e)
  {
    string path = FileDialog.Save(USBSettings.StudioSettingsFilter);
    if (path == null)
      return;
    this.UpdateLastDeviceName();
    this.CheckSettings();
    string[] strArray = new string[this.USBParamsCount];
    strArray[0] = USBSettings.USBInfoProperty;
    strArray[1] = this.USB_VIDBox.Text;
    strArray[2] = this.USB_PIDBox.Text;
    strArray[3] = this.ManufacturerBox.Text;
    for (int index = 0; index < this.SpeakerCount; ++index)
      strArray[4 + index] = this.Settings.DeviceNames[index];
    using (StreamWriter text = File.CreateText(path))
      text.WriteLine(USBSettings.ConvertValueToFileField(string.Join(";", strArray)));
  }

  private static string ConvertValueToFileField(string Input)
  {
    return USBSettings.ValueStartSign + Input + USBSettings.ValueEndSign;
  }

  private static int FindPropertyIndex(List<string> PropertyList, string PropertyName)
  {
    int propertyIndex = -1;
    for (int index = 0; index < PropertyList.Count; ++index)
    {
      if (PropertyList[index].IndexOf(PropertyName) != -1)
      {
        propertyIndex = index;
        break;
      }
    }
    return propertyIndex;
  }

  [DebuggerNonUserCode]
  [GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
  public void InitializeComponent()
  {
    if (this._contentLoaded)
      return;
    this._contentLoaded = true;
    Application.LoadComponent((object) this, new Uri("/ChipStudio;component/usbsettings.xaml", UriKind.Relative));
  }

  [DebuggerNonUserCode]
  [GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
  [EditorBrowsable(EditorBrowsableState.Never)]
  void IComponentConnector.Connect(int connectionId, object target)
  {
    switch (connectionId)
    {
      case 1:
        this.USB_VIDBox = (TextBox) target;
        break;
      case 2:
        this.USB_PIDBox = (TextBox) target;
        break;
      case 3:
        this.ManufacturerBox = (TextBox) target;
        break;
      case 4:
        this.SpeakerConfSelector = (ComboBox) target;
        this.SpeakerConfSelector.SelectionChanged += new System.Windows.Controls.SelectionChangedEventHandler(this.SpeakerConfSelector_SelectionChanged);
        break;
      case 5:
        this.DeviceNameBox = (TextBox) target;
        break;
      case 6:
        ((ButtonBase) target).Click += new RoutedEventHandler(this.OpenButton_Click);
        break;
      case 7:
        ((ButtonBase) target).Click += new RoutedEventHandler(this.SaveButton_Click);
        break;
      case 8:
        ((ButtonBase) target).Click += new RoutedEventHandler(this.DownloadButton_Click);
        break;
      case 9:
        ((ButtonBase) target).Click += new RoutedEventHandler(this.CloseButton_Click);
        break;
      default:
        this._contentLoaded = true;
        break;
    }
  }
}
