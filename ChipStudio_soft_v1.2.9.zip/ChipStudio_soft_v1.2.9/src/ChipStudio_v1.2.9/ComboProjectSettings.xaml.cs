﻿// Decompiled with JetBrains decompiler
// Type: ChipStudio.ComboProjectSettings
// Assembly: ChipStudio, Version=1.2.9.0, Culture=neutral, PublicKeyToken=null
// MVID: 334E3BEA-37C7-4274-8118-535AAEFA1546
// Assembly location: D:\DocAndSec\Desktop\AUDIO\ChipDip\ChipStudio_soft_v1.2.9\ChipStudio_v1.2.9.exe

using System;
using System.CodeDom.Compiler;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Diagnostics;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Controls.Primitives;
using System.Windows.Markup;

#nullable disable
namespace ChipStudio;

public partial class ComboProjectSettings : UserControl, IComponentConnector
{
  private static readonly int[] BootLinesCountStrings = new int[4]
  {
    1,
    2,
    3,
    4
  };
  private static readonly string[][] BootLinesStatesStrings = new string[4][]
  {
    new string[2]{ "x x x 0", "x x x 1" },
    new string[4]{ "x x 0 0", "x x 0 1", "x x 1 0", "x x 1 1" },
    new string[8]
    {
      "x 0 0 0",
      "x 0 0 1",
      "x 0 1 0",
      "x 0 1 1",
      "x 1 0 0",
      "x 1 0 1",
      "x 1 1 0",
      "x 1 1 1"
    },
    new string[16 /*0x10*/]
    {
      "0 0 0 0",
      "0 0 0 1",
      "0 0 1 0",
      "0 0 1 1",
      "0 1 0 0",
      "0 1 0 1",
      "0 1 1 0",
      "0 1 1 1",
      "1 0 0 0",
      "1 0 0 1",
      "1 0 1 0",
      "1 0 1 1",
      "1 1 0 0",
      "1 1 0 1",
      "1 1 1 0",
      "1 1 1 1"
    }
  };
  private static readonly string[] ProjectBootModesStrings = new string[2]
  {
    "Boot lines",
    "Audio stream"
  };
  private static readonly string UndefinedWord = "Undefined";
  private static readonly string[] LR_FreqStrings = new string[11]
  {
    "44,1 kHz",
    "48 kHz",
    "88,2 kHz",
    "96 kHz",
    "176,4 kHz",
    "192 kHz",
    "352,8 kHz",
    "384 kHz",
    ComboProjectSettings.UndefinedWord,
    "705,6 kHz",
    "768 kHz"
  };
  private static readonly string[] LRtoBCLKStrings = new string[29]
  {
    "  44,1 кГц @ 32Fs",
    "  44,1 кГц @ 64Fs",
    "  44,1 кГц @ 128Fs",
    "  44,1 кГц @ 256Fs",
    "  48,0 кГц @ 32Fs",
    "  48,0 кГц @ 64Fs",
    "  48,0 кГц @ 128Fs",
    "  48,0 кГц @ 256Fs",
    "  88,2 кГц @ 32Fs",
    "  88,2 кГц @ 64Fs",
    "  88,2 кГц @ 128Fs",
    "  96,0 кГц @ 32Fs",
    "  96,0 кГц @ 64Fs",
    "  96,0 кГц @ 128Fs",
    "176,4 кГц @ 32Fs",
    "176,4 кГц @ 64Fs",
    "192,0 кГц @ 32Fs",
    "192,0 кГц @ 64Fs",
    "352,8 kHz @ any",
    "384,0 kHz @ any",
    ComboProjectSettings.UndefinedWord,
    "352,8 kHz @ 32Fs",
    "352,8 kHz @ 64Fs",
    "384,0 kHz @ 32Fs",
    "384,0 kHz @ 64Fs",
    "705,6 kHz @ 32Fs",
    "705,6 kHz @ 64Fs",
    "768,0 kHz @ 32Fs",
    "768,0 kHz @ 64Fs"
  };
  private static readonly string GPIOsString = "GPIOs  ";
  private const int COMBO_TYPE_BOOT_LINES = 0;
  private const int COMBO_TYPE_STREAM_LR = 1;
  private const int COMBO_TYPE_STREAM_LR_BCLK = 2;
  private const int COMBO_STREAM_SUBTYPE_LR = 0;
  private const int COMBO_STREAM_SUBTYPE_LR_BCLK = 1;
  private Func<string, string> ChangeComboPart;
  private Action ClearSchema;
  private List<ComboProjectPart> ComboProjectParts = new List<ComboProjectPart>();
  private int ComboProjectType;
  private readonly string[] ControllerStrings;
  private ControllerComboProperties ComboProperties;
  internal ComboBox ControllerSelector;
  internal ComboBox ProjectBootMode;
  internal CheckBox UpdateProjectCheck;
  internal StackPanel BootLinesView;
  internal ComboBox BootLinesCountSelector;
  internal Label BootGPIOLabel;
  internal ComboBox BootLinesStateSelector;
  internal StackPanel AudioStreamView;
  internal RadioButton LR_ModeBut;
  internal RadioButton LR_BCLK_ModeBut;
  internal ComboBox LRFreqSelector;
  internal ComboBox LRandBCLKSelector;
  internal TextBlock ComboProjectName;
  internal TextBlock CurrentProjectName;
  private bool _contentLoaded;

  public string CurrentPartProject
  {
    get => this.CurrentProjectName.Text;
    set => this.CurrentProjectName.Text = value;
  }

  public string ComboProject
  {
    get => this.ComboProjectName.Text;
    set => this.ComboProjectName.Text = value;
  }

  public List<ComboProjectPart> Projects => this.ComboProjectParts;

  public string Controller
  {
    get
    {
      return this.ControllerSelector.SelectedIndex == -1 ? "" : this.ControllerStrings[this.ControllerSelector.SelectedIndex];
    }
  }

  public int ComboType => this.ComboProjectType;

  public bool ReconfigType => this.UpdateProjectCheck.IsChecked.Value;

  public int BootLinesCount
  {
    get
    {
      return this.BootLinesCountSelector.SelectedIndex == -1 ? 0 : ComboProjectSettings.BootLinesCountStrings[this.BootLinesCountSelector.SelectedIndex];
    }
  }

  public ComboProjectSettings()
  {
    this.InitializeComponent();
    this.DataContext = (object) this;
    this.BootLinesCountSelector.ItemsSource = (IEnumerable) ComboProjectSettings.BootLinesCountStrings;
    this.BootLinesCountSelector.SelectedIndex = 0;
    this.BootLinesStateSelector.ItemsSource = (IEnumerable) ComboProjectSettings.BootLinesStatesStrings[0];
    this.BootLinesStateSelector.SelectedIndex = 0;
    this.ProjectBootMode.ItemsSource = (IEnumerable) ComboProjectSettings.ProjectBootModesStrings;
    this.ProjectBootMode.SelectedIndex = this.ComboProjectType;
    this.LRFreqSelector.ItemsSource = (IEnumerable) ComboProjectSettings.LR_FreqStrings;
    this.LRFreqSelector.SelectedIndex = 0;
    ComboBoxItem[] comboBoxItemArray1 = new ComboBoxItem[ComboProjectSettings.LRtoBCLKStrings.Length];
    for (int index1 = 0; index1 < ComboProjectSettings.LRtoBCLKStrings.Length; ++index1)
    {
      ComboBoxItem[] comboBoxItemArray2 = comboBoxItemArray1;
      int index2 = index1;
      ComboBoxItem comboBoxItem = new ComboBoxItem();
      comboBoxItem.Content = (object) ComboProjectSettings.LRtoBCLKStrings[index1];
      comboBoxItem.HorizontalContentAlignment = HorizontalAlignment.Left;
      comboBoxItem.VerticalContentAlignment = VerticalAlignment.Center;
      comboBoxItemArray2[index2] = comboBoxItem;
    }
    this.LRandBCLKSelector.ItemsSource = (IEnumerable) comboBoxItemArray1;
    this.LRandBCLKSelector.SelectedIndex = 0;
    this.ControllerStrings = Shared.GetFolderFiles(Shared.ControllersFolder);
    this.ControllerSelector.ItemsSource = (IEnumerable) this.ControllerStrings;
    this.ControllerSelector.SelectedIndex = 0;
    this.ComboProperties = new ControllerComboProperties(this.ControllerStrings[0]);
    this.UpdateComboProjectsParts();
    this.BootLinesCountSelector.SelectionChanged += new System.Windows.Controls.SelectionChangedEventHandler(this.BootLinesCountSelector_SelectionChanged);
    this.BootLinesStateSelector.SelectionChanged += new System.Windows.Controls.SelectionChangedEventHandler(this.BootLinesStateSelector_SelectionChanged);
    this.ProjectBootMode.SelectionChanged += new System.Windows.Controls.SelectionChangedEventHandler(this.ProjectBootMode_SelectionChanged);
    this.LR_ModeBut.Checked += new RoutedEventHandler(this.LR_ModeBut_Checked);
    this.LRFreqSelector.SelectionChanged += new System.Windows.Controls.SelectionChangedEventHandler(this.LRFreqSelector_SelectionChanged);
    this.LR_BCLK_ModeBut.Checked += new RoutedEventHandler(this.LR_BCLK_ModeBut_Checked);
    this.LRandBCLKSelector.SelectionChanged += new System.Windows.Controls.SelectionChangedEventHandler(this.LRandBCLKSelector_SelectionChanged);
    this.BootGPIOLabel.Content = (object) ComboProjectSettings.GPIOsString;
  }

  public void Init(ComboProjectParameters ComboParams, List<ComboProjectPart> ComboParts)
  {
    this.ControllerSelector.SelectedIndex = 0;
    for (int index = 0; index < this.ControllerStrings.Length; ++index)
    {
      if (ComboParams.Controller == this.ControllerStrings[index])
      {
        this.ControllerSelector.SelectedIndex = index;
        break;
      }
    }
    ComboBox comboBox;
    if (ComboParams.Type == 0)
    {
      this.ProjectBootMode.SelectedIndex = 0;
      this.BootLinesCountSelector.SelectedIndex = ComboParams.SubType;
      comboBox = this.BootLinesStateSelector;
    }
    else
    {
      this.ProjectBootMode.SelectedIndex = 1;
      if (ComboParams.SubType == 0)
      {
        this.LR_ModeBut.IsChecked = new bool?(true);
        comboBox = this.LRFreqSelector;
      }
      else
      {
        this.LR_BCLK_ModeBut.IsChecked = new bool?(true);
        comboBox = this.LRandBCLKSelector;
        while (ComboParts.Count < ComboProjectSettings.LRtoBCLKStrings.Length)
          ComboParts.Add(new ComboProjectPart());
      }
    }
    this.ComboProjectParts = ComboParts;
    comboBox.SelectedIndex = -1;
    comboBox.SelectedIndex = 0;
    this.UpdateProjectCheck.IsChecked = new bool?(ComboParams.DoNotReboot);
  }

  public void Reset()
  {
    this.ComboProjectType = 0;
    this.BootLinesCountSelector.SelectedIndex = 0;
    this.BootLinesStateSelector.SelectedIndex = 0;
    this.ControllerSelector.SelectedIndex = 0;
    this.ProjectBootMode.SelectedIndex = this.ComboProjectType;
    this.LRFreqSelector.SelectedIndex = 0;
    this.LRandBCLKSelector.SelectedIndex = 0;
  }

  public ComboBox GetActiveComboPartSelector()
  {
    if (this.ComboProjectType == 0)
      return this.BootLinesStateSelector;
    return this.ComboProjectType == 1 ? this.LRFreqSelector : this.LRandBCLKSelector;
  }

  public ComboProjectParameters GetParams()
  {
    ComboProjectParameters projectParameters = new ComboProjectParameters()
    {
      Controller = this.ControllerStrings[this.ControllerSelector.SelectedIndex],
      Type = this.ComboProjectType
    };
    projectParameters.SubType = this.ComboProjectType != 0 ? (this.ComboProjectType != 1 ? 1 : 0) : this.BootLinesCountSelector.SelectedIndex;
    bool? isChecked = this.UpdateProjectCheck.IsChecked;
    bool flag = true;
    projectParameters.DoNotReboot = isChecked.GetValueOrDefault() == flag & isChecked.HasValue;
    return projectParameters;
  }

  public int ComboSubType()
  {
    int num = ComboProjectSettings.BootLinesCountStrings[this.BootLinesCountSelector.SelectedIndex];
    if (this.ComboProjectType == 1)
      num = 0;
    else if (this.ComboProjectType == 2)
      num = 1;
    return num;
  }

  public void SetComboPart(string NewProject)
  {
    if (this.ComboProjectType == 0)
      this.ComboProjectParts[this.BootLinesStateSelector.SelectedIndex].Name = NewProject;
    else if (this.ComboProjectType == 1)
      this.ComboProjectParts[this.LRFreqSelector.SelectedIndex].Name = NewProject;
    else
      this.ComboProjectParts[this.LRandBCLKSelector.SelectedIndex].Name = NewProject;
  }

  public void SetChangeComboPartCallBack(Func<string, string> Callback)
  {
    this.ChangeComboPart = Callback;
  }

  public void SetClearComboPartCallBack(Action Callback) => this.ClearSchema = Callback;

  private void UpdateComboProjectsParts()
  {
    int num = -1;
    if (this.ComboProjectType == 0)
    {
      if (this.BootLinesStateSelector.SelectedIndex != -1)
        num = ComboProjectSettings.BootLinesStatesStrings[this.BootLinesCountSelector.SelectedIndex].Length;
    }
    else
      num = this.ComboProjectType != 1 ? ComboProjectSettings.LRtoBCLKStrings.Length : ComboProjectSettings.LR_FreqStrings.Length;
    if (num == -1)
      return;
    this.ComboProjectParts.Clear();
    for (int index = 0; index < num; ++index)
      this.ComboProjectParts.Add(new ComboProjectPart());
  }

  private void BootLinesCountSelector_SelectionChanged(object sender, SelectionChangedEventArgs e)
  {
    if (this.BootLinesCountSelector.SelectedIndex == -1)
      return;
    this.UpdateComboProjectsParts();
    this.BootLinesStateSelector.ItemsSource = (IEnumerable) ComboProjectSettings.BootLinesStatesStrings[this.BootLinesCountSelector.SelectedIndex];
    this.BootLinesStateSelector.SelectedIndex = 0;
  }

  private void Controller_SelectionChanged(object sender, SelectionChangedEventArgs e)
  {
    if (this.ControllerSelector.SelectedIndex == -1)
      return;
    this.ComboProperties = new ControllerComboProperties(this.ControllerStrings[this.ControllerSelector.SelectedIndex]);
    this.BootGPIOLabel.Content = (object) (ComboProjectSettings.GPIOsString + this.ComboProperties.BootGpiosNumbers);
    if (this.ComboProperties.IsGpioBootSupported)
    {
      this.ProjectBootMode.IsEnabled = true;
      this.LR_ModeBut.IsEnabled = true;
    }
    else
    {
      this.ProjectBootMode.SelectedIndex = 1;
      this.ProjectBootMode.IsEnabled = false;
      this.LR_BCLK_ModeBut.IsChecked = new bool?(true);
      this.LR_ModeBut.IsEnabled = false;
    }
    this.LRandBCLKSelector.SelectedIndex = 0;
    this.UpdateProjectCheck.IsChecked = new bool?(true);
    this.UpdateProjectCheck.IsEnabled = this.ComboProperties.ProjectBootOption;
    if (this.ComboProperties.UnusedStreams == null)
      return;
    for (int index = 0; index < ComboProjectSettings.LRtoBCLKStrings.Length; ++index)
      (this.LRandBCLKSelector.Items[index] as ComboBoxItem).IsEnabled = Array.IndexOf<int>(this.ComboProperties.UnusedStreams, index) == -1;
  }

  private void ProjectBootMode_SelectionChanged(object sender, SelectionChangedEventArgs e)
  {
    if (this.ProjectBootMode.SelectedIndex == 0)
    {
      this.ComboProjectType = 0;
      this.BootLinesView.IsEnabled = true;
      this.AudioStreamView.IsEnabled = false;
    }
    else
    {
      this.BootLinesView.IsEnabled = false;
      this.AudioStreamView.IsEnabled = true;
      bool? isChecked = this.LR_ModeBut.IsChecked;
      bool flag = true;
      this.ComboProjectType = !(isChecked.GetValueOrDefault() == flag & isChecked.HasValue) ? 2 : 1;
    }
    this.UpdateComboProjectsParts();
    Action clearSchema = this.ClearSchema;
    if (clearSchema == null)
      return;
    clearSchema();
  }

  private void LR_ModeBut_Checked(object sender, RoutedEventArgs e)
  {
    if (this.LRFreqSelector == null)
      return;
    this.LRFreqSelector.IsEnabled = true;
    this.LRandBCLKSelector.IsEnabled = false;
    this.ComboProjectType = 1;
    this.UpdateComboProjectsParts();
    Action clearSchema = this.ClearSchema;
    if (clearSchema == null)
      return;
    clearSchema();
  }

  private void LR_BCLK_ModeBut_Checked(object sender, RoutedEventArgs e)
  {
    if (this.LRFreqSelector == null)
      return;
    this.LRFreqSelector.IsEnabled = false;
    this.LRandBCLKSelector.IsEnabled = true;
    this.ComboProjectType = 2;
    this.UpdateComboProjectsParts();
    Action clearSchema = this.ClearSchema;
    if (clearSchema == null)
      return;
    clearSchema();
  }

  private void DeleteProjectFromCombo_Click(object sender, RoutedEventArgs e)
  {
    ComboBox comboPartSelector = this.GetActiveComboPartSelector();
    if (comboPartSelector.SelectedIndex == -1 || this.ComboProjectParts[comboPartSelector.SelectedIndex].Name == null || MessageBox.Show("Current project will be removed from CompoProject.\n\rPress 'YES' to continue, otherwise press 'NO'", "", MessageBoxButton.YesNo, MessageBoxImage.Exclamation) != MessageBoxResult.Yes)
      return;
    this.ComboProjectParts[comboPartSelector.SelectedIndex].Name = (string) null;
    Action clearSchema = this.ClearSchema;
    if (clearSchema == null)
      return;
    clearSchema();
  }

  private void ComboPartChanged(ComboBox ComboPartSelector)
  {
    if (ComboPartSelector.SelectedIndex == -1)
      return;
    if (ComboPartSelector.SelectedIndex < this.ComboProjectParts.Count)
    {
      ComboProjectPart comboProjectPart = this.ComboProjectParts[ComboPartSelector.SelectedIndex];
      Func<string, string> changeComboPart = this.ChangeComboPart;
      string str = changeComboPart != null ? changeComboPart(this.ComboProjectParts[ComboPartSelector.SelectedIndex].Name) : (string) null;
      comboProjectPart.Name = str;
    }
    else
    {
      int num = (int) MessageBox.Show("Combo project has no this subproject.\n\rCreate new ComboProject.", "", MessageBoxButton.OK, MessageBoxImage.Hand);
    }
  }

  private void BootLinesStateSelector_SelectionChanged(object sender, SelectionChangedEventArgs e)
  {
    this.ComboPartChanged(this.BootLinesStateSelector);
  }

  private void LRFreqSelector_SelectionChanged(object sender, SelectionChangedEventArgs e)
  {
    this.ComboPartChanged(this.LRFreqSelector);
  }

  private void LRandBCLKSelector_SelectionChanged(object sender, SelectionChangedEventArgs e)
  {
    this.ComboPartChanged(this.LRandBCLKSelector);
  }

  [DebuggerNonUserCode]
  [GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
  public void InitializeComponent()
  {
    if (this._contentLoaded)
      return;
    this._contentLoaded = true;
    Application.LoadComponent((object) this, new Uri("/ChipStudio;component/comboprojectsettings.xaml", UriKind.Relative));
  }

  [DebuggerNonUserCode]
  [GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
  [EditorBrowsable(EditorBrowsableState.Never)]
  void IComponentConnector.Connect(int connectionId, object target)
  {
    switch (connectionId)
    {
      case 1:
        this.ControllerSelector = (ComboBox) target;
        this.ControllerSelector.SelectionChanged += new System.Windows.Controls.SelectionChangedEventHandler(this.Controller_SelectionChanged);
        break;
      case 2:
        this.ProjectBootMode = (ComboBox) target;
        break;
      case 3:
        this.UpdateProjectCheck = (CheckBox) target;
        break;
      case 4:
        this.BootLinesView = (StackPanel) target;
        break;
      case 5:
        this.BootLinesCountSelector = (ComboBox) target;
        break;
      case 6:
        this.BootGPIOLabel = (Label) target;
        break;
      case 7:
        this.BootLinesStateSelector = (ComboBox) target;
        break;
      case 8:
        this.AudioStreamView = (StackPanel) target;
        break;
      case 9:
        this.LR_ModeBut = (RadioButton) target;
        break;
      case 10:
        this.LR_BCLK_ModeBut = (RadioButton) target;
        break;
      case 11:
        this.LRFreqSelector = (ComboBox) target;
        break;
      case 12:
        this.LRandBCLKSelector = (ComboBox) target;
        break;
      case 13:
        ((ButtonBase) target).Click += new RoutedEventHandler(this.DeleteProjectFromCombo_Click);
        break;
      case 14:
        this.ComboProjectName = (TextBlock) target;
        break;
      case 15:
        this.CurrentProjectName = (TextBlock) target;
        break;
      default:
        this._contentLoaded = true;
        break;
    }
  }
}
