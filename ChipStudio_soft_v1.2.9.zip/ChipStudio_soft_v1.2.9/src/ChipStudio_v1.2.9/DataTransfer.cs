﻿// Decompiled with JetBrains decompiler
// Type: ChipStudio.DataTransfer
// Assembly: ChipStudio, Version=1.2.9.0, Culture=neutral, PublicKeyToken=null
// MVID: 334E3BEA-37C7-4274-8118-535AAEFA1546
// Assembly location: D:\DocAndSec\Desktop\AUDIO\ChipDip\ChipStudio_soft_v1.2.9\ChipStudio_v1.2.9.exe

using System;

#nullable disable
namespace ChipStudio;

public class DataTransfer
{
  public ushort Address { get; set; }

  public int Size { get; set; }

  public byte[] Data { get; set; }

  public DataTransfer.TransferTypes Type { get; }

  public byte AddressIncrement { get; }

  public DataTransfer(ushort address, int datasize, byte adrincr, DataTransfer.TransferTypes type)
  {
    this.Address = address;
    this.Size = datasize;
    this.Type = type;
    this.AddressIncrement = adrincr;
    this.Data = new byte[this.Size];
  }

  public static bool TryParseType(string value, out DataTransfer.TransferTypes result)
  {
    result = DataTransfer.TransferTypes.Clear;
    foreach (DataTransfer.TransferTypes transferTypes in Enum.GetValues(typeof (DataTransfer.TransferTypes)))
    {
      if (transferTypes.ToString() == value)
      {
        result = transferTypes;
        return true;
      }
    }
    return false;
  }

  public enum TransferTypes : byte
  {
    Write,
    Read,
    Clear,
    Poll,
  }
}
