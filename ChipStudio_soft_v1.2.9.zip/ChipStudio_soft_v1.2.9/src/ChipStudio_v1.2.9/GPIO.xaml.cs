﻿// Decompiled with JetBrains decompiler
// Type: ChipStudio.GPIO
// Assembly: ChipStudio, Version=1.2.9.0, Culture=neutral, PublicKeyToken=null
// MVID: 334E3BEA-37C7-4274-8118-535AAEFA1546
// Assembly location: D:\DocAndSec\Desktop\AUDIO\ChipDip\ChipStudio_soft_v1.2.9\ChipStudio_v1.2.9.exe

using System;
using System.CodeDom.Compiler;
using System.Collections;
using System.ComponentModel;
using System.Diagnostics;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Markup;

#nullable disable
namespace ChipStudio;

public partial class GPIO : UserControl, INotifyPropertyChanged, IComponentConnector
{
  private bool isactive = true;
  private bool isconnectable;
  private Anchor.AnchorTypes[] _OwnAnchors;
  private Anchor.AnchorTypes[] _OppositeAnchors;
  private string[] funcs;
  internal StackPanel MainPanel;
  internal Label GPIOTitle;
  internal ComboBox FunctionBox;
  internal Anchor ConnectionPoint;
  private bool _contentLoaded;

  public string Title { get; set; }

  public int TitleLength { get; set; }

  public string[] Functions
  {
    get => this.funcs;
    set
    {
      if (this.funcs == value)
        return;
      this.funcs = value;
      this.FunctionBox.ItemsSource = (IEnumerable) this.Functions;
    }
  }

  public string ActiveFunction => this.FunctionBox.SelectedItem?.ToString();

  public int ActiveFuncIndex
  {
    get => this.FunctionBox.SelectedIndex;
    set => this.FunctionBox.SelectedIndex = value;
  }

  public int FunctionLength { get; set; }

  public bool IsActive
  {
    get => this.isactive;
    set
    {
      if (this.isactive == value)
        return;
      this.isactive = value;
      this.IsConnectable = false;
      this.NotifyPropertyChanged(nameof (IsActive));
    }
  }

  public bool IsConnectable
  {
    get => this.isconnectable;
    set
    {
      if (this.isconnectable == value)
        return;
      this.isconnectable = value;
      this.ConnectionPoint.IsActivated = this.isconnectable;
    }
  }

  public Anchor.AnchorTypes[] OwnAnchors
  {
    set
    {
      this._OwnAnchors = value;
      this.ConnectionPoint.Type = this._OwnAnchors[0];
    }
  }

  public Anchor.AnchorTypes[] OppositeAnchors
  {
    set => this._OppositeAnchors = value;
  }

  public Anchor.AnchorTypes ActiveOppositeAnchor
  {
    get
    {
      return this._OppositeAnchors == null || this.FunctionBox.SelectedIndex == -1 ? Anchor.AnchorTypes.EMPTY : this._OppositeAnchors[this.FunctionBox.SelectedIndex];
    }
  }

  public uint Option { get; set; }

  public GPIO()
  {
    this.InitializeComponent();
    this.DataContext = (object) this;
  }

  public void FlipHorizontal()
  {
    this.MainPanel.FlowDirection = this.MainPanel.FlowDirection == FlowDirection.LeftToRight ? FlowDirection.RightToLeft : FlowDirection.LeftToRight;
    this.FunctionBox.FlowDirection = FlowDirection.LeftToRight;
  }

  public event PropertyChangedEventHandler PropertyChanged;

  public void NotifyPropertyChanged(string PropertyName)
  {
    PropertyChangedEventHandler propertyChanged = this.PropertyChanged;
    if (propertyChanged == null)
      return;
    propertyChanged((object) this, new PropertyChangedEventArgs(PropertyName));
  }

  public event GPIO.FunctionChangedEventHandler FunctionChanged;

  private void Function_SelectionChanged(object sender, SelectionChangedEventArgs e)
  {
    int selectedIndex = (sender as ComboBox).SelectedIndex;
    if (selectedIndex != -1 && this._OwnAnchors != null && selectedIndex < this._OwnAnchors.Length)
      this.ConnectionPoint.Type = this._OwnAnchors[selectedIndex];
    if (!this.IsLoaded)
      return;
    GPIO.FunctionChangedEventHandler functionChanged = this.FunctionChanged;
    if (functionChanged == null)
      return;
    functionChanged(this.ConnectionPoint.Number, selectedIndex);
  }

  [DebuggerNonUserCode]
  [GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
  public void InitializeComponent()
  {
    if (this._contentLoaded)
      return;
    this._contentLoaded = true;
    Application.LoadComponent((object) this, new Uri("/ChipStudio;component/gpio.xaml", UriKind.Relative));
  }

  [DebuggerNonUserCode]
  [GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
  internal Delegate _CreateDelegate(Type delegateType, string handler)
  {
    return Delegate.CreateDelegate(delegateType, (object) this, handler);
  }

  [DebuggerNonUserCode]
  [GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
  [EditorBrowsable(EditorBrowsableState.Never)]
  void IComponentConnector.Connect(int connectionId, object target)
  {
    switch (connectionId)
    {
      case 1:
        this.MainPanel = (StackPanel) target;
        break;
      case 2:
        this.GPIOTitle = (Label) target;
        break;
      case 3:
        this.FunctionBox = (ComboBox) target;
        this.FunctionBox.SelectionChanged += new System.Windows.Controls.SelectionChangedEventHandler(this.Function_SelectionChanged);
        break;
      case 4:
        this.ConnectionPoint = (Anchor) target;
        break;
      default:
        this._contentLoaded = true;
        break;
    }
  }

  public delegate void FunctionChangedEventHandler(int GPIONumber, int NewFunctionIndex);
}
