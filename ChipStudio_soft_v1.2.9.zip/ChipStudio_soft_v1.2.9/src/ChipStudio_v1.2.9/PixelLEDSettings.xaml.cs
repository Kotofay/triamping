﻿// Decompiled with JetBrains decompiler
// Type: ChipStudio.PixelLEDSettings
// Assembly: ChipStudio, Version=1.2.9.0, Culture=neutral, PublicKeyToken=null
// MVID: 334E3BEA-37C7-4274-8118-535AAEFA1546
// Assembly location: D:\DocAndSec\Desktop\AUDIO\ChipDip\ChipStudio_soft_v1.2.9\ChipStudio_v1.2.9.exe

using System;
using System.CodeDom.Compiler;
using System.ComponentModel;
using System.Diagnostics;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Controls.Primitives;
using System.Windows.Markup;

#nullable disable
namespace ChipStudio;

public partial class PixelLEDSettings : Window, IComponentConnector
{
  public PixelLEDBlock Settings = new PixelLEDBlock();
  internal TextBox CountBox;
  internal RadioButton ProjectPixel;
  internal RadioButton BlockPixel;
  internal RadioButton CompPixel;
  internal StackPanel IndModePanel;
  internal RadioButton IndModeDataTable;
  internal RadioButton IndModeScale;
  private bool _contentLoaded;

  public PixelLEDSettings(PixelLEDBlock ActiveSettings)
  {
    this.InitializeComponent();
    this.CountBox.Text = ActiveSettings.LEDsCount.ToString();
    switch (ActiveSettings.IndicationType)
    {
      case PixelLEDBlock.IndicationTypes.Project:
        this.ProjectPixel.IsChecked = new bool?(true);
        this.IndModePanel.IsEnabled = false;
        break;
      case PixelLEDBlock.IndicationTypes.DSPBlock:
        this.BlockPixel.IsChecked = new bool?(true);
        this.IndModePanel.IsEnabled = true;
        if (ActiveSettings.IndicationMode == PixelLEDBlock.IndicationModes.DataTable)
        {
          this.IndModeDataTable.IsChecked = new bool?(true);
          break;
        }
        this.IndModeScale.IsChecked = new bool?(true);
        break;
      case PixelLEDBlock.IndicationTypes.Comparator:
        this.CompPixel.IsChecked = new bool?(true);
        this.IndModeDataTable.IsChecked = new bool?(true);
        this.IndModePanel.IsEnabled = false;
        break;
    }
    this.Settings.StatesCount = ActiveSettings.StatesCount;
  }

  private void OKButton_Click(object sender, RoutedEventArgs e)
  {
    int result;
    this.Settings.LEDsCount = int.TryParse(this.CountBox.Text, out result) ? result : 1;
    this.Settings.IndicationType = PixelLEDBlock.IndicationTypes.Project;
    bool? isChecked = this.BlockPixel.IsChecked;
    bool flag1 = true;
    if (isChecked.GetValueOrDefault() == flag1 & isChecked.HasValue)
    {
      this.Settings.IndicationType = PixelLEDBlock.IndicationTypes.DSPBlock;
      PixelLEDBlock settings = this.Settings;
      isChecked = this.IndModeScale.IsChecked;
      bool flag2 = true;
      int num = isChecked.GetValueOrDefault() == flag2 & isChecked.HasValue ? 1 : 0;
      settings.IndicationMode = (PixelLEDBlock.IndicationModes) num;
    }
    else
    {
      isChecked = this.CompPixel.IsChecked;
      bool flag3 = true;
      if (isChecked.GetValueOrDefault() == flag3 & isChecked.HasValue)
      {
        this.Settings.IndicationType = PixelLEDBlock.IndicationTypes.Comparator;
        this.Settings.IndicationMode = PixelLEDBlock.IndicationModes.DataTable;
      }
    }
    this.DialogResult = new bool?(true);
  }

  private void CancelButton_Click(object sender, RoutedEventArgs e)
  {
    this.DialogResult = new bool?(false);
  }

  private void ProjectPixel_Checked(object sender, RoutedEventArgs e)
  {
    if (this.IndModePanel == null)
      return;
    this.IndModePanel.IsEnabled = false;
  }

  private void BlockPixel_Checked(object sender, RoutedEventArgs e)
  {
    if (this.IndModePanel == null)
      return;
    this.IndModePanel.IsEnabled = true;
  }

  private void CompPixel_Checked(object sender, RoutedEventArgs e)
  {
    if (this.IndModePanel == null)
      return;
    this.IndModeDataTable.IsChecked = new bool?(true);
    this.IndModePanel.IsEnabled = false;
  }

  [DebuggerNonUserCode]
  [GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
  public void InitializeComponent()
  {
    if (this._contentLoaded)
      return;
    this._contentLoaded = true;
    Application.LoadComponent((object) this, new Uri("/ChipStudio;component/pixelledsettings.xaml", UriKind.Relative));
  }

  [DebuggerNonUserCode]
  [GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
  [EditorBrowsable(EditorBrowsableState.Never)]
  void IComponentConnector.Connect(int connectionId, object target)
  {
    switch (connectionId)
    {
      case 1:
        this.CountBox = (TextBox) target;
        break;
      case 2:
        this.ProjectPixel = (RadioButton) target;
        this.ProjectPixel.Checked += new RoutedEventHandler(this.ProjectPixel_Checked);
        break;
      case 3:
        this.BlockPixel = (RadioButton) target;
        this.BlockPixel.Checked += new RoutedEventHandler(this.BlockPixel_Checked);
        break;
      case 4:
        this.CompPixel = (RadioButton) target;
        this.CompPixel.Checked += new RoutedEventHandler(this.CompPixel_Checked);
        break;
      case 5:
        this.IndModePanel = (StackPanel) target;
        break;
      case 6:
        this.IndModeDataTable = (RadioButton) target;
        break;
      case 7:
        this.IndModeScale = (RadioButton) target;
        break;
      case 8:
        ((ButtonBase) target).Click += new RoutedEventHandler(this.OKButton_Click);
        break;
      case 9:
        ((ButtonBase) target).Click += new RoutedEventHandler(this.CancelButton_Click);
        break;
      default:
        this._contentLoaded = true;
        break;
    }
  }
}
