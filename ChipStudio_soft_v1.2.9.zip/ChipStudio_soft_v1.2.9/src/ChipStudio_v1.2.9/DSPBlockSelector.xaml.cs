﻿// Decompiled with JetBrains decompiler
// Type: ChipStudio.DSPBlockSelector
// Assembly: ChipStudio, Version=1.2.9.0, Culture=neutral, PublicKeyToken=null
// MVID: 334E3BEA-37C7-4274-8118-535AAEFA1546
// Assembly location: D:\DocAndSec\Desktop\AUDIO\ChipDip\ChipStudio_soft_v1.2.9\ChipStudio_v1.2.9.exe

using System;
using System.CodeDom.Compiler;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Diagnostics;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Markup;

#nullable disable
namespace ChipStudio;

public partial class DSPBlockSelector : UserControl, IComponentConnector
{
  private readonly List<string> EventBlockSelectorList = new List<string>();
  private readonly List<SchemaBlock_DSPCell> EventBlocks = new List<SchemaBlock_DSPCell>();
  internal ComboBox EventBlockSelector;
  private bool _contentLoaded;

  public string Title { get; set; }

  public int DefaultBlock { get; set; }

  public DSPBlockSelector()
  {
    this.InitializeComponent();
    this.DataContext = (object) this;
  }

  public ConnectionNode ActiveConnectionNode()
  {
    if (this.EventBlockSelector.SelectedIndex == -1)
      return (ConnectionNode) null;
    return this.EventBlockSelectorList[this.EventBlockSelector.SelectedIndex].IndexOf("EN") != -1 ? this.EventBlocks[this.EventBlockSelector.SelectedIndex].GetAnchorConnectionNode(1) : this.EventBlocks[this.EventBlockSelector.SelectedIndex].GetAnchorConnectionNode(0);
  }

  public void Update(SchemaBlock_DSPCell[] Blocks, Schema.UpdateOptions Option)
  {
    int num = this.EventBlockSelector.SelectedIndex;
    this.EventBlockSelector.ItemsSource = (IEnumerable) null;
    List<SchemaBlock_DSPCell> schemaBlockDspCellList = new List<SchemaBlock_DSPCell>();
    schemaBlockDspCellList.AddRange((IEnumerable<SchemaBlock_DSPCell>) Blocks);
    switch (Option)
    {
      case Schema.UpdateOptions.Init:
        for (int index = 0; index < schemaBlockDspCellList.Count; ++index)
        {
          this.AddEventBlockFromCell(schemaBlockDspCellList[index]);
          this.EventBlocks.Add(schemaBlockDspCellList[index]);
          if (schemaBlockDspCellList[index].IsBypassable)
            this.EventBlocks.Add(schemaBlockDspCellList[index]);
        }
        num = this.DefaultBlock;
        break;
      case Schema.UpdateOptions.Add:
        this.AddEventBlockFromCell(schemaBlockDspCellList[schemaBlockDspCellList.Count - 1]);
        this.EventBlocks.Add(schemaBlockDspCellList[schemaBlockDspCellList.Count - 1]);
        if (schemaBlockDspCellList[schemaBlockDspCellList.Count - 1].IsBypassable)
        {
          this.EventBlocks.Add(schemaBlockDspCellList[schemaBlockDspCellList.Count - 1]);
          break;
        }
        break;
      case Schema.UpdateOptions.Remove:
        bool flag1 = false;
        for (int index = 0; index < schemaBlockDspCellList.Count; ++index)
        {
          if (schemaBlockDspCellList[index].IsBypassable)
          {
            if (index != schemaBlockDspCellList.Count - 1)
              schemaBlockDspCellList.Insert(index + 1, schemaBlockDspCellList[index]);
            else
              schemaBlockDspCellList.Add(schemaBlockDspCellList[index]);
            ++index;
          }
        }
        for (int index = 0; index < schemaBlockDspCellList.Count; ++index)
        {
          if (schemaBlockDspCellList[index].Title + schemaBlockDspCellList[index].DSPTitle != this.EventBlocks[index].Title + this.EventBlocks[index].DSPTitle)
          {
            bool flag2 = false;
            if (this.EventBlocks[index].IsBypassable)
            {
              this.EventBlocks.RemoveAt(index + 1);
              this.EventBlockSelectorList.RemoveAt(index + 1);
              flag2 = true;
            }
            this.EventBlocks.RemoveAt(index);
            this.EventBlockSelectorList.RemoveAt(index);
            if (num == index)
              num = 0;
            else if (num > index)
            {
              --num;
              if (flag2)
                --num;
            }
            flag1 = true;
            break;
          }
        }
        if (!flag1)
        {
          if (num == this.EventBlocks.Count - 1)
          {
            --num;
            if (this.EventBlocks[this.EventBlocks.Count - 1].IsBypassable)
              --num;
          }
          if (this.EventBlocks[this.EventBlocks.Count - 1].IsBypassable)
          {
            this.EventBlocks.RemoveAt(this.EventBlocks.Count - 1);
            this.EventBlockSelectorList.RemoveAt(this.EventBlockSelectorList.Count - 1);
          }
          this.EventBlocks.RemoveAt(this.EventBlocks.Count - 1);
          this.EventBlockSelectorList.RemoveAt(this.EventBlockSelectorList.Count - 1);
          break;
        }
        break;
    }
    this.DefaultBlock = num;
    this.EventBlockSelector.ItemsSource = (IEnumerable) this.EventBlockSelectorList;
    this.EventBlockSelector.SelectionChanged -= new System.Windows.Controls.SelectionChangedEventHandler(this.BlockSelector_SelectionChanged);
    if (num == -1 && this.EventBlockSelectorList.Count != 0)
      num = 0;
    this.EventBlockSelector.SelectedIndex = num;
    this.EventBlockSelector.SelectionChanged += new System.Windows.Controls.SelectionChangedEventHandler(this.BlockSelector_SelectionChanged);
  }

  public int ActiveValuesCount()
  {
    int num = -1;
    if (this.EventBlockSelector.SelectedIndex != -1)
    {
      num = this.EventBlocks[this.EventBlockSelector.SelectedIndex].ValuesCount;
      if (this.EventBlockSelectorList[this.EventBlockSelector.SelectedIndex].IndexOf("EN") != -1)
        num = this.EventBlocks[this.EventBlockSelector.SelectedIndex].EnValuesCount;
    }
    return num;
  }

  private void AddEventBlockFromCell(SchemaBlock_DSPCell Cell)
  {
    this.EventBlockSelectorList.Add($"REG {Cell.Title} {Cell.DSPTitle}");
    if (!Cell.IsBypassable)
      return;
    this.EventBlockSelectorList.Add($"EN {Cell.Title} {Cell.DSPTitle}");
  }

  public event DSPBlockSelector.SelectionChangedEventHandler SelectionChanged;

  private void BlockSelector_SelectionChanged(object sender, SelectionChangedEventArgs e)
  {
    if (this.EventBlockSelector.SelectedIndex == -1)
      return;
    this.DefaultBlock = this.EventBlockSelector.SelectedIndex;
    DSPBlockSelector.SelectionChangedEventHandler selectionChanged = this.SelectionChanged;
    if (selectionChanged == null)
      return;
    selectionChanged(this.EventBlocks[this.EventBlockSelector.SelectedIndex].ValuesCount);
  }

  [DebuggerNonUserCode]
  [GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
  public void InitializeComponent()
  {
    if (this._contentLoaded)
      return;
    this._contentLoaded = true;
    Application.LoadComponent((object) this, new Uri("/ChipStudio;component/dspblockselector.xaml", UriKind.Relative));
  }

  [DebuggerNonUserCode]
  [GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
  [EditorBrowsable(EditorBrowsableState.Never)]
  void IComponentConnector.Connect(int connectionId, object target)
  {
    if (connectionId == 1)
    {
      this.EventBlockSelector = (ComboBox) target;
      this.EventBlockSelector.SelectionChanged += new System.Windows.Controls.SelectionChangedEventHandler(this.BlockSelector_SelectionChanged);
    }
    else
      this._contentLoaded = true;
  }

  public delegate void SelectionChangedEventHandler(int ValuesCount);
}
