﻿// Decompiled with JetBrains decompiler
// Type: ChipStudio.BoolToBrushConverter
// Assembly: ChipStudio, Version=1.2.9.0, Culture=neutral, PublicKeyToken=null
// MVID: 334E3BEA-37C7-4274-8118-535AAEFA1546
// Assembly location: D:\DocAndSec\Desktop\AUDIO\ChipDip\ChipStudio_soft_v1.2.9\ChipStudio_v1.2.9.exe

using System;
using System.Globalization;
using System.Windows;
using System.Windows.Data;
using System.Windows.Media;

#nullable disable
namespace ChipStudio;

public class BoolToBrushConverter : IValueConverter
{
  private static readonly Brush ELEMENT_SELECTION_COLOR = (Brush) Application.Current.FindResource((object) "ElementSelectionColor");
  private static readonly Brush CONNECTION_COLOR = (Brush) Application.Current.FindResource((object) "ConnectionColor");
  private static readonly Brush BLOCK_COLOR = (Brush) Application.Current.FindResource((object) "BlockColor");

  public object Convert(object value, Type targetType, object parameter, CultureInfo culture)
  {
    if (value == null)
      return (object) null;
    if ((bool) value)
      return (object) BoolToBrushConverter.ELEMENT_SELECTION_COLOR;
    return !(parameter as string == Shared.ElementTypeConnection) ? (object) BoolToBrushConverter.BLOCK_COLOR : (object) BoolToBrushConverter.CONNECTION_COLOR;
  }

  public object ConvertBack(object value, Type targetType, object parameter, CultureInfo culture)
  {
    throw new NotImplementedException();
  }
}
