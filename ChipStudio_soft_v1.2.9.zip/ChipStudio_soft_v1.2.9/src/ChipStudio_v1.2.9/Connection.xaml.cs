﻿// Decompiled with JetBrains decompiler
// Type: ChipStudio.Connection
// Assembly: ChipStudio, Version=1.2.9.0, Culture=neutral, PublicKeyToken=null
// MVID: 334E3BEA-37C7-4274-8118-535AAEFA1546
// Assembly location: D:\DocAndSec\Desktop\AUDIO\ChipDip\ChipStudio_soft_v1.2.9\ChipStudio_v1.2.9.exe

using System;
using System.CodeDom.Compiler;
using System.Collections.ObjectModel;
using System.Collections.Specialized;
using System.ComponentModel;
using System.Diagnostics;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Markup;

#nullable disable
namespace ChipStudio;

public partial class Connection : 
  UserControl,
  INotifyPropertyChanged,
  ISchemaElement,
  IComponentConnector
{
  private readonly ObservableCollection<ConnectionNode> nodes = new ObservableCollection<ConnectionNode>();
  private bool isselected;
  private bool _contentLoaded;

  public ObservableCollection<ConnectionNode> Nodes => this.nodes;

  public bool IsSelected
  {
    get => this.isselected;
    set
    {
      if (this.isselected == value)
        return;
      this.isselected = value;
      this.NotifyPropertyChanged(nameof (IsSelected));
    }
  }

  public string ElementType => Shared.ElementTypeConnection;

  public Connection()
  {
    this.InitializeComponent();
    this.DataContext = (object) this;
    this.Nodes.CollectionChanged += new NotifyCollectionChangedEventHandler(this.NotifyCollectionChanged_CollectionChanged);
  }

  public void AddNode(ConnectionNode NewNode) => this.nodes.Add(NewNode);

  public int GetAnchorNumberInBlock(string BlockTitle)
  {
    int anchorNumberInBlock = -1;
    foreach (ConnectionNode node in (Collection<ConnectionNode>) this.nodes)
    {
      if (node.BlockName == BlockTitle)
      {
        anchorNumberInBlock = node.AnchorNumber;
        break;
      }
    }
    return anchorNumberInBlock;
  }

  public void Update(ConnectionNode Node)
  {
    for (int index = 0; index < this.nodes.Count; ++index)
    {
      if (this.nodes[index].BlockName == Node.BlockName)
      {
        this.nodes.RemoveAt(index);
        this.nodes.Insert(index, Node);
        break;
      }
    }
  }

  public void RemoveNodeAt(int Index) => this.nodes.RemoveAt(Index);

  private void NotifyCollectionChanged_CollectionChanged(
    object sender,
    NotifyCollectionChangedEventArgs e)
  {
    PropertyChangedEventHandler propertyChanged = this.PropertyChanged;
    if (propertyChanged != null)
      propertyChanged((object) this, new PropertyChangedEventArgs("Nodes"));
    this.UpdateLayout();
  }

  public event PropertyChangedEventHandler PropertyChanged;

  public void NotifyPropertyChanged(string PropertyName)
  {
    PropertyChangedEventHandler propertyChanged = this.PropertyChanged;
    if (propertyChanged == null)
      return;
    propertyChanged((object) this, new PropertyChangedEventArgs(PropertyName));
  }

  [DebuggerNonUserCode]
  [GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
  public void InitializeComponent()
  {
    if (this._contentLoaded)
      return;
    this._contentLoaded = true;
    Application.LoadComponent((object) this, new Uri("/ChipStudio;component/connection.xaml", UriKind.Relative));
  }

  [DebuggerNonUserCode]
  [GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
  [EditorBrowsable(EditorBrowsableState.Never)]
  void IComponentConnector.Connect(int connectionId, object target) => this._contentLoaded = true;
}
