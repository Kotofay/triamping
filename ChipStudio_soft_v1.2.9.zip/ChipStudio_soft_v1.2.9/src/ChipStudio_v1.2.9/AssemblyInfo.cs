﻿using System.Reflection;
using System.Runtime.InteropServices;
using System.Windows;
using System.Windows.Resources;

[assembly: AssemblyTitle("ChipStudio")]
[assembly: AssemblyDescription("")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCompany("ChipDip")]
[assembly: AssemblyProduct("ChipStudio")]
[assembly: AssemblyCopyright("Copyright © 2020 - 2025 ChipDip")]
[assembly: AssemblyTrademark("")]
[assembly: ComVisible(false)]
[assembly: ThemeInfo(ResourceDictionaryLocation.None, ResourceDictionaryLocation.SourceAssembly)]
[assembly: AssemblyFileVersion("1.2.9")]
[assembly: AssemblyAssociatedContentFile("images/save_32x32.png")]
[assembly: AssemblyAssociatedContentFile("images/apply_32x32.png")]
[assembly: AssemblyAssociatedContentFile("images/warning_32x32.png")]
[assembly: AssemblyAssociatedContentFile("images/open_32x32.png")]
[assembly: AssemblyAssociatedContentFile("images/new_32x32.png")]
[assembly: AssemblyAssociatedContentFile("images/chipdip-logo.png")]
[assembly: AssemblyAssociatedContentFile("images/download_32x32.png")]
[assembly: AssemblyAssociatedContentFile("images/icon.ico")]
[assembly: AssemblyAssociatedContentFile("images/combomode_32x32.png")]
[assembly: AssemblyAssociatedContentFile("images/comboprojectdownload_32x32.png")]
[assembly: AssemblyVersion("1.2.9.0")]
