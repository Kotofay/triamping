﻿// Decompiled with JetBrains decompiler
// Type: ChipStudio.Selector
// Assembly: ChipStudio, Version=1.2.9.0, Culture=neutral, PublicKeyToken=null
// MVID: 334E3BEA-37C7-4274-8118-535AAEFA1546
// Assembly location: D:\DocAndSec\Desktop\AUDIO\ChipDip\ChipStudio_soft_v1.2.9\ChipStudio_v1.2.9.exe

using System;
using System.CodeDom.Compiler;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Diagnostics;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Markup;

#nullable disable
namespace ChipStudio;

public partial class Selector : UserControl, IComponentConnector
{
  private readonly List<string> Items = new List<string>();
  internal ComboBox ItemsList;
  private bool _contentLoaded;

  public string Title { get; set; }

  public int ListWidth { get; set; }

  public int SelectedIndex { get; set; }

  public string SelectedItem
  {
    get
    {
      return this.Items.Count == 0 || this.SelectedIndex == -1 ? (string) null : this.Items[this.SelectedIndex];
    }
  }

  public Selector()
  {
    this.InitializeComponent();
    this.DataContext = (object) this;
  }

  public void Update(string[] NewItems, Schema.UpdateOptions Option)
  {
    this.ItemsList.ItemsSource = (IEnumerable) null;
    switch (Option)
    {
      case Schema.UpdateOptions.Init:
        this.Items.AddRange((IEnumerable<string>) NewItems);
        break;
      case Schema.UpdateOptions.Add:
        this.Items.Add(NewItems[NewItems.Length - 1]);
        break;
      case Schema.UpdateOptions.Remove:
        int num = Array.IndexOf<string>(NewItems, this.Items[this.SelectedIndex]);
        this.SelectedIndex = num != -1 ? num : 0;
        this.Items.Clear();
        this.Items.AddRange((IEnumerable<string>) NewItems);
        break;
    }
    this.ItemsList.SelectionChanged -= new System.Windows.Controls.SelectionChangedEventHandler(this.ItemsList_SelectionChanged);
    if (this.SelectedIndex == -1 && this.Items.Count != 0)
      this.SelectedIndex = 0;
    this.ItemsList.ItemsSource = (IEnumerable) this.Items;
    this.ItemsList.SelectedIndex = this.SelectedIndex;
    this.ItemsList.SelectionChanged += new System.Windows.Controls.SelectionChangedEventHandler(this.ItemsList_SelectionChanged);
  }

  private void ItemsList_SelectionChanged(object sender, SelectionChangedEventArgs e)
  {
    if (this.ItemsList.SelectedIndex == -1)
      return;
    this.SelectedIndex = this.ItemsList.SelectedIndex;
  }

  [DebuggerNonUserCode]
  [GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
  public void InitializeComponent()
  {
    if (this._contentLoaded)
      return;
    this._contentLoaded = true;
    Application.LoadComponent((object) this, new Uri("/ChipStudio;component/selector.xaml", UriKind.Relative));
  }

  [DebuggerNonUserCode]
  [GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
  [EditorBrowsable(EditorBrowsableState.Never)]
  void IComponentConnector.Connect(int connectionId, object target)
  {
    if (connectionId == 1)
    {
      this.ItemsList = (ComboBox) target;
      this.ItemsList.SelectionChanged += new System.Windows.Controls.SelectionChangedEventHandler(this.ItemsList_SelectionChanged);
    }
    else
      this._contentLoaded = true;
  }
}
