﻿// Decompiled with JetBrains decompiler
// Type: ChipStudio.Pixel
// Assembly: ChipStudio, Version=1.2.9.0, Culture=neutral, PublicKeyToken=null
// MVID: 334E3BEA-37C7-4274-8118-535AAEFA1546
// Assembly location: D:\DocAndSec\Desktop\AUDIO\ChipDip\ChipStudio_soft_v1.2.9\ChipStudio_v1.2.9.exe

using System;
using System.CodeDom.Compiler;
using System.ComponentModel;
using System.Diagnostics;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Markup;
using System.Windows.Media;

#nullable disable
namespace ChipStudio;

public partial class Pixel : UserControl, INotifyPropertyChanged, IComponentConnector
{
  private string color = Brushes.Black.ToString();
  private string title;
  internal TextBlock PixelTitle;
  private bool _contentLoaded;

  public Pixel()
  {
    this.InitializeComponent();
    this.DataContext = (object) this;
  }

  public string Color
  {
    get => this.color;
    set
    {
      if (!(this.color != value))
        return;
      this.color = value;
      this.NotifyPropertyChanged(nameof (Color));
    }
  }

  public string Title
  {
    get => this.title;
    set
    {
      if (!(this.title != value))
        return;
      this.title = value;
      this.PixelTitle.Visibility = Visibility.Visible;
      this.PixelTitle.Text = this.title;
    }
  }

  public double Diameter { get; set; }

  public event PropertyChangedEventHandler PropertyChanged;

  public void NotifyPropertyChanged(string PropertyName)
  {
    PropertyChangedEventHandler propertyChanged = this.PropertyChanged;
    if (propertyChanged == null)
      return;
    propertyChanged((object) this, new PropertyChangedEventArgs(PropertyName));
  }

  private void Pixel_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
  {
    ColorPalette colorPalette = new ColorPalette(this.Color);
    bool? nullable = colorPalette.ShowDialog();
    bool flag = true;
    if (!(nullable.GetValueOrDefault() == flag & nullable.HasValue))
      return;
    this.Color = colorPalette.Color;
  }

  [DebuggerNonUserCode]
  [GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
  public void InitializeComponent()
  {
    if (this._contentLoaded)
      return;
    this._contentLoaded = true;
    Application.LoadComponent((object) this, new Uri("/ChipStudio;component/pixel.xaml", UriKind.Relative));
  }

  [DebuggerNonUserCode]
  [GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
  [EditorBrowsable(EditorBrowsableState.Never)]
  void IComponentConnector.Connect(int connectionId, object target)
  {
    if (connectionId != 1)
    {
      if (connectionId == 2)
        this.PixelTitle = (TextBlock) target;
      else
        this._contentLoaded = true;
    }
    else
      ((UIElement) target).MouseLeftButtonDown += new MouseButtonEventHandler(this.Pixel_MouseLeftButtonDown);
  }
}
