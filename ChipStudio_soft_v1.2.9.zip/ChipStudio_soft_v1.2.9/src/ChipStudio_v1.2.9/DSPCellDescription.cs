﻿// Decompiled with JetBrains decompiler
// Type: ChipStudio.DSPCellDescription
// Assembly: ChipStudio, Version=1.2.9.0, Culture=neutral, PublicKeyToken=null
// MVID: 334E3BEA-37C7-4274-8118-535AAEFA1546
// Assembly location: D:\DocAndSec\Desktop\AUDIO\ChipDip\ChipStudio_soft_v1.2.9\ChipStudio_v1.2.9.exe

using System;
using System.Collections.Generic;
using System.Linq;

#nullable disable
namespace ChipStudio;

public class DSPCellDescription
{
  private DSPCell Cell;
  private IDSPCellSpecific CellSpec;
  private List<byte> RegData = new List<byte>();
  private List<byte> EnData = new List<byte>();
  private int RegValuesCount;
  private int EnValuesCount;
  private int BytesPerValue;

  public ushort ValueSize => (ushort) this.CellSpec.OneValueSize(this.Cell);

  public bool AreParamsUpdated { get; set; }

  public bool AreParamsModifiable { get; set; }

  public ushort ParamsCount => (ushort) this.Cell.ParamsUsed.Count;

  public DSPCell.WriteTypes WriteType => this.Cell.WriteType;

  public bool IsBypassable => this.Cell.IsBypassable;

  public void Initialize(DSPCell InCell)
  {
    this.Cell = InCell;
    this.Cell.BytesPerValue = this.Cell.ValueSize;
    this.BytesPerValue = this.Cell.BytesPerValue;
    this.CellSpec = DSPCellSelector.Cell(InCell);
    this.RegValuesCount = this.ValuesCountAfterParse(this.RegData.Count);
    this.EnValuesCount = this.ValuesCountAfterParse(this.EnData.Count);
    if (!this.Cell.AreParamsFixed && this.RegValuesCount == 0 && this.EnValuesCount == 0)
      return;
    this.AreParamsUpdated = true;
  }

  public List<byte> GetRegulatorData() => this.RegData;

  public List<byte> GetEnableData() => this.EnData;

  public void SetRegulatorData(byte[] NewData)
  {
    this.RegData = NewData != null ? new List<byte>((IEnumerable<byte>) NewData) : new List<byte>();
  }

  public void SetEnableData(byte[] NewData)
  {
    this.EnData = NewData != null ? new List<byte>((IEnumerable<byte>) NewData) : new List<byte>();
  }

  public void ParameterAddressAndSize(int ParamIndex, out int address, out ushort size)
  {
    address = (int) this.Cell.ParamsUsed[ParamIndex].Address;
    size = this.Cell.ParamsUsed[ParamIndex].Size;
  }

  public void SetParamsModifiabilityForReg()
  {
    if (this.Cell.AreParamsFixed)
      return;
    this.AreParamsModifiable = this.EnValuesCount == 0;
  }

  public void SetParamsModifiabilityForEn()
  {
    if (this.Cell.AreParamsFixed)
      return;
    this.AreParamsModifiable = this.RegValuesCount == 0;
  }

  public ushort[] ParamsAddresses()
  {
    return this.Cell.ParamsUsed.Select<DSPCellParameter, ushort>((Func<DSPCellParameter, ushort>) (p => p.Address)).ToArray<ushort>();
  }

  public bool TryParseData(string FileName, out byte[] Result)
  {
    Result = (byte[]) null;
    if (!this.Cell.AreParamsFixed && !this.AreParamsUpdated)
    {
      this.AreParamsUpdated = (this.CellSpec is IDSPCellModifiable cellSpec ? new bool?(cellSpec.TryUpdateCellParams(FileName, this.Cell)) : new bool?()).Value;
      if (!this.AreParamsUpdated)
        return false;
    }
    return this.CellSpec.TryParseData(FileName, out Result, this.Cell);
  }

  public void ResetParams()
  {
    if (!this.AreParamsModifiable)
      return;
    this.AreParamsUpdated = false;
    this.Cell.ParamsUsed.Clear();
  }

  public int UpdateRegData()
  {
    this.UpdateData(this.RegData.Count, ref this.RegValuesCount);
    return this.RegValuesCount;
  }

  public int UpdateEnData()
  {
    this.UpdateData(this.EnData.Count, ref this.EnValuesCount);
    return this.EnValuesCount;
  }

  public void UpdateParamsAddresses(DSPCell cell)
  {
    foreach (DSPCellParameter dspCellParameter1 in cell.ParamsFromFile)
    {
      foreach (DSPCellParameter dspCellParameter2 in this.Cell.ParamsFromFile)
      {
        if (dspCellParameter2.Name == dspCellParameter1.Name)
        {
          dspCellParameter2.Address = dspCellParameter1.Address;
          break;
        }
      }
      foreach (DSPCellParameter dspCellParameter3 in this.Cell.ParamsUsed)
      {
        if (dspCellParameter3.Name == dspCellParameter1.Name)
        {
          dspCellParameter3.Address = dspCellParameter1.Address;
          break;
        }
      }
    }
  }

  private void UpdateData(int DataLength, ref int ValuesCount)
  {
    this.Cell.BytesPerValue = this.Cell.ValueSize;
    this.BytesPerValue = this.Cell.BytesPerValue;
    ValuesCount = this.ValuesCountAfterParse(DataLength);
    if (this.RegValuesCount != 0 || this.EnValuesCount != 0 || this.Cell.AreParamsFixed)
      return;
    this.AreParamsUpdated = false;
  }

  private int ValuesCountAfterParse(int DataSize)
  {
    int num = this.CellSpec.OneValueSize(this.Cell);
    return num <= 0 ? 0 : DataSize / num;
  }
}
