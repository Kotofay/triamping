﻿// Decompiled with JetBrains decompiler
// Type: ChipStudio.DownloadStream
// Assembly: ChipStudio, Version=1.2.9.0, Culture=neutral, PublicKeyToken=null
// MVID: 334E3BEA-37C7-4274-8118-535AAEFA1546
// Assembly location: D:\DocAndSec\Desktop\AUDIO\ChipDip\ChipStudio_soft_v1.2.9\ChipStudio_v1.2.9.exe

using System.Collections.Generic;

#nullable disable
namespace ChipStudio;

public class DownloadStream
{
  private List<byte> DownloadData;
  private int MemoryPageSize;
  private byte PartFullSize;
  private byte LastPartSize;
  private int LastPacketPartIndex;
  private int PacketPartNumber;
  private int address;
  private DownloadStream.PacketParts packetpart;
  private byte size;
  private byte[] data;

  public int Address => this.address;

  public byte Size => this.size;

  public DownloadStream.PacketParts PacketPart => this.packetpart;

  public byte[] Data => this.data;

  public bool IsDataAvailable()
  {
    this.address += (int) this.size;
    if (this.address == this.DownloadData.Count)
      return false;
    ++this.PacketPartNumber;
    if (this.PacketPartNumber == 0)
    {
      this.size = this.PartFullSize;
      this.packetpart = DownloadStream.PacketParts.Start;
    }
    else if (this.PacketPartNumber < this.LastPacketPartIndex)
    {
      this.size = this.PartFullSize;
      this.packetpart = DownloadStream.PacketParts.Next;
    }
    else if (this.PacketPartNumber == this.LastPacketPartIndex)
    {
      this.size = this.LastPartSize;
      this.packetpart = DownloadStream.PacketParts.End;
      this.PacketPartNumber = -1;
    }
    if (this.address + (int) this.size > this.DownloadData.Count)
    {
      this.size = (byte) (this.DownloadData.Count - this.address);
      this.packetpart = this.packetpart != DownloadStream.PacketParts.Start ? DownloadStream.PacketParts.End : DownloadStream.PacketParts.StartEnd;
    }
    this.data = new byte[(int) this.size];
    this.DownloadData.CopyTo(this.address, this.data, 0, (int) this.size);
    return true;
  }

  public void New(List<byte> datalist, int PageSize, byte DataBytesInPacket)
  {
    this.MemoryPageSize = PageSize;
    this.DownloadData = datalist;
    if (this.DownloadData.Count > (int) DataBytesInPacket)
    {
      int num = this.MemoryPageSize / (int) DataBytesInPacket;
      if (this.MemoryPageSize % (int) DataBytesInPacket != 0)
        ++num;
      this.PartFullSize = DataBytesInPacket;
      this.LastPartSize = (byte) (PageSize - (int) this.PartFullSize * (num - 1));
      this.LastPacketPartIndex = num - 1;
      this.packetpart = DownloadStream.PacketParts.Start;
    }
    else
    {
      this.PartFullSize = (byte) this.DownloadData.Count;
      this.LastPartSize = (byte) 0;
      this.LastPacketPartIndex = 0;
      this.packetpart = DownloadStream.PacketParts.StartEnd;
    }
    this.address = 0;
    this.PacketPartNumber = 0;
    this.size = this.PartFullSize;
    this.data = new byte[(int) this.size];
    this.DownloadData.CopyTo(this.address, this.data, 0, (int) this.size);
  }

  public enum PacketParts : byte
  {
    Start,
    Next,
    End,
    StartEnd,
  }
}
