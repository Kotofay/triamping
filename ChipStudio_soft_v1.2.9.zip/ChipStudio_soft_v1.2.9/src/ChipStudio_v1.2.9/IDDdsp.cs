﻿// Decompiled with JetBrains decompiler
// Type: ChipStudio.IDDdsp
// Assembly: ChipStudio, Version=1.2.9.0, Culture=neutral, PublicKeyToken=null
// MVID: 334E3BEA-37C7-4274-8118-535AAEFA1546
// Assembly location: D:\DocAndSec\Desktop\AUDIO\ChipDip\ChipStudio_soft_v1.2.9\ChipStudio_v1.2.9.exe

#nullable disable
namespace ChipStudio;

public interface IDDdsp
{
  bool IsLoaded { get; }

  byte ID { get; }

  string Interface { get; }

  bool IsSelfBootable { get; }

  string FileFormat { get; }

  bool AreCellsConstant { get; }

  DSPCell[] Cells { get; }

  void BusAddressInfo(out uint BusAdr, out string[] AdrLineStates, out uint[] AdrValues);
}
