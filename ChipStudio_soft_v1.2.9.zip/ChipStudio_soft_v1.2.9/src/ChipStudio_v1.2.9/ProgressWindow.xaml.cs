﻿// Decompiled with JetBrains decompiler
// Type: ChipStudio.ProgressWindow
// Assembly: ChipStudio, Version=1.2.9.0, Culture=neutral, PublicKeyToken=null
// MVID: 334E3BEA-37C7-4274-8118-535AAEFA1546
// Assembly location: D:\DocAndSec\Desktop\AUDIO\ChipDip\ChipStudio_soft_v1.2.9\ChipStudio_v1.2.9.exe

using System;
using System.CodeDom.Compiler;
using System.ComponentModel;
using System.Diagnostics;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Markup;

#nullable disable
namespace ChipStudio;

public partial class ProgressWindow : Window, INotifyPropertyChanged, IComponentConnector
{
  private double progress;
  private string description = string.Empty;
  internal ProgressBar ProcessStatus;
  private bool _contentLoaded;

  public double Minimum { get; set; }

  public double Maximum { get; set; }

  public double Progress
  {
    get => this.progress;
    set
    {
      if (this.progress == value)
        return;
      this.progress = value;
      this.NotifyPropertyChanged(nameof (Progress));
    }
  }

  public string Description
  {
    get => this.description;
    set
    {
      if (!(this.description != value))
        return;
      this.description = value;
      this.NotifyPropertyChanged(nameof (Description));
    }
  }

  public ProgressWindow()
  {
    this.InitializeComponent();
    this.DataContext = (object) this;
  }

  public event PropertyChangedEventHandler PropertyChanged;

  public void NotifyPropertyChanged(string PropertyName)
  {
    PropertyChangedEventHandler propertyChanged = this.PropertyChanged;
    if (propertyChanged == null)
      return;
    propertyChanged((object) this, new PropertyChangedEventArgs(PropertyName));
  }

  [DebuggerNonUserCode]
  [GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
  public void InitializeComponent()
  {
    if (this._contentLoaded)
      return;
    this._contentLoaded = true;
    Application.LoadComponent((object) this, new Uri("/ChipStudio;component/progresswindow.xaml", UriKind.Relative));
  }

  [DebuggerNonUserCode]
  [GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
  [EditorBrowsable(EditorBrowsableState.Never)]
  void IComponentConnector.Connect(int connectionId, object target)
  {
    if (connectionId == 1)
      this.ProcessStatus = (ProgressBar) target;
    else
      this._contentLoaded = true;
  }
}
