﻿// Decompiled with JetBrains decompiler
// Type: ChipStudio.DSPBootParser_PPPC3
// Assembly: ChipStudio, Version=1.2.9.0, Culture=neutral, PublicKeyToken=null
// MVID: 334E3BEA-37C7-4274-8118-535AAEFA1546
// Assembly location: D:\DocAndSec\Desktop\AUDIO\ChipDip\ChipStudio_soft_v1.2.9\ChipStudio_v1.2.9.exe

using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;

#nullable disable
namespace ChipStudio;

public class DSPBootParser_PPPC3 : IDSPBootParser
{
  private const string PPPC3DataStart = "cfg_reg registers[]";
  private const string CommentSign = "//";
  private const string PPPC3DataEnd = "};";
  private const string TAS3251_DATA_OPEN_SIGN = "{";
  private const string TAS3251_DATA_CLOSE_SIGN = "}";
  private const int PPPC3_ADR_INDEX = 0;
  private const int PPPC3_DATA_INDEX = 1;
  private const int PPPC3_CMD_DATA_SIZE = 1;

  public bool TryParse(string ProjectFile, out List<DataTransfer> BootSequence)
  {
    BootSequence = new List<DataTransfer>();
    if (!File.Exists(ProjectFile))
      return false;
    foreach (string input in ((IEnumerable<string>) File.ReadAllLines(ProjectFile)).SkipWhile<string>((Func<string, bool>) (s => s.IndexOf("cfg_reg registers[]") == -1)).Where<string>((Func<string, bool>) (s => s.Length != 0 && s.IndexOf("cfg_reg registers[]") == -1 && !s.StartsWith("//") && !s.StartsWith("};"))).ToArray<string>())
    {
      byte[] Data;
      if (!DSPBootParser_PPPC3.TryParsePPPC3Line(input, out Data))
        return false;
      DataTransfer dataTransfer = new DataTransfer((ushort) Data[0], 1, (byte) 0, DataTransfer.TransferTypes.Write);
      dataTransfer.Data[0] = Data[1];
      BootSequence.Add(dataTransfer);
    }
    Shared.ConcatByAddress(BootSequence);
    return true;
  }

  private static bool TryParsePPPC3Line(string input, out byte[] Data)
  {
    Data = (byte[]) null;
    string[] array = ((IEnumerable<string>) input.Replace(" ", "").Replace("{", "").Replace("}", "").Replace("0x", "").Split(","[0])).Where<string>((Func<string, bool>) (sd => sd.Length != 0)).ToArray<string>();
    return array.Length >= 2 && Shared.TryParseHEXMany(array, out Data);
  }
}
