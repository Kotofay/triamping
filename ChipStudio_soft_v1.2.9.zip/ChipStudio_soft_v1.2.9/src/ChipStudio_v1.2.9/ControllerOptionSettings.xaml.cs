﻿// Decompiled with JetBrains decompiler
// Type: ChipStudio.ControllerOptionSettings
// Assembly: ChipStudio, Version=1.2.9.0, Culture=neutral, PublicKeyToken=null
// MVID: 334E3BEA-37C7-4274-8118-535AAEFA1546
// Assembly location: D:\DocAndSec\Desktop\AUDIO\ChipDip\ChipStudio_soft_v1.2.9\ChipStudio_v1.2.9.exe

using System;
using System.CodeDom.Compiler;
using System.ComponentModel;
using System.Diagnostics;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Controls.Primitives;
using System.Windows.Markup;

#nullable disable
namespace ChipStudio;

public partial class ControllerOptionSettings : Window, IComponentConnector
{
  internal CheckBox OptGenSel;
  internal CheckBox OptFreq;
  internal CheckBox OptRes;
  internal CheckBox OptPwrKey;
  internal CheckBox OptFixProj;
  internal CheckBox OptUSBStdWake;
  private bool _contentLoaded;

  public ControllerOptions Settings { get; } = new ControllerOptions();

  public ControllerOptionSettings(ControllerOptions InitSettings, uint OptionsMask)
  {
    this.InitializeComponent();
    if (((int) OptionsMask & 1) != 0)
    {
      this.OptGenSel.IsEnabled = true;
      this.OptGenSel.IsChecked = new bool?(InitSettings.IsGenSelectionEnabled);
    }
    else
      this.OptGenSel.IsEnabled = false;
    if (((int) OptionsMask & 2) != 0)
    {
      this.OptFreq.IsEnabled = true;
      this.OptFreq.IsChecked = new bool?(InitSettings.IsFreqIndicationEnabled);
    }
    else
      this.OptFreq.IsEnabled = false;
    if (((int) OptionsMask & 4) != 0)
    {
      this.OptRes.IsEnabled = true;
      this.OptRes.IsChecked = new bool?(InitSettings.IsResIndicationEnabled);
    }
    else
      this.OptRes.IsEnabled = false;
    if (((int) OptionsMask & 8) != 0)
    {
      this.OptPwrKey.IsEnabled = true;
      this.OptPwrKey.IsChecked = new bool?(InitSettings.IsPwrKeyEnabled);
    }
    else
      this.OptPwrKey.IsEnabled = false;
    if (((int) OptionsMask & 16 /*0x10*/) != 0)
    {
      this.OptUSBStdWake.IsEnabled = true;
      this.OptUSBStdWake.IsChecked = new bool?(InitSettings.IsUSBStdByWakeEnabled);
    }
    else
      this.OptUSBStdWake.IsEnabled = false;
    if (((int) OptionsMask & 32 /*0x20*/) != 0)
    {
      this.OptFixProj.IsEnabled = true;
      this.OptFixProj.IsChecked = new bool?(InitSettings.IsFixProjectEnabled);
    }
    else
      this.OptFixProj.IsEnabled = false;
  }

  private void OKButton_Click(object sender, RoutedEventArgs e)
  {
    this.DialogResult = new bool?(true);
    this.Settings.IsGenSelectionEnabled = this.OptGenSel.IsChecked.Value;
    this.Settings.IsFreqIndicationEnabled = this.OptFreq.IsChecked.Value;
    this.Settings.IsResIndicationEnabled = this.OptRes.IsChecked.Value;
    this.Settings.IsPwrKeyEnabled = this.OptPwrKey.IsChecked.Value;
    this.Settings.IsUSBStdByWakeEnabled = this.OptUSBStdWake.IsChecked.Value;
    this.Settings.IsFixProjectEnabled = this.OptFixProj.IsChecked.Value;
  }

  private void CancelButton_Click(object sender, RoutedEventArgs e)
  {
    this.DialogResult = new bool?(false);
  }

  [DebuggerNonUserCode]
  [GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
  public void InitializeComponent()
  {
    if (this._contentLoaded)
      return;
    this._contentLoaded = true;
    Application.LoadComponent((object) this, new Uri("/ChipStudio;component/controlleroptionsettings.xaml", UriKind.Relative));
  }

  [DebuggerNonUserCode]
  [GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
  [EditorBrowsable(EditorBrowsableState.Never)]
  void IComponentConnector.Connect(int connectionId, object target)
  {
    switch (connectionId)
    {
      case 1:
        this.OptGenSel = (CheckBox) target;
        break;
      case 2:
        this.OptFreq = (CheckBox) target;
        break;
      case 3:
        this.OptRes = (CheckBox) target;
        break;
      case 4:
        this.OptPwrKey = (CheckBox) target;
        break;
      case 5:
        this.OptFixProj = (CheckBox) target;
        break;
      case 6:
        this.OptUSBStdWake = (CheckBox) target;
        break;
      case 7:
        ((ButtonBase) target).Click += new RoutedEventHandler(this.OKButton_Click);
        break;
      case 8:
        ((ButtonBase) target).Click += new RoutedEventHandler(this.CancelButton_Click);
        break;
      default:
        this._contentLoaded = true;
        break;
    }
  }
}
