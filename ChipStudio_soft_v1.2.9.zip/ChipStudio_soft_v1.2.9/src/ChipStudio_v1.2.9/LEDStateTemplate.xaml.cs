﻿// Decompiled with JetBrains decompiler
// Type: ChipStudio.LEDStateTemplate
// Assembly: ChipStudio, Version=1.2.9.0, Culture=neutral, PublicKeyToken=null
// MVID: 334E3BEA-37C7-4274-8118-535AAEFA1546
// Assembly location: D:\DocAndSec\Desktop\AUDIO\ChipDip\ChipStudio_soft_v1.2.9\ChipStudio_v1.2.9.exe

using System;
using System.CodeDom.Compiler;
using System.ComponentModel;
using System.Diagnostics;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Markup;

#nullable disable
namespace ChipStudio;

public partial class LEDStateTemplate : UserControl, IComponentConnector
{
  internal ComboBox StatesComboBox;
  private bool _contentLoaded;

  public string[] LEDStatesStrings { get; } = new string[8]
  {
    "OFF",
    "ON",
    "0,25 Hz",
    "0,5 Hz",
    "1 Hz",
    "2 Hz",
    "4 Hz",
    "8 Hz"
  };

  public int Number { get; set; }

  public int ActiveState { get; set; }

  public LEDStateTemplate()
  {
    this.InitializeComponent();
    this.DataContext = (object) this;
  }

  [DebuggerNonUserCode]
  [GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
  public void InitializeComponent()
  {
    if (this._contentLoaded)
      return;
    this._contentLoaded = true;
    Application.LoadComponent((object) this, new Uri("/ChipStudio;component/ledstatetemplate.xaml", UriKind.Relative));
  }

  [DebuggerNonUserCode]
  [GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
  [EditorBrowsable(EditorBrowsableState.Never)]
  void IComponentConnector.Connect(int connectionId, object target)
  {
    if (connectionId == 1)
      this.StatesComboBox = (ComboBox) target;
    else
      this._contentLoaded = true;
  }
}
