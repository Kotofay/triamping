﻿// Decompiled with JetBrains decompiler
// Type: ChipStudio.DSPParserSelector
// Assembly: ChipStudio, Version=1.2.9.0, Culture=neutral, PublicKeyToken=null
// MVID: 334E3BEA-37C7-4274-8118-535AAEFA1546
// Assembly location: D:\DocAndSec\Desktop\AUDIO\ChipDip\ChipStudio_soft_v1.2.9\ChipStudio_v1.2.9.exe

#nullable disable
namespace ChipStudio;

public class DSPParserSelector
{
  private const byte ADAU1701_I2C_ID = 1;
  private const byte ADAU1761_I2C_ID = 2;
  private const byte TAS3251_I2C_ID = 3;
  private const byte AD19xx_SPI_ID = 4;
  private const byte SSM3582_I2C_ID = 5;
  private const byte PCM5x4x_I2C_ID = 6;
  private const byte ADAU1452_SPI_ID = 7;
  private const byte ADAU1467_SPI_ID = 8;
  private const byte ES9038Q2M_ID = 9;
  private const byte PCM5122_I2C_ID = 10;

  public static IDSPBootParser BootParser(byte DspId)
  {
    switch (DspId)
    {
      case 1:
      case 7:
      case 8:
        return (IDSPBootParser) new DSPBootParser_SigmaStudioDSP();
      case 2:
        return (IDSPBootParser) new DSPBootParser_ADAU1761();
      case 3:
        return (IDSPBootParser) new DSPBootParser_PPPC3();
      case 4:
        return (IDSPBootParser) new DSPBootParser_AD19xx();
      case 5:
        return (IDSPBootParser) new DSPBootParser_SSM3582();
      case 6:
        return (IDSPBootParser) new DSPBootParser_PurePathStudio();
      default:
        return (IDSPBootParser) new DSPBootParser_Generic();
    }
  }

  public static IDSPCellParser CellParser(byte DspId)
  {
    switch (DspId)
    {
      case 1:
      case 2:
      case 7:
      case 8:
        return (IDSPCellParser) new DSPCellParser_SigmaStudio();
      case 6:
        return (IDSPCellParser) new DSPCellParser_PurePathStudio();
      default:
        return (IDSPCellParser) null;
    }
  }
}
