﻿// Decompiled with JetBrains decompiler
// Type: ChipStudio.ControllerDriver
// Assembly: ChipStudio, Version=1.2.9.0, Culture=neutral, PublicKeyToken=null
// MVID: 334E3BEA-37C7-4274-8118-535AAEFA1546
// Assembly location: D:\DocAndSec\Desktop\AUDIO\ChipDip\ChipStudio_soft_v1.2.9\ChipStudio_v1.2.9.exe

using System;
using System.Collections.Generic;
using System.Linq;
using System.Management;
using System.Windows;
using System.Windows.Threading;

#nullable disable
namespace ChipStudio;

internal class ControllerDriver
{
  private const int USB_PACKET_SIZE = 64 /*0x40*/;
  private const byte USB_CMD_POS = 1;
  private const byte USB_REPORT_ID_INDEX = 0;
  private const byte USB_REPORT_CMD = 1;
  private const byte USB_REPORT_DATA = 2;
  private const byte USB_CMD_INDEX = 1;
  private const byte USB_SUBCMD_INDEX = 2;
  private const byte USB_CMD_DATA_INDEX = 3;
  private const byte USB_CMD_GET_STATUS = 0;
  private const byte USB_CMD_MEMORY_WRITE = 1;
  private const byte USB_CMD_BOOT_CONFIG = 2;
  private const byte USB_CMD_MEMORY_ERASE = 3;
  private const byte USB_CMD_GET_ID = 4;
  private const byte USB_CMD_USBSET_WRITE = 5;
  private const byte USB_DATA_SIZE_INDEX = 1;
  private const byte USB_DATA_START_INDEX = 3;
  private const byte USB_DATA_ADDRESS_OFFSET = 3;
  private const byte USB_DATA_ADDRESS_SIZE = 4;
  private const byte USB_DATA_SIZE_OFFSET = 7;
  private const byte USB_DATA_SIZE_SIZE = 1;
  private const byte USB_DATA_DATA_OFFSET = 8;
  private const byte USB_DATA_CONTROLLER_ID_INDEX = 3;
  private const byte USB_DATA_FIRMWARE_INDEX = 4;
  private const byte USB_DATA_FIRMWARE_SIZE = 4;
  private const byte USB_DATA_MEMORY_SIZE_INDEX = 8;
  private const byte USB_DATA_HARDWARE_INDEX = 10;
  private const byte USB_DATA_MEMORY_DETECT_INDEX = 11;
  private const byte USB_DATA_PACKET_SIZE_INDEX = 12;
  private const byte USB_DATA_PACKET_SIZE_SIZE = 2;
  private const byte USB_DATA_DOWNLOAD_API_INDEX = 14;
  private const byte USB_DATA_NAME_SIZE_INDEX = 15;
  private const byte USB_DATA_NAME_INDEX = 16 /*0x10*/;
  private const byte M_BITS_UINTS = 0;
  private const byte K_BITS_UINTS = 1;
  private const byte USB_DATA_STATUS_INDEX = 3;
  private const byte USB_DATA_STATUS_SIZE = 2;
  private const byte USB_DATA_BYTES_WRITTEN_INDEX = 5;
  private const byte USB_DATA_BYTES_WRITTEN_SIZE = 4;
  private const byte MEMORY_CHIP_DETECTED = 1;
  private const byte USB_PORT_BUSY_TO_RECEIVE = 128 /*0x80*/;
  private const int USB_PORT_FW_WRITE_CMPLT = 512 /*0x0200*/;
  private static readonly byte MaxDataSizeInUSBPacket = 56;
  private const byte USBTransferInterval = 1;
  internal const int WriteProject = 0;
  internal const int WriteUSBSettings = 1;
  private static readonly string ControllerVidPid = "VID_0483&PID_A210";
  private static readonly string ErasingProcess = "Erasing memory...";
  private static readonly string DownloadingProcess = "Downloading...";
  private static readonly DispatcherTimer DownloadTimer = new DispatcherTimer();
  private static byte[] BootData;
  private static readonly DownloadStream Transfer = new DownloadStream();
  private static Action<double> DownloadProgress;
  private static Action<string> DownloadDescription;
  private static Action<bool> DownloadFinished;
  private static bool MemoryErase = false;
  private static byte WriteCmd = 1;
  private static int DownloadPtr;
  private static int DataPacketSize = 64 /*0x40*/;
  private static int DataSizeMAX;

  public static void SetDownLoadActions(
    Action<double> progress,
    Action<bool> finish,
    Action<string> description)
  {
    ControllerDriver.DownloadProgress = progress;
    ControllerDriver.DownloadFinished = finish;
    ControllerDriver.DownloadDescription = description;
    ControllerDriver.DownloadTimer.Interval = TimeSpan.FromMilliseconds(1.0);
  }

  public static ControllerInfo GetDeviceInfo()
  {
    byte[] numArray = new byte[64 /*0x40*/];
    numArray[0] = (byte) 1;
    numArray[1] = (byte) 4;
    USB_device.Write(numArray);
    USB_device.Read(numArray);
    ControllerInfo deviceInfo = new ControllerInfo();
    deviceInfo.ID = (int) numArray[3];
    deviceInfo.Name = "";
    if (numArray[15] <= (byte) 32 /*0x20*/)
    {
      for (int index = 0; index < (int) numArray[15]; ++index)
        deviceInfo.Name += ((char) numArray[16 /*0x10*/ + index]).ToString();
    }
    deviceInfo.FirmwareVersion = $"{numArray[4].ToString()}.{numArray[5].ToString()}.{((int) numArray[6] << 8 | (int) numArray[7]).ToString()}";
    deviceInfo.DownLoadAPIVersion = ControllerDriver.IsDownLoadAPICorrect((int) numArray[14]) ? (int) numArray[14] : -1;
    deviceInfo.USBPacketSize = ControllerDriver.JoinBytesIntoValue(numArray, 12, 2);
    deviceInfo.USBPacketSize = ControllerDriver.IsPackSizeCorrect(deviceInfo.USBPacketSize) ? deviceInfo.USBPacketSize : -1;
    return deviceInfo;
  }

  public static bool DownloadStart(
    List<byte> image,
    int PacketMaxSize,
    int WriteType,
    int APIVersion)
  {
    if (!ControllerDriver.IsDownLoadAPICorrect(APIVersion))
    {
      int num = (int) MessageBox.Show("Wrong controller download API version", "", MessageBoxButton.OK, MessageBoxImage.Hand);
      return false;
    }
    if (!ControllerDriver.IsPackSizeCorrect(PacketMaxSize))
    {
      int num = (int) MessageBox.Show("Wrong controller packet size", "", MessageBoxButton.OK, MessageBoxImage.Hand);
      return false;
    }
    ControllerDriver.BootData = image.ToArray();
    switch (WriteType)
    {
      case 0:
        ControllerDriver.WriteCmd = (byte) 1;
        break;
      case 1:
        ControllerDriver.WriteCmd = (byte) 5;
        break;
    }
    byte[] Buffer = new byte[64 /*0x40*/];
    if (APIVersion == 1)
    {
      ControllerDriver.Transfer.New(image, PacketMaxSize, ControllerDriver.MaxDataSizeInUSBPacket);
      ControllerDriver.DownloadTimer.Tick += new EventHandler(ControllerDriver.DownloadTimer_Tick_v1);
    }
    else
    {
      ControllerDriver.DataPacketSize = PacketMaxSize;
      ControllerDriver.DataSizeMAX = ControllerDriver.DataPacketSize - 3;
      Buffer[0] = (byte) 1;
      Buffer[1] = ControllerDriver.WriteCmd;
      for (int index = 0; index < 4; ++index)
        Buffer[3 + index] = (byte) (image.Count >> index * 8);
      USB_device.Write(Buffer);
      USB_device.Read(Buffer);
      ControllerDriver.DownloadTimer.Tick += new EventHandler(ControllerDriver.DownloadTimer_Tick_v2);
    }
    Buffer[0] = (byte) 1;
    Buffer[1] = (byte) 3;
    USB_device.Write(Buffer);
    ControllerDriver.DownloadPtr = 0;
    ControllerDriver.MemoryErase = true;
    Action<string> downloadDescription = ControllerDriver.DownloadDescription;
    if (downloadDescription != null)
      downloadDescription(ControllerDriver.ErasingProcess);
    ControllerDriver.DownloadTimer.Start();
    return true;
  }

  public static bool IsDeviceConnected()
  {
    using (ManagementObjectSearcher managementObjectSearcher = new ManagementObjectSearcher("Select * From Win32_PnPEntity"))
    {
      try
      {
        ManagementObjectCollection objectCollection = managementObjectSearcher.Get();
        foreach (ManagementBaseObject managementBaseObject in objectCollection)
        {
          if (((string) managementBaseObject.GetPropertyValue("DeviceID")).IndexOf(ControllerDriver.ControllerVidPid) != -1)
            return true;
        }
        objectCollection.Dispose();
      }
      catch (ObjectDisposedException ex)
      {
        Console.WriteLine("Caught: {0}", (object) ex.Message);
      }
    }
    return false;
  }

  public static void OpenDevice() => USB_device.Open();

  public static void CloseDevice() => USB_device.Close();

  private static void DownloadTimer_Tick_v1(object sender, EventArgs e)
  {
    bool flag = true;
    byte[] Buffer = new byte[64 /*0x40*/];
    if (ControllerDriver.Transfer.PacketPart == DownloadStream.PacketParts.End || ControllerDriver.MemoryErase)
    {
      Buffer[0] = (byte) 1;
      Buffer[1] = (byte) 0;
      USB_device.Write(Buffer);
      USB_device.Read(Buffer);
      if (((int) Buffer[3] & 128 /*0x80*/) == 128 /*0x80*/)
        flag = false;
      if (ControllerDriver.MemoryErase & flag)
      {
        Action<string> downloadDescription = ControllerDriver.DownloadDescription;
        if (downloadDescription != null)
          downloadDescription(ControllerDriver.DownloadingProcess);
        Buffer = ControllerDriver.PrepareUSBPacket();
        USB_device.Write(Buffer);
        ControllerDriver.MemoryErase = false;
        flag = false;
      }
    }
    if (!flag)
      return;
    Action<double> downloadProgress = ControllerDriver.DownloadProgress;
    if (downloadProgress != null)
      downloadProgress((double) (100 * (ControllerDriver.Transfer.Address + (int) ControllerDriver.Transfer.Size) / ControllerDriver.BootData.Length));
    if (ControllerDriver.Transfer.IsDataAvailable())
    {
      USB_device.Write(ControllerDriver.PrepareUSBPacket());
    }
    else
    {
      Buffer[0] = (byte) 1;
      Buffer[1] = (byte) 2;
      USB_device.Write(Buffer);
      ControllerDriver.DownloadTimer.Stop();
      ControllerDriver.DownloadTimer.Tick -= new EventHandler(ControllerDriver.DownloadTimer_Tick_v1);
      Action<bool> downloadFinished = ControllerDriver.DownloadFinished;
      if (downloadFinished == null)
        return;
      downloadFinished(true);
    }
  }

  private static byte[] PrepareUSBPacket()
  {
    byte[] numArray = new byte[64 /*0x40*/];
    numArray[0] = (byte) 1;
    numArray[1] = ControllerDriver.WriteCmd;
    numArray[2] = (byte) ControllerDriver.Transfer.PacketPart;
    for (int index = 0; index < 4; ++index)
      numArray[3 + index] = (byte) (ControllerDriver.Transfer.Address >> index * 8);
    numArray[7] = ControllerDriver.Transfer.Size;
    for (int index = 0; index < (int) ControllerDriver.Transfer.Size; ++index)
      numArray[8 + index] = ControllerDriver.Transfer.Data[index];
    return numArray;
  }

  private static void DownloadTimer_Tick_v2(object sender, EventArgs e)
  {
    bool flag1 = true;
    bool flag2 = false;
    byte[] numArray1 = new byte[64 /*0x40*/];
    numArray1[0] = (byte) 1;
    numArray1[1] = (byte) 0;
    USB_device.Write(numArray1);
    USB_device.Read(numArray1);
    int num1 = ControllerDriver.JoinBytesIntoValue(numArray1, 3, 2);
    if ((num1 & 128 /*0x80*/) == 128 /*0x80*/)
      flag1 = false;
    else if ((num1 & 512 /*0x0200*/) == 512 /*0x0200*/)
      flag2 = true;
    if (!flag2)
    {
      if (!flag1)
        return;
      int num2 = ControllerDriver.JoinBytesIntoValue(numArray1, 5, 4);
      Action<double> downloadProgress = ControllerDriver.DownloadProgress;
      if (downloadProgress != null)
        downloadProgress((double) (100 * num2 / ControllerDriver.BootData.Length));
      if (ControllerDriver.MemoryErase)
      {
        ControllerDriver.MemoryErase = false;
        Action<string> downloadDescription = ControllerDriver.DownloadDescription;
        if (downloadDescription != null)
          downloadDescription(ControllerDriver.DownloadingProcess);
      }
      if (ControllerDriver.DownloadPtr >= ControllerDriver.BootData.Length)
        return;
      int length = ControllerDriver.BootData.Length - ControllerDriver.DownloadPtr;
      if (length > ControllerDriver.DataSizeMAX)
        length = ControllerDriver.DataSizeMAX;
      byte[] numArray2 = new byte[ControllerDriver.DataPacketSize];
      numArray2[0] = (byte) 2;
      numArray2[1] = (byte) length;
      numArray2[2] = (byte) (length >> 8);
      Array.Copy((Array) ((IEnumerable<byte>) ControllerDriver.BootData).ToArray<byte>(), ControllerDriver.DownloadPtr, (Array) numArray2, 3, length);
      USB_device.Write(numArray2);
      ControllerDriver.DownloadPtr += length;
    }
    else
    {
      ControllerDriver.DownloadTimer.Stop();
      ControllerDriver.DownloadTimer.Tick -= new EventHandler(ControllerDriver.DownloadTimer_Tick_v2);
      Action<bool> downloadFinished = ControllerDriver.DownloadFinished;
      if (downloadFinished == null)
        return;
      downloadFinished(true);
    }
  }

  private static bool IsDownLoadAPICorrect(int Value) => Value == 1 || Value == 2;

  private static bool IsPackSizeCorrect(int Value)
  {
    return Value >= 64 /*0x40*/ && Value <= 2048 /*0x0800*/ && Value % 64 /*0x40*/ == 0;
  }

  private static int JoinBytesIntoValue(byte[] Data, int StartIndex, int Size)
  {
    int num = 0;
    for (int index = 0; index < Size; ++index)
      num |= (int) Data[StartIndex + index] << index * 8;
    return num;
  }

  private enum DownlodAPI
  {
    DownlodAPI_v1 = 1,
    DownlodAPI_v2 = 2,
  }
}
