using System.Windows.Controls;
using System.Windows.Markup;

namespace ChipStudio
{
	public partial class LEDStateTemplate : UserControl, IComponentConnector
	{
		public string[] LEDStatesStrings { get; } = new string[8] { "OFF", "ON", "0,25 Hz", "0,5 Hz", "1 Hz", "2 Hz", "4 Hz", "8 Hz" };

		public int Number { get; set; }

		public int ActiveState { get; set; }

		public LEDStateTemplate()
		{
			InitializeComponent();
			base.DataContext = this;
		}
	}
}
