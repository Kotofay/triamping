using System.Windows;
using System.Windows.Markup;

namespace ChipStudio
{
	public partial class PixelModuleSettings : Window, IComponentConnector
	{
		public PixelModule Settings { get; } = new PixelModule();

		public PixelModuleSettings(PixelModule InitSettings)
		{
			InitializeComponent();
			if (InitSettings.IsEnabled)
			{
				IsEnabledCheck.IsChecked = true;
			}
			if (InitSettings.PixelType == PixelModule.PixelTypes.RGB)
			{
				RGBType.IsChecked = true;
			}
			else
			{
				RGBWType.IsChecked = true;
			}
			if (InitSettings.IsPwrOnEnabled)
			{
				IsPwrOnCheck.IsChecked = true;
			}
		}

		private void OKButton_Click(object sender, RoutedEventArgs e)
		{
			base.DialogResult = true;
			if (IsEnabledCheck.IsChecked == true)
			{
				Settings.IsEnabled = true;
			}
			else
			{
				Settings.IsEnabled = false;
			}
			if (RGBType.IsChecked == true)
			{
				Settings.PixelType = PixelModule.PixelTypes.RGB;
			}
			else
			{
				Settings.PixelType = PixelModule.PixelTypes.RGBW;
			}
			if (IsPwrOnCheck.IsChecked == true)
			{
				Settings.IsPwrOnEnabled = true;
			}
			else
			{
				Settings.IsPwrOnEnabled = false;
			}
		}

		private void CancelButton_Click(object sender, RoutedEventArgs e)
		{
			base.DialogResult = false;
		}
	}
}
