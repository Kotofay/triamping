﻿// Decompiled with JetBrains decompiler
// Type: ChipStudio.DSPCellConstant
// Assembly: ChipStudio, Version=1.2.9.0, Culture=neutral, PublicKeyToken=null
// MVID: 334E3BEA-37C7-4274-8118-535AAEFA1546
// Assembly location: D:\DocAndSec\Desktop\AUDIO\ChipDip\ChipStudio_soft_v1.2.9\ChipStudio_v1.2.9.exe

#nullable disable
namespace ChipStudio;

public class DSPCellConstant : IDSPCellSpecific
{
  public DSPCellConstant(DSPCell InCell)
  {
  }

  public int OneValueSize(DSPCell Cell) => Cell.ValueSize;

  public bool TryParseData(string FileName, out byte[] Result, DSPCell Cell = null)
  {
    return Shared.TryParseDSPCellDataGeneric(FileName, out Result);
  }
}
