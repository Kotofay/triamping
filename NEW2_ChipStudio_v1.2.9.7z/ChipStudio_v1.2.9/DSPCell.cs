﻿// Decompiled with JetBrains decompiler
// Type: ChipStudio.DSPCell
// Assembly: ChipStudio, Version=1.2.9.0, Culture=neutral, PublicKeyToken=null
// MVID: 334E3BEA-37C7-4274-8118-535AAEFA1546
// Assembly location: D:\DocAndSec\Desktop\AUDIO\ChipDip\ChipStudio_soft_v1.2.9\ChipStudio_v1.2.9.exe

using System;
using System.Collections.Generic;
using System.Linq;

#nullable disable
namespace ChipStudio;

public class DSPCell
{
  public string Title { get; }

  public string DSPTitle { get; set; }

  public bool IsControllable { get; set; }

  public bool IsBypassable { get; set; }

  public bool AreParamsFixed { get; set; } = true;

  public DSPCell.WriteTypes WriteType { get; set; }

  public List<DSPCellParameter> ParamsUsed { get; set; }

  public List<DSPCellParameter> ParamsFromFile { get; set; }

  public int BytesPerValue { get; set; }

  public int ValueSize
  {
    get
    {
      int valueSize = 0;
      foreach (DSPCellParameter dspCellParameter in this.ParamsUsed)
      {
        if (dspCellParameter.Name != "ChangePage")
          valueSize += (int) dspCellParameter.Size;
      }
      return valueSize;
    }
  }

  public int ParamsSize
  {
    get
    {
      int paramsSize = 0;
      foreach (DSPCellParameter dspCellParameter in this.ParamsUsed)
        paramsSize += (int) dspCellParameter.Size;
      return paramsSize;
    }
  }

  public DSPCell(string title)
  {
    this.Title = title;
    this.ParamsUsed = new List<DSPCellParameter>();
    this.ParamsFromFile = new List<DSPCellParameter>();
  }

  public void CloneParamsFromFileToParamsUsed()
  {
    this.ParamsUsed.AddRange(this.ParamsFromFile.Select<DSPCellParameter, DSPCellParameter>((Func<DSPCellParameter, DSPCellParameter>) (p => DSPCellParameter.Clone(p))));
  }

  public static bool TryParse(string value, out DSPCell.WriteTypes result)
  {
    result = DSPCell.WriteTypes.BlockWrite;
    foreach (DSPCell.WriteTypes writeTypes in Enum.GetValues(typeof (DSPCell.WriteTypes)))
    {
      if (writeTypes.ToString() == value)
      {
        result = writeTypes;
        return true;
      }
    }
    return false;
  }

  public enum WriteTypes : byte
  {
    SafeLoadWrite,
    BlockWrite,
    ReadModifyWrite,
  }
}
