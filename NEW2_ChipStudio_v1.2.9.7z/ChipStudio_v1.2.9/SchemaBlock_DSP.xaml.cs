using System;
using System.CodeDom.Compiler;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Windows;
using System.Windows.Markup;

namespace ChipStudio
{
	public partial class SchemaBlock_DSP : SchemaBlock, IComponentConnector
	{
		public enum FileParseOption
		{
			Cancel,
			Update,
			Replace
		}

		public delegate void FileParseEndEventHandler(List<DSPCell> CellList, FileParseOption Option);

		private static readonly string FileParseQuestion = "Do you want to update DSP project?\n\r- press 'Yes' to update project and save common blocks\n\r- press 'No' to replace project and delete all blocks\n\r- press 'Cancel' to cancel operation";

		private List<DataTransfer> BootSequence;

		private List<DSPCell> Cells;

		private readonly DSP DSPDev;

		public string Module { get; }

		public bool IsReady => DSPDev.IsLoaded;

		public override byte CoreID => DSPDev.ID;

		public override SchemaBlockTypes BlockType => SchemaBlockTypes.DSP;

		public bool IsChipSelectable => DSPDev.IsSelectable;

		public byte Interface => DSPDev.HWInterface;

		public bool IsSelfBooted
		{
			get
			{
				return SelfBootCheck.IsChecked.Value;
			}
			set
			{
				SelfBootCheck.IsChecked = value;
			}
		}

		public event FileParseEndEventHandler FileParseEnd;

		public SchemaBlock_DSP(string moduletype)
		{
			InitializeComponent();
			base.DataContext = this;
			Module = moduletype;
			DSPDev = new DSP(new DDdspXml(Module));
			if (!DSPDev.IsLoaded)
			{
				return;
			}
			if (DSPDev.IsSelfBootable)
			{
				SelfBootCheck.Visibility = Visibility.Visible;
			}
			if (DSPDev.IsAddressSelectable)
			{
				AdrSelectView.Visibility = Visibility.Visible;
				Adr0ComboBox.ItemsSource = DSPDev.AddressLineStates;
				Adr0ComboBox.SelectedIndex = 0;
				Adr1ComboBox.ItemsSource = DSPDev.AddressLineStates;
				Adr1ComboBox.SelectedIndex = 0;
				if (DSPDev.AddressLineCount == 1)
				{
					Adr1ComboBox.IsEnabled = false;
				}
			}
			BootSequence = new List<DataTransfer>();
			Cells = new List<DSPCell>();
			InitConnectionPoints(DSPDev.ActivePointAnchors());
			string[] array = DSPDev.ActivePointTitles();
			for (int i = 0; i < base.ConnectionPoints.Length; i++)
			{
				base.ConnectionPoints[i].Title = array[i];
			}
			if (base.ConnectionPoints.Length == 2)
			{
				base.ConnectionPoints[1].Margin = new Thickness(0.0, 10.0, 0.0, 0.0);
			}
			ConnectPoints.ItemsSource = base.ConnectionPoints;
			FileSelector.Filter = DSPDev.ProjectFileFormat;
			FileSelector.FileProcessingSet(ParseProjectFile);
		}

		public byte GetBusAddress()
		{
			return DSPDev.BusAddress(Adr0ComboBox.SelectedIndex, Adr1ComboBox.SelectedIndex);
		}

		public void SetBusAddress(byte Address)
		{
			DSPDev.SetAdrLines(Address, out var AdrState_, out var AdrState_2);
			Adr0ComboBox.SelectedIndex = AdrState_;
			Adr1ComboBox.SelectedIndex = AdrState_2;
		}

		private DataFileSelector.ProcessResult ParseProjectFile(string ProjectFile)
		{
			if (!DSPDev.ParseProject(ProjectFile, out var BootSequence, out var Cells))
			{
				if (this.BootSequence.Count != 0)
				{
					return DataFileSelector.ProcessResult.FailedAndSave;
				}
				return DataFileSelector.ProcessResult.FailedAndClear;
			}
			return Update(BootSequence, Cells);
		}

		public List<DataTransfer> GetBoot()
		{
			return new List<DataTransfer>(BootSequence);
		}

		public List<DSPCell> GetCells()
		{
			return new List<DSPCell>(Cells);
		}

		public void SetBoot(DataTransfer[] DSPBoot)
		{
			BootSequence.Clear();
			BootSequence.AddRange(DSPBoot);
			if (BootSequence.Count != 0)
			{
				FileSelector.IsDataSet = true;
			}
		}

		public void SetCells(DSPCell[] DSPCells)
		{
			DSPDev.CorrectDefaultCellsWriteType(DSPCells);
			Cells.Clear();
			Cells.AddRange(DSPCells);
			foreach (DSPCell cell in Cells)
			{
				if (cell.ParamsFromFile.Count == 0)
				{
					cell.ParamsFromFile.AddRange(cell.ParamsUsed.Select((DSPCellParameter p) => DSPCellParameter.Clone(p)));
				}
			}
		}

		public void AddConstantCells()
		{
			DSPDev.AddDefaultCells(Cells);
		}

		public void SetDSPTitleToCells()
		{
			foreach (DSPCell cell in Cells)
			{
				cell.DSPTitle = base.Title;
			}
		}

		public void UpdateBootAndCells(List<DataTransfer> NewBoot, List<DSPCell> NewCells)
		{
			if (NewBoot.Count != 0 && Update(NewBoot, NewCells) == DataFileSelector.ProcessResult.Success)
			{
				FileSelector.IsDataSet = true;
			}
		}

		private DataFileSelector.ProcessResult Update(List<DataTransfer> NewBoot, List<DSPCell> NewCells)
		{
			BootSequence = NewBoot;
			if (DSPDev.AreCellsConstant)
			{
				if (Cells.Count == 0)
				{
					if (NewCells.Count != 0)
					{
						Cells = NewCells;
					}
					else
					{
						DSPDev.AddDefaultCells(Cells);
					}
					SetDSPTitleToCells();
					this.FileParseEnd?.Invoke(Cells, FileParseOption.Replace);
				}
			}
			else
			{
				FileParseOption fileParseOption = ((Cells.Count == 0) ? FileParseOption.Replace : AskForPraseOption());
				switch (fileParseOption)
				{
				case FileParseOption.Cancel:
					return DataFileSelector.ProcessResult.FailedAndSave;
				case FileParseOption.Update:
					foreach (DSPCell cell in Cells)
					{
						foreach (DSPCell NewCell in NewCells)
						{
							if (!(cell.Title == NewCell.Title))
							{
								continue;
							}
							NewCell.ParamsUsed = cell.ParamsUsed;
							foreach (DSPCellParameter item in NewCell.ParamsUsed)
							{
								foreach (DSPCellParameter item2 in NewCell.ParamsFromFile)
								{
									if (item.Name == item2.Name)
									{
										item.Address = item2.Address;
										break;
									}
								}
							}
							break;
						}
					}
					break;
				}
				Cells = NewCells;
				if (Cells.Count != 0)
				{
					SetDSPTitleToCells();
					foreach (DSPCell cell2 in Cells)
					{
						if (cell2.ParamsUsed.Count == 0)
						{
							cell2.CloneParamsFromFileToParamsUsed();
						}
					}
					this.FileParseEnd?.Invoke(Cells, fileParseOption);
				}
			}
			return DataFileSelector.ProcessResult.Success;
		}

		private FileParseOption AskForPraseOption()
		{
			switch (MessageBox.Show("<" + base.Title + ">\n\r" + FileParseQuestion, "", MessageBoxButton.YesNoCancel, MessageBoxImage.Question))
			{
			case MessageBoxResult.Yes:
				return FileParseOption.Update;
			case MessageBoxResult.No:
				return FileParseOption.Replace;
			default:
				return FileParseOption.Cancel;
			}
		}

		protected override void Dispose(bool disposing)
		{
			if (disposing)
			{
				this.FileParseEnd = null;
				base.Dispose(disposing);
			}
		}
	}
}
