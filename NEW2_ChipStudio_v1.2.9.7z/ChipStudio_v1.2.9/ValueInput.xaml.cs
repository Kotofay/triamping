using System;
using System.Text.RegularExpressions;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Markup;

namespace ChipStudio
{
	public partial class ValueInput : UserControl, IComponentConnector
	{
		private delegate bool TryParseValue(string Input, out ulong Result);

		public const string HEX = "HEX";

		public const string DEC = "DEC";

		private const string DecFilter = "\\d";

		private const string HexFilter = "[0-9aAbBcCdDeEfF]";

		private string InputFilter = "[0-9aAbBcCdDeEfF]";

		private TryParseValue TryParse = TryParseHEX;

		public string Title { get; set; }

		public int ValueFieldWidth { get; set; }

		public int ValueMaxLength { get; set; } = 4;

		public string Format { get; set; } = "HEX";

		public ValueInput()
		{
			InitializeComponent();
			base.DataContext = this;
		}

		public string GetInput()
		{
			return ValueBox.Text;
		}

		public void SetInput(string Input)
		{
			ValueBox.Text = Input;
		}

		public ulong GetValue()
		{
			if (!TryParse(ValueBox.Text, out var Result))
			{
				return 0uL;
			}
			return Result;
		}

		public void SetFormat(string NewFormat)
		{
			Format = NewFormat;
			string format = Format;
			if (!(format == "DEC"))
			{
				if (format == "HEX")
				{
					TryParse = TryParseHEX;
					InputFilter = "[0-9aAbBcCdDeEfF]";
				}
			}
			else
			{
				TryParse = ulong.TryParse;
				InputFilter = "\\d";
			}
		}

		private static bool TryParseHEX(string input, out ulong result)
		{
			result = 0uL;
			if (input.Length == 0)
			{
				return false;
			}
			try
			{
				result = Convert.ToUInt64(input, 16);
			}
			catch (FormatException)
			{
				return false;
			}
			return true;
		}

		private void PreviewTextInput_Event(object sender, TextCompositionEventArgs e)
		{
			if (!Regex.IsMatch(e.Text, InputFilter))
			{
				e.Handled = true;
			}
		}

		private void PreviewKeyDown_Event(object sender, KeyEventArgs e)
		{
			if (e.Key == Key.Space)
			{
				e.Handled = true;
			}
		}
	}
}
