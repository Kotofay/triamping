﻿// Decompiled with JetBrains decompiler
// Type: ChipStudio.ControllerComboProperties
// Assembly: ChipStudio, Version=1.2.9.0, Culture=neutral, PublicKeyToken=null
// MVID: 334E3BEA-37C7-4274-8118-535AAEFA1546
// Assembly location: D:\DocAndSec\Desktop\AUDIO\ChipDip\ChipStudio_soft_v1.2.9\ChipStudio_v1.2.9.exe

using System;
using System.Collections.Generic;
using System.Linq;
using System.Xml.Linq;

#nullable disable
namespace ChipStudio;

public class ControllerComboProperties
{
  private const string ComboProjectString = "ComboProject";
  private const string BootGpiosString = "BootGPIOs";
  private const string StreamGpiosString = "StreamGPIOs";
  private const string UnusedStreamsString = "UnusedStreams";
  private const string ProjectBootOptionString = "ProjectBootOption";
  private readonly int ComboTypesMask;

  public int[] BootGpios { get; }

  public bool IsGpioBootSupported { get; }

  public string BootGpiosNumbers { get; } = "";

  public int[] StreamGpios { get; }

  public int[] UnusedStreams { get; }

  public bool ProjectBootOption { get; }

  public ControllerComboProperties(string moduletype)
  {
    XDocument xdocument = XDocument.Load(Shared.DDControllerPath + Shared.FilePathSlash + moduletype + Shared.DDFileExt);
    int Value;
    this.ComboTypesMask = int.TryParse(xdocument.Element((XName) "Controller")?.Element((XName) "ComboProject")?.Attribute((XName) "Mask")?.Value, out Value) ? Value : 0;
    if (this.ComboTypesMask == 0)
      return;
    if ((this.ComboTypesMask & 1) == 1)
    {
      XElement xelement1 = xdocument.Element((XName) "Controller");
      int[] numArray;
      if (xelement1 == null)
      {
        numArray = (int[]) null;
      }
      else
      {
        XElement xelement2 = xelement1.Element((XName) "ComboProject");
        if (xelement2 == null)
        {
          numArray = (int[]) null;
        }
        else
        {
          XElement xelement3 = xelement2.Element((XName) "BootGPIOs");
          if (xelement3 == null)
            numArray = (int[]) null;
          else
            numArray = ((IEnumerable<string>) xelement3.Value.Split(";"[0])).Select<string, int>((Func<string, int>) (p => !int.TryParse(p, out Value) ? 1 : Value)).ToArray<int>();
        }
      }
      this.BootGpios = numArray;
      if (this.BootGpios != null)
      {
        for (int index = this.BootGpios.Length - 1; index >= 0; --index)
          this.BootGpiosNumbers = $"{this.BootGpiosNumbers}{this.BootGpios[index].ToString()} ";
        this.IsGpioBootSupported = true;
      }
      else
        this.ComboTypesMask &= -2;
    }
    XElement xelement4 = xdocument.Element((XName) "Controller");
    int[] numArray1;
    if (xelement4 == null)
    {
      numArray1 = (int[]) null;
    }
    else
    {
      XElement xelement5 = xelement4.Element((XName) "ComboProject");
      if (xelement5 == null)
      {
        numArray1 = (int[]) null;
      }
      else
      {
        XElement xelement6 = xelement5.Element((XName) "StreamGPIOs");
        if (xelement6 == null)
          numArray1 = (int[]) null;
        else
          numArray1 = ((IEnumerable<string>) xelement6.Value.Split(";"[0])).Select<string, int>((Func<string, int>) (p => !int.TryParse(p, out Value) ? 1 : Value)).ToArray<int>();
      }
    }
    this.StreamGpios = numArray1;
    XElement xelement7 = xdocument.Element((XName) "Controller");
    int[] numArray2;
    if (xelement7 == null)
    {
      numArray2 = (int[]) null;
    }
    else
    {
      XElement xelement8 = xelement7.Element((XName) "ComboProject");
      if (xelement8 == null)
      {
        numArray2 = (int[]) null;
      }
      else
      {
        XElement xelement9 = xelement8.Element((XName) nameof (UnusedStreams));
        if (xelement9 == null)
          numArray2 = (int[]) null;
        else
          numArray2 = ((IEnumerable<string>) xelement9.Value.Split(";"[0])).Select<string, int>((Func<string, int>) (p => !int.TryParse(p, out Value) ? 1 : Value)).ToArray<int>();
      }
    }
    this.UnusedStreams = numArray2;
    bool result;
    this.ProjectBootOption = bool.TryParse(xdocument.Element((XName) "Controller")?.Element((XName) "ComboProject")?.Attribute((XName) nameof (ProjectBootOption))?.Value, out result) && result;
  }

  private enum ComboTypes
  {
    BOOT_GPIO = 1,
    BOOT_LR = 2,
    BOOT_LR_BCLK = 4,
    BOOT_SOUNDCARD = 8,
  }
}
