using System;
using System.CodeDom.Compiler;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Windows;
using System.Windows.Markup;

namespace ChipStudio
{
	public partial class SchemaBlock_LED : SchemaBlock, ILed, IComparatorDependent, IComponentConnector
	{
		private static readonly Anchor.AnchorTypes[] PointAnchors = new Anchor.AnchorTypes[1] { Anchor.AnchorTypes.FromLED };

		private const int COMPARATOR_STATES_COUNT = 2;

		private List<LEDStateTemplate> LEDStatesList = new List<LEDStateTemplate>();

		private bool dsp_mode;

		public override SchemaBlockTypes BlockType => SchemaBlockTypes.LED;

		public ConnectionNode DSPBlockConnectionNode => BlockList.ActiveConnectionNode();

		public string ActiveComparator
		{
			get
			{
				if (DSPMode)
				{
					return null;
				}
				return CompSelector.SelectedItem;
			}
		}

		public bool DSPMode
		{
			get
			{
				return dsp_mode;
			}
			set
			{
				if (dsp_mode != value)
				{
					dsp_mode = value;
					BlockList.Visibility = ((!dsp_mode) ? Visibility.Hidden : Visibility.Visible);
					CompSelector.Visibility = (dsp_mode ? Visibility.Hidden : Visibility.Visible);
				}
			}
		}

		public SchemaBlock_LED()
		{
			InitializeComponent();
			base.DataContext = this;
			BlockList.SelectionChanged += BlockChanged;
			InitConnectionPoints(PointAnchors);
			ConnectPoints.ItemsSource = base.ConnectionPoints;
			DSPModeSel.IsChecked = true;
			DSPMode = true;
		}

		public void UpdateBlockList(SchemaBlock_DSPCell[] Blocks, Schema.UpdateOptions Option)
		{
			BlockList.Update(Blocks, Option);
		}

		public void UpdateComparatorList(string[] ComparatorTitles, Schema.UpdateOptions Option)
		{
			CompSelector.Update(ComparatorTitles, Option);
		}

		public byte[] GetData()
		{
			return LEDStatesList.Select((LEDStateTemplate i) => (byte)i.ActiveState).ToArray();
		}

		public void SetData(byte[] Data)
		{
			LEDStatesList.Clear();
			for (int i = 0; i < Data.Length; i++)
			{
				AddNewLEDStateTemplate(i);
				LEDStatesList[i].ActiveState = Data[i];
			}
		}

		public int GetDefaultBlockIndex()
		{
			if (!DSPMode)
			{
				return CompSelector.SelectedIndex;
			}
			return BlockList.DefaultBlock;
		}

		public void SetDefaultBlockIndex(int BlockIndex)
		{
			if (DSPMode)
			{
				BlockList.DefaultBlock = BlockIndex;
			}
			else
			{
				CompSelector.SelectedIndex = BlockIndex;
			}
		}

		public void SetMode(bool Mode)
		{
			if (Mode)
			{
				DSPModeSel.IsChecked = true;
			}
			else
			{
				CompModeSel.IsChecked = true;
			}
		}

		private void LEDStatesConfig_Click(object sender, RoutedEventArgs e)
		{
			int num = (DSPMode ? BlockList.ActiveValuesCount() : 2);
			if (num == -1)
			{
				return;
			}
			if (LEDStatesList.Count < num)
			{
				while (LEDStatesList.Count < num)
				{
					AddNewLEDStateTemplate(LEDStatesList.Count);
				}
			}
			else if (LEDStatesList.Count > num)
			{
				while (LEDStatesList.Count > num)
				{
					LEDStatesList.RemoveAt(LEDStatesList.Count - 1);
				}
			}
			List<LEDStateTemplate> list = new List<LEDStateTemplate>();
			for (int i = 0; i < LEDStatesList.Count; i++)
			{
				LEDStateTemplate item = new LEDStateTemplate
				{
					Number = i,
					ActiveState = LEDStatesList[i].ActiveState
				};
				list.Add(item);
			}
			if (new LEDStatesWindow(base.Title, list).ShowDialog() == true)
			{
				LEDStatesList = list;
			}
		}

		private void BlockChanged(int ValuesCount)
		{
			LEDStatesList.Clear();
			for (int i = 0; i < ValuesCount; i++)
			{
				AddNewLEDStateTemplate(i);
			}
		}

		private void AddNewLEDStateTemplate(int Number)
		{
			LEDStateTemplate item = new LEDStateTemplate
			{
				Number = Number,
				ActiveState = 0
			};
			LEDStatesList.Add(item);
		}

		private void DSPModeSel_Checked(object sender, RoutedEventArgs e)
		{
			DSPMode = true;
		}

		private void DSPModeSel_UnChecked(object sender, RoutedEventArgs e)
		{
			DSPMode = false;
		}
	}
}
