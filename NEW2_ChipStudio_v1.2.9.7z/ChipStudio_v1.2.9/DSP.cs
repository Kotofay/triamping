﻿// Decompiled with JetBrains decompiler
// Type: ChipStudio.DSP
// Assembly: ChipStudio, Version=1.2.9.0, Culture=neutral, PublicKeyToken=null
// MVID: 334E3BEA-37C7-4274-8118-535AAEFA1546
// Assembly location: D:\DocAndSec\Desktop\AUDIO\ChipDip\ChipStudio_soft_v1.2.9\ChipStudio_v1.2.9.exe

using System;
using System.Collections.Generic;
using System.Windows;

#nullable disable
namespace ChipStudio;

public class DSP
{
  private const byte I2C_INTERFACE = 0;
  private const byte SPI_INTERFACE = 1;
  public const int INTERFACE_POINT_INDEX = 0;
  public const int CS_POINT_INDEX = 1;
  private readonly uint PrimaryBusAddress;
  private readonly string[] AdrLineStates;
  private readonly uint[] AdrValues;
  private readonly int BitsPerAdrLine;
  private readonly DSPCell[] DefaultCells;
  private readonly IDSPBootParser BootParser;
  private readonly IDSPCellParser CellParser;

  public bool IsLoaded { get; }

  public byte ID { get; }

  public bool IsSelectable { get; }

  public byte HWInterface { get; }

  public bool IsSelfBootable { get; }

  public bool IsAddressSelectable { get; }

  public string[] AddressLineStates => this.AdrLineStates;

  public int AddressLineCount { get; } = 2;

  public string ProjectFileFormat { get; }

  public bool AreCellsConstant { get; }

  public DSP(IDDdsp DspDescription)
  {
    this.IsLoaded = DspDescription.IsLoaded;
    if (!this.IsLoaded)
    {
      int num = (int) MessageBox.Show("Wrong device description format", "", MessageBoxButton.OK, MessageBoxImage.Hand);
    }
    else
    {
      this.ID = DspDescription.ID;
      this.HWInterface = DspDescription.Interface == "I2C" ? (byte) 0 : (byte) 1;
      if (this.HWInterface == (byte) 1)
        this.IsSelectable = true;
      this.BootParser = DSPParserSelector.BootParser(this.ID);
      this.CellParser = DSPParserSelector.CellParser(this.ID);
      this.IsSelfBootable = DspDescription.IsSelfBootable;
      DspDescription.BusAddressInfo(out this.PrimaryBusAddress, out this.AdrLineStates, out this.AdrValues);
      if (this.AdrValues != null)
      {
        this.IsAddressSelectable = true;
        if (this.AdrLineStates == null || this.AdrValues == null)
          return;
        this.BitsPerAdrLine = this.AdrLineStates.Length >> 1;
        if (this.AdrLineStates.Length == this.AdrValues.Length)
          this.AddressLineCount = 1;
      }
      this.ProjectFileFormat = DspDescription.FileFormat;
      this.AreCellsConstant = DspDescription.AreCellsConstant;
      this.DefaultCells = DspDescription.Cells;
    }
  }

  public byte BusAddress(int AdrState_0, int AdrState_1)
  {
    if (!this.IsAddressSelectable)
      return (byte) this.PrimaryBusAddress;
    bool flag = false;
    if (AdrState_0 == -1 || AdrState_1 == -1)
      flag = true;
    int index = AdrState_0;
    if (this.AddrLineStatesCount() < this.AdrValues.Length)
      index |= AdrState_1 << this.BitsPerAdrLine;
    if (index >= this.AdrValues.Length)
      flag = true;
    if (!flag)
      return (byte) this.AdrValues[index];
    int num = (int) MessageBox.Show("Wrong device address", "", MessageBoxButton.OK, MessageBoxImage.Hand);
    return (byte) this.PrimaryBusAddress;
  }

  public void SetAdrLines(byte Address, out int AdrState_0, out int AdrState_1)
  {
    AdrState_0 = 0;
    AdrState_1 = 0;
    if (!this.IsAddressSelectable)
      return;
    int num1 = this.AddrLineStatesCount();
    if (num1 < this.AdrValues.Length)
    {
      AdrState_0 = 0;
      while (AdrState_0 < num1)
      {
        AdrState_1 = 0;
        while (AdrState_1 < num1)
        {
          if ((int) this.BusAddress(AdrState_0, AdrState_1) == (int) Address)
            return;
          ++AdrState_1;
        }
        ++AdrState_0;
      }
    }
    else
    {
      AdrState_0 = 0;
      while (AdrState_0 < num1)
      {
        if ((int) this.BusAddress(AdrState_0, AdrState_1) == (int) Address)
          return;
        ++AdrState_0;
      }
    }
    int num2 = (int) MessageBox.Show("Wrong device address", "", MessageBoxButton.OK, MessageBoxImage.Hand);
  }

  public bool ParseProject(
    string ProjectFile,
    out List<DataTransfer> BootSequence,
    out List<DSPCell> Cells)
  {
    BootSequence = new List<DataTransfer>();
    Cells = new List<DSPCell>();
    if (!this.BootParser.TryParse(ProjectFile, out BootSequence))
      return false;
    IDSPCellParser cellParser = this.CellParser;
    if ((cellParser != null ? (!cellParser.TryParse(ProjectFile, out Cells) ? 1 : 0) : 0) != 0)
      return false;
    if (this.DefaultCells != null)
    {
      if (Cells == null)
        Cells = new List<DSPCell>();
      Cells.AddRange((IEnumerable<DSPCell>) this.DefaultCells);
    }
    return true;
  }

  public void AddDefaultCells(List<DSPCell> Cells)
  {
    if (this.DefaultCells == null)
      return;
    Cells.AddRange((IEnumerable<DSPCell>) this.DefaultCells);
  }

  public void CorrectDefaultCellsWriteType(DSPCell[] DSPCells)
  {
    if (this.DefaultCells == null)
      return;
    foreach (DSPCell dspCell in DSPCells)
    {
      foreach (DSPCell defaultCell in this.DefaultCells)
      {
        if (dspCell.Title == defaultCell.Title)
        {
          dspCell.WriteType = defaultCell.WriteType;
          break;
        }
      }
    }
  }

  public Anchor.AnchorTypes[] ActivePointAnchors()
  {
    return this.HWInterface != (byte) 0 ? new Anchor.AnchorTypes[2]
    {
      Anchor.AnchorTypes.FromSlave_SPI,
      Anchor.AnchorTypes.FromSlave_CS
    } : new Anchor.AnchorTypes[1]
    {
      Anchor.AnchorTypes.FromSlave_I2C
    };
  }

  public string[] ActivePointTitles()
  {
    return this.HWInterface != (byte) 0 ? new string[2]
    {
      "SPI",
      "CS"
    } : new string[1]{ "I2C" };
  }

  private int AddrLineStatesCount() => (int) Math.Pow(2.0, (double) this.BitsPerAdrLine);
}
