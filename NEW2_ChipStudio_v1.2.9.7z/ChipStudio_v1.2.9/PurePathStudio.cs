﻿// Decompiled with JetBrains decompiler
// Type: ChipStudio.PurePathStudio
// Assembly: ChipStudio, Version=1.2.9.0, Culture=neutral, PublicKeyToken=null
// MVID: 334E3BEA-37C7-4274-8118-535AAEFA1546
// Assembly location: D:\DocAndSec\Desktop\AUDIO\ChipDip\ChipStudio_soft_v1.2.9\ChipStudio_v1.2.9.exe

using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Windows;

#nullable disable
namespace ChipStudio;

public class PurePathStudio
{
  private const string PPStudioCMDWrite = "w";
  private const string PPStudioCMDNextReg = ">";
  private const string LstFileExt = ".lst";
  private const string AicMainFile = "aic_main.lst";
  private const string PurePathStudioCFGFileExt = "cfg";
  private const string PPStudioNameWord = "Name";
  private const string PPStudioAddressWord = "Address";
  private const string PPStudioI2CWord = "I2C";
  private const string PPStudioRegCodeWord = "Reg Code";
  private const string PPStudioParamNameDevider = "_";
  private const string NotRegulatedBlock = " not regulated";
  private const string BiquadNotRegulatedBlockName = "One_M2";
  private const string MinusSeparatorSign = "-";
  private const string EqualSeparatorSign = "=";
  private const string miniDSPString = "miniDSP_";
  private static readonly string[] PPStudioBypassableCells = new string[2]
  {
    "Biquad",
    "Volume"
  };
  private const int AdrIndexInWriteString = 2;
  private const int DataIndexInWriteString = 3;
  private const int DataIndexInNextRegString = 1;
  private const int PP_CMD_DATA_SIZE = 1;
  private const int TxDataIndex = 0;
  private const byte PCM5x4x_AUTO_INCR = 128 /*0x80*/;
  private const byte PCM5x4x_CHANGE_PAGE_REG = 0;
  private const byte PCM5x4x_CHANGE_PAGE_PARAM_SIZE = 1;
  private const byte PCM5x4x_RAM_COEF_SIZE = 4;
  private const byte PPSTUDIO_RAM_COEF_PAGE_INDEX = 0;
  private const byte PPSTUDIO_RAM_COEF_REG_INDEX = 1;
  private const ushort PPSTUDIO_RAM_COEF_COUNT_MAX = 256 /*0x0100*/;
  private const int PPStudioLSTDataSize = 2;
  private const int ParamNameIndex = 0;
  private const int ParamAddressIndex = 1;
  private const int ParamData_0_Index = 2;
  private const int ParamData_1_Index = 3;
  private const int ParamAddressCharSize = 4;
  private const int ParamDataCharSize = 2;

  public static bool TryParseCFG(string ProjectFile, out List<DataTransfer> BootSequence)
  {
    BootSequence = new List<DataTransfer>();
    foreach (string[] strArray in ((IEnumerable<string>) File.ReadAllLines(ProjectFile)).Where<string>((Func<string, bool>) (e => e.StartsWith("w") || e.StartsWith(">"))).Select<string, string[]>((Func<string, string[]>) (s => s.Split(" "[0]))).ToArray<string[]>())
    {
      uint result;
      ushort address;
      string input;
      if (strArray[0] == "w")
      {
        if (!Shared.TryParseHEX(strArray[2], out result))
          return false;
        address = (ushort) result;
        input = strArray[3];
      }
      else
      {
        address = (ushort) ((uint) BootSequence[BootSequence.Count - 1].Address + 1U);
        input = strArray[1];
      }
      if (!Shared.TryParseHEX(input, out result))
        return false;
      DataTransfer dataTransfer = new DataTransfer(address, 1, (byte) 0, DataTransfer.TransferTypes.Write);
      dataTransfer.Data[0] = (byte) result;
      BootSequence.Add(dataTransfer);
    }
    Shared.ConcatByAddress(BootSequence);
    foreach (DataTransfer dataTransfer in BootSequence)
    {
      if (dataTransfer.Size > 1)
        dataTransfer.Address |= (ushort) 128 /*0x80*/;
    }
    return true;
  }

  public static bool TryParseLST(string ProjectFile, out List<DSPCell> Cells)
  {
    Cells = (List<DSPCell>) null;
    string LSTFilePath;
    if (!PurePathStudio.TryFindLSTFile(ProjectFile, out LSTFilePath) || PurePathStudio.ParseLSTFile(LSTFilePath, out Cells))
      return true;
    int num = (int) MessageBox.Show($"Error in file <{LSTFilePath}>", "", MessageBoxButton.OK, MessageBoxImage.Hand);
    return false;
  }

  private static bool TryFindLSTFile(string ProjectFile, out string LSTFilePath)
  {
    string[] strArray = ProjectFile.Split("."[0]);
    LSTFilePath = strArray[0] + ".lst";
    if (!File.Exists(LSTFilePath))
    {
      LSTFilePath = $"{strArray[0]}{Shared.FilePathSlash}aic_main.lst";
      if (!File.Exists(LSTFilePath))
      {
        int num = (int) MessageBox.Show("Unable to find .lst file", "", MessageBoxButton.OK, MessageBoxImage.Exclamation);
        return false;
      }
    }
    return true;
  }

  private static bool ParseLSTFile(string InputFile, out List<DSPCell> Cells)
  {
    Cells = (List<DSPCell>) null;
    List<DSPCellParameter> Parameters;
    if (!PurePathStudio.ExtractParameters(InputFile, out Parameters))
      return false;
    Cells = PurePathStudio.ExtractCells(Parameters);
    return true;
  }

  private static List<DSPCell> ExtractCells(List<DSPCellParameter> InputParams)
  {
    List<DSPCell> cells = new List<DSPCell>();
    List<DSPCellParameter> Params = new List<DSPCellParameter>()
    {
      InputParams[0]
    };
    for (int index = 1; index < InputParams.Count; ++index)
    {
      string str1 = PurePathStudio.ParameterBaseName(Params[0].Name);
      string str2 = PurePathStudio.ParameterBaseName(InputParams[index].Name);
      if (str2 != str1)
      {
        if (str2.IndexOf(str1) != -1)
        {
          Params.Add(InputParams[index]);
          continue;
        }
        if (str1.IndexOf(str2) != -1)
        {
          Params[0].Name = str2;
          Params.Add(InputParams[index]);
          continue;
        }
        cells.Add(PurePathStudio.JoinParametersToCell(Params));
        Params.Clear();
      }
      Params.Add(InputParams[index]);
    }
    cells.Add(PurePathStudio.JoinParametersToCell(Params));
    return cells;
  }

  private static bool ExtractParameters(string InputFile, out List<DSPCellParameter> Parameters)
  {
    string[] array = ((IEnumerable<string>) File.ReadAllLines(InputFile)).SkipWhile<string>((Func<string, bool>) (s => s.IndexOf("Name") == -1 || s.IndexOf("Address") == -1 || s.IndexOf("I2C") == -1)).TakeWhile<string>((Func<string, bool>) (s => s.IndexOf("Reg Code") == -1)).Where<string>((Func<string, bool>) (s => s.Length != 0 && s.IndexOf("Name") == -1 && !s.StartsWith("-") && !s.StartsWith("=") && !s.StartsWith("miniDSP_"))).ToArray<string>();
    Parameters = new List<DSPCellParameter>();
    foreach (string input in array)
    {
      DSPCellParameter dspCellParameter;
      if (!PurePathStudio.ExtractParameter(input, out dspCellParameter))
        return false;
      Parameters.Add(dspCellParameter);
    }
    Parameters.Sort((Comparison<DSPCellParameter>) ((x, y) => x.Address.CompareTo(y.Address)));
    return true;
  }

  private static bool ExtractParameter(string input, out DSPCellParameter Param)
  {
    Param = new DSPCellParameter() { Data = new byte[2] };
    input = input.Replace(" ", "");
    string[] strArray = input.Split(new string[1]{ "0x" }, StringSplitOptions.None);
    if (strArray == null)
      return false;
    Param.Name = strArray[0];
    uint result;
    Param.Address = Shared.TryParseHEX(strArray[1].Substring(0, 4), out result) ? (ushort) result : (ushort) 0;
    if (strArray.Length > 3)
    {
      Param.Data[0] = Shared.TryParseHEX(strArray[2].Substring(0, 2), out result) ? (byte) result : (byte) 0;
      Param.Data[1] = Shared.TryParseHEX(strArray[3].Substring(0, 2), out result) ? (byte) result : (byte) 0;
    }
    return true;
  }

  private static string ParameterBaseName(string input)
  {
    int length = input.LastIndexOf("_");
    return length == -1 ? input : input.Substring(0, length);
  }

  private static DSPCell JoinParametersToCell(List<DSPCellParameter> Params)
  {
    DSPCell cell;
    if (Params[0].Address < (ushort) 256 /*0x0100*/ && (Params[0].Name.IndexOf(PurePathStudio.PPStudioBypassableCells[0]) == -1 || Params[0].Name.IndexOf("One_M2") == -1))
    {
      cell = new DSPCell(PurePathStudio.ParameterBaseName(Params[0].Name))
      {
        IsControllable = true,
        IsBypassable = ((IEnumerable<string>) PurePathStudio.PPStudioBypassableCells).Where<string>((Func<string, bool>) (s => Params[0].Name.IndexOf(s) != -1)) != null
      };
      cell.ParamsFromFile.Add(PurePathStudio.ChangePageParam(Params[0].Data[0]));
      byte PageAdr = Params[0].Data[0];
      byte Address = Params[0].Data[1];
      byte num = 1;
      string name = Params[0].Name;
      for (int index = 1; index < Params.Count; ++index)
      {
        if ((int) Params[index].Data[0] != (int) PageAdr)
        {
          if (num > (byte) 1)
            Address |= (byte) 128 /*0x80*/;
          cell.ParamsFromFile.Add(new DSPCellParameter(name, (ushort) Address, (ushort) ((uint) num * 4U)));
          num = (byte) 0;
          Address = Params[index].Data[1];
          PageAdr = Params[index].Data[0];
          name = Params[index].Name;
          cell.ParamsFromFile.Add(PurePathStudio.ChangePageParam(PageAdr));
        }
        ++num;
      }
      if (num > (byte) 1)
        Address |= (byte) 128 /*0x80*/;
      cell.ParamsFromFile.Add(new DSPCellParameter(name, (ushort) Address, (ushort) ((uint) num * 4U)));
    }
    else
      cell = new DSPCell(PurePathStudio.ParameterBaseName(Params[0].Name) + " not regulated");
    return cell;
  }

  private static DSPCellParameter ChangePageParam(byte PageAdr)
  {
    DSPCellParameter dspCellParameter = new DSPCellParameter("ChangePage", (ushort) 0, (ushort) 1);
    dspCellParameter.Data[0] = PageAdr;
    return dspCellParameter;
  }
}
