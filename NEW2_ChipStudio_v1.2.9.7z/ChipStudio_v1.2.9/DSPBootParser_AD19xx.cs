﻿// Decompiled with JetBrains decompiler
// Type: ChipStudio.DSPBootParser_AD19xx
// Assembly: ChipStudio, Version=1.2.9.0, Culture=neutral, PublicKeyToken=null
// MVID: 334E3BEA-37C7-4274-8118-535AAEFA1546
// Assembly location: D:\DocAndSec\Desktop\AUDIO\ChipDip\ChipStudio_soft_v1.2.9\ChipStudio_v1.2.9.exe

using System.Collections.Generic;

#nullable disable
namespace ChipStudio;

public class DSPBootParser_AD19xx : IDSPBootParser
{
  public bool TryParse(string ProjectFile, out List<DataTransfer> BootSequence)
  {
    return SigmaStudio.TryParseCodecBoot(ProjectFile, "AD1938", out BootSequence);
  }
}
