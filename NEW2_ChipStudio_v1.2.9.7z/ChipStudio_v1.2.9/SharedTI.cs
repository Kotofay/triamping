﻿// Decompiled with JetBrains decompiler
// Type: ChipStudio.SharedTI
// Assembly: ChipStudio, Version=1.2.9.0, Culture=neutral, PublicKeyToken=null
// MVID: 334E3BEA-37C7-4274-8118-535AAEFA1546
// Assembly location: D:\DocAndSec\Desktop\AUDIO\ChipDip\ChipStudio_soft_v1.2.9\ChipStudio_v1.2.9.exe

using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;

#nullable disable
namespace ChipStudio;

public class SharedTI
{
  private const int RAM_COEF_SIZE = 4;
  private const byte RAM_COEF_LSBYTE = 0;
  public const string PPCellParamChangePage = "ChangePage";

  public static bool TryParseDSPCellDataTI(string InputFile, out byte[] Result, DSPCell Cell)
  {
    Result = (byte[]) null;
    if (Cell.ParamsUsed.Count == 0)
      return false;
    string[] array = ((IEnumerable<string>) File.ReadAllLines(InputFile)).Where<string>((Func<string, bool>) (s => s.StartsWith("0x"))).Select<string, string>((Func<string, string>) (s => s.Replace(" ", "").Replace("0x", ""))).ToArray<string>();
    int index1 = 0;
    List<byte> byteList = new List<byte>();
    uint result;
    while (index1 < array.Length)
    {
      foreach (DSPCellParameter dspCellParameter in Cell.ParamsUsed)
      {
        if (dspCellParameter.Name == "ChangePage")
          byteList.Add(dspCellParameter.Data[0]);
        else if (dspCellParameter.Size != (ushort) 1)
        {
          int num = (int) dspCellParameter.Size / 4;
          for (int index2 = 0; index2 < num; ++index2)
          {
            if (index1 >= array.Length || !Shared.TryParseHEX(array[index1], out result))
              return false;
            for (int index3 = 2; index3 >= 0; --index3)
              byteList.Add((byte) (result >> index3 * 8));
            byteList.Add((byte) 0);
            ++index1;
          }
        }
        else
        {
          if (!Shared.TryParseHEX(array[index1], out result))
            return false;
          byteList.Add((byte) result);
          ++index1;
        }
      }
    }
    Result = byteList.ToArray();
    return true;
  }
}
