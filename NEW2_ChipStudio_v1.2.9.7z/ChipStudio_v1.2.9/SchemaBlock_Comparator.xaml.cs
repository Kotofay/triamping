using System;
using System.CodeDom.Compiler;
using System.Diagnostics;
using System.Windows.Markup;

namespace ChipStudio
{
	public partial class SchemaBlock_Comparator : SchemaBlock, IComponentConnector
	{
		private static readonly Anchor.AnchorTypes[] PointAnchors = new Anchor.AnchorTypes[1] { Anchor.AnchorTypes.ToRead };

		private static readonly string[] ComparisonOperations = new string[3] { "<", "=", ">" };

		private const int DEFAULT_COMPARE_OPERATION = 1;

		public override SchemaBlockTypes BlockType => SchemaBlockTypes.Comparator;

		public int Mode
		{
			get
			{
				return ModeSelector.SelectedIndex;
			}
			set
			{
				ModeSelector.SelectedIndex = value;
			}
		}

		public SchemaBlock_Comparator()
		{
			InitializeComponent();
			base.DataContext = this;
			Mask.SetFormat("HEX");
			Value.SetFormat("HEX");
			ModeSelector.ItemsSource = ComparisonOperations;
			Mode = 1;
			InitConnectionPoints(PointAnchors);
			ConnectPoints.ItemsSource = base.ConnectionPoints;
		}

		public string GetMaskInput()
		{
			return Mask.GetInput();
		}

		public string GetValueInput()
		{
			return Value.GetInput();
		}

		public ulong GetMaskValue()
		{
			return Mask.GetValue();
		}

		public ulong GetValueValue()
		{
			return Value.GetValue();
		}

		public void SetMask(string MaskInput)
		{
			Mask.SetInput(MaskInput);
		}

		public void SetValue(string ValueInput)
		{
			Value.SetInput(ValueInput);
		}
	}
}
