using System.Collections.ObjectModel;
using System.Collections.Specialized;
using System.ComponentModel;
using System.Windows.Controls;
using System.Windows.Markup;

namespace ChipStudio
{
	public partial class Connection : UserControl, INotifyPropertyChanged, ISchemaElement, IComponentConnector
	{
		private readonly ObservableCollection<ConnectionNode> nodes = new ObservableCollection<ConnectionNode>();

		private bool isselected;

		public ObservableCollection<ConnectionNode> Nodes => nodes;

		public bool IsSelected
		{
			get
			{
				return isselected;
			}
			set
			{
				if (isselected != value)
				{
					isselected = value;
					NotifyPropertyChanged("IsSelected");
				}
			}
		}

		public string ElementType => Shared.ElementTypeConnection;

		public event PropertyChangedEventHandler PropertyChanged;

		public Connection()
		{
			InitializeComponent();
			base.DataContext = this;
			((INotifyCollectionChanged)Nodes).CollectionChanged += NotifyCollectionChanged_CollectionChanged;
		}

		public void AddNode(ConnectionNode NewNode)
		{
			nodes.Add(NewNode);
		}

		public int GetAnchorNumberInBlock(string BlockTitle)
		{
			int result = -1;
			foreach (ConnectionNode node in nodes)
			{
				if (node.BlockName == BlockTitle)
				{
					result = node.AnchorNumber;
					break;
				}
			}
			return result;
		}

		public void Update(ConnectionNode Node)
		{
			for (int i = 0; i < nodes.Count; i++)
			{
				if (nodes[i].BlockName == Node.BlockName)
				{
					nodes.RemoveAt(i);
					nodes.Insert(i, Node);
					break;
				}
			}
		}

		public void RemoveNodeAt(int Index)
		{
			nodes.RemoveAt(Index);
		}

		private void NotifyCollectionChanged_CollectionChanged(object sender, NotifyCollectionChangedEventArgs e)
		{
			this.PropertyChanged?.Invoke(this, new PropertyChangedEventArgs("Nodes"));
			UpdateLayout();
		}

		public void NotifyPropertyChanged(string PropertyName)
		{
			this.PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(PropertyName));
		}
	}
}
