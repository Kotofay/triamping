using System.Collections.Generic;
using System.Windows.Controls;
using System.Windows.Markup;

namespace ChipStudio
{
	public partial class DSPBlockSelector : UserControl, IComponentConnector
	{
		public delegate void SelectionChangedEventHandler(int ValuesCount);

		private readonly List<string> EventBlockSelectorList = new List<string>();

		private readonly List<SchemaBlock_DSPCell> EventBlocks = new List<SchemaBlock_DSPCell>();

		public string Title { get; set; }

		public int DefaultBlock { get; set; }

		public event SelectionChangedEventHandler SelectionChanged;

		public DSPBlockSelector()
		{
			InitializeComponent();
			base.DataContext = this;
		}

		public ConnectionNode ActiveConnectionNode()
		{
			if (EventBlockSelector.SelectedIndex != -1)
			{
				if (EventBlockSelectorList[EventBlockSelector.SelectedIndex].IndexOf("EN") != -1)
				{
					return EventBlocks[EventBlockSelector.SelectedIndex].GetAnchorConnectionNode(1);
				}
				return EventBlocks[EventBlockSelector.SelectedIndex].GetAnchorConnectionNode(0);
			}
			return null;
		}

		public void Update(SchemaBlock_DSPCell[] Blocks, Schema.UpdateOptions Option)
		{
			int num = EventBlockSelector.SelectedIndex;
			EventBlockSelector.ItemsSource = null;
			List<SchemaBlock_DSPCell> list = new List<SchemaBlock_DSPCell>();
			list.AddRange(Blocks);
			switch (Option)
			{
			case Schema.UpdateOptions.Init:
			{
				for (int k = 0; k < list.Count; k++)
				{
					AddEventBlockFromCell(list[k]);
					EventBlocks.Add(list[k]);
					if (list[k].IsBypassable)
					{
						EventBlocks.Add(list[k]);
					}
				}
				num = DefaultBlock;
				break;
			}
			case Schema.UpdateOptions.Add:
				AddEventBlockFromCell(list[list.Count - 1]);
				EventBlocks.Add(list[list.Count - 1]);
				if (list[list.Count - 1].IsBypassable)
				{
					EventBlocks.Add(list[list.Count - 1]);
				}
				break;
			case Schema.UpdateOptions.Remove:
			{
				bool flag = false;
				for (int i = 0; i < list.Count; i++)
				{
					if (list[i].IsBypassable)
					{
						if (i != list.Count - 1)
						{
							list.Insert(i + 1, list[i]);
						}
						else
						{
							list.Add(list[i]);
						}
						i++;
					}
				}
				for (int j = 0; j < list.Count; j++)
				{
					if (!(list[j].Title + list[j].DSPTitle != EventBlocks[j].Title + EventBlocks[j].DSPTitle))
					{
						continue;
					}
					bool flag2 = false;
					if (EventBlocks[j].IsBypassable)
					{
						EventBlocks.RemoveAt(j + 1);
						EventBlockSelectorList.RemoveAt(j + 1);
						flag2 = true;
					}
					EventBlocks.RemoveAt(j);
					EventBlockSelectorList.RemoveAt(j);
					if (num == j)
					{
						num = 0;
					}
					else if (num > j)
					{
						num--;
						if (flag2)
						{
							num--;
						}
					}
					flag = true;
					break;
				}
				if (flag)
				{
					break;
				}
				if (num == EventBlocks.Count - 1)
				{
					num--;
					if (EventBlocks[EventBlocks.Count - 1].IsBypassable)
					{
						num--;
					}
				}
				if (EventBlocks[EventBlocks.Count - 1].IsBypassable)
				{
					EventBlocks.RemoveAt(EventBlocks.Count - 1);
					EventBlockSelectorList.RemoveAt(EventBlockSelectorList.Count - 1);
				}
				EventBlocks.RemoveAt(EventBlocks.Count - 1);
				EventBlockSelectorList.RemoveAt(EventBlockSelectorList.Count - 1);
				break;
			}
			}
			DefaultBlock = num;
			EventBlockSelector.ItemsSource = EventBlockSelectorList;
			EventBlockSelector.SelectionChanged -= BlockSelector_SelectionChanged;
			if (num == -1 && EventBlockSelectorList.Count != 0)
			{
				num = 0;
			}
			EventBlockSelector.SelectedIndex = num;
			EventBlockSelector.SelectionChanged += BlockSelector_SelectionChanged;
		}

		public int ActiveValuesCount()
		{
			int result = -1;
			if (EventBlockSelector.SelectedIndex != -1)
			{
				result = EventBlocks[EventBlockSelector.SelectedIndex].ValuesCount;
				if (EventBlockSelectorList[EventBlockSelector.SelectedIndex].IndexOf("EN") != -1)
				{
					result = EventBlocks[EventBlockSelector.SelectedIndex].EnValuesCount;
				}
			}
			return result;
		}

		private void AddEventBlockFromCell(SchemaBlock_DSPCell Cell)
		{
			EventBlockSelectorList.Add("REG " + Cell.Title + " " + Cell.DSPTitle);
			if (Cell.IsBypassable)
			{
				EventBlockSelectorList.Add("EN " + Cell.Title + " " + Cell.DSPTitle);
			}
		}

		private void BlockSelector_SelectionChanged(object sender, SelectionChangedEventArgs e)
		{
			if (EventBlockSelector.SelectedIndex != -1)
			{
				DefaultBlock = EventBlockSelector.SelectedIndex;
				this.SelectionChanged?.Invoke(EventBlocks[EventBlockSelector.SelectedIndex].ValuesCount);
			}
		}
	}
}
