using System.Collections.Generic;
using System.IO;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Markup;

namespace ChipStudio
{
	public partial class USBSettings : Window, IComponentConnector
	{
		private static readonly string StudioSettingsFilter = (string)Application.Current.FindResource("StudioSettingsFilter");

		private static readonly string USBInfoProperty = "USBInfo";

		private static readonly string ValueStartSign = "[";

		private static readonly string ValueEndSign = "]";

		private const int USBPropertyIndex = 0;

		private const int USBVIDIndex = 1;

		private const int USBPIDIndex = 2;

		private const int USBManufactIndex = 3;

		private const int USBDevName1Index = 4;

		private int USBNameIndex;

		private readonly int SpeakerCount;

		private readonly int USBParamsCount = 4;

		public USBDeviceInfo Settings { get; }

		public USBSettings(string[] AudioDescription)
		{
			InitializeComponent();
			base.DataContext = this;
			SpeakerCount = AudioDescription.Length;
			Settings = new USBDeviceInfo(SpeakerCount);
			USBParamsCount += SpeakerCount;
			SpeakerConfSelector.ItemsSource = AudioDescription;
			SpeakerConfSelector.SelectedIndex = USBNameIndex;
		}

		private void CheckSettings()
		{
			if (USB_VIDBox.Text == null || USB_VIDBox.Text == "")
			{
				USB_VIDBox.Text = "0483";
			}
			if (USB_PIDBox.Text == null || USB_PIDBox.Text == "")
			{
				USB_PIDBox.Text = "A210";
			}
			if (ManufacturerBox.Text == null || ManufacturerBox.Text == "")
			{
				ManufacturerBox.Text = "ChipDip";
			}
		}

		private void UpdateLastDeviceName()
		{
			if (SpeakerConfSelector.SelectedIndex != -1)
			{
				Settings.DeviceNames[USBNameIndex] = DeviceNameBox.Text;
				DeviceNameBox.Text = Settings.DeviceNames[SpeakerConfSelector.SelectedIndex];
				USBNameIndex = SpeakerConfSelector.SelectedIndex;
			}
		}

		private void SpeakerConfSelector_SelectionChanged(object sender, SelectionChangedEventArgs e)
		{
			UpdateLastDeviceName();
		}

		private void DownloadButton_Click(object sender, RoutedEventArgs e)
		{
			UpdateLastDeviceName();
			CheckSettings();
			Settings.VID = USB_VIDBox.Text;
			Settings.PID = USB_PIDBox.Text;
			Settings.Manufacturer = ManufacturerBox.Text;
			base.DialogResult = true;
		}

		private void CloseButton_Click(object sender, RoutedEventArgs e)
		{
			base.DialogResult = false;
		}

		private void OpenButton_Click(object sender, RoutedEventArgs e)
		{
			string text = FileDialog.Open(StudioSettingsFilter);
			if (text == null)
			{
				return;
			}
			List<string> list = new List<string>();
			using (StreamReader streamReader = File.OpenText(text))
			{
				while (streamReader.Peek() >= 0)
				{
					list.Add(streamReader.ReadLine());
				}
			}
			int num = FindPropertyIndex(list, USBInfoProperty);
			if (num != -1)
			{
				string[] array = Shared.ConvertFileFieldToValues(list[num]);
				USB_VIDBox.Text = array[1];
				USB_PIDBox.Text = array[2];
				ManufacturerBox.Text = array[3];
				int num2 = array.Length - 4;
				int num3 = ((SpeakerCount <= num2) ? SpeakerCount : num2);
				for (int i = 0; i < num3; i++)
				{
					Settings.DeviceNames[i] = array[4 + i];
				}
				USBNameIndex = 0;
				DeviceNameBox.Text = Settings.DeviceNames[USBNameIndex];
				SpeakerConfSelector.SelectedIndex = USBNameIndex;
			}
		}

		private void SaveButton_Click(object sender, RoutedEventArgs e)
		{
			string text = FileDialog.Save(StudioSettingsFilter);
			if (text != null)
			{
				UpdateLastDeviceName();
				CheckSettings();
				string[] array = new string[USBParamsCount];
				array[0] = USBInfoProperty;
				array[1] = USB_VIDBox.Text;
				array[2] = USB_PIDBox.Text;
				array[3] = ManufacturerBox.Text;
				for (int i = 0; i < SpeakerCount; i++)
				{
					array[4 + i] = Settings.DeviceNames[i];
				}
				using (StreamWriter streamWriter = File.CreateText(text))
				{
					streamWriter.WriteLine(ConvertValueToFileField(string.Join(";", array)));
				}
			}
		}

		private static string ConvertValueToFileField(string Input)
		{
			return ValueStartSign + Input + ValueEndSign;
		}

		private static int FindPropertyIndex(List<string> PropertyList, string PropertyName)
		{
			int result = -1;
			for (int i = 0; i < PropertyList.Count; i++)
			{
				if (PropertyList[i].IndexOf(PropertyName) != -1)
				{
					result = i;
					break;
				}
			}
			return result;
		}
	}
}
