﻿// Decompiled with JetBrains decompiler
// Type: ChipStudio.ConnectionNode
// Assembly: ChipStudio, Version=1.2.9.0, Culture=neutral, PublicKeyToken=null
// MVID: 334E3BEA-37C7-4274-8118-535AAEFA1546
// Assembly location: D:\DocAndSec\Desktop\AUDIO\ChipDip\ChipStudio_soft_v1.2.9\ChipStudio_v1.2.9.exe

#nullable disable
namespace ChipStudio;

public class ConnectionNode
{
  public string BlockName { get; }

  public int AnchorNumber { get; }

  public LinePoint AnchorPoint { get; }

  public Anchor.AnchorTypes AnchorType { get; }

  public ConnectionNode(
    string blockname,
    int anchornumber,
    LinePoint anchorpoint,
    Anchor.AnchorTypes anchortype)
  {
    this.BlockName = blockname;
    this.AnchorNumber = anchornumber;
    this.AnchorPoint = anchorpoint;
    this.AnchorType = anchortype;
  }
}
