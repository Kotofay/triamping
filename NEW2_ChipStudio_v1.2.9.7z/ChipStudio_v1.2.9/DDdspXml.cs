﻿// Decompiled with JetBrains decompiler
// Type: ChipStudio.DDdspXml
// Assembly: ChipStudio, Version=1.2.9.0, Culture=neutral, PublicKeyToken=null
// MVID: 334E3BEA-37C7-4274-8118-535AAEFA1546
// Assembly location: D:\DocAndSec\Desktop\AUDIO\ChipDip\ChipStudio_soft_v1.2.9\ChipStudio_v1.2.9.exe

using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Windows;
using System.Xml.Linq;

#nullable disable
namespace ChipStudio;

public class DDdspXml : IDDdsp
{
    private const string InterfaceString = "Interface";

    private const string IsSelfBootableString = "IsSelfBootable";

    private const string AdrLineStatesString = "AdrLineStates";

    private const string AdrValuesString = "AdrValues";

    private const string AreCellsConstantString = "AreCellsConstant";

    private const string ProjectFileFormatString = "ProjectFileFormat";

    private const string ConfigurationFileString = "ConfigurationFile";

    private const string ProjectFileFormatDefault = "(*.txt)|*.txt";

    private const string InternalAddressSizeString = "InternalAddressSize";

    private const byte Dsp_1_ByteAddressId = 254;

    private const byte Dsp_2_ByteAddressId = 253;

    private const byte Dsp_0_ByteAddressId = 252;

    private const byte BusAddressDefault = byte.MaxValue;

    private readonly uint BusAddress;

    private readonly string[] AdrLineStates;

    private readonly uint[] AdrValues;

    private readonly DSPCell[] cells;

    public bool IsLoaded { get; }

    public byte ID { get; }

    public string Interface { get; }

    public bool IsSelfBootable { get; }

    public string FileFormat { get; }

    public DSPCell[] Cells => cells;

    public bool AreCellsConstant { get; }

    public DDdspXml(string ModuleType)
    {
        if (!Directory.Exists(Shared.DDdspPath))
        {
            MessageBox.Show("Folder\n\r..." + Shared.DSPCodecFolder + "\n\r" + Shared.DoesNotExistString, "", MessageBoxButton.OK, MessageBoxImage.Hand);
            return;
        }
        string text = ModuleType + Shared.DDFileExt;
        string text2 = Shared.DDdspPath + Shared.FilePathSlash + text;
        string uri = text2;
        if (!File.Exists(text2))
        {
            MessageBox.Show("Device description file\n\r" + text + "\n\r" + Shared.DoesNotExistString, "", MessageBoxButton.OK, MessageBoxImage.Hand);
            return;
        }
        XDocument xDocument = XDocument.Load(text2);
        string text3 = xDocument.Element("DSP")?.Attribute("Base")?.Value;
        bool flag = false;
        if (text3 != null)
        {
            if (xDocument.Element("DSP")?.Element("Cells")?.Elements("Cell") != null)
            {
                flag = true;
            }
            text = text3 + Shared.DDFileExt;
            text2 = Shared.DDdspPath + Shared.FilePathSlash + text;
            if (!File.Exists(text2))
            {
                MessageBox.Show("Device description file\n\r" + text + "\n\r" + Shared.DoesNotExistString, "", MessageBoxButton.OK, MessageBoxImage.Hand);
                return;
            }
            xDocument = XDocument.Load(text2);
        }
        ID = (byte)(int.TryParse(xDocument.Element("DSP")?.Attribute("ID")?.Value, out var result) ? ((byte)result) : 254);
        if (ID == 254)
        {
            text3 = xDocument.Element("DSP")?.Attribute("InternalAddressSize")?.Value;
            if (text3 != null && int.TryParse(text3, out result))
            {
                switch (result)
                {
                    default:
                        ID = 254;
                        break;
                    case 0:
                        ID = 252;
                        break;
                    case 2:
                        ID = 253;
                        break;
                }
            }
        }
        text3 = xDocument.Element("DSP")?.Attribute("Interface")?.Value;
        Interface = ((text3 != null) ? text3 : "SPI");
        IsSelfBootable = bool.TryParse(xDocument.Element("DSP")?.Attribute("IsSelfBootable")?.Value, out var result2) && result2;
        text3 = xDocument.Element("DSP")?.Element("BusAddress")?.Attribute("Value")?.Value;
        BusAddress = ((text3 == null) ? 255u : (Shared.TryParseHEX(text3.Replace("0x", ""), out var result3) ? result3 : 255u));
        AdrLineStates = xDocument.Element("DSP")?.Element("BusAddress")?.Element("AdrLineStates")?.Value.Split(";"[0]);
        if (AdrLineStates != null)
        {
            AdrValues = (xDocument.Element("DSP")?.Element("BusAddress")?.Element("AdrValues")?.Value.Split(";"[0])).Select((string p) => (!Shared.TryParseHEX(p.Replace("0x", ""), out var result4)) ? BusAddress : result4).ToArray();
        }
        text3 = xDocument.Element("DSP")?.Element("ProjectFileFormat")?.Value;
        FileFormat = ((text3 != null) ? text3 : "(*.txt)|*.txt");
        AreCellsConstant = bool.TryParse(xDocument.Element("DSP")?.Element("Cells")?.Attribute("AreCellsConstant")?.Value, out result2) && result2;
        if (!GetCells(xDocument, out var XmlCells))
        {
            return;
        }
        if (flag)
        {
            if (!GetCells(XDocument.Load(uri), out var XmlCells2))
            {
                return;
            }
            XmlCells = XmlCells.Concat(XmlCells2).ToArray();
        }
        cells = XmlCells;
        IsLoaded = true;
    }

    public void BusAddressInfo(out uint BusAdr, out string[] AdrLineStates, out uint[] AdrValues)
    {
        BusAdr = BusAddress;
        AdrLineStates = this.AdrLineStates;
        AdrValues = this.AdrValues;
    }

    private bool GetCells(XDocument DspDoc, out DSPCell[] XmlCells)
    {
        XmlCells = null;
        bool result;
        bool result2;
        DSPCell.WriteTypes result3;
        ushort result4;
        ushort result5;
        var array = DspDoc.Element("DSP")?.Element("Cells")?.Elements("Cell")?.Select((XElement p) => new
        {
            Title = p.Attribute("Title")?.Value,
            IsControllable = (!bool.TryParse(p.Attribute("IsControllable")?.Value, out result) || result),
            IsBypassable = (bool.TryParse(p.Attribute("IsBypassable")?.Value, out result2) && result2),
            WriteType = ((!DSPCell.TryParse(p.Attribute("WriteType")?.Value, out result3)) ? DSPCell.WriteTypes.BlockWrite : result3),
            Parameters = p.Element("Parameters")?.Elements("Parameter")?.Select((XElement e) => new
            {
                Name = e.Element("Name")?.Value,
                Address = (ushort)(ushort.TryParse(e.Element("Address")?.Value, out result4) ? result4 : 0),
                Size = (ushort)((!ushort.TryParse(e.Element("Size")?.Value, out result5)) ? 1 : result5)
            }).ToArray()
        }).ToArray();
        if (array != null && array.Count() != 0)
        {
            XmlCells = new DSPCell[array.Count()];
            for (int i = 0; i < array.Count(); i++)
            {
                XmlCells[i] = new DSPCell(array[i].Title)
                {
                    IsControllable = array[i].IsControllable,
                    IsBypassable = array[i].IsBypassable,
                    WriteType = array[i].WriteType
                };
                var parameters = array[i].Parameters;
                foreach (var anon in parameters)
                {
                    XmlCells[i].ParamsFromFile.Add(new DSPCellParameter(anon.Name, anon.Address, anon.Size));
                }
                XmlCells[i].CloneParamsFromFileToParamsUsed();
            }
        }
        return true;
    }
}
