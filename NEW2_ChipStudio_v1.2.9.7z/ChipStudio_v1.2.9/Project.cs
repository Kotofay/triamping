﻿// Decompiled with JetBrains decompiler
// Type: ChipStudio.Project
// Assembly: ChipStudio, Version=1.2.9.0, Culture=neutral, PublicKeyToken=null
// MVID: 334E3BEA-37C7-4274-8118-535AAEFA1546
// Assembly location: D:\DocAndSec\Desktop\AUDIO\ChipDip\ChipStudio_soft_v1.2.9\ChipStudio_v1.2.9.exe

using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Windows;
using System.Windows.Controls;
using System.Xml.Linq;

#nullable disable
namespace ChipStudio;

public class Project
{
    private static readonly string SoftwareVersion = (string)Application.Current.FindResource("SoftwareVersion");

    private const string RootElement = "Project";

    private const string ModuleTypeElement = "Module";

    private const string CtrlGpioFuncsElement = "GpioFuncs";

    private const string DSPBootElement = "Boot";

    private const string TransferElement = "Transfer";

    private const string AudioStatusString = "AudioStatus";

    private const string BlockString = "Block";

    private const string ColorsString = "Colors";

    private const string ConnectionsString = "Connections";

    private const string DSPCellsString = "DSPCells";

    private const string DSPCellIndexString = "DSPCellIndex";

    private const string DSPModeString = "DSPMode";

    private const string EnableDataString = "EnableData";

    private const string FixProjectString = "FixProject";

    private const string FreqIndicationString = "FreqIndication";

    private const string GenSelectString = "GenSelect";

    private const string IndexString = "Index";

    private const string LevelString = "Level";

    private const string IndicationTypeString = "IndicationType";

    private const string IndicationModeString = "IndicationMode";

    private const string IsPwrOnString = "IsPwrOn";

    private const string IsSelfBootedString = "SelfBooted";

    private const string LEDsString = "LEDs";

    private const string LEDsCountString = "LEDsCount";

    private const string BytesCountString = "BytesCount";

    private const string PeriodString = "Period";

    private const string LocationString = "Location";

    private const string LocationX = "X";

    private const string LocationY = "Y";

    private const string MuteGpioString = "MuteGpio";

    private const string NodeString = "Node";

    private const string NumberString = "Number";

    private const string ParamsFromFileString = "ParamsFromFile";

    private const string ParamsUsedString = "ParamsUsed";

    private const string PortString = "Port";

    private const string PwrKeyString = "PwrKey";

    private const string RegulationDataString = "RegulationData";

    private const string ResIndicationString = "ResIndication";

    private const string StatesCountString = "StatesCount";

    private const string TvOffString = "TvOff";

    private const string TvOnString = "TvOn";

    private const string VolGpioString = "VolGpio";

    private const string ModeString = "Mode";

    private const string ChipStudioProjectExt = ".cspro";

    private static readonly CultureInfo NumericStringCulture = CultureInfo.InvariantCulture;

    public string Path { get; }

    public Project(string path)
    {
        Path = path;
    }

    public bool Open(out ISchemaElement[] Elements)
    {
        if (!IsNewFormatFile(Path))
        {
            return OpenOldFormat(Path, out Elements);
        }
        return OpenNewFormat(XDocument.Load(Path), out Elements);
    }

    public void Save(UIElementCollection Schema)
    {
        XDocument xDocument = new XDocument(new XElement("Project", new XElement("Version", SoftwareVersion)));
        if (ExtractBlocks(Schema, SchemaBlock.SchemaBlockTypes.Controller, out var Blocks))
        {
            xDocument.Root.Add(Controller(Blocks[0]));
        }
        Func<ISchemaElement[], XElement>[] array = new Func<ISchemaElement[], XElement>[7] { DSPGroup, DSPCellGroup, LEDsGroup, PixelLEDsGroup, ReadsGroup, ComparatorsGroup, CommentsGroup };
        SchemaBlock.SchemaBlockTypes[] array2 = new SchemaBlock.SchemaBlockTypes[7]
        {
                SchemaBlock.SchemaBlockTypes.DSP,
                SchemaBlock.SchemaBlockTypes.DSPCell,
                SchemaBlock.SchemaBlockTypes.LED,
                SchemaBlock.SchemaBlockTypes.PixelLED,
                SchemaBlock.SchemaBlockTypes.Read,
                SchemaBlock.SchemaBlockTypes.Comparator,
                SchemaBlock.SchemaBlockTypes.Comment
        };
        for (int i = 0; i < array2.Length; i++)
        {
            if (ExtractBlocks(Schema, array2[i], out Blocks))
            {
                xDocument.Root.Add(array[i](Blocks));
            }
        }
        if (ExtractConnections(Schema, out Blocks))
        {
            xDocument.Root.Add(ConnectionsGroup(Blocks));
        }
        xDocument.Save(Path);
    }

    private static bool IsNewFormatFile(string FilePath)
    {
        return Shared.IsXMLFile(FilePath);
    }

    private static bool OpenNewFormat(XDocument ProjFile, out ISchemaElement[] SchElements)
    {
        SchElements = null;
        Func<XElement, ISchemaElement>[] array = new Func<XElement, ISchemaElement>[9] { TryParseController, TryParseDSP, TryParseDSPCellBlock, TryParseLED, TryParsePixelLED, TryParseRead, TryParseComparator, TryParseComment, TryParseConnection };
        string[] array2 = new string[9] { "Controller", "DSP", "DSPCells", "LEDs", "PixelLED", "Read", "Comparator", "Comment", "Connections" };
        List<ISchemaElement> list = new List<ISchemaElement>();
        for (int i = 0; i < array2.Length; i++)
        {
            XElement xElement = ProjFile.Element("Project").Element(array2[i]);
            if (xElement != null)
            {
                if (!TryParseSchemaElements(xElement, array[i], out var SchemaElements))
                {
                    return false;
                }
                list.AddRange(SchemaElements);
            }
        }
        SchElements = list.ToArray();
        return true;
    }

    private static bool TryParseSchemaElements(XElement ElementGroup, Func<XElement, ISchemaElement> TryParse, out ISchemaElement[] SchemaElements)
    {
        SchemaElements = (from e in ElementGroup.Elements("Block")
                          select TryParse(e)).ToArray();
        return SchemaElements.Where((ISchemaElement b) => b == null).ToArray().Length == 0;
    }

    private static ISchemaElement TryParseController(XElement Element)
    {
        SchemaBlock_Controller schemaBlock_Controller = new SchemaBlock_Controller(Element.Element("Module")?.Value);
        if (!schemaBlock_Controller.IsReady)
        {
            return null;
        }
        Func<XElement, SchemaBlock_Controller, bool>[] array = new Func<XElement, SchemaBlock_Controller, bool>[7] { CommonProperties, TryParseCtrlDelay, TryParseCtrlPixel, TryParseCtrlCLI, TryParseCtrlCEC, TryParseCtrlOptions, TryParseCtrlMute };
        for (int i = 0; i < array.Length; i++)
        {
            if (!array[i](Element, schemaBlock_Controller))
            {
                return null;
            }
        }
        schemaBlock_Controller.SetGPIOFunctions((from s in Element.Element("GpioFuncs")?.Value.Split(";"[0])
                                                 select int.TryParse(s, out var result) ? result : 0).ToArray());
        return schemaBlock_Controller;
    }

    private static ISchemaElement TryParseDSP(XElement Element)
    {
        SchemaBlock_DSP schemaBlock_DSP = new SchemaBlock_DSP(Element.Element("Module")?.Value);
        if (!schemaBlock_DSP.IsReady)
        {
            return null;
        }
        Func<XElement, SchemaBlock_DSP, bool>[] array = new Func<XElement, SchemaBlock_DSP, bool>[3] { CommonProperties, TryParseDSPBoot, TryParseDSPCells };
        for (int i = 0; i < array.Length; i++)
        {
            if (!array[i](Element, schemaBlock_DSP))
            {
                return null;
            }
        }
        schemaBlock_DSP.SetBusAddress((byte)(int.TryParse(Element.Element("BusAddress")?.Value, out var result) ? ((byte)result) : 0));
        schemaBlock_DSP.IsSelfBooted = bool.TryParse(Element.Element("SelfBooted")?.Value, out var result2) && result2;
        return schemaBlock_DSP;
    }

    private static ISchemaElement TryParseDSPCellBlock(XElement Element)
    {
        SchemaBlock_DSPCell schemaBlock_DSPCell = new SchemaBlock_DSPCell();
        if (!CommonProperties(Element, schemaBlock_DSPCell))
        {
            return null;
        }
        schemaBlock_DSPCell.DSPTitle = Element.Element("DSP")?.Value;
        string text = Element.Element("RegulationData")?.Value;
        schemaBlock_DSPCell.SetData((text != "") ? (from d in text.Split(";"[0]).ToArray()
                                                    select (byte)(int.TryParse(d, out var result) ? ((byte)result) : 0)).ToArray() : null);
        text = Element.Element("EnableData")?.Value;
        schemaBlock_DSPCell.SetEnData((text != "") ? (from d in text.Split(";"[0]).ToArray()
                                                      select (byte)(int.TryParse(d, out var result2) ? ((byte)result2) : 0)).ToArray() : null);
        return schemaBlock_DSPCell;
    }

    private static ISchemaElement TryParseLED(XElement Element)
    {
        SchemaBlock_LED schemaBlock_LED = new SchemaBlock_LED();
        if (!CommonProperties(Element, schemaBlock_LED))
        {
            return null;
        }
        schemaBlock_LED.SetMode(!bool.TryParse(Element.Element("DSPMode")?.Value, out var result) || result);
        schemaBlock_LED.SetDefaultBlockIndex(int.TryParse(Element.Element("DSPCellIndex")?.Value, out var result2) ? result2 : 0);
        schemaBlock_LED.SetData((from d in Element.Element("Data")?.Value?.Split(";"[0]).ToArray()
                                 select (byte)(int.TryParse(d, out var result3) ? ((byte)result3) : 0)).ToArray());
        return schemaBlock_LED;
    }

    private static ISchemaElement TryParsePixelLED(XElement Element)
    {
        SchemaBlock_PixelLED schemaBlock_PixelLED = new SchemaBlock_PixelLED();
        Func<XElement, SchemaBlock_PixelLED, bool>[] array = new Func<XElement, SchemaBlock_PixelLED, bool>[2] { CommonProperties, TryParsePixelSettings };
        for (int i = 0; i < array.Length; i++)
        {
            if (!array[i](Element, schemaBlock_PixelLED))
            {
                return null;
            }
        }
        if (!int.TryParse(Element.Element("DSPCellIndex")?.Value, out var result))
        {
            return null;
        }
        schemaBlock_PixelLED.SetDefaultBlockIndex(result);
        schemaBlock_PixelLED.SetColors(Element.Element("Colors")?.Value.Split(";"[0]));
        return schemaBlock_PixelLED;
    }

    private static ISchemaElement TryParseRead(XElement Element)
    {
        SchemaBlock_Read schemaBlock_Read = new SchemaBlock_Read();
        if (!CommonProperties(Element, schemaBlock_Read))
        {
            return null;
        }
        schemaBlock_Read.DSPIndex = (int.TryParse(Element.Element("DSP")?.Value, out var result) ? result : 0);
        schemaBlock_Read.SetAddress(Element.Element("Address")?.Value);
        schemaBlock_Read.SetBytesCount(Element.Element("BytesCount")?.Value);
        schemaBlock_Read.PeriodIndex = (int.TryParse(Element.Element("Period")?.Value, out result) ? result : 3);
        return schemaBlock_Read;
    }

    private static ISchemaElement TryParseComparator(XElement Element)
    {
        SchemaBlock_Comparator schemaBlock_Comparator = new SchemaBlock_Comparator();
        if (!CommonProperties(Element, schemaBlock_Comparator))
        {
            return null;
        }
        schemaBlock_Comparator.SetMask(Element.Element("Mask")?.Value);
        schemaBlock_Comparator.SetValue(Element.Element("Value")?.Value);
        schemaBlock_Comparator.Mode = ((!int.TryParse(Element.Element("Mode")?.Value, out var result)) ? 1 : result);
        return schemaBlock_Comparator;
    }

    private static ISchemaElement TryParseComment(XElement Element)
    {
        SchemaBlock_Comment schemaBlock_Comment = new SchemaBlock_Comment();
        if (!CommonProperties(Element, schemaBlock_Comment))
        {
            return null;
        }
        schemaBlock_Comment.Comment = Element.Element("Value")?.Value;
        return schemaBlock_Comment;
    }

    private static ISchemaElement TryParseConnection(XElement Element)
    {
        Connection connection = new Connection();
        ConnectionNode[] array = Element.Elements("Node")?.Select((XElement n) => TryParseNode(n)).ToArray();
        foreach (ConnectionNode connectionNode in array)
        {
            if (connectionNode == null)
            {
                return null;
            }
            connection.AddNode(connectionNode);
        }
        return connection;
    }

    private static ConnectionNode TryParseNode(XElement Element)
    {
        if (!int.TryParse(Element.Element("Number")?.Value, out var result))
        {
            return null;
        }
        if (!Anchor.TryParseAnchorType(Element.Element("Type")?.Value, out var result2))
        {
            return null;
        }
        if (!TryParseStringToDouble(Element.Element("Location")?.Attribute("X")?.Value, out var Result))
        {
            return null;
        }
        if (!TryParseStringToDouble(Element.Element("Location")?.Attribute("Y")?.Value, out var Result2))
        {
            return null;
        }
        return new ConnectionNode(Element.Element("Name")?.Value, result, new LinePoint
        {
            X = Result,
            Y = Result2
        }, result2);
    }

    private static bool TryParsePixelSettings(XElement Element, SchemaBlock_PixelLED Block)
    {
        if (!int.TryParse(Element.Element("LEDsCount")?.Value, out var result))
        {
            return false;
        }
        if (!int.TryParse(Element.Element("StatesCount")?.Value, out var result2))
        {
            return false;
        }
        if (!PixelLEDBlock.TryParseIndicationType(Element.Element("IndicationType")?.Value, out var result3))
        {
            return false;
        }
        if (!PixelLEDBlock.TryParseIndicationMode(Element.Element("IndicationMode")?.Value, out var result4))
        {
            return false;
        }
        Block.Settings = new PixelLEDBlock
        {
            LEDsCount = result,
            StatesCount = result2,
            IndicationType = result3,
            IndicationMode = result4
        };
        return true;
    }

    private static bool TryParseDSPBoot(XElement Element, SchemaBlock_DSP Block)
    {
        var array = Element.Element("Boot")?.Elements("Transfer")?.Select((XElement t) => new
        {
            Type = t.Element("Type")?.Value,
            Address = t.Element("Address")?.Value,
            AddrIncr = t.Element("AddrIncr")?.Value,
            Size = t.Element("Size")?.Value,
            Data = t.Element("Data")?.Value?.Split(";"[0]).ToArray()
        }).ToArray();
        DataTransfer[] array2 = new DataTransfer[array.Length];
        for (int i = 0; i < array.Length; i++)
        {
            if (!int.TryParse(array[i].Address, out var result))
            {
                return false;
            }
            if (!int.TryParse(array[i].Size, out var result2))
            {
                return false;
            }
            if (!int.TryParse(array[i].AddrIncr, out var result3))
            {
                return false;
            }
            if (!DataTransfer.TryParseType(array[i].Type, out var result4))
            {
                return false;
            }
            array2[i] = new DataTransfer((ushort)result, (ushort)result2, (byte)result3, result4)
            {
                Data = array[i].Data.Select((string d) => (byte)(int.TryParse(d, out var result5) ? ((byte)result5) : 0)).ToArray()
            };
        }
        Block.SetBoot(array2);
        return true;
    }

    private static bool TryParseDSPCells(XElement Element, SchemaBlock_DSP Block)
    {
        var array = Element.Element("Cells")?.Elements("Cell")?.Select((XElement t) => new
        {
            Title = t.Element("Title")?.Value,
            DSPTitle = t.Element("DSP")?.Value,
            IsControllable = t.Element("IsControllable")?.Value,
            IsBypassable = t.Element("IsBypassable")?.Value,
            ParamsUsed = t.Element("ParamsUsed")?.Elements("Parameter").ToArray(),
            ParamsFromFile = t.Element("ParamsFromFile")?.Elements("Parameter").ToArray()
        }).ToArray();
        DSPCell[] array2 = new DSPCell[array.Length];
        for (int i = 0; i < array.Length; i++)
        {
            array2[i] = new DSPCell(array[i].Title)
            {
                DSPTitle = array[i].DSPTitle
            };
            if (!bool.TryParse(array[i].IsControllable, out var result))
            {
                return false;
            }
            array2[i].IsControllable = result;
            if (!bool.TryParse(array[i].IsBypassable, out result))
            {
                return false;
            }
            array2[i].IsBypassable = result;
            if (!TryParseParams(array[i].ParamsUsed, out var Params))
            {
                return false;
            }
            array2[i].ParamsUsed = new List<DSPCellParameter>(Params);
            if (!TryParseParams(array[i].ParamsFromFile, out Params))
            {
                return false;
            }
            array2[i].ParamsFromFile = new List<DSPCellParameter>(Params);
        }
        Block.SetCells(array2);
        return true;
    }

    private static bool TryParseParams(XElement[] ParamElements, out DSPCellParameter[] Params)
    {
        var array = ParamElements.Select((XElement t) => new
        {
            Name = t.Element("Name")?.Value,
            Address = t.Element("Address")?.Value,
            Size = t.Element("Size")?.Value,
            Data = t.Element("Data")?.Value?.Split(";"[0]).ToArray()
        }).ToArray();
        Params = new DSPCellParameter[array.Length];
        int Value;
        for (int i = 0; i < array.Length; i++)
        {
            Params[i] = new DSPCellParameter
            {
                Name = array[i].Name
            };
            if (!int.TryParse(array[i].Address, out Value))
            {
                return false;
            }
            Params[i].Address = (ushort)Value;
            if (!int.TryParse(array[i].Size, out Value))
            {
                return false;
            }
            Params[i].Size = (ushort)Value;
            Params[i].Data = array[i].Data.Select((string d) => (byte)(int.TryParse(d, out Value) ? ((byte)Value) : 0)).ToArray();
        }
        return true;
    }

    private static bool TryParseCtrlDelay(XElement Element, SchemaBlock_Controller Block)
    {
        if (!bool.TryParse(Element.Element("Delay")?.Attribute("IsEnabled")?.Value, out var result))
        {
            return false;
        }
        if (!int.TryParse(Element.Element("Delay")?.Attribute("Index")?.Value, out var result2))
        {
            return false;
        }
        Block.SetStartDelayParams(result, result2);
        return true;
    }

    private static bool TryParseCtrlPixel(XElement Element, SchemaBlock_Controller Block)
    {
        XElement xElement = Element.Element("PixelLED");
        if (xElement != null)
        {
            Block.PixelSettings = new PixelModule
            {
                IsEnabled = (bool.TryParse(xElement.Attribute("IsEnabled")?.Value, out var result) && result),
                PixelType = (PixelModule.TryParse(xElement.Attribute("Type")?.Value, out var result2) ? result2 : PixelModule.PixelTypes.RGB),
                IsPwrOnEnabled = (bool.TryParse(xElement.Attribute("IsPwrOn")?.Value, out var result3) && result3)
            };
        }
        return true;
    }

    private static bool TryParseCtrlCLI(XElement Element, SchemaBlock_Controller Block)
    {
        XElement xElement = Element.Element("CLI");
        if (xElement != null)
        {
            Block.CLISettings = new CLIModule
            {
                IsEnabled = (bool.TryParse(xElement.Attribute("IsEnabled")?.Value, out var result) && result)
            };
        }
        return true;
    }

    private static bool TryParseCtrlCEC(XElement Element, SchemaBlock_Controller Block)
    {
        XElement xElement = Element.Element("CEC");
        if (xElement != null)
        {
            Block.CECSettings = new CEC
            {
                IsEnabled = (bool.TryParse(xElement.Element("IsEnabled")?.Value, out var result) && result),
                PortNumber = ((!int.TryParse(xElement.Element("Port")?.Value, out var result2)) ? 1 : result2),
                Name = xElement.Element("Name")?.Value,
                VolumeGpio = (int.TryParse(xElement.Element("VolGpio")?.Value, out result2) ? result2 : 0),
                MuteGpio = (int.TryParse(xElement.Element("MuteGpio")?.Value, out result2) ? result2 : 0),
                IsTVonEnabled = (bool.TryParse(xElement.Element("TvOn")?.Value, out result) && result),
                IsTVoffEnabled = (bool.TryParse(xElement.Element("TvOff")?.Value, out result) && result),
                IsAudioStatusEnabled = (bool.TryParse(xElement.Element("AudioStatus")?.Value, out result) && result)
            };
        }
        return true;
    }

    private static bool TryParseCtrlOptions(XElement Element, SchemaBlock_Controller Block)
    {
        XElement xElement = Element.Element("Options");
        if (xElement != null)
        {
            Block.Options = new ControllerOptions
            {
                IsGenSelectionEnabled = (bool.TryParse(xElement.Element("GenSelect")?.Value, out var result) && result),
                IsFreqIndicationEnabled = (bool.TryParse(xElement.Element("FreqIndication")?.Value, out result) && result),
                IsResIndicationEnabled = (bool.TryParse(xElement.Element("ResIndication")?.Value, out result) && result),
                IsPwrKeyEnabled = (bool.TryParse(xElement.Element("PwrKey")?.Value, out result) && result),
                IsFixProjectEnabled = (bool.TryParse(xElement.Element("FixProject")?.Value, out result) && result)
            };
        }
        return true;
    }

    private static bool TryParseCtrlMute(XElement Element, SchemaBlock_Controller Block)
    {
        XElement xElement = Element.Element("Mute");
        if (xElement != null)
        {
            Block.MuteIndex = (int.TryParse(xElement.Attribute("Index")?.Value, out var result) ? result : 0);
            Block.MuteLevel = (int.TryParse(xElement.Attribute("Level")?.Value, out var result2) ? result2 : 0);
        }
        return true;
    }

    private static bool CommonProperties(XElement Element, SchemaBlock Block)
    {
        Block.Title = Element.Element("Title")?.Value;
        if (!TryParseStringToDouble(Element.Element("Location")?.Attribute("X")?.Value, out var Result))
        {
            return false;
        }
        if (!TryParseStringToDouble(Element.Element("Location")?.Attribute("Y")?.Value, out var Result2))
        {
            return false;
        }
        Block.UpperLeftPoint = new Point(Result, Result2);
        return true;
    }

    private static bool ExtractBlocks(UIElementCollection Schema, SchemaBlock.SchemaBlockTypes Type, out ISchemaElement[] Blocks)
    {
        ISchemaElement[] array = (from b in Schema.OfType<SchemaBlock>()
                                  where b.BlockType == Type
                                  select b).ToArray();
        Blocks = array;
        return Blocks.Length != 0;
    }

    private static bool ExtractConnections(UIElementCollection Schema, out ISchemaElement[] Connects)
    {
        Connects = (from e in Schema.OfType<ISchemaElement>()
                    where e.ElementType == Shared.ElementTypeConnection
                    select e).ToArray();
        return Connects.Length != 0;
    }

    private static XElement Controller(ISchemaElement Block)
    {
        return new XElement("Controller", new XElement("Block", CommonElements(Block as SchemaBlock_Controller), ControllerSpecific(Block as SchemaBlock_Controller)));
    }

    private static XElement DSPGroup(ISchemaElement[] Blocks)
    {
        XName name = "DSP";
        object[] content = Blocks.Select((ISchemaElement b) => DSPElement(b as SchemaBlock_DSP)).ToArray();
        return new XElement(name, content);
    }

    private static XElement DSPElement(SchemaBlock_DSP Block)
    {
        return new XElement("Block", CommonElements(Block), DSPSpecific(Block));
    }

    private static XElement DSPCellGroup(ISchemaElement[] Blocks)
    {
        XName name = "DSPCells";
        object[] content = Blocks.Select((ISchemaElement b) => DSPCellElement(b as SchemaBlock_DSPCell)).ToArray();
        return new XElement(name, content);
    }

    private static XElement DSPCellElement(SchemaBlock_DSPCell Block)
    {
        return new XElement("Block", CommonElements(Block), DSPCellSpecific(Block));
    }

    private static XElement LEDsGroup(ISchemaElement[] Blocks)
    {
        XName name = "LEDs";
        object[] content = Blocks.Select((ISchemaElement b) => LEDElement(b as SchemaBlock_LED)).ToArray();
        return new XElement(name, content);
    }

    private static XElement LEDElement(SchemaBlock_LED Block)
    {
        return new XElement("Block", CommonElements(Block), LEDSpecific(Block));
    }

    private static XElement PixelLEDsGroup(ISchemaElement[] Blocks)
    {
        XName name = "PixelLED";
        object[] content = Blocks.Select((ISchemaElement b) => PexelLEDElement(b as SchemaBlock_PixelLED)).ToArray();
        return new XElement(name, content);
    }

    private static XElement PexelLEDElement(SchemaBlock_PixelLED Block)
    {
        return new XElement("Block", CommonElements(Block), PixelLEDSpecific(Block));
    }

    private static XElement ReadsGroup(ISchemaElement[] Blocks)
    {
        XName name = "Read";
        object[] content = Blocks.Select((ISchemaElement b) => ReadElement(b as SchemaBlock_Read)).ToArray();
        return new XElement(name, content);
    }

    private static XElement ReadElement(SchemaBlock_Read Block)
    {
        return new XElement("Block", CommonElements(Block), ReadSpecific(Block));
    }

    private static XElement ComparatorsGroup(ISchemaElement[] Blocks)
    {
        XName name = "Comparator";
        object[] content = Blocks.Select((ISchemaElement b) => ComparatorElement(b as SchemaBlock_Comparator)).ToArray();
        return new XElement(name, content);
    }

    private static XElement CommentsGroup(ISchemaElement[] Blocks)
    {
        XName name = "Comment";
        object[] content = Blocks.Select((ISchemaElement b) => CommentElement(b as SchemaBlock_Comment)).ToArray();
        return new XElement(name, content);
    }

    private static XElement ComparatorElement(SchemaBlock_Comparator Block)
    {
        return new XElement("Block", CommonElements(Block), ComparatorSpecific(Block));
    }

    private static XElement CommentElement(SchemaBlock_Comment Block)
    {
        return new XElement("Block", CommonElements(Block), CommentSpecific(Block));
    }

    private static XElement ConnectionsGroup(ISchemaElement[] Blocks)
    {
        XName name = "Connections";
        object[] content = Blocks.Select((ISchemaElement b) => ConnectionElement(b as Connection)).ToArray();
        return new XElement(name, content);
    }

    private static XElement ConnectionElement(Connection Element)
    {
        XName name = "Block";
        object[] content = Element.Nodes.Select((ConnectionNode n) => NodeElement(n)).ToArray();
        return new XElement(name, content);
    }

    private static XElement[] ControllerSpecific(SchemaBlock_Controller Block)
    {
        Block.GetStartDelayParams(out var IsDelayActive, out var DelayIndex);
        return new XElement[8]
        {
                new XElement("Module", Block.Module),
                CtrlGpioFuncs(Block.GetGPIOFunctions()),
                CtrlDelay(IsDelayActive, DelayIndex),
                CtrlPixel(Block.PixelSettings),
                CtrlCLI(Block.CLISettings),
                CtrlCEC(Block.CECSettings),
                CtrlOptions(Block.Options),
                CtrlMute(Block.MuteIndex, Block.MuteLevel)
        };
    }

    private static XElement[] DSPSpecific(SchemaBlock_DSP Block)
    {
        return new XElement[5]
        {
                new XElement("Module", Block.Module),
                new XElement("BusAddress", Block.GetBusAddress().ToString()),
                new XElement("SelfBooted", Block.IsSelfBooted.ToString()),
                DSPBoot(Block.GetBoot()),
                DSPCells(Block.GetCells())
        };
    }

    private static XElement[] DSPCellSpecific(SchemaBlock_DSPCell Block)
    {
        return new XElement[3]
        {
                new XElement("DSP", Block.DSPTitle),
                new XElement("RegulationData", string.Join(";", from d in Block.GetData()
                    select d.ToString())),
                new XElement("EnableData", string.Join(";", from d in Block.GetEnData()
                    select d.ToString()))
        };
    }

    private static XElement[] LEDSpecific(SchemaBlock_LED Block)
    {
        return new XElement[3]
        {
                new XElement("DSPMode", Block.DSPMode.ToString()),
                new XElement("DSPCellIndex", Block.GetDefaultBlockIndex().ToString()),
                new XElement("Data", string.Join(";", from d in Block.GetData()
                    select d.ToString()))
        };
    }

    private static XElement[] PixelLEDSpecific(SchemaBlock_PixelLED Block)
    {
        PixelLEDBlock settings = Block.Settings;
        return new XElement[6]
        {
                new XElement("LEDsCount", settings.LEDsCount.ToString()),
                new XElement("StatesCount", settings.StatesCount.ToString()),
                new XElement("IndicationType", settings.IndicationType.ToString()),
                new XElement("IndicationMode", settings.IndicationMode.ToString()),
                new XElement("DSPCellIndex", Block.GetDefaultBlockIndex().ToString()),
                new XElement("Colors", string.Join(";", Block.GetColors()))
        };
    }

    private static XElement[] ReadSpecific(SchemaBlock_Read Block)
    {
        return new XElement[4]
        {
                new XElement("DSP", Block.DSPIndex.ToString()),
                new XElement("Address", Block.GetAddressInput()),
                new XElement("BytesCount", Block.GetBytesCountInput()),
                new XElement("Period", Block.PeriodIndex.ToString())
        };
    }

    private static XElement[] ComparatorSpecific(SchemaBlock_Comparator Block)
    {
        return new XElement[3]
        {
                new XElement("Mask", Block.GetMaskInput()),
                new XElement("Value", Block.GetValueInput()),
                new XElement("Mode", Block.Mode)
        };
    }

    private static XElement[] CommentSpecific(SchemaBlock_Comment Block)
    {
        return new XElement[1]
        {
                new XElement("Value", Block.Comment)
        };
    }

    private static XElement CtrlGpioFuncs(byte[] Funcs)
    {
        return new XElement("GpioFuncs", string.Join(";", Funcs.Select((byte v) => v.ToString())));
    }

    private static XElement CtrlDelay(bool IsActive, int Index)
    {
        return new XElement("Delay", new XAttribute("IsEnabled", IsActive.ToString()), new XAttribute("Index", Index.ToString()));
    }

    private static XElement CtrlPixel(PixelModule Settings)
    {
        if (Settings == null)
        {
            return null;
        }
        return new XElement("PixelLED", new XAttribute("IsEnabled", Settings.IsEnabled.ToString()), new XAttribute("Type", Settings.PixelType.ToString()), new XAttribute("IsPwrOn", Settings.IsPwrOnEnabled.ToString()));
    }

    private static XElement CtrlCLI(CLIModule Settings)
    {
        if (Settings == null)
        {
            return null;
        }
        return new XElement("CLI", new XAttribute("IsEnabled", Settings.IsEnabled.ToString()));
    }

    private static XElement CtrlCEC(CEC Settings)
    {
        if (Settings == null)
        {
            return null;
        }
        return new XElement("CEC", new XElement("IsEnabled", Settings.IsEnabled.ToString()), new XElement("Port", Settings.PortNumber.ToString()), new XElement("Name", Settings.Name), new XElement("VolGpio", Settings.VolumeGpio.ToString()), new XElement("MuteGpio", Settings.MuteGpio.ToString()), new XElement("TvOn", Settings.IsTVonEnabled.ToString()), new XElement("TvOff", Settings.IsTVoffEnabled.ToString()), new XElement("AudioStatus", Settings.IsAudioStatusEnabled.ToString()));
    }

    private static XElement CtrlOptions(ControllerOptions Settings)
    {
        if (Settings == null)
        {
            return null;
        }
        return new XElement("Options", new XElement("GenSelect", Settings.IsGenSelectionEnabled.ToString()), new XElement("FreqIndication", Settings.IsFreqIndicationEnabled.ToString()), new XElement("ResIndication", Settings.IsResIndicationEnabled.ToString()), new XElement("PwrKey", Settings.IsPwrKeyEnabled.ToString()), new XElement("FixProject", Settings.IsFixProjectEnabled.ToString()));
    }

    private static XElement CtrlMute(int Index, int Level)
    {
        if (Index == -1)
        {
            return null;
        }
        return new XElement("Mute", new XAttribute("Index", Index.ToString()), new XAttribute("Level", Level.ToString()));
    }

    private static XElement DSPBoot(List<DataTransfer> TXs)
    {
        XName name = "Boot";
        object[] content = TXs.Select((DataTransfer t) => TxElement(t)).ToArray();
        return new XElement(name, content);
    }

    private static XElement DSPCells(List<DSPCell> Cells)
    {
        XName name = "Cells";
        object[] content = Cells.Select((DSPCell s) => CellElement(s)).ToArray();
        return new XElement(name, content);
    }

    private static XElement TxElement(DataTransfer TX)
    {
        return new XElement("Transfer", new XElement("Type", TX.Type.ToString()), new XElement("Address", TX.Address.ToString()), new XElement("AddrIncr", TX.AddressIncrement.ToString()), new XElement("Size", TX.Size.ToString()), new XElement("Data", string.Join(";", TX.Data.Select((byte d) => d.ToString()))));
    }

    private static XElement CellElement(DSPCell Cell)
    {
        XName name = "Cell";
        object[] obj = new object[6]
        {
                new XElement("Title", Cell.Title),
                new XElement("DSP", Cell.DSPTitle),
                new XElement("IsControllable", Cell.IsControllable.ToString()),
                new XElement("IsBypassable", Cell.IsBypassable.ToString()),
                null,
                null
        };
        XName name2 = "ParamsUsed";
        object[] content = Cell.ParamsUsed.Select((DSPCellParameter p) => ParamElement(p)).ToArray();
        obj[4] = new XElement(name2, content);
        XName name3 = "ParamsFromFile";
        content = Cell.ParamsFromFile.Select((DSPCellParameter p) => ParamElement(p)).ToArray();
        obj[5] = new XElement(name3, content);
        return new XElement(name, obj);
    }

    private static XElement ParamElement(DSPCellParameter Param)
    {
        return new XElement("Parameter", new XElement("Name", Param.Name), new XElement("Address", Param.Address.ToString()), new XElement("Size", Param.Size.ToString()), new XElement("Data", string.Join(";", Param.Data.Select((byte d) => d.ToString()))));
    }

    private static XElement NodeElement(ConnectionNode Node)
    {
        return new XElement("Node", new XElement("Name", Node.BlockName), new XElement("Number", Node.AnchorNumber.ToString()), new XElement("Type", Node.AnchorType.ToString()), new XElement("Location", new XAttribute("X", ParseDoubleToString(Node.AnchorPoint.X)), new XAttribute("Y", ParseDoubleToString(Node.AnchorPoint.Y))));
    }

    private static XElement[] CommonElements(SchemaBlock Block)
    {
        return new XElement[2]
        {
                new XElement("Title", Block.Title),
                new XElement("Location", new XAttribute("X", ParseDoubleToString(Block.UpperLeftPoint.X)), new XAttribute("Y", ParseDoubleToString(Block.UpperLeftPoint.Y)))
        };
    }

    private static bool TryParseStringToDouble(string Input, out double Result)
    {
        return double.TryParse(Input, NumberStyles.Float, NumericStringCulture, out Result);
    }

    private static string ParseDoubleToString(double Value)
    {
        return Value.ToString(NumericStringCulture);
    }

    private static bool OpenOldFormat(string FilePath, out ISchemaElement[] SchElements)
    {
        SchElements = null;
        if (!OldFormatProject.Open(FilePath, out var Elements))
        {
            return false;
        }
        SchElements = Elements.ToArray();
        SaveBackupCopy(FilePath);
        return true;
    }

    private static void SaveBackupCopy(string FilePath)
    {
        string destFileName = FilePath.Insert(FilePath.IndexOf(".cspro"), "_backup");
        File.Copy(FilePath, destFileName, overwrite: true);
    }
}
