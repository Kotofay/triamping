using System;
using System.ComponentModel;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Markup;
using System.Windows.Media;

namespace ChipStudio
{
	public partial class Anchor : UserControl, INotifyPropertyChanged, IComponentConnector
	{
		public enum AnchorTypes : byte
		{
			EMPTY,
			ToSlave_I2C,
			FromSlave_I2C,
			ToSlave_SPI,
			FromSlave_SPI,
			ToSlave_CS,
			FromSlave_CS,
			ToDSPCell,
			FromDSPCell,
			ToLED,
			FromLED,
			FromPixel,
			ToPixel,
			ToRead,
			FromRead,
			ToComparator,
			FromComparator
		}

		public delegate void AnchorConnectionEventHandler(int AnchorNumber, LinePoint AnchorPoint, AnchorTypes AnchorType);

		private static readonly Brush AnchorActiveColor = (Brush)Application.Current.FindResource("AnchorActiveColor");

		private static readonly Brush AnchorNotActiveColor = (Brush)Application.Current.FindResource("AnchorNotActiveColor");

		private static readonly string OldAnchorFromPOTToDSPCell = "FromPOTToDSPCell";

		private static readonly string OldAnchorFromDSPCellToPOT = "FromDSPCellToPOT";

		private static readonly string OldAnchorFromKeySwitchToDSPCell = "FromKeySwitchToDSPCell";

		private static readonly string OldAnchorFromDSPCellToKeySwitch = "FromDSPCellToKeySwitch";

		private static readonly AnchorTypes[] DirectAnchors = new AnchorTypes[17]
		{
			AnchorTypes.EMPTY,
			AnchorTypes.ToSlave_I2C,
			AnchorTypes.ToSlave_SPI,
			AnchorTypes.ToSlave_CS,
			AnchorTypes.ToDSPCell,
			AnchorTypes.ToLED,
			AnchorTypes.ToPixel,
			AnchorTypes.FromSlave_I2C,
			AnchorTypes.FromSlave_SPI,
			AnchorTypes.FromSlave_CS,
			AnchorTypes.FromDSPCell,
			AnchorTypes.FromLED,
			AnchorTypes.FromPixel,
			AnchorTypes.ToRead,
			AnchorTypes.ToComparator,
			AnchorTypes.FromRead,
			AnchorTypes.FromComparator
		};

		private static readonly AnchorTypes[] OppositeAnchors = new AnchorTypes[17]
		{
			AnchorTypes.EMPTY,
			AnchorTypes.FromSlave_I2C,
			AnchorTypes.FromSlave_SPI,
			AnchorTypes.FromSlave_CS,
			AnchorTypes.FromDSPCell,
			AnchorTypes.FromLED,
			AnchorTypes.FromPixel,
			AnchorTypes.ToSlave_I2C,
			AnchorTypes.ToSlave_SPI,
			AnchorTypes.ToSlave_CS,
			AnchorTypes.ToDSPCell,
			AnchorTypes.ToLED,
			AnchorTypes.ToPixel,
			AnchorTypes.FromRead,
			AnchorTypes.FromComparator,
			AnchorTypes.ToRead,
			AnchorTypes.ToComparator
		};

		private Brush color = Brushes.LightGray;

		private bool isactivated;

		private Point center;

		private LinePoint relativecenter = new LinePoint();

		private bool isfilteredout;

		private string title;

		public Brush Color
		{
			get
			{
				return color;
			}
			set
			{
				if (color != value)
				{
					color = value;
					NotifyPropertyChanged("Color");
				}
			}
		}

		public bool IsActivated
		{
			get
			{
				return isactivated;
			}
			set
			{
				if (isactivated != value)
				{
					isactivated = value;
					if (isactivated)
					{
						AnchorPoint.Cursor = Cursors.Hand;
						AnchorPoint.MouseLeftButtonDown += Anchorpoint_MouseLeftButtonDown;
						Color = AnchorActiveColor;
					}
					else
					{
						AnchorPoint.Cursor = Cursors.Arrow;
						AnchorPoint.MouseLeftButtonDown -= Anchorpoint_MouseLeftButtonDown;
						Color = AnchorNotActiveColor;
					}
				}
			}
		}

		public bool IsFilteredOut
		{
			get
			{
				return isfilteredout;
			}
			set
			{
				if (isfilteredout != value)
				{
					isfilteredout = value;
					IsActivated = !isfilteredout;
				}
			}
		}

		public AnchorTypes Type { get; set; }

		public LinePoint RelativeCenter => relativecenter;

		public int Number { get; set; }

		public string Title
		{
			get
			{
				return title;
			}
			set
			{
				if (title != value)
				{
					title = value;
					AnchorName.Visibility = Visibility.Visible;
					AnchorName.Text = title;
				}
			}
		}

		public event PropertyChangedEventHandler PropertyChanged;

		public event AnchorConnectionEventHandler AnchorConnection;

		public Anchor()
		{
			InitializeComponent();
			base.DataContext = this;
			Color = AnchorNotActiveColor;
		}

		public void UpdateCenterRelativeTo(Visual visual)
		{
			center = new Point(AnchorPoint.ActualWidth / 2.0, AnchorPoint.ActualHeight / 2.0);
			Point point = TransformToVisual(visual).Transform(center);
			relativecenter.X = point.X;
			relativecenter.Y = point.Y;
		}

		public static bool TryParseAnchorType(string value, out AnchorTypes result)
		{
			result = AnchorTypes.EMPTY;
			foreach (AnchorTypes value2 in Enum.GetValues(typeof(AnchorTypes)))
			{
				if (value2.ToString() == value)
				{
					result = value2;
					return true;
				}
			}
			if (value == OldAnchorFromPOTToDSPCell || value == OldAnchorFromKeySwitchToDSPCell)
			{
				result = AnchorTypes.ToDSPCell;
				return true;
			}
			if (value == OldAnchorFromDSPCellToPOT || value == OldAnchorFromDSPCellToKeySwitch)
			{
				result = AnchorTypes.FromDSPCell;
				return true;
			}
			return false;
		}

		public static AnchorTypes OppositeAnchor(AnchorTypes AnchorValue)
		{
			return OppositeAnchors[Array.IndexOf(DirectAnchors, AnchorValue)];
		}

		public void NotifyPropertyChanged(string PropertyName)
		{
			this.PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(PropertyName));
		}

		private void Anchorpoint_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
		{
			this.AnchorConnection?.Invoke(Number, RelativeCenter, Type);
		}
	}
}
