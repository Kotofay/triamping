using System.Windows;
using System.Windows.Markup;

namespace ChipStudio
{
	public partial class PixelLEDSettings : Window, IComponentConnector
	{
		public PixelLEDBlock Settings = new PixelLEDBlock();

		public PixelLEDSettings(PixelLEDBlock ActiveSettings)
		{
			InitializeComponent();
			CountBox.Text = ActiveSettings.LEDsCount.ToString();
			switch (ActiveSettings.IndicationType)
			{
			case PixelLEDBlock.IndicationTypes.Project:
				ProjectPixel.IsChecked = true;
				IndModePanel.IsEnabled = false;
				break;
			case PixelLEDBlock.IndicationTypes.DSPBlock:
				BlockPixel.IsChecked = true;
				IndModePanel.IsEnabled = true;
				if (ActiveSettings.IndicationMode == PixelLEDBlock.IndicationModes.DataTable)
				{
					IndModeDataTable.IsChecked = true;
				}
				else
				{
					IndModeScale.IsChecked = true;
				}
				break;
			case PixelLEDBlock.IndicationTypes.Comparator:
				CompPixel.IsChecked = true;
				IndModeDataTable.IsChecked = true;
				IndModePanel.IsEnabled = false;
				break;
			}
			Settings.StatesCount = ActiveSettings.StatesCount;
		}

		private void OKButton_Click(object sender, RoutedEventArgs e)
		{
			Settings.LEDsCount = ((!int.TryParse(CountBox.Text, out var result)) ? 1 : result);
			Settings.IndicationType = PixelLEDBlock.IndicationTypes.Project;
			if (BlockPixel.IsChecked == true)
			{
				Settings.IndicationType = PixelLEDBlock.IndicationTypes.DSPBlock;
				Settings.IndicationMode = ((IndModeScale.IsChecked == true) ? PixelLEDBlock.IndicationModes.Scale : PixelLEDBlock.IndicationModes.DataTable);
			}
			else if (CompPixel.IsChecked == true)
			{
				Settings.IndicationType = PixelLEDBlock.IndicationTypes.Comparator;
				Settings.IndicationMode = PixelLEDBlock.IndicationModes.DataTable;
			}
			base.DialogResult = true;
		}

		private void CancelButton_Click(object sender, RoutedEventArgs e)
		{
			base.DialogResult = false;
		}

		private void ProjectPixel_Checked(object sender, RoutedEventArgs e)
		{
			if (IndModePanel != null)
			{
				IndModePanel.IsEnabled = false;
			}
		}

		private void BlockPixel_Checked(object sender, RoutedEventArgs e)
		{
			if (IndModePanel != null)
			{
				IndModePanel.IsEnabled = true;
			}
		}

		private void CompPixel_Checked(object sender, RoutedEventArgs e)
		{
			if (IndModePanel != null)
			{
				IndModeDataTable.IsChecked = true;
				IndModePanel.IsEnabled = false;
			}
		}
	}
}
