using System;
using System.Collections.Generic;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Markup;

namespace ChipStudio
{
	public partial class ComboProjectSettings : UserControl, IComponentConnector
	{
		private static readonly int[] BootLinesCountStrings = new int[4] { 1, 2, 3, 4 };

		private static readonly string[][] BootLinesStatesStrings = new string[4][]
		{
			new string[2] { "x x x 0", "x x x 1" },
			new string[4] { "x x 0 0", "x x 0 1", "x x 1 0", "x x 1 1" },
			new string[8] { "x 0 0 0", "x 0 0 1", "x 0 1 0", "x 0 1 1", "x 1 0 0", "x 1 0 1", "x 1 1 0", "x 1 1 1" },
			new string[16]
			{
				"0 0 0 0", "0 0 0 1", "0 0 1 0", "0 0 1 1", "0 1 0 0", "0 1 0 1", "0 1 1 0", "0 1 1 1", "1 0 0 0", "1 0 0 1",
				"1 0 1 0", "1 0 1 1", "1 1 0 0", "1 1 0 1", "1 1 1 0", "1 1 1 1"
			}
		};

		private static readonly string[] ProjectBootModesStrings = new string[2] { "Boot lines", "Audio stream" };

		private static readonly string UndefinedWord = "Undefined";

		private static readonly string[] LR_FreqStrings = new string[11]
		{
			"44,1 kHz", "48 kHz", "88,2 kHz", "96 kHz", "176,4 kHz", "192 kHz", "352,8 kHz", "384 kHz", UndefinedWord, "705,6 kHz",
			"768 kHz"
		};

		private static readonly string[] LRtoBCLKStrings = new string[29]
		{
			"  44,1 кГц @ 32Fs", "  44,1 кГц @ 64Fs", "  44,1 кГц @ 128Fs", "  44,1 кГц @ 256Fs", "  48,0 кГц @ 32Fs", "  48,0 кГц @ 64Fs", "  48,0 кГц @ 128Fs", "  48,0 кГц @ 256Fs", "  88,2 кГц @ 32Fs", "  88,2 кГц @ 64Fs",
			"  88,2 кГц @ 128Fs", "  96,0 кГц @ 32Fs", "  96,0 кГц @ 64Fs", "  96,0 кГц @ 128Fs", "176,4 кГц @ 32Fs", "176,4 кГц @ 64Fs", "192,0 кГц @ 32Fs", "192,0 кГц @ 64Fs", "352,8 kHz @ any", "384,0 kHz @ any",
			UndefinedWord, "352,8 kHz @ 32Fs", "352,8 kHz @ 64Fs", "384,0 kHz @ 32Fs", "384,0 kHz @ 64Fs", "705,6 kHz @ 32Fs", "705,6 kHz @ 64Fs", "768,0 kHz @ 32Fs", "768,0 kHz @ 64Fs"
		};

		private static readonly string GPIOsString = "GPIOs  ";

		private const int COMBO_TYPE_BOOT_LINES = 0;

		private const int COMBO_TYPE_STREAM_LR = 1;

		private const int COMBO_TYPE_STREAM_LR_BCLK = 2;

		private const int COMBO_STREAM_SUBTYPE_LR = 0;

		private const int COMBO_STREAM_SUBTYPE_LR_BCLK = 1;

		private Func<string, string> ChangeComboPart;

		private Action ClearSchema;

		private List<ComboProjectPart> ComboProjectParts = new List<ComboProjectPart>();

		private int ComboProjectType;

		private readonly string[] ControllerStrings;

		private ControllerComboProperties ComboProperties;

		public string CurrentPartProject
		{
			get
			{
				return CurrentProjectName.Text;
			}
			set
			{
				CurrentProjectName.Text = value;
			}
		}

		public string ComboProject
		{
			get
			{
				return ComboProjectName.Text;
			}
			set
			{
				ComboProjectName.Text = value;
			}
		}

		public List<ComboProjectPart> Projects => ComboProjectParts;

		public string Controller
		{
			get
			{
				if (ControllerSelector.SelectedIndex == -1)
				{
					return "";
				}
				return ControllerStrings[ControllerSelector.SelectedIndex];
			}
		}

		public int ComboType => ComboProjectType;

		public bool ReconfigType => UpdateProjectCheck.IsChecked.Value;

		public int BootLinesCount
		{
			get
			{
				if (BootLinesCountSelector.SelectedIndex == -1)
				{
					return 0;
				}
				return BootLinesCountStrings[BootLinesCountSelector.SelectedIndex];
			}
		}

		public ComboProjectSettings()
		{
			InitializeComponent();
			base.DataContext = this;
			BootLinesCountSelector.ItemsSource = BootLinesCountStrings;
			BootLinesCountSelector.SelectedIndex = 0;
			BootLinesStateSelector.ItemsSource = BootLinesStatesStrings[0];
			BootLinesStateSelector.SelectedIndex = 0;
			ProjectBootMode.ItemsSource = ProjectBootModesStrings;
			ProjectBootMode.SelectedIndex = ComboProjectType;
			LRFreqSelector.ItemsSource = LR_FreqStrings;
			LRFreqSelector.SelectedIndex = 0;
			ComboBoxItem[] array = new ComboBoxItem[LRtoBCLKStrings.Length];
			for (int i = 0; i < LRtoBCLKStrings.Length; i++)
			{
				array[i] = new ComboBoxItem
				{
					Content = LRtoBCLKStrings[i],
					HorizontalContentAlignment = HorizontalAlignment.Left,
					VerticalContentAlignment = VerticalAlignment.Center
				};
			}
			LRandBCLKSelector.ItemsSource = array;
			LRandBCLKSelector.SelectedIndex = 0;
			ControllerStrings = Shared.GetFolderFiles(Shared.ControllersFolder);
			ControllerSelector.ItemsSource = ControllerStrings;
			ControllerSelector.SelectedIndex = 0;
			ComboProperties = new ControllerComboProperties(ControllerStrings[0]);
			UpdateComboProjectsParts();
			BootLinesCountSelector.SelectionChanged += BootLinesCountSelector_SelectionChanged;
			BootLinesStateSelector.SelectionChanged += BootLinesStateSelector_SelectionChanged;
			ProjectBootMode.SelectionChanged += ProjectBootMode_SelectionChanged;
			LR_ModeBut.Checked += LR_ModeBut_Checked;
			LRFreqSelector.SelectionChanged += LRFreqSelector_SelectionChanged;
			LR_BCLK_ModeBut.Checked += LR_BCLK_ModeBut_Checked;
			LRandBCLKSelector.SelectionChanged += LRandBCLKSelector_SelectionChanged;
			BootGPIOLabel.Content = GPIOsString;
		}

		public void Init(ComboProjectParameters ComboParams, List<ComboProjectPart> ComboParts)
		{
			ControllerSelector.SelectedIndex = 0;
			for (int i = 0; i < ControllerStrings.Length; i++)
			{
				if (ComboParams.Controller == ControllerStrings[i])
				{
					ControllerSelector.SelectedIndex = i;
					break;
				}
			}
			ComboBox comboBox;
			if (ComboParams.Type == 0)
			{
				ProjectBootMode.SelectedIndex = 0;
				BootLinesCountSelector.SelectedIndex = ComboParams.SubType;
				comboBox = BootLinesStateSelector;
			}
			else
			{
				ProjectBootMode.SelectedIndex = 1;
				if (ComboParams.SubType == 0)
				{
					LR_ModeBut.IsChecked = true;
					comboBox = LRFreqSelector;
				}
				else
				{
					LR_BCLK_ModeBut.IsChecked = true;
					comboBox = LRandBCLKSelector;
					while (ComboParts.Count < LRtoBCLKStrings.Length)
					{
						ComboParts.Add(new ComboProjectPart());
					}
				}
			}
			ComboProjectParts = ComboParts;
			comboBox.SelectedIndex = -1;
			comboBox.SelectedIndex = 0;
			UpdateProjectCheck.IsChecked = ComboParams.DoNotReboot;
		}

		public void Reset()
		{
			ComboProjectType = 0;
			BootLinesCountSelector.SelectedIndex = 0;
			BootLinesStateSelector.SelectedIndex = 0;
			ControllerSelector.SelectedIndex = 0;
			ProjectBootMode.SelectedIndex = ComboProjectType;
			LRFreqSelector.SelectedIndex = 0;
			LRandBCLKSelector.SelectedIndex = 0;
		}

		public ComboBox GetActiveComboPartSelector()
		{
			if (ComboProjectType == 0)
			{
				return BootLinesStateSelector;
			}
			if (ComboProjectType == 1)
			{
				return LRFreqSelector;
			}
			return LRandBCLKSelector;
		}

		public ComboProjectParameters GetParams()
		{
			ComboProjectParameters comboProjectParameters = new ComboProjectParameters
			{
				Controller = ControllerStrings[ControllerSelector.SelectedIndex],
				Type = ComboProjectType
			};
			if (ComboProjectType == 0)
			{
				comboProjectParameters.SubType = BootLinesCountSelector.SelectedIndex;
			}
			else if (ComboProjectType == 1)
			{
				comboProjectParameters.SubType = 0;
			}
			else
			{
				comboProjectParameters.SubType = 1;
			}
			if (UpdateProjectCheck.IsChecked == true)
			{
				comboProjectParameters.DoNotReboot = true;
			}
			else
			{
				comboProjectParameters.DoNotReboot = false;
			}
			return comboProjectParameters;
		}

		public int ComboSubType()
		{
			int result = BootLinesCountStrings[BootLinesCountSelector.SelectedIndex];
			if (ComboProjectType == 1)
			{
				result = 0;
			}
			else if (ComboProjectType == 2)
			{
				result = 1;
			}
			return result;
		}

		public void SetComboPart(string NewProject)
		{
			if (ComboProjectType == 0)
			{
				ComboProjectParts[BootLinesStateSelector.SelectedIndex].Name = NewProject;
			}
			else if (ComboProjectType == 1)
			{
				ComboProjectParts[LRFreqSelector.SelectedIndex].Name = NewProject;
			}
			else
			{
				ComboProjectParts[LRandBCLKSelector.SelectedIndex].Name = NewProject;
			}
		}

		public void SetChangeComboPartCallBack(Func<string, string> Callback)
		{
			ChangeComboPart = Callback;
		}

		public void SetClearComboPartCallBack(Action Callback)
		{
			ClearSchema = Callback;
		}

		private void UpdateComboProjectsParts()
		{
			int num = -1;
			if (ComboProjectType != 0)
			{
				num = ((ComboProjectType != 1) ? LRtoBCLKStrings.Length : LR_FreqStrings.Length);
			}
			else if (BootLinesStateSelector.SelectedIndex != -1)
			{
				num = BootLinesStatesStrings[BootLinesCountSelector.SelectedIndex].Length;
			}
			if (num != -1)
			{
				ComboProjectParts.Clear();
				for (int i = 0; i < num; i++)
				{
					ComboProjectPart item = new ComboProjectPart();
					ComboProjectParts.Add(item);
				}
			}
		}

		private void BootLinesCountSelector_SelectionChanged(object sender, SelectionChangedEventArgs e)
		{
			if (BootLinesCountSelector.SelectedIndex != -1)
			{
				UpdateComboProjectsParts();
				BootLinesStateSelector.ItemsSource = BootLinesStatesStrings[BootLinesCountSelector.SelectedIndex];
				BootLinesStateSelector.SelectedIndex = 0;
			}
		}

		private void Controller_SelectionChanged(object sender, SelectionChangedEventArgs e)
		{
			if (ControllerSelector.SelectedIndex == -1)
			{
				return;
			}
			ComboProperties = new ControllerComboProperties(ControllerStrings[ControllerSelector.SelectedIndex]);
			BootGPIOLabel.Content = GPIOsString + ComboProperties.BootGpiosNumbers;
			if (ComboProperties.IsGpioBootSupported)
			{
				ProjectBootMode.IsEnabled = true;
				LR_ModeBut.IsEnabled = true;
			}
			else
			{
				ProjectBootMode.SelectedIndex = 1;
				ProjectBootMode.IsEnabled = false;
				LR_BCLK_ModeBut.IsChecked = true;
				LR_ModeBut.IsEnabled = false;
			}
			LRandBCLKSelector.SelectedIndex = 0;
			UpdateProjectCheck.IsChecked = true;
			UpdateProjectCheck.IsEnabled = ComboProperties.ProjectBootOption;
			if (ComboProperties.UnusedStreams != null)
			{
				for (int i = 0; i < LRtoBCLKStrings.Length; i++)
				{
					(LRandBCLKSelector.Items[i] as ComboBoxItem).IsEnabled = Array.IndexOf(ComboProperties.UnusedStreams, i) == -1;
				}
			}
		}

		private void ProjectBootMode_SelectionChanged(object sender, SelectionChangedEventArgs e)
		{
			if (ProjectBootMode.SelectedIndex == 0)
			{
				ComboProjectType = 0;
				BootLinesView.IsEnabled = true;
				AudioStreamView.IsEnabled = false;
			}
			else
			{
				BootLinesView.IsEnabled = false;
				AudioStreamView.IsEnabled = true;
				if (LR_ModeBut.IsChecked == true)
				{
					ComboProjectType = 1;
				}
				else
				{
					ComboProjectType = 2;
				}
			}
			UpdateComboProjectsParts();
			ClearSchema?.Invoke();
		}

		private void LR_ModeBut_Checked(object sender, RoutedEventArgs e)
		{
			if (LRFreqSelector != null)
			{
				LRFreqSelector.IsEnabled = true;
				LRandBCLKSelector.IsEnabled = false;
				ComboProjectType = 1;
				UpdateComboProjectsParts();
				ClearSchema?.Invoke();
			}
		}

		private void LR_BCLK_ModeBut_Checked(object sender, RoutedEventArgs e)
		{
			if (LRFreqSelector != null)
			{
				LRFreqSelector.IsEnabled = false;
				LRandBCLKSelector.IsEnabled = true;
				ComboProjectType = 2;
				UpdateComboProjectsParts();
				ClearSchema?.Invoke();
			}
		}

		private void DeleteProjectFromCombo_Click(object sender, RoutedEventArgs e)
		{
			ComboBox activeComboPartSelector = GetActiveComboPartSelector();
			if (activeComboPartSelector.SelectedIndex != -1 && ComboProjectParts[activeComboPartSelector.SelectedIndex].Name != null && MessageBox.Show("Current project will be removed from CompoProject.\n\rPress 'YES' to continue, otherwise press 'NO'", "", MessageBoxButton.YesNo, MessageBoxImage.Exclamation) == MessageBoxResult.Yes)
			{
				ComboProjectParts[activeComboPartSelector.SelectedIndex].Name = null;
				ClearSchema?.Invoke();
			}
		}

		private void ComboPartChanged(ComboBox ComboPartSelector)
		{
			if (ComboPartSelector.SelectedIndex != -1)
			{
				if (ComboPartSelector.SelectedIndex < ComboProjectParts.Count)
				{
					ComboProjectParts[ComboPartSelector.SelectedIndex].Name = ChangeComboPart?.Invoke(ComboProjectParts[ComboPartSelector.SelectedIndex].Name);
				}
				else
				{
					MessageBox.Show("Combo project has no this subproject.\n\rCreate new ComboProject.", "", MessageBoxButton.OK, MessageBoxImage.Hand);
				}
			}
		}

		private void BootLinesStateSelector_SelectionChanged(object sender, SelectionChangedEventArgs e)
		{
			ComboPartChanged(BootLinesStateSelector);
		}

		private void LRFreqSelector_SelectionChanged(object sender, SelectionChangedEventArgs e)
		{
			ComboPartChanged(LRFreqSelector);
		}

		private void LRandBCLKSelector_SelectionChanged(object sender, SelectionChangedEventArgs e)
		{
			ComboPartChanged(LRandBCLKSelector);
		}
	}
}
