﻿// Decompiled with JetBrains decompiler
// Type: ChipStudio.ControllerOptions
// Assembly: ChipStudio, Version=1.2.9.0, Culture=neutral, PublicKeyToken=null
// MVID: 334E3BEA-37C7-4274-8118-535AAEFA1546
// Assembly location: D:\DocAndSec\Desktop\AUDIO\ChipDip\ChipStudio_soft_v1.2.9\ChipStudio_v1.2.9.exe

#nullable disable
namespace ChipStudio;

public class ControllerOptions
{
  public bool IsGenSelectionEnabled { get; set; }

  public bool IsFreqIndicationEnabled { get; set; }

  public bool IsResIndicationEnabled { get; set; }

  public bool IsPwrKeyEnabled { get; set; }

  public bool IsUSBStdByWakeEnabled { get; set; }

  public bool IsFixProjectEnabled { get; set; }

  public ushort Get()
  {
    ushort num1 = 0;
    ushort num2;
    int num3;
    if (!this.IsGenSelectionEnabled)
      num3 = (int) (num2 = (ushort) ((uint) num1 | 0U));
    else
      num2 = (ushort) (num3 = (int) (ushort) ((uint) num1 | 1U));
    ushort num4 = (ushort) num3;
    int num5;
    if (!this.IsFreqIndicationEnabled)
      num5 = (int) (num2 = (ushort) ((uint) num4 | 0U));
    else
      num2 = (ushort) (num5 = (int) (ushort) ((uint) num4 | 2U));
    ushort num6 = (ushort) num5;
    int num7;
    if (!this.IsResIndicationEnabled)
      num7 = (int) (num2 = (ushort) ((uint) num6 | 0U));
    else
      num2 = (ushort) (num7 = (int) (ushort) ((uint) num6 | 4U));
    ushort num8 = (ushort) num7;
    int num9;
    if (!this.IsPwrKeyEnabled)
      num9 = (int) (num2 = (ushort) ((uint) num8 | 0U));
    else
      num2 = (ushort) (num9 = (int) (ushort) ((uint) num8 | 8U));
    ushort num10 = (ushort) num9;
    int num11;
    if (!this.IsUSBStdByWakeEnabled)
      num11 = (int) (num2 = (ushort) ((uint) num10 | 0U));
    else
      num2 = (ushort) (num11 = (int) (ushort) ((uint) num10 | 16U /*0x10*/));
    ushort num12 = (ushort) num11;
    int num13;
    if (!this.IsFixProjectEnabled)
      num13 = (int) (num2 = (ushort) ((uint) num12 | 0U));
    else
      num2 = (ushort) (num13 = (int) (ushort) ((uint) num12 | 32U /*0x20*/));
    return (ushort) num13;
  }

  public enum Options : ushort
  {
    OPT_GEN_SELECTION = 1,
    OPT_FREQ_INDICATION = 2,
    OPT_RES_INDICATION = 4,
    OPT_PWR_ON_OFF_BY_KEY = 8,
    OPT_USB_STANDBY_WAKEUP = 16, // 0x0010
    OPT_FIX_DEF_PROJECT = 32, // 0x0020
  }
}
