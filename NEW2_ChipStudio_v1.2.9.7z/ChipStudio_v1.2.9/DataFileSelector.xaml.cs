using System;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Markup;
using System.Windows.Media.Imaging;
using Microsoft.Win32;

namespace ChipStudio
{
	public partial class DataFileSelector : UserControl, IComponentConnector
	{
		public enum ProcessResult : byte
		{
			Success,
			FailedAndClear,
			FailedAndSave
		}

		private static readonly string ImageWarning = (string)Application.Current.FindResource("ImageWarning");

		private static readonly string ImageApply = (string)Application.Current.FindResource("ImageApply");

		private Func<string, ProcessResult> ProcessFile;

		private bool isdataset;

		public string Title { get; set; }

		public string Filter { get; set; }

		public string ButtonTitle { get; set; }

		public bool IsDataSet
		{
			set
			{
				if (isdataset != value)
				{
					isdataset = value;
					Image.Source = (isdataset ? new BitmapImage(new Uri(ImageApply, UriKind.Relative)) : new BitmapImage(new Uri(ImageWarning, UriKind.Relative)));
				}
			}
		}

		public DataFileSelector()
		{
			InitializeComponent();
			base.DataContext = this;
			Image.Source = new BitmapImage(new Uri(ImageWarning, UriKind.Relative));
		}

		public void FileProcessingSet(Func<string, ProcessResult> NewAction)
		{
			ProcessFile = NewAction;
		}

		private void SelectFile_Click(object sender, RoutedEventArgs e)
		{
			OpenFileDialog openFileDialog = new OpenFileDialog
			{
				Filter = Filter
			};
			if (openFileDialog.ShowDialog() == true)
			{
				ProcessResult value = (ProcessFile?.Invoke(openFileDialog.FileName)).Value;
				IsDataSet = value == ProcessResult.Success || value == ProcessResult.FailedAndSave;
			}
		}
	}
}
