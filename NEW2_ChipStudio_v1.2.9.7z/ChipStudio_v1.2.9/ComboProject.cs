﻿// Decompiled with JetBrains decompiler
// Type: ChipStudio.ComboProject
// Assembly: ChipStudio, Version=1.2.9.0, Culture=neutral, PublicKeyToken=null
// MVID: 334E3BEA-37C7-4274-8118-535AAEFA1546
// Assembly location: D:\DocAndSec\Desktop\AUDIO\ChipDip\ChipStudio_soft_v1.2.9\ChipStudio_v1.2.9.exe

using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Windows;
using System.Xml.Linq;

#nullable disable
namespace ChipStudio;

public class ComboProject
{
  private static readonly string SoftwareVersion = (string) Application.Current.FindResource((object) nameof (SoftwareVersion));
  private const string RootElement = "ComboProject";
  private const string ProjectsString = "Projects";
  private const string ComboSettingsString = "ComboSettings";
  private const string ControllerString = "Controller";
  private const string ComboTypeString = "ComboType";
  private const string ComboSubTypeString = "ComboSubType";
  private const string ComboChangeProjectMethod = "DoNotReboot";
  private const string ChipStudioComboProjectExt = ".cscom";

  public string Path { get; }

  public ComboProject(string path) => this.Path = path;

  public void Save(ComboProjectParameters Params, List<ComboProjectPart> Parts)
  {
    XDocument xdocument = new XDocument(new object[1]
    {
      (object) new XElement((XName) nameof (ComboProject), new object[2]
      {
        (object) new XElement((XName) "Version", (object) ComboProject.SoftwareVersion),
        (object) new XElement((XName) "ComboSettings", new object[4]
        {
          (object) new XAttribute((XName) "Controller", (object) Params.Controller),
          (object) new XAttribute((XName) "ComboType", (object) Params.Type.ToString()),
          (object) new XAttribute((XName) "ComboSubType", (object) Params.SubType.ToString()),
          (object) new XAttribute((XName) "DoNotReboot", (object) Params.DoNotReboot.ToString())
        })
      })
    });
    XElement content = new XElement((XName) "Projects");
    foreach (ComboProjectPart part in Parts)
      content.Add((object) new XElement((XName) "Path", (object) part.Name));
    xdocument.Root.Add((object) content);
    xdocument.Save(this.Path);
  }

  public bool Open(ComboProjectParameters Params, List<ComboProjectPart> Parts)
  {
    return !ComboProject.IsNewFormatFile(this.Path) ? ComboProject.OpenOldFormat(this.Path, Params, Parts) : ComboProject.OpenNewFormat(XDocument.Load(this.Path), Params, Parts);
  }

  private static bool IsNewFormatFile(string FilePath) => Shared.IsXMLFile(FilePath);

  private static bool OpenNewFormat(
    XDocument ProjFile,
    ComboProjectParameters Params,
    List<ComboProjectPart> Parts)
  {
    Params.Controller = ProjFile.Element((XName) nameof (ComboProject))?.Element((XName) "ComboSettings")?.Attribute((XName) "Controller")?.Value;
    int result1;
    if (!int.TryParse(ProjFile.Element((XName) nameof (ComboProject))?.Element((XName) "ComboSettings")?.Attribute((XName) "ComboType")?.Value, out result1))
      return false;
    Params.Type = result1;
    if (!int.TryParse(ProjFile.Element((XName) nameof (ComboProject))?.Element((XName) "ComboSettings")?.Attribute((XName) "ComboSubType")?.Value, out result1))
      return false;
    Params.SubType = result1;
    bool result2;
    if (!bool.TryParse(ProjFile.Element((XName) nameof (ComboProject))?.Element((XName) "ComboSettings")?.Attribute((XName) "DoNotReboot")?.Value, out result2))
      return false;
    Params.DoNotReboot = result2;
    XElement xelement1 = ProjFile.Element((XName) nameof (ComboProject));
    string[] strArray;
    if (xelement1 == null)
    {
      strArray = (string[]) null;
    }
    else
    {
      XElement xelement2 = xelement1.Element((XName) "Projects");
      strArray = xelement2 != null ? xelement2.Elements((XName) "Path").Select<XElement, string>((Func<XElement, string>) (e => e.Value)).ToArray<string>() : (string[]) null;
    }
    foreach (string str in strArray)
      Parts.Add(new ComboProjectPart()
      {
        Name = str.Length > 6 ? str : (string) null
      });
    return true;
  }

  private static bool OpenOldFormat(
    string FilePath,
    ComboProjectParameters Params,
    List<ComboProjectPart> Parts)
  {
    if (!OldFormatComboProject.Open(FilePath, Params, Parts))
      return false;
    ComboProject.SaveBackupCopy(FilePath);
    return true;
  }

  private static void SaveBackupCopy(string FilePath)
  {
    string destFileName = FilePath.Insert(FilePath.IndexOf(".cscom"), "_backup");
    File.Copy(FilePath, destFileName, true);
  }
}
