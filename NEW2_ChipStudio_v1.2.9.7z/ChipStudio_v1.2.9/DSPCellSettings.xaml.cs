using System.Collections.Generic;
using System.Linq;
using System.Windows;
using System.Windows.Markup;
using Microsoft.Win32;

namespace ChipStudio
{
	public partial class DSPCellSettings : Window, IComponentConnector
	{
		private const string DataFileFilter = "Data file (*.txt)|*.txt";

		private const string AddressStringFormat = "X4";

		private const string DataStringFormat = "X2";

		private readonly List<byte> Data;

		private readonly DSPCellDescription CellDesc;

		public List<string> DataList = new List<string>();

		public DSPCellSettings(DSPCellDescription cell, List<byte> data)
		{
			CellDesc = cell;
			Data = data;
			InitializeComponent();
			base.DataContext = this;
			if (CellDesc.AreParamsUpdated)
			{
				UpdateAddressList();
			}
			AddNewDataToList(Data.ToArray());
		}

		private void UpdateAddressList()
		{
			CellAddresses.ItemsSource = null;
			CellAddresses.ItemsSource = from a in CellDesc.ParamsAddresses()
				select "0x" + a.ToString("X4");
		}

		private void AddNewDataToList(byte[] NewData)
		{
			string text = " ";
			for (int i = 0; i < NewData.Length; i++)
			{
				text = text + NewData[i].ToString("X2") + " ";
				if ((i + 1) % 4 == 0)
				{
					DataList.Add(text);
					text = " ";
				}
				else if (i + 1 == NewData.Length)
				{
					DataList.Add(text);
				}
			}
			CellData.ItemsSource = null;
			CellData.ItemsSource = DataList;
		}

		private void AddDataButton_Click(object sender, RoutedEventArgs e)
		{
			OpenFileDialog openFileDialog = new OpenFileDialog
			{
				Filter = "Data file (*.txt)|*.txt"
			};
			if (openFileDialog.ShowDialog() == true && CellDesc.TryParseData(openFileDialog.FileName, out var Result))
			{
				Data.AddRange(Result);
				AddNewDataToList(Result);
				if (CellAddresses.Items.Count == 0)
				{
					UpdateAddressList();
				}
			}
		}

		private void ClearDataButton_Click(object sender, RoutedEventArgs e)
		{
			Data.Clear();
			DataList.Clear();
			CellData.ItemsSource = null;
			CellData.ItemsSource = DataList;
			if (CellDesc.AreParamsModifiable)
			{
				CellDesc.ResetParams();
				CellAddresses.ItemsSource = null;
			}
		}
	}
}
