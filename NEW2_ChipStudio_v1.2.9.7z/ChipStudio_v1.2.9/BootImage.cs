using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;

namespace ChipStudio
{
	public class BootImage
	{
		private const int BLOCK_CONFIGURATION_SIZE = 2;

		private const int ID_SIZE = 1;

		private const int ADDRESS_IN_DSP_SIZE = 4;

		private const int USB_MANUFACTURE_MAX_LENGTH = 20;

		private const int USB_DEVICE_NAME_MAX_LENGTH = 40;

		private const int USB_VID_SIZE = 2;

		private const int USB_PID_SIZE = 2;

		private const int USB_SET_SIZE_OFFSET = 0;

		private const int USB_SET_SIZE_SIZE = 2;

		private const int USB_VID_OFFSET = 2;

		private const int USB_PID_OFFSET = 4;

		private const int USB_MANUFACT_SIZE_OFFSET = 6;

		private const int USB_MANUFACT_SIZE_SIZE = 1;

		private const int USB_MANUFACT_OFFSET = 7;

		private const int USB_MANUFACT_SIZE = 20;

		private const int FIRST_USB_DEV_NAME_MAP_OFFSET = 27;

		private const int USB_DEV_NAME_SIZE_OFFSET = 0;

		private const int USB_DEV_NAME_SIZE_SIZE = 1;

		private const int USB_DEV_NAME_OFFSET = 1;

		private const int USB_DEV_NAME_SIZE = 40;

		private const int USB_DEV_NAME_MAP_SIZE = 41;

		private const int BOOT_IMAGE_SIZE_OFFSET = 0;

		private const int BOOT_IMAGE_SIZE_SIZE = 4;

		private const int PROJECT_TYPE_OFFSET = 4;

		private const int PROJECT_TYPE_SIZE = 1;

		private const int COMBO_PROJECT_TYPE_OFFSET = 5;

		private const int COMBO_PROJECT_TYPE_SIZE = 1;

		private const int BOOT_LINES_COUNT_OFFSET = 6;

		private const int BOOT_LINES_COUNT_SIZE = 1;

		private const int COMBO_PROJECT_RECONF_TYPE_OFFSET = 7;

		private const int COMBO_PROJECT_RECONF_TYPE_SIZE = 1;

		private const int COMBO_PROJECT_MAP_RESERV_OFFSET = 8;

		private const int COMBO_PROJECT_MAP_RESERV_SIZE = 3;

		private const int COMBO_PROJECT_TABLE_SIZE_OFFSET = 11;

		private const int COMBO_PROJECT_TABLE_SIZE_SIZE = 2;

		private const int FIRST_PROJECT_MAP_OFFSET = 13;

		private const int PROJECT_NUMBER_OFFSET = 0;

		private const int PROJECT_NUMBER_SIZE = 1;

		private const int PROJECT_ADRESS_OFFSET = 1;

		private const int PROJECT_ADRESS_SIZE = 4;

		private const int PROJECT_MAP_IN_COMBO_RES_SIZE = 4;

		private const int PROJECT_MAP_IN_COMBO_SIZE = 9;

		private const int PROJECT_MAP_RESERV_OFFSET = 5;

		private const int PROJECT_MAP_RESERV_SIZE = 1;

		private const int MEMORY_MAP_TABLE_SIZE_OFFSET = 6;

		private const int MEMORY_MAP_TABLE_SIZE_SIZE = 2;

		private const int CONTROLLER_CONF_ADR_OFFSET = 8;

		private const int CONTROLLER_CONF_ADR_SIZE = 4;

		private const int CONTROLLER_CONF_SIZE_OFFSET = 12;

		private const int CONTROLLER_CONF_SIZE_SIZE = 2;

		private const int FIRST_BLOCK_CONF_MAP_OFFSET = 14;

		private const int FIRST_BLOCK_ADR_OFFSET = 15;

		private const int CONTROLLER_DELAY_CONF_SIZE = 6;

		private const int CONTROLLER_OPTIONS_SIZE = 2;

		private const int CONTROLLER_RESERVE_SIZE = 4;

		private const int CONTROLLER_CONF_MAP_SIZE = 6;

		private const byte CONTROLLER_DELAY_ACTIVE = 1;

		private const int BLOCK_ID_OFFSET = 0;

		private const int BLOCK_CONF_ADR_OFFSET = 1;

		private const int BLOCK_CONF_ADR_SIZE = 4;

		private const int BLOCK_CONF_SIZE_OFFSET = 5;

		private const int BLOCK_CONF_MAP_SIZE = 7;

		private const int DSP_ID_OFFSET = 0;

		private const int DSP_ID_SIZE = 1;

		private const int DSP_BUS_ADR_OFFSET = 1;

		private const int DSP_BUS_ADR_SIZE = 1;

		private const int DSP_CS_GPIO_NUM_OFFSET = 2;

		private const int DSP_CS_GPIO_NUM_SIZE = 1;

		private const int DSP_INTERFACE_TYPE_OFFSET = 3;

		private const int DSP_INTERFACE_TYPE_SIZE = 1;

		private const int DSP_INTERFACE_NUM_OFFSET = 4;

		private const int DSP_INTERFACE_NUM_SIZE = 1;

		private const int DSP_OPERATIONS_COUNT_OFFSET = 5;

		private const int DSP_OPERATIONS_COUNT_SIZE = 1;

		private const int DSP_FIRST_OPER_DESC_OFFSET = 6;

		private const int LINE_OWNER_ID_OFFSET = 0;

		private const int LINE_OWNER_ID_SIZE = 1;

		private const int LINE_NUMBER_OFFSET = 1;

		private const int LINE_NUMBER_SIZE = 1;

		private const int LINE_FUNCTION_BLOCK_ID1_OFFSET = 2;

		private const int LINE_FUNCTION_BLOCK_ID1_SIZE = 1;

		private const int LINE_FUNCTION_BLOCK_ID2_OFFSET = 3;

		private const int LINE_FUNCTION_BLOCK_ID2_SIZE = 1;

		private const int LINE_DSP_CELLS_COUNT_OFFSET = 4;

		private const int LINE_DSP_CELLS_COUNT_SIZE = 1;

		private const int LINE_FIRST_DSP_CELL_CONF_SIZE_OFFSET = 5;

		private const int LINE_DSP_CELL_CONF_SIZE = 3;

		private const int LINE_FIRST_DSP_CELL_CONFIG_OFFSET = 8;

		private const int COM_PIXEL_ACTIVITY_OFFSET = 0;

		private const int COM_PIXEL_ACTIVITY_SIZE = 1;

		private const int COM_PIXEL_TYPE_OFFSET = 1;

		private const int COM_PIXEL_TYPE_SIZE = 1;

		private const int COM_PIXEL_COUNT_OFFSET = 2;

		private const int COM_PIXEL_COUNT_SIZE = 1;

		private const int COM_PIXEL_PWRON_ACTIVITY_OFFSET = 3;

		private const int COM_PIXEL_PWRON_ACTIVITY_SIZE = 1;

		private const int COM_PIXEL_RESERVE_OFFSET = 4;

		private const int COM_PIXEL_RESERVE_SIZE = 3;

		private const int COM_PIXEL_PROJ_GROUP_COUNT_OFFSET = 7;

		private const int COM_PIXEL_PROJ_GROUP_COUNT_SIZE = 1;

		private const int COM_PIXEL_PROJ_1_GROUP_CONF_SIZE_OFFSET = 8;

		private const int COM_PIXEL_PROJ_GROUP_CONF_SIZE_SIZE = 1;

		private const int COM_PIXEL_PROJ_1_GROUP_CONF_OFFSET = 9;

		private const int PROJ_PIXEL_GROUP_RESERVE_OFFSET = 0;

		private const int PROJ_PIXEL_GROUP_RESERVE_SIZE = 2;

		private const int PROJ_PIXEL_GROUP_INDEX_OFFSET = 2;

		private const int PROJ_PIXEL_GROUP_INDEX_SIZE = 1;

		private const int PROJ_PIXEL_GROUP_LED_COUNT_OFFSET = 3;

		private const int PROJ_PIXEL_GROUP_LED_COUNT_SIZE = 1;

		private const int PROJ_PIXEL_GROUP_COLORS_OFFSET = 4;

		private const int CEC_GPIO_NUM_SIZE = 1;

		private const int CEC_MAX_NAME_LENGTH = 14;

		private const byte CEC_VOL_VALUES_COUNT_DEFAULT = 50;

		private const int CEC_ACTIVITY_OFFSET = 0;

		private const int CEC_ACTIVITY_SIZE = 1;

		private const int CEC_PORT_NUM_OFFSET = 1;

		private const int CEC_PORT_NUM_SIZE = 1;

		private const int CEC_DEVICE_NAME_SIZE_OFFSET = 2;

		private const int CEC_DEVICE_NAME_SIZE_SIZE = 1;

		private const int CEC_DEVICE_NAME_OFFSET = 3;

		private const int CEC_DEVICE_NAME_SIZE = 14;

		private const int CEC_OPTIONS_OFFSET = 17;

		private const int CEC_OPTIONS_SIZE = 1;

		private const int CEC_RESERVE1_OFFSET = 18;

		private const int CEC_RESERVE1_SIZE = 1;

		private const int CEC_LOGIC_ADDRESS_MASK_OFFSET = 19;

		private const int CEC_LOGIC_ADDRESS_MASK_SIZE = 2;

		private const int CEC_GPIO_NUM_VOLUME_OFFSET = 21;

		private const int CEC_GPIO_NUM_VOLUME_SIZE = 1;

		private const int CEC_VOLUME_VALUES_COUNT_OFFSET = 22;

		private const int CEC_VOLUME_VALUES_COUNT_SIZE = 1;

		private const int CEC_GPIO_NUM_MUTE_OFFSET = 23;

		private const int CEC_GPIO_NUM_MUTE_SIZE = 1;

		private const int CEC_RESERVE2_OFFSET = 24;

		private const int CEC_RESERVE2_SIZE = 9;

		private const int CEC_CONFIG_SIZE = 33;

		private const int LED_GPIO_ID_OFFSET = 0;

		private const int LED_GPIO_ID_SIZE = 1;

		private const int LED_GPIO_NUM_OFFSET = 1;

		private const int LED_GPIO_NUM_SIZE = 1;

		private const int LED_RESERVE_1_OFFSET = 2;

		private const int LED_RESERVE_1_SIZE = 3;

		private const int LED_BLOCK_ID1_OFFSET = 5;

		private const int LED_BLOCK_ID1_SIZE = 1;

		private const int LED_BLOCK_ID2_OFFSET = 6;

		private const int LED_BLOCK_ID2_SIZE = 1;

		private const int LED_RESERVE_2_OFFSET = 7;

		private const int LED_RESERVE_2_SIZE = 1;

		private const int LED_VALUES_COUNT_OFFSET = 8;

		private const int LED_VALUES_COUNT_SIZE = 1;

		private const int LED_VALUES_TABLE_OFFSET = 9;

		private const int PIXEL_GPIO_ID_OFFSET = 0;

		private const int PIXEL_GPIO_ID_SIZE = 1;

		private const int PIXEL_START_INDEX_OFFSET = 1;

		private const int PIXEL_START_INDEX_SIZE = 1;

		private const int PIXEL_COUNT_OFFSET = 2;

		private const int PIXEL_COUNT_SIZE = 1;

		private const int PIXEL_INDICATION_MODE_OFFSET = 3;

		private const int PIXEL_INDICATION_MODE_SIZE = 1;

		private const int PIXEL_RESERVE_1_OFFSET = 4;

		private const int PIXEL_RESERVE_1_SIZE = 1;

		private const int PIXEL_BLOCK_ID1_OFFSET = 5;

		private const int PIXEL_BLOCK_ID1_SIZE = 1;

		private const int PIXEL_BLOCK_ID2_OFFSET = 6;

		private const int PIXEL_BLOCK_ID2_SIZE = 1;

		private const int PIXEL_RESERVE_2_OFFSET = 7;

		private const int PIXEL_RESERVE_2_SIZE = 1;

		private const int PIXEL_BLOCK_VALUES_COUNT_OFFSET = 8;

		private const int PIXEL_BLOCK_VALUES_COUNT_SIZE = 1;

		private const int PIXEL_COLORS_TABLE_OFFSET = 9;

		private const int READ_DSP_DESCRIPTOR_OFFSET = 0;

		private const int READ_DSP_DESCRIPTOR_SIZE = 5;

		private const int READ_READ_ADDRESS_OFFSET = 5;

		private const int READ_READ_ADDRESS_SIZE = 2;

		private const int READ_RESERVE_1_OFFSET = 7;

		private const int READ_RESERVE_1_SIZE = 2;

		private const int READ_BYTE_COUNT_OFFSET = 9;

		private const int READ_BYTE_COUNT_SIZE = 1;

		private const int READ_PERIOD_OFFSET = 10;

		private const int READ_PERIOD_SIZE = 1;

		private const int READ_RESERVE_2_OFFSET = 11;

		private const int READ_RESERVE_2_SIZE = 3;

		private const int READ_CONFIG_SIZE = 14;

		private const int READ_ALL_BLOCK_COUNT_OFFSET = 0;

		private const int READ_ALL_BLOCK_COUNT_SIZE = 1;

		private const int READ_ALL_RESERVE_OFFSET = 1;

		private const int READ_ALL_RESERVE_SIZE = 3;

		private const int READ_ALL_1_BLOCK_CONFIG_OFFSET = 4;

		private const int COMPARATOR_MASK_OFFSET = 0;

		private const int COMPARATOR_MASK_SIZE = 8;

		private const int COMPARATOR_VALUE_OFFSET = 8;

		private const int COMPARATOR_VALUE_SIZE = 8;

		private const int COMPARATOR_READ_BLOCK_NUM_OFFSET = 16;

		private const int COMPARATOR_READ_BLOCK_NUM_SIZE = 1;

		private const int COMPARATOR_MODE_OFFSET = 17;

		private const int COMPARATOR_MODE_SIZE = 1;

		private const int COMPARATOR_RESERVE_OFFSET = 18;

		private const int COMPARATOR_RESERVE_SIZE = 10;

		private const int COMPARATOR_BLOCKS_COUNT_OFFSET = 28;

		private const int COMPARATOR_BLOCKS_COUNT_SIZE = 1;

		private const int COMPARATOR_1_BLOCK_CONFIG_SIZE_OFFSET = 29;

		private const int COMPARATOR_1_BLOCK_CONFIG_SIZE_SIZE = 3;

		private const int COMPARATOR_1_BLOCK_CONFIG_OFFSET = 32;

		private const int COMPARATOR_ALL_BLOCK_COUNT_OFFSET = 0;

		private const int COMPARATOR_ALL_BLOCK_COUNT_SIZE = 1;

		private const int COMPARATOR_ALL_RESERVE_OFFSET = 1;

		private const int COMPARATOR_ALL_RESERVE_SIZE = 3;

		private const int COMPARATOR_ALL_1_BLOCK_CONFIG_SIZE_OFFSET = 4;

		private const int COMPARATOR_ALL_1_BLOCK_CONFIG_SIZE_SIZE = 3;

		private const int COMPARATOR_ALL_1_BLOCK_CONFIG_OFFSET = 7;

		private const int CLI_BLOCK_NAME_OFFSET = 0;

		private const int CLI_BLOCK_NAME_SIZE = 17;

		private const int CLI_RESERVE_OFFSET = 17;

		private const int CLI_RESERVE_SIZE = 11;

		private const int CLI_DSPCELL_CONFIG_SIZE_OFFSET = 28;

		private const int CLI_DSPCELL_CONFIG_SIZE_SIZE = 3;

		private const int CLI_DSPCELL_CONFIG_OFFSET = 31;

		private const int CLI_BLOCKS_COUNT_OFFSET = 0;

		private const int CLI_BLOCKS_COUNT_SIZE = 1;

		private const int CLI_1_BLOCK_CONFIG_SIZE_OFFSET = 1;

		private const int CLI_1_BLOCK_CONFIG_SIZE_SIZE = 3;

		private const int CLI_1_BLOCK_CONFIG_OFFSET = 4;

		private const int CLI_ALL_BLOCK_COUNT_OFFSET = 0;

		private const int CLI_ALL_BLOCK_COUNT_SIZE = 1;

		private const int CLI_ALL_RESERVE_OFFSET = 1;

		private const int CLI_ALL_RESERVE_SIZE = 3;

		private const int CLI_ALL_1_BLOCK_CONFIG_SIZE_OFFSET = 4;

		private const int CLI_ALL_1_BLOCK_CONFIG_SIZE_SIZE = 3;

		private const int CLI_ALL_1_BLOCK_CONFIG_OFFSET = 7;

		private const int MUTE_TIMPCS_OFFSET = 0;

		private const int MUTE_TIMPCS_SIZE = 2;

		private const int MUTE_TIMARR_OFFSET = 2;

		private const int MUTE_TIMARR_SIZE = 2;

		private const int MUTE_ACTIVE_LEVEL_OFFSET = 4;

		private const int MUTE_ACTIVE_LEVEL_SIZE = 1;

		private const int MUTE_RESERVE_OFFSET = 5;

		private const int MUTE_RESERVE_SIZE = 3;

		private const int MUTE_CONFIG_SIZE = 8;

		private const int PIXEL_COLOR_SIZE = 4;

		private const int LINE_DSP_CELL_RESERVE_SIZE = 8;

		private const int TransferToDSPSize = 2;

		private const int DSP_BOOT_BLOCK_ID = 0;

		private const int REGULATION_LINE_BLOCK_ID = 1;

		private const int COMMON_PIXEL_BLOCK_ID = 2;

		private const int CEC_BLOCK_ID = 3;

		private const int READS_BLOCK_ID = 4;

		private const int COMPARATORS_BLOCK_ID = 5;

		private const int CLI_BLOCK_ID = 6;

		private const int MUTE_BLOCK_ID = 7;

		private const byte NO_CHIP_SELECT_LINE = byte.MaxValue;

		private const byte NO_LINE_FUNCTION_BLOCK = byte.MaxValue;

		private const byte DSP_CELL_NO_ID = byte.MaxValue;

		private const byte DSP_CELL_ANALOG_EN_ID = 1;

		private const byte LED_BLOCK_ID = 2;

		private const byte PIXEL_LED_BLOCK_ID = 3;

		private const byte CONTROLLER_LINE = 0;

		private const byte PROJECT_TYPE_SINGLE = 0;

		private const byte PROJECT_TYPE_COMBO = 1;

		private const byte PROJECT_CHANGE_REBOOT = 0;

		private const byte PROJECT_CHANGE_RECONFIG = 1;

		private const byte PIXEL_MODULE_DISABLED = 0;

		private const byte PIXEL_MODULE_ENABLED = 1;

		private const byte PIXEL_TYPE_RGB = 0;

		private const byte PIXEL_TYPE_RGBW = 1;

		private const byte PIXEL_PWRON_DISABLED = 0;

		private const byte PIXEL_PWRON_ENABLED = 1;

		private const byte PIXEL_MODE_DATA_TABLE = 0;

		private const byte PIXEL_MODE_SCALE = 1;

		private const byte CEC_NOT_ACTIVE = 0;

		private const byte CEC_ACTIVE = 1;

		private const int DATA_SIZE_PER_TRANSFER_MAX = 65520;

		public static void CombineProjects(int ComboType, int ComboSubType, bool RecongCheck, List<ComboProjectPart> ProjectParts, out List<byte> image)
		{
			image = new List<byte>();
			List<int> list = new List<int>();
			for (int i = 0; i < 4; i++)
			{
				image.Add(0);
			}
			image.Add(1);
			image.Add((byte)ComboType);
			image.Add((byte)ComboSubType);
			if (!RecongCheck)
			{
				image.Add(0);
			}
			else if (RecongCheck)
			{
				image.Add(1);
			}
			for (int j = 0; j < 5; j++)
			{
				image.Add(0);
			}
			int num = 0;
			for (int k = 0; k < ProjectParts.Count; k++)
			{
				if (ProjectParts[k].Image.Count != 0)
				{
					image.Add((byte)k);
					for (int l = 0; l < 8; l++)
					{
						image.Add(0);
					}
					num++;
					list.Add(k);
				}
			}
			int num2 = num * 9;
			image[11] = (byte)num2;
			image[12] = (byte)(num2 >> 8);
			for (int m = 0; m < list.Count; m++)
			{
				int index = list[m];
				int num3 = 13 + m * 9 + 1;
				bool flag = false;
				if (m > 0 && ProjectsEqual(ProjectParts[index].Image, ProjectParts[list[m - 1]].Image))
				{
					flag = true;
				}
				if (!flag)
				{
					int count = image.Count;
					ChangeSegment(image, count, num3, 4);
					List<byte> list2 = new List<byte>(ProjectParts[index].Image);
					int num4 = JoinIntoValue(list2, 8, 4);
					num4 += count;
					ChangeSegment(list2, num4, 8, 4);
					int num5 = JoinIntoValue(list2, 6, 2);
					num5 -= 6;
					num5 /= 7;
					for (int n = 0; n < num5; n++)
					{
						int index2 = 15 + n * 7;
						num4 = JoinIntoValue(list2, index2, 4);
						num4 += count;
						ChangeSegment(list2, num4, index2, 4);
					}
					image.AddRange(list2);
				}
				else
				{
					int num6 = 13 + (m - 1) * 9 + 1;
					for (int num7 = 0; num7 < 4; num7++)
					{
						image[num3 + num7] = image[num6 + num7];
					}
				}
			}
			ChangeSegment(image, image.Count, 0, 4);
		}

		public static bool MakeForProject(UIElementCollection Schema, out List<byte> image)
		{
			image = new List<byte>();
			image.AddRange(new byte[14]);
			image[6] = 6;
			image[8] = 14;
			image[9] = 0;
			if (!ControllerConfig(Schema, out var config))
			{
				return false;
			}
			ChangeSegment(image, config.Length, 12, 2);
			image.AddRange(config);
			int num = 0;
			if (GetCommonPixelConfig(Schema, out config))
			{
				RearrangeMap(image, config, 2, num);
				num++;
			}
			if (GetCECConfig(Schema, out config))
			{
				RearrangeMap(image, config, 3, num);
				num++;
			}
			SchemaBlock_DSP[] array = (from d in ChipStudio.Schema.GetDSPs(Schema)
				where !d.IsSelfBooted
				select d).ToArray();
			foreach (SchemaBlock_DSP dSP in array)
			{
				RearrangeMap(image, GetDSPConfig(Schema, dSP), 0, num);
				num++;
			}
			GetLinesConfig(Schema, out var AllLinesConfig);
			foreach (byte[] item in AllLinesConfig)
			{
				RearrangeMap(image, item, 1, num);
				num++;
			}
			if (GetAllReadConfig(Schema, out config))
			{
				RearrangeMap(image, config, 4, num);
				num++;
			}
			if (GetAllComparatorConfig(Schema, out config))
			{
				RearrangeMap(image, config, 5, num);
				num++;
			}
			if (GetAllCLIConfig(Schema, out config))
			{
				RearrangeMap(image, config, 6, num);
				num++;
			}
			if (GetCtrlMuteConfig(Schema, out config))
			{
				RearrangeMap(image, config, 7, num);
				num++;
			}
			ChangeSegment(image, image.Count, 0, 4);
			return true;
		}

		public static List<byte> MakeForUSBSettings(USBDeviceInfo USBSettings)
		{
			int num = 27 + USBSettings.DeviceNames.Length * 41;
			List<byte> list = new List<byte>
			{
				(byte)(num & 0xFF),
				(byte)(num >> 8)
			};
			ushort num2;
			try
			{
				num2 = Convert.ToUInt16(USBSettings.VID, 16);
			}
			catch (FormatException)
			{
				num2 = 1155;
			}
			list.Add((byte)num2);
			list.Add((byte)(num2 >> 8));
			try
			{
				num2 = Convert.ToUInt16(USBSettings.PID, 16);
			}
			catch (FormatException)
			{
				num2 = 41488;
			}
			list.Add((byte)num2);
			list.Add((byte)(num2 >> 8));
			int count = list.Count;
			for (int i = 0; i < 21; i++)
			{
				list.Add(0);
			}
			if (USBSettings.Manufacturer != null)
			{
				list[count] = (byte)USBSettings.Manufacturer.Length;
				byte[] bytes = Encoding.ASCII.GetBytes(USBSettings.Manufacturer);
				for (int j = 0; j < bytes.Length; j++)
				{
					list[count + 1 + j] = bytes[j];
				}
			}
			for (int k = 0; k < USBSettings.DeviceNames.Length; k++)
			{
				count = list.Count;
				for (int l = 0; l < 41; l++)
				{
					list.Add(0);
				}
				if (USBSettings.DeviceNames[k] != null)
				{
					list[count] = (byte)USBSettings.DeviceNames[k].Length;
					byte[] bytes = Encoding.ASCII.GetBytes(USBSettings.DeviceNames[k]);
					for (int m = 0; m < bytes.Length; m++)
					{
						list[count + 1 + m] = bytes[m];
					}
				}
			}
			return list;
		}

		private static bool ProjectsEqual(List<byte> Proj1, List<byte> Proj2)
		{
			if (Proj1.Count != Proj2.Count)
			{
				return false;
			}
			for (int i = 0; i < Proj1.Count; i++)
			{
				if (Proj1[i] != Proj2[i])
				{
					return false;
				}
			}
			return true;
		}

		private static void RearrangeMap(List<byte> WholeMap, byte[] NewConfig, int ConfigID, int ItemsCount)
		{
			int value = JoinIntoValue(WholeMap[6], WholeMap[7]) + 7;
			ChangeSegment(WholeMap, value, 6, 2);
			int value2 = JoinIntoValue(WholeMap[8], WholeMap[9]) + 7;
			ChangeSegment(WholeMap, value2, 8, 4);
			for (int i = 0; i < ItemsCount; i++)
			{
				int index = 15 + i * 7;
				int value3 = JoinIntoValue(WholeMap, index, 4) + 7;
				ChangeSegment(WholeMap, value3, index, 4);
			}
			List<byte> list = new List<byte>();
			for (int j = 0; j < 7; j++)
			{
				list.Add(0);
			}
			list[0] = (byte)ConfigID;
			ChangeSegment(list, WholeMap.Count + 7, 1, 4);
			ChangeSegment(list, NewConfig.Length, 5, 2);
			int num = 14;
			for (int k = 0; k < ItemsCount; k++)
			{
				num += 7;
			}
			WholeMap.InsertRange(num, list);
			WholeMap.AddRange(NewConfig);
		}

		private static void GetLinesConfig(UIElementCollection SchemaElements, out List<byte[]> AllLinesConfig)
		{
			AllLinesConfig = new List<byte[]>();
			SchemaBlock_Controller controller = Schema.GetController(SchemaElements);
			SchemaBlock_PixelLED[] pixelLEDs = Schema.GetPixelLEDs(SchemaElements);
			int[] array = ((pixelLEDs.Length != 0) ? GetPixelBlocksStartIndex(SchemaElements) : null);
			bool[] gPIOsActivity = controller.GetGPIOsActivity();
			for (int i = 0; i < gPIOsActivity.Length; i++)
			{
				if (!gPIOsActivity[i])
				{
					continue;
				}
				List<byte> list = new List<byte>
				{
					0,
					(byte)i,
					byte.MaxValue,
					byte.MaxValue
				};
				ConnectionNode anchorConnectionNode = controller.GetAnchorConnectionNode(i);
				if (!GetLineDSPCellsConfig(SchemaElements, anchorConnectionNode, list))
				{
					continue;
				}
				SchemaBlock[] lineLeds = GetLineLeds(SchemaElements, anchorConnectionNode);
				foreach (SchemaBlock schemaBlock in lineLeds)
				{
					List<byte> config;
					if (schemaBlock.BlockType == SchemaBlock.SchemaBlockTypes.LED)
					{
						if (!GetLEDConfig(schemaBlock as SchemaBlock_LED, Schema.GetConnections(SchemaElements), out config))
						{
							continue;
						}
					}
					else
					{
						if (array == null)
						{
							continue;
						}
						SchemaBlock_PixelLED schemaBlock_PixelLED = schemaBlock as SchemaBlock_PixelLED;
						config = GetPixelConfig(schemaBlock_PixelLED, controller.PixelSettings.PixelType, array[Array.IndexOf(pixelLEDs, schemaBlock_PixelLED)]);
					}
					list[4]++;
					for (int k = 0; k < 3; k++)
					{
						list.Add((byte)(config.Count >> k * 8));
					}
					list.AddRange(config);
				}
				AllLinesConfig.Add(list.ToArray());
			}
		}

		private static bool GetLineDSPCellsConfig(UIElementCollection SchemaElements, ConnectionNode LineNode, List<byte> config)
		{
			config.Add(0);
			Connection[] connections = Schema.GetConnections(SchemaElements);
			int connectindex;
			for (ConnectionNode oppositeNode = GetOppositeNode(connections, LineNode, 0, out connectindex); oppositeNode != null; oppositeNode = GetOppositeNode(connections, LineNode, connectindex + 1, out connectindex))
			{
				SchemaBlock_DSPCell[] dSPCells = Schema.GetDSPCells(SchemaElements, oppositeNode.BlockName);
				foreach (SchemaBlock_DSPCell schemaBlock_DSPCell in dSPCells)
				{
					int count = config.Count;
					config.AddRange(new byte[3]);
					if (!GetDSPCellConfig(SchemaElements, schemaBlock_DSPCell, oppositeNode.AnchorNumber, out var config2))
					{
						return false;
					}
					config.AddRange(config2);
					if (schemaBlock_DSPCell.IsBypassable && oppositeNode.AnchorNumber == 0)
					{
						ConnectionNode anchorConnectionNode = schemaBlock_DSPCell.GetAnchorConnectionNode(1);
						if (anchorConnectionNode != null)
						{
							int connectindex2;
							ConnectionNode oppositeNode2 = GetOppositeNode(connections, anchorConnectionNode, 0, out connectindex2);
							if (oppositeNode2 != null)
							{
								config[2] = (byte)oppositeNode2.AnchorNumber;
							}
						}
					}
					int num = config.Count - (count + 3);
					for (int j = 0; j < 3; j++)
					{
						config[count + j] = (byte)(num >> j * 8);
					}
					byte b = config[4];
					b++;
					config[4] = b;
				}
			}
			return true;
		}

		private static bool GetDSPCellConfig(UIElementCollection SchemaElements, SchemaBlock_DSPCell DSPCell, int ActiveAnchorNum, out List<byte> config)
		{
			config = new List<byte>();
			SchemaBlock_DSP dSP = Schema.GetDSP(SchemaElements, DSPCell.DSPTitle);
			if (dSP == null)
			{
				MessageBox.Show("<" + DSPCell.DSPTitle + "> is not in the project.", "", MessageBoxButton.OK, MessageBoxImage.Hand);
				return false;
			}
			config.AddRange(GetDSPDescriptor(SchemaElements, dSP));
			if (DSPCell.IsBypassable && ActiveAnchorNum == 1)
			{
				ConnectionNode anchorConnectionNode = DSPCell.GetAnchorConnectionNode(0);
				if (GetOppositeNode(Schema.GetConnections(SchemaElements), anchorConnectionNode, 0, out var _) != null)
				{
					config.Add(1);
				}
				else
				{
					config.Add(byte.MaxValue);
				}
			}
			else
			{
				config.Add(byte.MaxValue);
			}
			config.Add(byte.MaxValue);
			config.AddRange(new byte[8]);
			config.Add((byte)DSPCell.WriteType);
			config.Add((byte)DSPCell.ValueSize);
			config.Add((byte)(DSPCell.ValueSize >> 8));
			if (DSPCell.IsBypassable && ActiveAnchorNum == 1)
			{
				config.Add((byte)DSPCell.EnValuesCount);
			}
			else
			{
				config.Add((byte)DSPCell.ValuesCount);
			}
			config.Add((byte)DSPCell.ParametersCount);
			config.Add((byte)(DSPCell.ParametersCount >> 8));
			for (int i = 0; i < DSPCell.ParametersCount; i++)
			{
				DSPCell.ParamAddressAndSize(i, out var address, out var size);
				for (int j = 0; j < 4; j++)
				{
					config.Add((byte)(address >> j * 8));
				}
				config.Add((byte)size);
				config.Add((byte)(size >> 8));
			}
			if (DSPCell.IsBypassable && ActiveAnchorNum == 1)
			{
				config.AddRange(DSPCell.GetEnData());
			}
			else
			{
				config.AddRange(DSPCell.GetData());
			}
			return true;
		}

		private static bool GetLEDConfig(SchemaBlock_LED LEDBlock, Connection[] Connections, out List<byte> config)
		{
			config = new List<byte> { 0 };
			int connectindex;
			ConnectionNode oppositeNode = GetOppositeNode(Connections, LEDBlock.GetAnchorConnectionNode(0), 0, out connectindex);
			if (oppositeNode == null)
			{
				MessageBox.Show("Block <" + LEDBlock.Title + "> is not connected to controller", "", MessageBoxButton.OK, MessageBoxImage.Exclamation);
				return false;
			}
			config.Add((byte)oppositeNode.AnchorNumber);
			config.AddRange(new byte[3]);
			config.Add(2);
			config.Add(byte.MaxValue);
			config.Add(0);
			byte[] data = LEDBlock.GetData();
			config.Add((byte)data.Length);
			config.AddRange(data);
			return true;
		}

		private static byte[] GetDSPConfig(UIElementCollection SchemaElements, SchemaBlock_DSP DSP)
		{
			List<byte> list = new List<byte>();
			list.AddRange(GetDSPDescriptor(SchemaElements, DSP));
			List<DataTransfer> boot = DSP.GetBoot();
			int num = boot.Count;
			int count = list.Count;
			list.Add((byte)boot.Count);
			list.Add((byte)(boot.Count >> 8));
			foreach (DataTransfer item in boot)
			{
				if (item.Size <= 65535)
				{
					list.Add((byte)item.Type);
					list.AddRange(SplitToBytes(item.Address, 4));
					list.Add(item.AddressIncrement);
					list.AddRange(SplitToBytes(item.Size, 2));
					if (item.Type == DataTransfer.TransferTypes.Write || item.Type == DataTransfer.TransferTypes.Poll)
					{
						list.AddRange(item.Data);
					}
					continue;
				}
				num++;
				for (int i = 0; i < 2; i++)
				{
					int num2 = ((i == 0) ? 65520 : (item.Size - 65520));
					list.Add((byte)item.Type);
					list.AddRange(SplitToBytes(item.Address + i * (65520 / item.AddressIncrement), 4));
					list.Add(item.AddressIncrement);
					list.AddRange(SplitToBytes(num2, 2));
					byte[] array = new byte[num2];
					Array.Copy(item.Data, i * 65520, array, 0, num2);
					if (item.Type == DataTransfer.TransferTypes.Write || item.Type == DataTransfer.TransferTypes.Poll)
					{
						list.AddRange(array);
					}
				}
			}
			list[count] = (byte)num;
			list[count + 1] = (byte)(num >> 8);
			return list.ToArray();
		}

		private static byte[] GetDSPDescriptor(UIElementCollection SchemaElements, SchemaBlock_DSP DSP)
		{
			byte[] array = new byte[5]
			{
				DSP.CoreID,
				DSP.GetBusAddress(),
				0,
				0,
				0
			};
			Connection[] connections = Schema.GetConnections(SchemaElements);
			byte AnchorNumber;
			if (DSP.IsChipSelectable)
			{
				array[2] = (GetOppositeNodeAnchorNumber(connections, DSP.GetAnchorConnectionNode(1), out AnchorNumber) ? AnchorNumber : byte.MaxValue);
			}
			else
			{
				array[2] = byte.MaxValue;
			}
			array[3] = DSP.Interface;
			GetOppositeNodeAnchorNumber(connections, DSP.GetAnchorConnectionNode(0), out AnchorNumber);
			array[4] = Schema.GetController(SchemaElements).GetInterfaceNum(AnchorNumber);
			return array;
		}

		private static bool ControllerConfig(UIElementCollection SchemaElements, out byte[] config)
		{
			config = null;
			SchemaBlock_Controller controller = Schema.GetController(SchemaElements);
			if (controller == null)
			{
				return false;
			}
			List<byte> list = new List<byte> { controller.CoreID };
			list.AddRange(controller.GetGPIOFunctions());
			controller.GetStartDelayParams(out var IsDelayActive, out var _);
			if (IsDelayActive)
			{
				list.Add(1);
				list.Add(0);
				controller.GetStartDelay(out var TimPSC, out var TimARR);
				list.Add((byte)TimPSC);
				list.Add((byte)(TimPSC >> 8));
				list.Add((byte)TimARR);
				list.Add((byte)(TimARR >> 8));
			}
			else
			{
				list.AddRange(new byte[6]);
			}
			ushort num = (ushort)((controller.Options != null) ? controller.Options.Get() : 0);
			list.Add((byte)num);
			list.Add((byte)(num >> 8));
			list.AddRange(new byte[4]);
			config = list.ToArray();
			return true;
		}

		private static bool GetCommonPixelConfig(UIElementCollection SchemaElements, out byte[] CommonPixelconfig)
		{
			CommonPixelconfig = null;
			PixelModule pixelSettings = Schema.GetController(SchemaElements).PixelSettings;
			SchemaBlock_PixelLED[] pixelLEDs = Schema.GetPixelLEDs(SchemaElements);
			if (pixelSettings == null || !pixelSettings.IsEnabled || pixelLEDs.Length == 0)
			{
				return false;
			}
			int[] pixelBlocksStartIndex = GetPixelBlocksStartIndex(SchemaElements);
			if (pixelBlocksStartIndex == null)
			{
				return false;
			}
			List<byte> list = new List<byte>();
			if (pixelSettings.IsEnabled)
			{
				list.Add(1);
			}
			else
			{
				list.Add(0);
			}
			if (pixelSettings.PixelType == PixelModule.PixelTypes.RGB)
			{
				list.Add(0);
			}
			else
			{
				list.Add(1);
			}
			list.Add((byte)pixelLEDs.Select((SchemaBlock_PixelLED p) => p.Settings.LEDsCount).ToArray().Sum());
			if (pixelSettings.IsPwrOnEnabled)
			{
				list.Add(1);
			}
			else
			{
				list.Add(0);
			}
			list.AddRange(new byte[3]);
			SchemaBlock_PixelLED[] array = pixelLEDs.Where((SchemaBlock_PixelLED p) => p.Settings.IndicationType == PixelLEDBlock.IndicationTypes.Project).ToArray();
			list.Add((byte)array.Length);
			SchemaBlock_PixelLED[] array2 = array;
			foreach (SchemaBlock_PixelLED schemaBlock_PixelLED in array2)
			{
				byte[] pixelProjGroupConfig = GetPixelProjGroupConfig(schemaBlock_PixelLED, pixelSettings.PixelType, pixelBlocksStartIndex[Array.IndexOf(pixelLEDs, schemaBlock_PixelLED)]);
				list.Add((byte)pixelProjGroupConfig.Length);
				list.AddRange(pixelProjGroupConfig);
			}
			CommonPixelconfig = list.ToArray();
			return true;
		}

		private static bool GetCECConfig(UIElementCollection SchemaElements, out byte[] CECConfig)
		{
			CECConfig = new byte[33];
			SchemaBlock_Controller controller = Schema.GetController(SchemaElements);
			CEC cECSettings = controller.CECSettings;
			if (cECSettings == null || !cECSettings.IsEnabled)
			{
				return false;
			}
			CECConfig[0] = 1;
			CECConfig[1] = (byte)cECSettings.PortNumber;
			CECConfig[2] = (byte)cECSettings.Name.Length;
			byte[] bytes = Encoding.ASCII.GetBytes(cECSettings.Name);
			for (int i = 0; i < bytes.Length; i++)
			{
				CECConfig[3 + i] = bytes[i];
			}
			CECConfig[17] = cECSettings.Options();
			CECConfig[21] = (byte)cECSettings.VolumeGpio;
			int lineDSPCellValuesCount = GetLineDSPCellValuesCount(SchemaElements, controller.GetAnchorConnectionNode(CECConfig[21]));
			CECConfig[22] = (byte)((lineDSPCellValuesCount > 0) ? ((byte)lineDSPCellValuesCount) : 50);
			CECConfig[23] = (byte)cECSettings.MuteGpio;
			return true;
		}

		private static byte[] GetPixelProjGroupConfig(SchemaBlock_PixelLED Pixel, PixelModule.PixelTypes PixelType, int StartIndex)
		{
			List<byte> list = new List<byte>
			{
				0,
				0,
				(byte)StartIndex,
				(byte)Pixel.Settings.LEDsCount
			};
			string[] colors = Pixel.GetColors();
			for (int i = 0; i < colors.Length; i++)
			{
				list.AddRange(ColorStringToByteArray(colors[i], PixelType));
			}
			return list.ToArray();
		}

		private static List<byte> GetPixelConfig(SchemaBlock_PixelLED Pixel, PixelModule.PixelTypes PixelType, int StartIndex)
		{
			List<byte> list = new List<byte>
			{
				0,
				(byte)StartIndex,
				(byte)Pixel.Settings.LEDsCount
			};
			if (Pixel.Settings.IndicationMode == PixelLEDBlock.IndicationModes.DataTable)
			{
				list.Add(0);
			}
			else
			{
				list.Add(1);
			}
			list.Add(0);
			list.Add(3);
			list.Add(byte.MaxValue);
			list.Add(0);
			list.Add((byte)Pixel.Settings.StatesCount);
			string[] colors = Pixel.GetColors();
			for (int i = 0; i < colors.Length; i++)
			{
				list.AddRange(ColorStringToByteArray(colors[i], PixelType));
			}
			return list;
		}

		private static bool GetAllReadConfig(UIElementCollection SchemaElements, out byte[] config)
		{
			config = null;
			List<byte> list = new List<byte>();
			SchemaBlock_Read[] array = (from r in Schema.GetReads(SchemaElements)
				where r.DSP != null
				select r).ToArray();
			if (array.Length == 0)
			{
				return false;
			}
			list.Add((byte)array.Length);
			list.AddRange(new byte[3]);
			SchemaBlock_Read[] array2 = array;
			foreach (SchemaBlock_Read schemaBlock_Read in array2)
			{
				list.AddRange(GetDSPDescriptor(SchemaElements, Schema.GetDSP(SchemaElements, schemaBlock_Read.DSP)));
				list.Add((byte)schemaBlock_Read.GetAddressValue());
				list.Add((byte)(schemaBlock_Read.GetAddressValue() >> 8));
				list.AddRange(new byte[2]);
				list.Add(schemaBlock_Read.GetBytesCountValue());
				list.Add((byte)schemaBlock_Read.PeriodIndex);
				list.AddRange(new byte[3]);
			}
			config = list.ToArray();
			return true;
		}

		private static bool GetAllComparatorConfig(UIElementCollection SchemaElements, out byte[] config)
		{
			config = null;
			List<byte> list = new List<byte>();
			SchemaBlock_Comparator[] array = Schema.GetComparators(SchemaElements).ToArray();
			if (array.Length == 0)
			{
				return false;
			}
			list.Add(0);
			list.AddRange(new byte[3]);
			SchemaBlock_Comparator[] array2 = array;
			foreach (SchemaBlock_Comparator comp in array2)
			{
				if (GetComparatorConfig(SchemaElements, comp, out var Config))
				{
					list[0]++;
					for (int j = 0; j < 3; j++)
					{
						list.Add((byte)(Config.Count >> j * 8));
					}
					list.AddRange(Config);
				}
			}
			config = list.ToArray();
			return list[0] != 0;
		}

		private static bool GetComparatorConfig(UIElementCollection SchemaElements, SchemaBlock_Comparator comp, out List<byte> Config)
		{
			Config = new List<byte>();
			for (int i = 0; i < 8; i++)
			{
				Config.Add((byte)(comp.GetMaskValue() >> i * 8));
			}
			for (int j = 0; j < 8; j++)
			{
				Config.Add((byte)(comp.GetValueValue() >> j * 8));
			}
			int comparatorReadBlockIndex = GetComparatorReadBlockIndex(SchemaElements, comp);
			if (comparatorReadBlockIndex == -1)
			{
				return false;
			}
			Config.Add((byte)comparatorReadBlockIndex);
			Config.Add((byte)comp.Mode);
			Config.AddRange(new byte[10]);
			Config.Add(0);
			SchemaBlock[] comparatorUsers = GetComparatorUsers(SchemaElements, comp);
			if (comparatorUsers.Length == 0)
			{
				MessageBox.Show("Comparator <" + comp.Title + "> is not used by any block", "", MessageBoxButton.OK, MessageBoxImage.Exclamation);
				return false;
			}
			PixelModule.PixelTypes pixelType = Schema.GetController(SchemaElements).PixelSettings.PixelType;
			SchemaBlock_PixelLED[] pixelLEDs = Schema.GetPixelLEDs(SchemaElements);
			int[] array = ((pixelLEDs.Length != 0) ? GetPixelBlocksStartIndex(SchemaElements) : null);
			SchemaBlock[] array2 = comparatorUsers;
			foreach (SchemaBlock schemaBlock in array2)
			{
				SchemaBlock.SchemaBlockTypes blockType = schemaBlock.BlockType;
				List<byte> config;
				if (blockType != SchemaBlock.SchemaBlockTypes.LED)
				{
					if (blockType != SchemaBlock.SchemaBlockTypes.PixelLED || array == null)
					{
						continue;
					}
					SchemaBlock_PixelLED schemaBlock_PixelLED = schemaBlock as SchemaBlock_PixelLED;
					config = GetPixelConfig(schemaBlock_PixelLED, pixelType, array[Array.IndexOf(pixelLEDs, schemaBlock_PixelLED)]);
				}
				else if (!GetLEDConfig(schemaBlock as SchemaBlock_LED, Schema.GetConnections(SchemaElements), out config))
				{
					continue;
				}
				Config[28]++;
				for (int l = 0; l < 3; l++)
				{
					Config.Add((byte)(config.Count >> l * 8));
				}
				Config.AddRange(config);
			}
			return Config[28] != 0;
		}

		private static int GetComparatorReadBlockIndex(UIElementCollection SchemaElements, SchemaBlock_Comparator comp)
		{
			SchemaBlock_Read[] array = (from r in Schema.GetReads(SchemaElements)
				where r.DSP != null
				select r).ToArray();
			if (array.Length == 0)
			{
				return -1;
			}
			for (int i = 0; i < array.Length; i++)
			{
				if (Schema.GetConnections(SchemaElements, comp.GetAnchorConnectionNode(0), array[i].GetAnchorConnectionNode(0)).Length != 0)
				{
					return i;
				}
			}
			MessageBox.Show("Comparator <" + comp.Title + "> is not connected to any Read block", "", MessageBoxButton.OK, MessageBoxImage.Exclamation);
			return -1;
		}

		private static SchemaBlock[] GetComparatorUsers(UIElementCollection SchemaElements, SchemaBlock_Comparator comp)
		{
			return (from b in SchemaElements.OfType<SchemaBlock>()
				where b is IComparatorDependent && (b as IComparatorDependent).ActiveComparator == comp.Title
				select b).ToArray();
		}

		private static bool GetAllCLIConfig(UIElementCollection SchemaElements, out byte[] config)
		{
			config = null;
			List<byte> list = new List<byte>();
			SchemaBlock_Controller controller = Schema.GetController(SchemaElements);
			if (controller.CLISettings == null || !controller.CLISettings.IsEnabled)
			{
				return false;
			}
			list.Add(0);
			list.AddRange(new byte[3]);
			SchemaBlock_DSPCell[] dSPCells = Schema.GetDSPCells(SchemaElements);
			if (dSPCells.Length != 0)
			{
				ConnectionNode cLIConnectionNode = controller.GetCLIConnectionNode();
				SchemaBlock_DSPCell[] array = dSPCells;
				foreach (SchemaBlock_DSPCell schemaBlock_DSPCell in array)
				{
					for (int j = 0; j < 2; j++)
					{
						if ((j != 1 || schemaBlock_DSPCell.IsBypassable) && Schema.GetConnections(SchemaElements, cLIConnectionNode, schemaBlock_DSPCell.GetAnchorConnectionNode(j)).Length != 0 && GetDSPCellConfigForCLI(SchemaElements, schemaBlock_DSPCell, j, out var Config))
						{
							list[0]++;
							for (int k = 0; k < 3; k++)
							{
								list.Add((byte)(Config.Count >> k * 8));
							}
							list.AddRange(Config);
						}
					}
				}
			}
			config = list.ToArray();
			return true;
		}

		private static bool GetDSPCellConfigForCLI(UIElementCollection SchemaElements, SchemaBlock_DSPCell DSPCell, int ActiveAnchorNum, out List<byte> Config)
		{
			Config = new List<byte>();
			byte[] bytes = Encoding.ASCII.GetBytes(DSPCell.Title);
			Config.AddRange(new byte[17]);
			int num = ((bytes.Length < 17) ? bytes.Length : 16);
			for (int i = 0; i < num; i++)
			{
				Config[i] = bytes[i];
			}
			Config[num] = 0;
			Config.AddRange(new byte[11]);
			if (!GetDSPCellConfig(SchemaElements, DSPCell, ActiveAnchorNum, out var config))
			{
				return false;
			}
			for (int j = 0; j < 3; j++)
			{
				Config.Add((byte)(config.Count >> j * 8));
			}
			Config.AddRange(config);
			int count = Config.Count;
			Config.Add(0);
			SchemaBlock[] array = (from b in SchemaElements.OfType<SchemaBlock>()
				where b is ILed && (b as ILed).DSPBlockConnectionNode != null && (b as ILed).DSPBlockConnectionNode.BlockName == DSPCell.FullName && (b as ILed).DSPBlockConnectionNode.AnchorNumber == ActiveAnchorNum
				select b).ToArray();
			PixelModule.PixelTypes pixelType = Schema.GetController(SchemaElements).PixelSettings.PixelType;
			SchemaBlock_PixelLED[] pixelLEDs = Schema.GetPixelLEDs(SchemaElements);
			int[] array2 = ((pixelLEDs.Length != 0) ? GetPixelBlocksStartIndex(SchemaElements) : null);
			SchemaBlock[] array3 = array;
			foreach (SchemaBlock schemaBlock in array3)
			{
				SchemaBlock.SchemaBlockTypes blockType = schemaBlock.BlockType;
				List<byte> config2;
				if (blockType != SchemaBlock.SchemaBlockTypes.LED)
				{
					if (blockType != SchemaBlock.SchemaBlockTypes.PixelLED || array2 == null)
					{
						continue;
					}
					SchemaBlock_PixelLED schemaBlock_PixelLED = schemaBlock as SchemaBlock_PixelLED;
					config2 = GetPixelConfig(schemaBlock_PixelLED, pixelType, array2[Array.IndexOf(pixelLEDs, schemaBlock_PixelLED)]);
				}
				else if (!GetLEDConfig(schemaBlock as SchemaBlock_LED, Schema.GetConnections(SchemaElements), out config2))
				{
					continue;
				}
				Config[count]++;
				for (int l = 0; l < 3; l++)
				{
					Config.Add((byte)(config2.Count >> l * 8));
				}
				Config.AddRange(config2);
			}
			return true;
		}

		private static bool GetCtrlMuteConfig(UIElementCollection SchemaElements, out byte[] config)
		{
			config = new byte[8];
			SchemaBlock_Controller controller = Schema.GetController(SchemaElements);
			if (controller == null || controller.MuteIndex == -1)
			{
				return false;
			}
			controller.GetMuteTimParams(out var TimPSC, out var TimARR);
			for (int i = 0; i < 2; i++)
			{
				config[i] = (byte)(TimPSC >> 8 * i);
			}
			for (int j = 0; j < 2; j++)
			{
				config[2 + j] = (byte)(TimARR >> 8 * j);
			}
			config[4] = (byte)controller.MuteLevel;
			return true;
		}

		private static SchemaBlock[] GetLineLeds(UIElementCollection SchemaElements, ConnectionNode LineNode)
		{
			List<SchemaBlock> list = new List<SchemaBlock>();
			SchemaBlock[] array = (from b in SchemaElements.OfType<SchemaBlock>()
				where b is ILed
				select b).ToArray();
			foreach (SchemaBlock schemaBlock in array)
			{
				ConnectionNode dSPBlockConnectionNode = (schemaBlock as ILed).DSPBlockConnectionNode;
				if (dSPBlockConnectionNode != null && Schema.GetConnections(SchemaElements, LineNode, dSPBlockConnectionNode).Length != 0)
				{
					list.Add(schemaBlock);
				}
			}
			return list.ToArray();
		}

		private static int[] GetPixelBlocksStartIndex(UIElementCollection SchemaElements)
		{
			SchemaBlock_PixelLED[] pixelLEDs = Schema.GetPixelLEDs(SchemaElements);
			Connection[] connections = Schema.GetConnections(SchemaElements);
			string title = Schema.GetController(SchemaElements).Title;
			int[] array = new int[pixelLEDs.Length];
			int num = 0;
			int num2 = 0;
			int connectindex;
			for (int i = 0; i < pixelLEDs.Length; i++)
			{
				ConnectionNode oppositeNode = GetOppositeNode(connections, pixelLEDs[i].GetAnchorConnectionNode(0), 0, out connectindex);
				if (oppositeNode == null)
				{
					MessageBox.Show("PixelLEDs are not connected to controller", "", MessageBoxButton.OK, MessageBoxImage.Exclamation);
					return null;
				}
				if (oppositeNode.BlockName == title)
				{
					array[i] = num;
					num += pixelLEDs[i].Settings.LEDsCount;
					num2 = i;
					break;
				}
			}
			ConnectionNode anchorConnectionNode = pixelLEDs[num2].GetAnchorConnectionNode(1);
			for (ConnectionNode oppositeNode2 = GetOppositeNode(connections, anchorConnectionNode, 0, out connectindex); oppositeNode2 != null; oppositeNode2 = GetOppositeNode(connections, anchorConnectionNode, 0, out connectindex))
			{
				for (int j = 0; j < pixelLEDs.Length; j++)
				{
					if (oppositeNode2.BlockName == pixelLEDs[j].Title)
					{
						array[j] = num;
						num += pixelLEDs[j].Settings.LEDsCount;
						anchorConnectionNode = pixelLEDs[j].GetAnchorConnectionNode(1);
						break;
					}
				}
			}
			return array;
		}

		private static byte[] ColorStringToByteArray(string ColorString, PixelModule.PixelTypes LEDType)
		{
			uint num = uint.Parse(ColorString.Substring(1), NumberStyles.HexNumber);
			byte[] array = new byte[4]
			{
				(byte)(255 - (num >> 24)),
				(byte)num,
				(byte)(num >> 16),
				(byte)(num >> 8)
			};
			if (LEDType == PixelModule.PixelTypes.RGB)
			{
				array[0] = array[1];
				array[1] = array[2];
				array[2] = array[3];
				array[3] = 0;
			}
			return array;
		}

		private static byte[] SplitToBytes(int value, int BytesCount)
		{
			byte[] array = new byte[BytesCount];
			for (int i = 0; i < BytesCount; i++)
			{
				array[i] = (byte)(value >> i * 8);
			}
			return array;
		}

		private static int JoinIntoValue(params byte[] input)
		{
			int num = 0;
			for (int i = 0; i < input.Length && i != 4; i++)
			{
				num |= input[i] << i * 8;
			}
			return num;
		}

		private static int JoinIntoValue(List<byte> list, int index, int size)
		{
			int num = 0;
			for (int i = 0; i < size && i != 4; i++)
			{
				num |= list[index + i] << i * 8;
			}
			return num;
		}

		private static void ChangeSegment(List<byte> list, int value, int index, int size)
		{
			byte[] array = SplitToBytes(value, size);
			for (int i = 0; i < size; i++)
			{
				list[index + i] = array[i];
			}
		}

		private static ConnectionNode GetOppositeNode(Connection[] Connections, ConnectionNode Node, int startindex, out int connectindex)
		{
			connectindex = -1;
			for (int i = startindex; i < Connections.Length; i++)
			{
				for (int j = 0; j < Connections[i].Nodes.Count; j++)
				{
					if (Connections[i].Nodes[j].BlockName == Node.BlockName && Connections[i].Nodes[j].AnchorNumber == Node.AnchorNumber)
					{
						connectindex = i;
						if (j != 0)
						{
							return Connections[i].Nodes[0];
						}
						return Connections[i].Nodes[1];
					}
				}
			}
			return null;
		}

		private static bool GetOppositeNodeAnchorNumber(Connection[] Connections, ConnectionNode Node, out byte AnchorNumber)
		{
			AnchorNumber = 0;
			Connection[] array = Connections.Where((Connection c) => (c.Nodes[0].BlockName == Node.BlockName && c.Nodes[0].AnchorNumber == Node.AnchorNumber) || (c.Nodes[1].BlockName == Node.BlockName && c.Nodes[1].AnchorNumber == Node.AnchorNumber)).ToArray();
			if (array.Length == 0)
			{
				return false;
			}
			AnchorNumber = ((array[0].Nodes[0].BlockName == Node.BlockName && array[0].Nodes[0].AnchorNumber == Node.AnchorNumber) ? ((byte)array[0].Nodes[1].AnchorNumber) : ((byte)array[0].Nodes[0].AnchorNumber));
			return true;
		}

		private static int GetLineDSPCellValuesCount(UIElementCollection SchemaElements, ConnectionNode LineNode)
		{
			int result = -1;
			Connection[] connections = Schema.GetConnections(SchemaElements);
			int connectindex;
			for (ConnectionNode oppositeNode = GetOppositeNode(connections, LineNode, 0, out connectindex); oppositeNode != null; oppositeNode = GetOppositeNode(connections, LineNode, connectindex + 1, out connectindex))
			{
				SchemaBlock_DSPCell[] dSPCells = Schema.GetDSPCells(SchemaElements, oppositeNode.BlockName);
				int num = 0;
				if (num < dSPCells.Length)
				{
					SchemaBlock_DSPCell schemaBlock_DSPCell = dSPCells[num];
					result = ((schemaBlock_DSPCell.IsBypassable && oppositeNode.AnchorNumber == 1) ? schemaBlock_DSPCell.EnValuesCount : schemaBlock_DSPCell.ValuesCount);
				}
			}
			return result;
		}
	}
}
