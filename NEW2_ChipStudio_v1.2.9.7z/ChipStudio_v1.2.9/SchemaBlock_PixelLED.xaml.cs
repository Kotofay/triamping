using System;
using System.CodeDom.Compiler;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Windows;
using System.Windows.Markup;

namespace ChipStudio
{
	public partial class SchemaBlock_PixelLED : SchemaBlock, ILed, IComparatorDependent, IComponentConnector
	{
		private static readonly Anchor.AnchorTypes[] PointAnchors = new Anchor.AnchorTypes[2]
		{
			Anchor.AnchorTypes.FromPixel,
			Anchor.AnchorTypes.ToPixel
		};

		public const int TO_PIXEL_OUTPUT_POINT_INDEX = 0;

		public const int TO_PIXEL_INPUT_POINT_INDEX = 1;

		private const double PixelDiameter = 15.0;

		private const int SCALE_FOREGROUND_LEDS_COUNT = 1;

		private const int SCALE_BACKGROUND_LEDS_COUNT = 1;

		private const int SCALE_LEDS_COUNT = 2;

		private const int COMPARATOR_STATES_COUNT = 2;

		private int pixelcount = 1;

		private PixelLEDBlock _Settings = new PixelLEDBlock();

		public override SchemaBlockTypes BlockType => SchemaBlockTypes.PixelLED;

		public string ActiveComparator
		{
			get
			{
				if (Settings.IndicationType != PixelLEDBlock.IndicationTypes.Comparator)
				{
					return null;
				}
				return CompSelector.SelectedItem;
			}
		}

		public int PixelCount
		{
			get
			{
				return pixelcount;
			}
			set
			{
				if (pixelcount != value)
				{
					pixelcount = value;
					NotifyPropertyChanged("PixelCount");
				}
			}
		}

		public int StateCount
		{
			get
			{
				return _Settings.StatesCount;
			}
			set
			{
				if (_Settings.StatesCount != value)
				{
					_Settings.StatesCount = value;
					NotifyPropertyChanged("StateCount");
				}
			}
		}

		public PixelLEDBlock Settings
		{
			get
			{
				return _Settings;
			}
			set
			{
				_Settings = value;
				ApplySettings();
			}
		}

		public ConnectionNode DSPBlockConnectionNode
		{
			get
			{
				if (Settings.IndicationType != PixelLEDBlock.IndicationTypes.DSPBlock)
				{
					return null;
				}
				return BlockList.ActiveConnectionNode();
			}
		}

		public List<Pixel> Pixels { get; private set; } = new List<Pixel>();

		public SchemaBlock_PixelLED()
		{
			InitializeComponent();
			base.DataContext = this;
			BlockList.SelectionChanged += BlockChanged;
			InitConnectionPoints(PointAnchors);
			base.ConnectionPoints[1].Margin = new Thickness(30.0, 0.0, 0.0, 0.0);
			ConnectPoints.ItemsSource = base.ConnectionPoints;
			UpdatePixelList();
			base.Loaded += PixelLEDBlock_Loaded;
		}

		public void UpdateBlockList(SchemaBlock_DSPCell[] Blocks, Schema.UpdateOptions Option)
		{
			BlockList.Update(Blocks, Option);
		}

		public void UpdateComparatorList(string[] ComparatorTitles, Schema.UpdateOptions Option)
		{
			CompSelector.Update(ComparatorTitles, Option);
		}

		public string[] GetColors()
		{
			return Pixels.Select((Pixel p) => p.Color).ToArray();
		}

		public void SetColors(string[] Colors)
		{
			if (Colors.Length >= Pixels.Count)
			{
				for (int i = 0; i < Pixels.Count; i++)
				{
					Pixels[i].Color = Colors[i];
				}
			}
			else
			{
				MessageBox.Show("Colors are not defined.\n\r<" + base.Title + ">", "", MessageBoxButton.OK, MessageBoxImage.Exclamation);
			}
		}

		public int GetDefaultBlockIndex()
		{
			if (Settings.IndicationType == PixelLEDBlock.IndicationTypes.Comparator)
			{
				return CompSelector.SelectedIndex;
			}
			return BlockList.DefaultBlock;
		}

		public void SetDefaultBlockIndex(int BlockIndex)
		{
			if (Settings.IndicationType != PixelLEDBlock.IndicationTypes.Comparator)
			{
				BlockList.DefaultBlock = BlockIndex;
			}
			else
			{
				CompSelector.SelectedIndex = BlockIndex;
			}
		}

		private void UpdatePixelList()
		{
			PixelItems.ItemsSource = null;
			int num = PixelCount;
			if (Settings.IndicationType == PixelLEDBlock.IndicationTypes.DSPBlock)
			{
				num = ((Settings.IndicationMode == PixelLEDBlock.IndicationModes.DataTable) ? StateCount : 2);
			}
			else if (Settings.IndicationType == PixelLEDBlock.IndicationTypes.Comparator)
			{
				num = StateCount;
			}
			if (Pixels.Count < num)
			{
				int num2 = num - Pixels.Count;
				for (int i = 0; i < num2; i++)
				{
					Pixel item = new Pixel
					{
						Diameter = 15.0
					};
					Pixels.Add(item);
				}
			}
			else if (Pixels.Count > num)
			{
				int count = Pixels.Count - num;
				Pixels.RemoveRange(num, count);
			}
			PixelItems.ItemsSource = Pixels;
		}

		private void UpdateStatesCount()
		{
			if (Settings.IndicationType == PixelLEDBlock.IndicationTypes.Comparator)
			{
				StateCount = 2;
			}
			else if (BlockList.IsLoaded)
			{
				StateCount = 0;
				int num = BlockList.ActiveValuesCount();
				if (num != -1)
				{
					StateCount = num;
				}
			}
		}

		private void ApplySettings()
		{
			switch (Settings.IndicationType)
			{
			case PixelLEDBlock.IndicationTypes.Project:
				ProjIndicatorLabel.Visibility = Visibility.Visible;
				BlockList.Visibility = Visibility.Hidden;
				CompSelector.Visibility = Visibility.Hidden;
				StatesPanel.Visibility = Visibility.Hidden;
				ScaleLabel.Visibility = Visibility.Hidden;
				break;
			case PixelLEDBlock.IndicationTypes.DSPBlock:
				ProjIndicatorLabel.Visibility = Visibility.Hidden;
				BlockList.Visibility = Visibility.Visible;
				CompSelector.Visibility = Visibility.Hidden;
				if (Settings.IndicationMode == PixelLEDBlock.IndicationModes.DataTable)
				{
					ScaleLabel.Visibility = Visibility.Hidden;
					StatesPanel.Visibility = Visibility.Visible;
					UpdateStatesCount();
				}
				else
				{
					ScaleLabel.Visibility = Visibility.Visible;
					StatesPanel.Visibility = Visibility.Hidden;
				}
				break;
			case PixelLEDBlock.IndicationTypes.Comparator:
				ProjIndicatorLabel.Visibility = Visibility.Hidden;
				BlockList.Visibility = Visibility.Hidden;
				CompSelector.Visibility = Visibility.Visible;
				Settings.IndicationMode = PixelLEDBlock.IndicationModes.DataTable;
				ScaleLabel.Visibility = Visibility.Hidden;
				StatesPanel.Visibility = Visibility.Visible;
				UpdateStatesCount();
				break;
			}
			PixelCount = Settings.LEDsCount;
			UpdatePixelList();
		}

		private void PixelLEDBlock_Loaded(object sender, RoutedEventArgs e)
		{
			UpdateStatesCount();
		}

		private void BlockChanged(int ValuesCount)
		{
			UpdateStatesCount();
			if (Settings.IndicationType == PixelLEDBlock.IndicationTypes.DSPBlock && Settings.IndicationMode == PixelLEDBlock.IndicationModes.DataTable)
			{
				UpdatePixelList();
			}
		}

		private void Edit_Click(object sender, RoutedEventArgs e)
		{
			PixelLEDSettings pixelLEDSettings = new PixelLEDSettings(Settings);
			if (pixelLEDSettings.ShowDialog() == true)
			{
				Settings = pixelLEDSettings.Settings;
			}
		}
	}
}
