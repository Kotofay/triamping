using System.Collections;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Markup;

namespace ChipStudio
{
	public partial class ModulePanel : UserControl, IComponentConnector
	{
		public ModulePanel()
		{
			InitializeComponent();
			base.DataContext = this;
			Initialize();
		}

		public void SetDragDropAction(MouseButtonEventHandler DragDropAction)
		{
			foreach (TreeViewItem item in (IEnumerable)Modules.Items)
			{
				foreach (TreeViewItem item2 in (IEnumerable)item.Items)
				{
					item2.PreviewMouseLeftButtonDown += DragDropAction;
				}
			}
		}

		private void Initialize()
		{
			AddGroup(Shared.ControllersFolder);
			AddGroup(Shared.DSPCodecFolder);
			TreeViewItem treeViewItem = new TreeViewItem
			{
				Header = "Parts",
				IsExpanded = true
			};
			treeViewItem.Items.Add(new TreeViewItem
			{
				Header = "LED"
			});
			treeViewItem.Items.Add(new TreeViewItem
			{
				Header = "PixelLED"
			});
			Modules.Items.Add(treeViewItem);
			TreeViewItem treeViewItem2 = new TreeViewItem
			{
				Header = "DSPFunctions",
				IsExpanded = true
			};
			treeViewItem2.Items.Add(new TreeViewItem
			{
				Header = "Read"
			});
			treeViewItem2.Items.Add(new TreeViewItem
			{
				Header = "Comparator"
			});
			Modules.Items.Add(treeViewItem2);
			TreeViewItem treeViewItem3 = new TreeViewItem
			{
				Header = "Others",
				IsExpanded = true
			};
			treeViewItem3.Items.Add(new TreeViewItem
			{
				Header = "Comment"
			});
			Modules.Items.Add(treeViewItem3);
		}

		private void AddGroup(string Header)
		{
			string[] folderFiles = Shared.GetFolderFiles(Header);
			if (folderFiles != null)
			{
				TreeViewItem treeViewItem = new TreeViewItem
				{
					Header = Header,
					IsExpanded = true
				};
				string[] array = folderFiles;
				foreach (string header in array)
				{
					treeViewItem.Items.Add(new TreeViewItem
					{
						Header = header
					});
				}
				Modules.Items.Add(treeViewItem);
			}
		}
	}
}
