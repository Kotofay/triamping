﻿// Decompiled with JetBrains decompiler
// Type: ChipStudio.SharedXml
// Assembly: ChipStudio, Version=1.2.9.0, Culture=neutral, PublicKeyToken=null
// MVID: 334E3BEA-37C7-4274-8118-535AAEFA1546
// Assembly location: D:\DocAndSec\Desktop\AUDIO\ChipDip\ChipStudio_soft_v1.2.9\ChipStudio_v1.2.9.exe

#nullable disable
namespace ChipStudio;

public class SharedXml
{
  public const string AddressString = "Address";
  public const string AddrIncrString = "AddrIncr";
  public const string BusAddressString = "BusAddress";
  public const string CECString = "CEC";
  public const string CellString = "Cell";
  public const string CellsGroup = "Cells";
  public const string ControllerString = "Controller";
  public const string DataString = "Data";
  public const string DelayString = "Delay";
  public const string MuteString = "Mute";
  public const string DSPString = "DSP";
  public const string IsBypassableString = "IsBypassable";
  public const string IsControllableString = "IsControllable";
  public const string WriteTypeString = "WriteType";
  public const string IsEnabledString = "IsEnabled";
  public const string NameString = "Name";
  public const string OptionsString = "Options";
  public const string ParametersGroup = "Parameters";
  public const string ParameterString = "Parameter";
  public const string PixelLEDString = "PixelLED";
  public const string CLIString = "CLI";
  public const string ReadString = "Read";
  public const string ComparatorString = "Comparator";
  public const string CommentString = "Comment";
  public const string SizeString = "Size";
  public const string TypeString = "Type";
  public const string IDString = "ID";
  public const string BaseString = "Base";
}
