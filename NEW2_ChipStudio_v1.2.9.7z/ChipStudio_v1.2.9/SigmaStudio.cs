﻿// Decompiled with JetBrains decompiler
// Type: ChipStudio.SigmaStudio
// Assembly: ChipStudio, Version=1.2.9.0, Culture=neutral, PublicKeyToken=null
// MVID: 334E3BEA-37C7-4274-8118-535AAEFA1546
// Assembly location: D:\DocAndSec\Desktop\AUDIO\ChipDip\ChipStudio_soft_v1.2.9\ChipStudio_v1.2.9.exe

using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Windows;
using System.Xml.Linq;

#nullable disable
namespace ChipStudio;

public class SigmaStudio
{
    private const string FileMustNotContain = "File name must not contain ";

    private const string WrongFile = "Wrong File";

    private const string WRONG_XML_FILE = "NetList";

    private const string WRONG_DAT_FILE = "NumBytes";

    private const string FREQUENCY_WORD = "Frequency";

    private const string SchematicString = "Schematic";

    private const string ICString = "IC";

    private const string PartNumber = "PartNumber";

    private const string RegisterString = "Register";

    private const string ProgramString = "Program";

    private const string ClearString = "Clear";

    private const string ModuleString = "Module";

    private const string CellNameString = "CellName";

    private const string AlgorithmString = "Algorithm";

    private const string ModuleParameterString = "ModuleParameter";

    private const string NameString = "Name";

    private const string SizeString = "Size";

    private const string DataString = "Data";

    private const string DescriptionString = "Description";

    private const string SigmaStudioDataSeparator = ",";

    private const string DATFileExt = ".dat";

    private const string SigmaStudioDescSeparator = ":";

    private const string MultiChannelString = "Multi-Channel";

    private const int AddressStringIndex = 1;

    private const int DataStringIndex = 0;

    private const int DataStringLength = 2;

    private const int ParamDataSize = 1;

    private const int ParamAddrInc = 0;

    private const ushort ADAU1761_CLK_CTRL_REG_ADR = 16384;

    private const byte ADAU1761_CLKSRC_PLL = 8;

    private const ushort ADAU1761_PLL_CTRL_REG_ADR = 16386;

    private const byte ADAU1761_PLL_LOCKED = 2;

    private static readonly byte[] ADAU1761_PLL_CTRL_REG_POLL_DATA = new byte[6] { 0, 0, 0, 0, 0, 2 };

    private static readonly string[] UnCtrlCellDescription = new string[2] { "Blocking", "Mixer" };

    private static readonly string[] AnalogCellDescription = new string[1] { "Gain" };

    public static bool TryParseXML(string XMLFile, out List<string> Parts, out List<DataTransfer[]> Boot, out List<DSPCell[]> Cells)
    {
        Boot = new List<DataTransfer[]>();
        Cells = new List<DSPCell[]>();
        Parts = new List<string>();
        if (!CheckXmlFileName(XMLFile))
        {
            return false;
        }
        GetPartNumbersAndICsXDoc(XMLFile, out var PartNumbers, out var ICsXDoc);
        if (PartNumbers == null || PartNumbers.Length == 0)
        {
            return false;
        }
        for (int i = 0; i < PartNumbers.Length; i++)
        {
            if (PartNumbers[i] == null)
            {
                continue;
            }
            if (!TryParseXMLBoot(ICsXDoc[i], out var BootSequence))
            {
                return false;
            }
            string text = PartNumbers[i];
            if (!(text == "ADAU1761"))
            {
                if (text == "SSM3582")
                {
                    Shared.ConcatByAddress(BootSequence);
                }
            }
            else
            {
                ADAU1761_AddPllPoll(BootSequence);
            }
            if (!TryParseXMLCells(ICsXDoc[i], out var Cells2))
            {
                return false;
            }
            Parts.Add(PartNumbers[i]);
            Boot.Add(BootSequence.ToArray());
            Cells.Add(Cells2.ToArray());
        }
        return true;
    }

    public static bool TryParseCodecBoot(string ProjectFile, string Codec, out List<DataTransfer> BootSequence)
    {
        BootSequence = null;
        if (IsDATFile(ProjectFile))
        {
            return TryParseDatBoot(ProjectFile, out BootSequence);
        }
        if (!CheckXmlFileName(ProjectFile))
        {
            return false;
        }
        XDocument xDocByPartNumber = GetXDocByPartNumber(ProjectFile, Codec);
        if (xDocByPartNumber == null)
        {
            return false;
        }
        return TryParseXMLBoot(xDocByPartNumber, out BootSequence);
    }

    public static bool TryParseXMLBoot(XDocument XDoc, out List<DataTransfer> BootSequence)
    {
        BootSequence = new List<DataTransfer>();
        var array = XDoc.Element("Schematic")?.Element("IC")?.Elements()?.Where((XElement e) => e.Name == "Register" || e.Name == "Program")?.Select(delegate (XElement t)
        {
            XElement xElement = t.Element("Name");
            ushort result;
            byte result2;
            int result3;
            return new
            {
                Type = ((xElement == null || xElement.Value.IndexOf("Clear") != -1) ? DataTransfer.TransferTypes.Clear : DataTransfer.TransferTypes.Write),
                Address = (ushort)(ushort.TryParse(t.Element("Address")?.Value, out result) ? result : 0),
                AddrIncr = (byte)(byte.TryParse(t.Element("AddrIncr")?.Value, out result2) ? result2 : 0),
                Size = (int.TryParse(t.Element("Size")?.Value, out result3) ? result3 : 0),
                Data = t.Element("Data")?.Value?.Replace(" ", "").Replace("0x", "").Split(","[0])
            };
        }).ToArray();
        if (array == null)
        {
            MessageBox.Show("File does not contain DSP configuration", "", MessageBoxButton.OK, MessageBoxImage.Hand);
            return false;
        }
        var array2 = array;
        foreach (var anon in array2)
        {
            DataTransfer dataTransfer = new DataTransfer(anon.Address, anon.Size, anon.AddrIncr, anon.Type);
            if (anon.Type != DataTransfer.TransferTypes.Clear)
            {
                string[] source = anon.Data.Take(anon.Size).ToArray();
                dataTransfer.Data = source.Select((string x) => (byte)(Shared.TryParseHEX(x, out var result4) ? ((byte)result4) : 0)).ToArray();
            }
            BootSequence.Add(dataTransfer);
        }
        if (BootSequence.Count == 0)
        {
            MessageBox.Show("File does not contain DSP configuration", "", MessageBoxButton.OK, MessageBoxImage.Hand);
            return false;
        }
        return true;
    }

    public static bool TryParseXMLCells(XDocument XDoc, out List<DSPCell> Cells)
    {
        Cells = new List<DSPCell>();
        ushort result;
        ushort result2;
        var array = XDoc.Element("Schematic")?.Element("IC")?.Elements()?.Where((XElement e) => e.Name == "Module")?.Select((XElement m) => new
        {
            Title = m.Element("CellName")?.Value,
            Description = m.Element("Algorithm")?.Element("Description")?.Value?.Replace(" ", ""),
            Parameters = m.Elements("Algorithm")?.Elements("ModuleParameter")?.Select((XElement p) => new
            {
                Name = p.Element("Name")?.Value,
                Address = (ushort)(ushort.TryParse(p.Element("Address")?.Value, out result) ? result : 0),
                Size = (ushort)(ushort.TryParse(p.Element("Size")?.Value, out result2) ? result2 : 0),
                Data = p.Element("Data")?.Value?.Replace(" ", "").Replace("0x", "").Split(","[0])
            }).ToArray()
        }).ToArray();
        foreach (var cell in array)
        {
            DSPCell dSPCell = new DSPCell(cell.Title)
            {
                IsControllable = (Array.FindIndex(UnCtrlCellDescription, (string s) => cell.Description.IndexOf(s) != -1) == -1)
            };
            if (!dSPCell.IsControllable)
            {
                continue;
            }
            var parameters = cell.Parameters;
            foreach (var anon in parameters)
            {
                DSPCellParameter dSPCellParameter = new DSPCellParameter
                {
                    Name = anon.Name,
                    Address = anon.Address,
                    Size = anon.Size,
                    Data = new byte[anon.Size]
                };
                string[] source = anon.Data.Take(anon.Size).ToArray();
                dSPCellParameter.Data = source.Select((string x) => (byte)(Shared.TryParseHEX(x, out var result3) ? ((byte)result3) : 0)).ToArray();
                dSPCell.ParamsFromFile.Add(dSPCellParameter);
            }
            dSPCell.IsBypassable = cell.Description.IndexOf("Frequency") != -1;
            if (IsCompositeCell(cell.Description, out var CellParts))
            {
                Cells.AddRange(SplitCompositeCell(cell.Description, cell.Title, dSPCell.ParamsFromFile, CellParts));
                continue;
            }
            if (Array.FindIndex(AnalogCellDescription, (string s) => cell.Description.IndexOf(s) != -1) != -1)
            {
                dSPCell.IsBypassable = true;
            }
            Cells.Add(dSPCell);
        }
        return true;
    }

    public static bool TryParseDatBoot(string ProjectFile, out List<DataTransfer> BootSequence)
    {
        BootSequence = new List<DataTransfer>();
        if (ProjectFile.IndexOf("NumBytes") != -1)
        {
            MessageBox.Show("Choose TxBuffer_xx.dat file", "Wrong File", MessageBoxButton.OK, MessageBoxImage.Exclamation);
            return false;
        }
        string[][] source = (from s in File.ReadAllLines(ProjectFile)
                             select s.Split(","[0])).ToArray();
        uint result;
        ushort[] array = (from i in source
                          where i.Length > 2
                          select i into x
                          select (ushort)(Shared.TryParseHEX(x[1].Replace(" ", "").Replace("0x", ""), out result) ? ((ushort)result) : 0)).ToArray();
        uint result2;
        byte[] array2 = (from i in source
                         where i.Length == 2
                         select i into x
                         select (byte)(Shared.TryParseHEX(x[0].Replace(" ", "").Replace("0x", ""), out result2) ? ((byte)result2) : 0)).ToArray();
        if (array.Length != array2.Length)
        {
            MessageBox.Show("Addresses count is not equal to values count", "", MessageBoxButton.OK, MessageBoxImage.Hand);
            return false;
        }
        for (int j = 0; j < array.Length; j++)
        {
            DataTransfer dataTransfer = new DataTransfer(array[j], 1, 0, DataTransfer.TransferTypes.Write);
            dataTransfer.Data[0] = array2[j];
            BootSequence.Add(dataTransfer);
        }
        return true;
    }

    public static void ADAU1761_AddPllPoll(List<DataTransfer> Boot)
    {
        int num = Boot.FindIndex((DataTransfer e) => e.Address == 16384);
        if (num != -1 && (Boot[num].Data[0] & 8) == 8)
        {
            List<DataTransfer> list = new List<DataTransfer>();
            int index = Boot.FindIndex((DataTransfer e) => e.Address == 16386);
            list.Add(Boot[index]);
            Boot.RemoveAt(index);
            DataTransfer dataTransfer = new DataTransfer(16386, (ushort)ADAU1761_PLL_CTRL_REG_POLL_DATA.Length, 0, DataTransfer.TransferTypes.Poll);
            ADAU1761_PLL_CTRL_REG_POLL_DATA.CopyTo(dataTransfer.Data, 0);
            list.Add(dataTransfer);
            list.Add(Boot[num]);
            Boot.RemoveAt(num);
            Boot.InsertRange(0, list);
        }
    }

    public static XDocument GetXDocByPartNumber(string ProjectFile, string PartNumber)
    {
        GetPartNumbersAndICsXDoc(ProjectFile, out var PartNumbers, out var ICsXDoc);
        if (PartNumbers == null || PartNumbers.Length == 0)
        {
            return null;
        }
        if (PartNumber == "AD1933" || PartNumber == "AD1934")
        {
            PartNumber = "AD1938";
        }
        for (int i = 0; i < PartNumbers.Length; i++)
        {
            if (PartNumbers[i] == PartNumber)
            {
                return ICsXDoc[i];
            }
        }
        MessageBox.Show("There is no configuration for " + PartNumber + " in file\n\r" + ProjectFile, "", MessageBoxButton.OK, MessageBoxImage.Hand);
        return null;
    }

    public static bool CheckXmlFileName(string FileName)
    {
        if (FileName.IndexOf("NetList") != -1)
        {
            MessageBox.Show("File name must not contain NetList", "Wrong File", MessageBoxButton.OK, MessageBoxImage.Exclamation);
            return false;
        }
        return true;
    }

    public static bool IsDATFile(string FileName)
    {
        return FileName.EndsWith(".dat");
    }

    private static void GetPartNumbersAndICsXDoc(string XMLFile, out string[] PartNumbers, out XDocument[] ICsXDoc)
    {
        XDocument xDocument = XDocument.Load(XMLFile);
        PartNumbers = xDocument.Element("Schematic")?.Elements("IC")?.Select((XElement p) => p.Element("PartNumber")?.Value).ToArray();
        if (PartNumbers != null)
        {
            CorrectPartNumbers(PartNumbers);
        }
        else
        {
            MessageBox.Show("There are no IC descriptions in chosen file", "Wrong File", MessageBoxButton.OK, MessageBoxImage.Hand);
        }
        ICsXDoc = xDocument.Element("Schematic")?.Elements("IC")?.Select((XElement x) => new XDocument(new XElement("Schematic", x))).ToArray();
    }

    private static void CorrectPartNumbers(string[] PartNumbers)
    {
        for (int i = 0; i < PartNumbers.Length; i++)
        {
            if (PartNumbers[i] != null)
            {
                if (PartNumbers[i].IndexOf("ADAU145") != -1)
                {
                    PartNumbers[i] = "ADAU145x";
                }
                else if (PartNumbers[i].IndexOf("ADAU146") != -1)
                {
                    PartNumbers[i] = "ADAU146x";
                }
                else if (PartNumbers[i].IndexOf("Sigma100") != -1)
                {
                    PartNumbers[i] = "ADAU1701";
                }
                else if (PartNumbers[i].IndexOf("DSPSigmaLP1") != -1)
                {
                    PartNumbers[i] = "ADAU1761";
                }
            }
        }
    }

    private static DSPCell[] SplitCompositeCell(string Description, string BaseTitle, List<DSPCellParameter> Params, int CellPartsCount)
    {
        DSPCell[] array = new DSPCell[CellPartsCount];
        string[] array2 = Description.Split(new string[1] { "Frequency1" }, StringSplitOptions.None);
        DSPCellParameter[] array3 = Params.Where((DSPCellParameter p) => !char.IsDigit(p.Name[p.Name.Length - 1])).ToArray();
        int i;
        for (i = 0; i < CellPartsCount; i++)
        {
            string text = ((i + 1 < array2.Length) ? array2[i + 1].Split(","[0])[0] : i.ToString());
            array[i] = new DSPCell(BaseTitle + text)
            {
                IsControllable = true,
                IsBypassable = true
            };
            array[i].ParamsFromFile = Params.Where((DSPCellParameter p) => p.Name.EndsWith((i + 1).ToString())).ToList();
            if (array3.Length != 0)
            {
                array[i].ParamsFromFile.AddRange(array3.Select((DSPCellParameter p) => DSPCellParameter.Clone(p)));
                array[i].WriteType = DSPCell.WriteTypes.BlockWrite;
            }
            array[i].ParamsFromFile.Sort((DSPCellParameter x, DSPCellParameter y) => x.Address.CompareTo(y.Address));
        }
        return array;
    }

    private static bool IsCompositeCell(string Description, out int CellParts)
    {
        CellParts = 1;
        string text = Description.Split(":"[0])[0].Replace(" ", "");
        if (text.IndexOf("Multi-Channel") == -1)
        {
            return false;
        }
        text = text.Substring(text.LastIndexOf("(") + 1).Replace(")", "");
        if (int.TryParse(text, out CellParts))
        {
            return CellParts > 1;
        }
        return false;
    }
}
