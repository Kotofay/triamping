﻿// Decompiled with JetBrains decompiler
// Type: ChipStudio.DSPCellPCM5x4x
// Assembly: ChipStudio, Version=1.2.9.0, Culture=neutral, PublicKeyToken=null
// MVID: 334E3BEA-37C7-4274-8118-535AAEFA1546
// Assembly location: D:\DocAndSec\Desktop\AUDIO\ChipDip\ChipStudio_soft_v1.2.9\ChipStudio_v1.2.9.exe

#nullable disable
namespace ChipStudio;

public class DSPCellPCM5x4x : IDSPCellSpecific
{
  public DSPCellPCM5x4x(DSPCell InCell) => InCell.WriteType = DSPCell.WriteTypes.BlockWrite;

  public int OneValueSize(DSPCell Cell) => Cell.ParamsSize;

  public bool TryParseData(string FileName, out byte[] Result, DSPCell Cell)
  {
    return SharedTI.TryParseDSPCellDataTI(FileName, out Result, Cell);
  }
}
