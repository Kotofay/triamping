using System.Windows;
using System.Windows.Markup;

namespace ChipStudio
{
	public partial class CECModuleSettings : Window, IComponentConnector
	{
		private readonly string[] Gpios;

		public CEC Settings { get; } = new CEC();

		public CECModuleSettings(CEC InitSettings, int GPIOsCount)
		{
			InitializeComponent();
			Gpios = new string[GPIOsCount];
			for (int i = 0; i < GPIOsCount; i++)
			{
				Gpios[i] = i.ToString();
			}
			VolGpioCombobox.ItemsSource = Gpios;
			MuteGpioCombobox.ItemsSource = Gpios;
			IsEnabledCheck.IsChecked = InitSettings.IsEnabled;
			PortNum.Text = InitSettings.PortNumber.ToString();
			DevName.Text = InitSettings.Name;
			VolGpioCombobox.SelectedIndex = InitSettings.VolumeGpio;
			MuteGpioCombobox.SelectedIndex = InitSettings.MuteGpio;
			OptionTVon.IsChecked = InitSettings.IsTVonEnabled;
			OptionTVoff.IsChecked = InitSettings.IsTVoffEnabled;
			OptionDeviceOn.IsChecked = InitSettings.IsDeviceOnEnabled;
			OptionDeviceOff.IsChecked = InitSettings.IsDeviceOffEnabled;
			OptionAudioStatus.IsChecked = InitSettings.IsAudioStatusEnabled;
		}

		private void OKButton_Click(object sender, RoutedEventArgs e)
		{
			base.DialogResult = true;
			Settings.IsEnabled = IsEnabledCheck.IsChecked.Value;
			Settings.PortNumber = ((!int.TryParse(PortNum.Text, out var result)) ? 1 : result);
			Settings.Name = ((DevName.Text.Length != 0) ? DevName.Text : "ChipDipDAC");
			Settings.VolumeGpio = ((VolGpioCombobox.SelectedIndex != -1) ? VolGpioCombobox.SelectedIndex : 0);
			Settings.MuteGpio = ((MuteGpioCombobox.SelectedIndex != -1) ? MuteGpioCombobox.SelectedIndex : 0);
			Settings.IsTVonEnabled = OptionTVon.IsChecked.Value;
			Settings.IsTVoffEnabled = OptionTVoff.IsChecked.Value;
			Settings.IsDeviceOnEnabled = OptionDeviceOn.IsChecked.Value;
			Settings.IsDeviceOffEnabled = OptionDeviceOff.IsChecked.Value;
			Settings.IsAudioStatusEnabled = OptionAudioStatus.IsChecked.Value;
		}

		private void CancelButton_Click(object sender, RoutedEventArgs e)
		{
			base.DialogResult = false;
		}
	}
}
