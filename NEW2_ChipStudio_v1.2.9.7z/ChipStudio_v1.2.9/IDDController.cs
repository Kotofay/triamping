﻿// Decompiled with JetBrains decompiler
// Type: ChipStudio.IDDController
// Assembly: ChipStudio, Version=1.2.9.0, Culture=neutral, PublicKeyToken=null
// MVID: 334E3BEA-37C7-4274-8118-535AAEFA1546
// Assembly location: D:\DocAndSec\Desktop\AUDIO\ChipDip\ChipStudio_soft_v1.2.9\ChipStudio_v1.2.9.exe

#nullable disable
namespace ChipStudio;

public interface IDDController
{
  bool IsLoaded { get; }

  byte ID { get; }

  byte DownLoadAPI { get; }

  ushort USBPacketSize { get; }

  int ProjectMemorySize { get; }

  string[] DelayValues { get; }

  int[] DelayTimerPCS { get; }

  int[] DelayTimerARR { get; }

  string[] MuteValues { get; }

  int[] MuteTimerPCS { get; }

  int[] MuteTimerARR { get; }

  bool IsPixelSupported { get; }

  int PixelGpio { get; }

  bool IsCLISupported { get; }

  int[] CLIGpio { get; }

  bool IsCECSupported { get; }

  int CECGpio { get; }

  uint OptionsMask { get; }

  bool AreUSBSetsSupported { get; }

  string[] AudioConfiguration { get; }

  void GetGpioDescription(
    string GpioType,
    out string[] GPIOsTitles,
    out string[][] GpiosFuncs,
    out bool[] IsGpioEnabled);

  uint[] GetGpioOptions();

  int GetTouchCapGpio();

  void GetGpioILinesAndFuncIndex(out int[][] Lines, out int[] FuncIndex);
}
