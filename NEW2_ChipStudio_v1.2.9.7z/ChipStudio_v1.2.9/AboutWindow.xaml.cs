using System.Windows;
using System.Windows.Markup;

namespace ChipStudio
{
	public partial class AboutWindow : Window, IComponentConnector
	{
		public AboutWindow()
		{
			InitializeComponent();
		}
	}
}
