using System;
using System.CodeDom.Compiler;
using System.Collections.Generic;
using System.ComponentModel;
using System.Diagnostics;
using System.IO;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Markup;
using System.Windows.Threading;

namespace ChipStudio
{
	public partial class MainWindow : Window, INotifyPropertyChanged, IComponentConnector
	{
		private static readonly string FileFilter = (string)Application.Current.FindResource("StudioFileFilter");

		private static readonly string ComboProjFilter = (string)Application.Current.FindResource("StudioComboProjFilter");

		private static readonly string WindowBaseTitle = (string)Application.Current.FindResource("WindowBaseTitle");

		private const string FileReadingError = "Error reading file";

		private const string FileDoesnotExistInfoHeader = "File does not exist";

		private const string RecentProjectsString = "RecentProjects";

		private const string ProjectIgnoredString = "Project will be ignored.";

		private const string BuildingProcess = "Building projects...";

		private const string DownloadingProcess = "Downloading...";

		private Project UserProject;

		private ComboProject UserComboProject;

		private readonly ProgressWindow ProgressBar;

		private bool combomode;

		private readonly DispatcherTimer ProgressBarTimer = new DispatcherTimer();

		private readonly RecentFiles RecentProjects = new RecentFiles("RecentProjects");

		public bool ComboMode
		{
			get
			{
				return combomode;
			}
			set
			{
				if (combomode != value)
				{
					combomode = value;
					NotifyPropertyChanged("ComboMode");
				}
			}
		}

		public event PropertyChangedEventHandler PropertyChanged;

		public MainWindow()
		{
			InitializeComponent();
			base.DataContext = this;
			ProgressBar = new ProgressWindow
			{
				Minimum = 0.0,
				Maximum = 100.0,
				Progress = 0.0
			};
			ProgressBarTimer.Interval = TimeSpan.FromMilliseconds(1.0);
			SchemaField.SetDSPCellsView(DSPCellsTree);
			SchemaField.SetControllerAddedCallback(ControllerAddedToSchema);
			ComboProjView.SetChangeComboPartCallBack(OpenComboPartProject);
			ComboProjView.SetClearComboPartCallBack(NewProjectPrepare);
			HWModules.SetDragDropAction(ModuleItem_MouseLeftButtonDown);
			ControllerDriver.SetDownLoadActions(ShowProcessProgress, ProcessFinished, SetProcessDescription);
			UpdateRecentProjects();
		}

		private void ModuleItem_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
		{
			SchemaField.DragDropBlock(e);
		}

		private void ControllerAddedToSchema()
		{
			UpdateControllerBootGpios();
		}

		private void UpdateRecentProjects()
		{
			RecentProjMenu.Items.Clear();
			string[] array = RecentProjects.Get();
			foreach (string header in array)
			{
				MenuItem menuItem = new MenuItem
				{
					Header = header
				};
				menuItem.Click += OpenRecentProject_Click;
				RecentProjMenu.Items.Add(menuItem);
			}
		}

		private void SaveProject_Click(object sender, ExecutedRoutedEventArgs e)
		{
			SaveProject();
		}

		private void SaveProjectAs_Click(object sender, RoutedEventArgs e)
		{
			UserProject = null;
			SaveProject();
		}

		private void OpenProject_Click(object sender, ExecutedRoutedEventArgs e)
		{
			OpenProject_Action();
		}

		private void OpenRecentProject_Click(object sender, RoutedEventArgs e)
		{
			string text = (sender as MenuItem).Header.ToString();
			if (File.Exists(text))
			{
				OpenProject(text);
				return;
			}
			MessageBox.Show("File was deleted or replaced", "", MessageBoxButton.OK, MessageBoxImage.Hand);
			RecentProjects.Delete(text);
			UpdateRecentProjects();
		}

		private bool OpenProject_Action()
		{
			string text = FileDialog.Open(FileFilter);
			if (text != null)
			{
				OpenProject(text);
				if (ComboMode)
				{
					ComboProjView.SetComboPart(text);
					ComboProjView.CurrentPartProject = text;
				}
				return true;
			}
			return false;
		}

		private void OpenProject(string ProjectName)
		{
			UserProject = new Project(ProjectName);
			if (UserProject.Open(out var Elements))
			{
				ChangeWindowTitle(ProjectName);
				ClearProjectField();
				SchemaField.AddElements(Elements);
				UpdateControllerBootGpios();
				RecentProjects.Add(ProjectName);
				UpdateRecentProjects();
			}
			else
			{
				MessageBox.Show("Error reading file", "", MessageBoxButton.OK, MessageBoxImage.Hand);
			}
		}

		private void ImportComboProject_Click(object sender, RoutedEventArgs e)
		{
			string text = FileDialog.Open(ComboProjFilter);
			if (text == null)
			{
				return;
			}
			UserComboProject = new ComboProject(text);
			ComboProjectParameters comboProjectParameters = new ComboProjectParameters();
			List<ComboProjectPart> list = new List<ComboProjectPart>();
			if (UserComboProject.Open(comboProjectParameters, list))
			{
				int startIndex = text.LastIndexOf(Shared.FilePathSlash);
				string[] files = Directory.GetFiles(text.Remove(startIndex), "*.cspro");
				for (int i = 0; i < list.Count; i++)
				{
					if (list[i].Name == null)
					{
						continue;
					}
					startIndex = list[i].Name.LastIndexOf(Shared.FilePathSlash);
					string text2 = list[i].Name.Substring(startIndex + 1);
					string[] array = files;
					foreach (string text3 in array)
					{
						startIndex = text3.LastIndexOf(Shared.FilePathSlash);
						string text4 = text3.Substring(startIndex + 1);
						if (text2 == text4)
						{
							list[i].Name = text3;
							break;
						}
					}
				}
				ComboMode = true;
				ComboProjView.Init(comboProjectParameters, list);
				ComboProjView.ComboProject = text;
				UserComboProject.Save(comboProjectParameters, list);
				MessageBox.Show("ComboProject has been opened successfully", "", MessageBoxButton.OK, MessageBoxImage.Asterisk);
			}
			else
			{
				MessageBox.Show("Error reading file", "", MessageBoxButton.OK, MessageBoxImage.Hand);
			}
		}

		private void NewProject_Click(object sender, ExecutedRoutedEventArgs e)
		{
			NewProjectPrepare();
		}

		private void NewComboProject_Click(object sender, RoutedEventArgs e)
		{
			ComboProjView.Reset();
			ComboMode = true;
			NewProjectPrepare();
		}

		private void NewProjectPrepare()
		{
			base.Title = WindowBaseTitle;
			UserProject = null;
			ClearProjectField();
		}

		private void SaveProject()
		{
			if (UserProject == null)
			{
				CreateNewProject();
			}
			if (UserProject != null)
			{
				UserProject.Save(SchemaField.GetElements());
				RecentProjects.Add(UserProject.Path);
				UpdateRecentProjects();
				if (ComboMode)
				{
					ComboProjView.SetComboPart(UserProject.Path);
					ComboProjView.CurrentPartProject = UserProject.Path;
				}
			}
		}

		private void SaveComboProject_Click(object sender, RoutedEventArgs e)
		{
			SaveComboProject();
		}

		private void SaveComboProjectAs_Click(object sender, RoutedEventArgs e)
		{
			UserComboProject = null;
			SaveComboProject();
		}

		private void SaveComboProject()
		{
			if (UserComboProject == null)
			{
				CreateNewComboProject();
			}
			if (UserComboProject != null)
			{
				UserComboProject.Save(ComboProjView.GetParams(), ComboProjView.Projects);
			}
		}

		private void ClearProjectField()
		{
			SchemaField.Clear();
			if (ComboMode)
			{
				ComboProjView.CurrentPartProject = "";
			}
		}

		private void DownloadButton_Click(object sender, RoutedEventArgs e)
		{
			SetProcessDescription("Building projects...");
			ShowProcessInit();
			ProgressBarTimer.Tick += ProgressBarTimer_DownloadProject;
			ProgressBarTimer.Start();
		}

		private void ProgressBarTimer_DownloadProject(object sender, EventArgs e)
		{
			ProgressBarTimer.Stop();
			ProgressBarTimer.Tick -= ProgressBarTimer_DownloadProject;
			List<byte> image = new List<byte>();
			if (!CanDownloadBeStarted(out var PacketSize, out var ApiVersion) || !BootImage.MakeForProject(SchemaField.GetElements(), out image) || !CheckImageSize(image.Count) || !ControllerDriver.DownloadStart(image, PacketSize, 0, ApiVersion))
			{
				ProcessFinished(Result: false);
			}
		}

		private void ShowProcessInit()
		{
			ProgressBar.Progress = 0.0;
			ProgressBar.Owner = this;
			ProgressBar.Show();
		}

		private void ShowProcessProgress(double progress)
		{
			ProgressBar.Progress = progress;
		}

		private void ProcessFinished(bool Result)
		{
			ProgressBar.Hide();
			ControllerDriver.CloseDevice();
			if (Result)
			{
				MessageBox.Show("Download has been completed successfully", "", MessageBoxButton.OK, MessageBoxImage.Asterisk);
			}
		}

		private void SetProcessDescription(string description)
		{
			ProgressBar.Description = description;
		}

		private void CreateNewProject()
		{
			string text = FileDialog.Save(FileFilter);
			if (text != null)
			{
				UserProject = new Project(text);
				ChangeWindowTitle(text);
			}
		}

		private void CreateNewComboProject()
		{
			string text = FileDialog.Save(ComboProjFilter);
			if (text != null)
			{
				UserComboProject = new ComboProject(text);
			}
		}

		private void ChangeWindowTitle(string ProjectTitle)
		{
			base.Title = ProjectTitle + " - " + WindowBaseTitle;
		}

		private void WindowIsClosing(object sender, CancelEventArgs e)
		{
			ProgressBar.Close();
			RecentProjects.Save();
		}

		private void About_Click(object sender, RoutedEventArgs e)
		{
			new AboutWindow().ShowDialog();
		}

		private void ComboModeButton_Checked(object sender, RoutedEventArgs e)
		{
			if (SchemaField.GetController() != null && UserProject != null)
			{
				string path = UserProject.Path;
				OpenProject(path);
			}
		}

		private string OpenComboPartProject(string ProjectPath)
		{
			if (ComboMode)
			{
				bool flag = false;
				if (ProjectPath != null)
				{
					if (File.Exists(ProjectPath))
					{
						OpenProject(ProjectPath);
						ComboProjView.CurrentPartProject = ProjectPath;
						flag = true;
					}
					else
					{
						switch (MessageBox.Show("File does not exist. Do you want to replace project?\n\r" + ProjectPath, "File does not exist", MessageBoxButton.YesNo, MessageBoxImage.Hand))
						{
						case MessageBoxResult.Yes:
							if (OpenProject_Action())
							{
								flag = true;
							}
							else
							{
								ProjectPath = null;
							}
							break;
						case MessageBoxResult.No:
							ProjectPath = null;
							break;
						}
						SaveComboProject();
					}
				}
				if (!flag)
				{
					NewProjectPrepare();
					ComboProjView.CurrentPartProject = "";
				}
			}
			return ProjectPath;
		}

		private void UpdateControllerBootGpios()
		{
			SchemaBlock_Controller controller = SchemaField.GetController();
			if (controller != null && ComboMode)
			{
				controller.SetBootGpios(ComboProjView.ComboType, ComboProjView.BootLinesCount);
			}
		}

		private void DownLoadComboButton_Click(object sender, RoutedEventArgs e)
		{
			SetProcessDescription("Building projects...");
			ShowProcessInit();
			ProgressBarTimer.Tick += ProgressBarTimer_DownloadCombo;
			ProgressBarTimer.Start();
		}

		private void ProgressBarTimer_DownloadCombo(object sender, EventArgs e)
		{
			ProgressBarTimer.Stop();
			ProgressBarTimer.Tick -= ProgressBarTimer_DownloadCombo;
			ComboBox activeComboPartSelector = ComboProjView.GetActiveComboPartSelector();
			activeComboPartSelector.SelectedIndex = -1;
			List<byte> image;
			for (int i = 0; i < ComboProjView.Projects.Count; i++)
			{
				if (ComboProjView.Projects[i].Name == null)
				{
					continue;
				}
				ComboProjView.Projects[i].Image.Clear();
				activeComboPartSelector.SelectedIndex = i;
				SchemaBlock_Controller controller = SchemaField.GetController();
				if (controller == null)
				{
					continue;
				}
				if (controller.Module.IndexOf(ComboProjView.Controller) != -1)
				{
					if (BootImage.MakeForProject(SchemaField.GetElements(), out image))
					{
						ComboProjView.Projects[i].Image.AddRange(image);
					}
					else
					{
						MessageBox.Show("Error has been detected in project <" + ComboProjView.Projects[i].Name + ">\n\rProject will be ignored.", "", MessageBoxButton.OK, MessageBoxImage.Exclamation);
					}
				}
				else
				{
					MessageBox.Show("Controller in project\n\r<" + ComboProjView.Projects[i].Name + ">\n\rdoes not correspond to ComboProject settings.\n\rProject will be ignored.", "", MessageBoxButton.OK, MessageBoxImage.Exclamation);
				}
			}
			BootImage.CombineProjects(ComboProjView.ComboType, ComboProjView.ComboSubType(), ComboProjView.ReconfigType, ComboProjView.Projects, out image);
			if (!CanDownloadBeStarted(out var PacketSize, out var ApiVersion) || !CheckImageSize(image.Count) || !ControllerDriver.DownloadStart(image, PacketSize, 0, ApiVersion))
			{
				ProcessFinished(Result: false);
			}
		}

		public void NotifyPropertyChanged(string PropertyName)
		{
			this.PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(PropertyName));
		}

		private void USBSettings_Click(object sender, RoutedEventArgs e)
		{
			SchemaBlock_Controller controller = SchemaField.GetController();
			if (controller == null)
			{
				return;
			}
			if (controller.AreUSBSetsSupported)
			{
				USBSettings uSBSettings = new USBSettings(controller.AudioDescription);
				if (uSBSettings.ShowDialog() == true)
				{
					SetProcessDescription("Downloading...");
					ShowProcessInit();
					if (!CanDownloadBeStarted(out var PacketSize, out var ApiVersion) || !ControllerDriver.DownloadStart(BootImage.MakeForUSBSettings(uSBSettings.Settings), PacketSize, 1, ApiVersion))
					{
						ProcessFinished(Result: false);
					}
				}
			}
			else
			{
				MessageBox.Show("Controller does not support USB settings feature", "", MessageBoxButton.OK, MessageBoxImage.Asterisk);
			}
		}

		private bool CanDownloadBeStarted(out int PacketSize, out int ApiVersion)
		{
			PacketSize = 0;
			ApiVersion = 1;
			bool flag = true;
			if (ControllerDriver.IsDeviceConnected())
			{
				SchemaBlock_Controller controller = SchemaField.GetController();
				if (controller != null)
				{
					ControllerDriver.OpenDevice();
					ControllerInfo deviceInfo = ControllerDriver.GetDeviceInfo();
					if (deviceInfo.ID == controller.CoreID)
					{
						PacketSize = ((deviceInfo.USBPacketSize != -1) ? deviceInfo.USBPacketSize : controller.USBPacketSize);
						ApiVersion = ((deviceInfo.DownLoadAPIVersion != -1) ? deviceInfo.DownLoadAPIVersion : controller.DownLoadAPI);
					}
					else
					{
						flag = false;
					}
					goto IL_0071;
				}
			}
			flag = false;
			goto IL_0071;
			IL_0071:
			if (!flag)
			{
				ControllerDriver.CloseDevice();
				MessageBox.Show("Controller is not connected", "", MessageBoxButton.OK, MessageBoxImage.Hand);
				return false;
			}
			return true;
		}

		private bool CheckImageSize(double Size)
		{
			if (Size == 0.0)
			{
				MessageBox.Show("Project image is empty", "", MessageBoxButton.OK, MessageBoxImage.Exclamation);
				return false;
			}
			SchemaBlock_Controller controller = SchemaField.GetController();
			if (controller.ProjectMemorySize <= 0)
			{
				MessageBox.Show("Controller project memory size value is not set.", "", MessageBoxButton.OK, MessageBoxImage.Exclamation);
			}
			else if (Size > (double)controller.ProjectMemorySize)
			{
				MessageBox.Show("Image size is too big\n\rImage size = " + (Size / 1024.0).ToString("f2") + " kB\n\rController project memory size = " + controller.ProjectMemorySize / 1024 + " kB", "", MessageBoxButton.OK, MessageBoxImage.Hand);
				return false;
			}
			return true;
		}

		private void DeleteKey_Pressed(object sender, ExecutedRoutedEventArgs e)
		{
			SchemaField.DeleteElement();
		}

		private void ImportSigmaStudioProject_Click(object sender, RoutedEventArgs e)
		{
			string text = FileDialog.Open("SigmaStudio XML file (*.xml)|*.xml");
			if (text != null)
			{
				if (SigmaStudio.TryParseXML(text, out var Parts, out var Boot, out var Cells))
				{
					SchemaField.ImportDSP(Parts, Boot, Cells);
				}
				else
				{
					MessageBox.Show("Error reading file", "", MessageBoxButton.OK, MessageBoxImage.Hand);
				}
			}
		}

		private void ControllerInfo_Click(object sender, RoutedEventArgs e)
		{
			new ControllerInfoDialog().ShowDialog();
		}
	}
}
