using System.CodeDom.Compiler;
using System.Diagnostics;
using System;
using System.Windows;

namespace ChipStudio
{
	public partial class App : Application
	{
        [STAThread]
        public static void Main()
        {
            var application = new App();
            application.InitializeComponent();
            application.Run();
        }
    }
}
