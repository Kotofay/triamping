using System;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Markup;
using System.Windows.Media.Imaging;

namespace ChipStudio
{
	public partial class SchemaBlock_DSPCell : SchemaBlock, IComponentConnector
	{
		private static readonly string ImageWarning = (string)Application.Current.FindResource("ImageWarning");

		private static readonly string ImageApply = (string)Application.Current.FindResource("ImageApply");

		internal const int REG_POINT_INDEX = 0;

		internal const int EN_POINT_INDEX = 1;

		private static readonly string[] ConnectTitles = new string[2] { "REG", "EN" };

		private static readonly Anchor.AnchorTypes[] PointAnchors = new Anchor.AnchorTypes[2]
		{
			Anchor.AnchorTypes.FromDSPCell,
			Anchor.AnchorTypes.FromDSPCell
		};

		private int valuescount;

		private int envaluescount;

		private readonly DSPCellDescription CellDesc = new DSPCellDescription();

		public ushort ParametersCount => CellDesc.ParamsCount;

		public ushort ValueSize => CellDesc.ValueSize;

		public DSPCell.WriteTypes WriteType => CellDesc.WriteType;

		public bool IsBypassable => CellDesc.IsBypassable;

		public string DSPTitle { get; set; }

		public override string FullName => base.Title + DSPTitle;

		public override SchemaBlockTypes BlockType => SchemaBlockTypes.DSPCell;

		public int ValuesCount
		{
			get
			{
				return valuescount;
			}
			private set
			{
				if (valuescount != value)
				{
					valuescount = value;
					NotifyPropertyChanged("ValuesCount");
				}
			}
		}

		public int EnValuesCount
		{
			get
			{
				return envaluescount;
			}
			private set
			{
				if (envaluescount != value)
				{
					envaluescount = value;
					NotifyPropertyChanged("EnValuesCount");
				}
			}
		}

		public SchemaBlock_DSPCell()
		{
			InitializeComponent();
			base.DataContext = this;
			RegDataImage.Source = new BitmapImage(new Uri(ImageWarning, UriKind.Relative));
			EnDataImage.Source = new BitmapImage(new Uri(ImageWarning, UriKind.Relative));
		}

		public void Initialize(DSPCell cell)
		{
			CellDesc.Initialize(cell);
			InitConnectionPoints(ActivePointAnchors());
			for (int i = 0; i < base.ConnectionPoints.Length; i++)
			{
				base.ConnectionPoints[i].Title = ConnectTitles[i];
			}
			if (base.ConnectionPoints.Length == 2)
			{
				base.ConnectionPoints[1].Margin = new Thickness(0.0, 10.0, 0.0, 0.0);
			}
			ConnectPoints.ItemsSource = base.ConnectionPoints;
			ValuesCount = CellDesc.UpdateRegData();
			if (ValuesCount != 0)
			{
				RegDataImage.Source = new BitmapImage(new Uri(ImageApply, UriKind.Relative));
			}
			if (CellDesc.IsBypassable)
			{
				EnPanel.Visibility = Visibility.Visible;
				EnValuesCount = CellDesc.UpdateEnData();
				if (EnValuesCount != 0)
				{
					EnDataImage.Source = new BitmapImage(new Uri(ImageApply, UriKind.Relative));
				}
			}
		}

		public void Update(DSPCell cell)
		{
			CellDesc.UpdateParamsAddresses(cell);
		}

		public byte[] GetData()
		{
			return CellDesc.GetRegulatorData().ToArray();
		}

		public void SetData(byte[] NewData)
		{
			CellDesc.SetRegulatorData(NewData);
		}

		public byte[] GetEnData()
		{
			return CellDesc.GetEnableData().ToArray();
		}

		public void SetEnData(byte[] NewData)
		{
			CellDesc.SetEnableData(NewData);
		}

		public void ParamAddressAndSize(int ParamIndex, out int address, out ushort size)
		{
			CellDesc.ParameterAddressAndSize(ParamIndex, out address, out size);
		}

		private Anchor.AnchorTypes[] ActivePointAnchors()
		{
			if (!IsBypassable)
			{
				return new Anchor.AnchorTypes[1] { PointAnchors[0] };
			}
			return PointAnchors;
		}

		private void RegEditButton_Click(object sender, RoutedEventArgs e)
		{
			CellDesc.SetParamsModifiabilityForReg();
			new DSPCellSettings(CellDesc, CellDesc.GetRegulatorData()).ShowDialog();
			ValuesCount = CellDesc.UpdateRegData();
			RegDataImage.Source = ((ValuesCount > 0) ? new BitmapImage(new Uri(ImageApply, UriKind.Relative)) : new BitmapImage(new Uri(ImageWarning, UriKind.Relative)));
		}

		private void EnEditButton_Click(object sender, RoutedEventArgs e)
		{
			CellDesc.SetParamsModifiabilityForEn();
			new DSPCellSettings(CellDesc, CellDesc.GetEnableData()).ShowDialog();
			EnValuesCount = CellDesc.UpdateEnData();
			EnDataImage.Source = ((EnValuesCount > 0) ? new BitmapImage(new Uri(ImageApply, UriKind.Relative)) : new BitmapImage(new Uri(ImageWarning, UriKind.Relative)));
		}

		private void BandwidthSelect_SelectionChanged(object sender, SelectionChangedEventArgs e)
		{
		}
	}
}
