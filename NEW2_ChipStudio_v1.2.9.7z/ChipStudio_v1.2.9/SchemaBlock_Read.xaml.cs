using System;
using System.CodeDom.Compiler;
using System.Diagnostics;
using System.Windows;
using System.Windows.Markup;

namespace ChipStudio
{
	public partial class SchemaBlock_Read : SchemaBlock, IDSPDependent, IComponentConnector
	{
		private static readonly string[] ReadPeriods = new string[12]
		{
			" 250", " 500", " 750", "1000", "1250", "1500", "1750", "2000", "2250", "2500",
			"2750", "3000"
		};

		private static readonly Anchor.AnchorTypes[] PointAnchors = new Anchor.AnchorTypes[1] { Anchor.AnchorTypes.FromRead };

		private const byte BYTES_COUNT_MAX = 8;

		private const int DEFAULT_PERIOD_INDEX = 3;

		public int DSPIndex
		{
			get
			{
				return DSPList.SelectedIndex;
			}
			set
			{
				DSPList.SelectedIndex = value;
			}
		}

		public string DSP => DSPList.SelectedItem;

		public int PeriodIndex
		{
			get
			{
				return PeriodsList.SelectedIndex;
			}
			set
			{
				PeriodsList.SelectedIndex = value;
			}
		}

		public override SchemaBlockTypes BlockType => SchemaBlockTypes.Read;

		public SchemaBlock_Read()
		{
			InitializeComponent();
			base.DataContext = this;
			Address.SetFormat("HEX");
			BytesCount.SetFormat("DEC");
			InitConnectionPoints(PointAnchors);
			ConnectPoints.ItemsSource = base.ConnectionPoints;
			PeriodsList.ItemsSource = ReadPeriods;
			PeriodsList.SelectedIndex = 3;
		}

		public string GetAddressInput()
		{
			return Address.GetInput();
		}

		public string GetBytesCountInput()
		{
			return BytesCount.GetInput();
		}

		public ushort GetAddressValue()
		{
			return (ushort)Address.GetValue();
		}

		public byte GetBytesCountValue()
		{
			byte b = (byte)BytesCount.GetValue();
			if (b > 8)
			{
				b = 8;
				BytesCount.SetInput(((byte)8).ToString());
				MessageBox.Show("Maximum Bytes count is 8.\n\r<" + base.Title + ">", "", MessageBoxButton.OK, MessageBoxImage.Exclamation);
			}
			return b;
		}

		public void SetAddress(string Addr)
		{
			Address.SetInput(Addr);
		}

		public void SetBytesCount(string Bytes)
		{
			BytesCount.SetInput(Bytes);
		}

		public void UpdateDSPList(string[] DSPTitles, Schema.UpdateOptions Option)
		{
			DSPList.Update(DSPTitles, Option);
		}
	}
}
