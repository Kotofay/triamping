using System.ComponentModel;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Markup;
using System.Windows.Media;

namespace ChipStudio
{
	public partial class Pixel : UserControl, INotifyPropertyChanged, IComponentConnector
	{
		private string color = Brushes.Black.ToString();

		private string title;

		public string Color
		{
			get
			{
				return color;
			}
			set
			{
				if (color != value)
				{
					color = value;
					NotifyPropertyChanged("Color");
				}
			}
		}

		public string Title
		{
			get
			{
				return title;
			}
			set
			{
				if (title != value)
				{
					title = value;
					PixelTitle.Visibility = Visibility.Visible;
					PixelTitle.Text = title;
				}
			}
		}

		public double Diameter { get; set; }

		public event PropertyChangedEventHandler PropertyChanged;

		public Pixel()
		{
			InitializeComponent();
			base.DataContext = this;
		}

		public void NotifyPropertyChanged(string PropertyName)
		{
			this.PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(PropertyName));
		}

		private void Pixel_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
		{
			ColorPalette colorPalette = new ColorPalette(Color);
			if (colorPalette.ShowDialog() == true)
			{
				Color = colorPalette.Color;
			}
		}
	}
}
