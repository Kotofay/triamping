using System.Windows;
using System.Windows.Markup;

namespace ChipStudio
{
	public partial class ControllerOptionSettings : Window, IComponentConnector
	{
		public ControllerOptions Settings { get; } = new ControllerOptions();

		public ControllerOptionSettings(ControllerOptions InitSettings, uint OptionsMask)
		{
			InitializeComponent();
			if ((OptionsMask & 1) != 0)
			{
				OptGenSel.IsEnabled = true;
				OptGenSel.IsChecked = InitSettings.IsGenSelectionEnabled;
			}
			else
			{
				OptGenSel.IsEnabled = false;
			}
			if ((OptionsMask & 2) != 0)
			{
				OptFreq.IsEnabled = true;
				OptFreq.IsChecked = InitSettings.IsFreqIndicationEnabled;
			}
			else
			{
				OptFreq.IsEnabled = false;
			}
			if ((OptionsMask & 4) != 0)
			{
				OptRes.IsEnabled = true;
				OptRes.IsChecked = InitSettings.IsResIndicationEnabled;
			}
			else
			{
				OptRes.IsEnabled = false;
			}
			if ((OptionsMask & 8) != 0)
			{
				OptPwrKey.IsEnabled = true;
				OptPwrKey.IsChecked = InitSettings.IsPwrKeyEnabled;
			}
			else
			{
				OptPwrKey.IsEnabled = false;
			}
			if ((OptionsMask & 0x10) != 0)
			{
				OptUSBStdWake.IsEnabled = true;
				OptUSBStdWake.IsChecked = InitSettings.IsUSBStdByWakeEnabled;
			}
			else
			{
				OptUSBStdWake.IsEnabled = false;
			}
			if ((OptionsMask & 0x20) != 0)
			{
				OptFixProj.IsEnabled = true;
				OptFixProj.IsChecked = InitSettings.IsFixProjectEnabled;
			}
			else
			{
				OptFixProj.IsEnabled = false;
			}
		}

		private void OKButton_Click(object sender, RoutedEventArgs e)
		{
			base.DialogResult = true;
			Settings.IsGenSelectionEnabled = OptGenSel.IsChecked.Value;
			Settings.IsFreqIndicationEnabled = OptFreq.IsChecked.Value;
			Settings.IsResIndicationEnabled = OptRes.IsChecked.Value;
			Settings.IsPwrKeyEnabled = OptPwrKey.IsChecked.Value;
			Settings.IsUSBStdByWakeEnabled = OptUSBStdWake.IsChecked.Value;
			Settings.IsFixProjectEnabled = OptFixProj.IsChecked.Value;
		}

		private void CancelButton_Click(object sender, RoutedEventArgs e)
		{
			base.DialogResult = false;
		}
	}
}
