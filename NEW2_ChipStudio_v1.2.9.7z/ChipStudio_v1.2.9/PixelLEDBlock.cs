﻿// Decompiled with JetBrains decompiler
// Type: ChipStudio.PixelLEDBlock
// Assembly: ChipStudio, Version=1.2.9.0, Culture=neutral, PublicKeyToken=null
// MVID: 334E3BEA-37C7-4274-8118-535AAEFA1546
// Assembly location: D:\DocAndSec\Desktop\AUDIO\ChipDip\ChipStudio_soft_v1.2.9\ChipStudio_v1.2.9.exe

using System;

#nullable disable
namespace ChipStudio;

public class PixelLEDBlock
{
  public int LEDsCount { get; set; } = 1;

  public int StatesCount { get; set; }

  public PixelLEDBlock.IndicationTypes IndicationType { get; set; }

  public PixelLEDBlock.IndicationModes IndicationMode { get; set; }

  public static bool TryParseIndicationType(string value, out PixelLEDBlock.IndicationTypes result)
  {
    result = PixelLEDBlock.IndicationTypes.Project;
    foreach (PixelLEDBlock.IndicationTypes indicationTypes in Enum.GetValues(typeof (PixelLEDBlock.IndicationTypes)))
    {
      if (indicationTypes.ToString() == value)
      {
        result = indicationTypes;
        return true;
      }
    }
    return false;
  }

  public static bool TryParseIndicationMode(string value, out PixelLEDBlock.IndicationModes result)
  {
    result = PixelLEDBlock.IndicationModes.DataTable;
    foreach (PixelLEDBlock.IndicationModes indicationModes in Enum.GetValues(typeof (PixelLEDBlock.IndicationModes)))
    {
      if (indicationModes.ToString() == value)
      {
        result = indicationModes;
        return true;
      }
    }
    return false;
  }

  public enum IndicationTypes : byte
  {
    Project,
    DSPBlock,
    Comparator,
  }

  public enum IndicationModes : byte
  {
    DataTable,
    Scale,
  }
}
