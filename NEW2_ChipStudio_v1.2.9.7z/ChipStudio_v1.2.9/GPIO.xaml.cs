using System;
using System.CodeDom.Compiler;
using System.ComponentModel;
using System.Diagnostics;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Markup;

namespace ChipStudio
{
	public partial class GPIO : UserControl, INotifyPropertyChanged, IComponentConnector
	{
		public delegate void FunctionChangedEventHandler(int GPIONumber, int NewFunctionIndex);

		private bool isactive = true;

		private bool isconnectable;

		private Anchor.AnchorTypes[] _OwnAnchors;

		private Anchor.AnchorTypes[] _OppositeAnchors;

		private string[] funcs;

		public string Title { get; set; }

		public int TitleLength { get; set; }

		public string[] Functions
		{
			get
			{
				return funcs;
			}
			set
			{
				if (funcs != value)
				{
					funcs = value;
					FunctionBox.ItemsSource = Functions;
				}
			}
		}

		public string ActiveFunction => FunctionBox.SelectedItem?.ToString();

		public int ActiveFuncIndex
		{
			get
			{
				return FunctionBox.SelectedIndex;
			}
			set
			{
				FunctionBox.SelectedIndex = value;
			}
		}

		public int FunctionLength { get; set; }

		public bool IsActive
		{
			get
			{
				return isactive;
			}
			set
			{
				if (isactive != value)
				{
					isactive = value;
					IsConnectable = false;
					NotifyPropertyChanged("IsActive");
				}
			}
		}

		public bool IsConnectable
		{
			get
			{
				return isconnectable;
			}
			set
			{
				if (isconnectable != value)
				{
					isconnectable = value;
					ConnectionPoint.IsActivated = isconnectable;
				}
			}
		}

		public Anchor.AnchorTypes[] OwnAnchors
		{
			set
			{
				_OwnAnchors = value;
				ConnectionPoint.Type = _OwnAnchors[0];
			}
		}

		public Anchor.AnchorTypes[] OppositeAnchors
		{
			set
			{
				_OppositeAnchors = value;
			}
		}

		public Anchor.AnchorTypes ActiveOppositeAnchor
		{
			get
			{
				if (_OppositeAnchors == null || FunctionBox.SelectedIndex == -1)
				{
					return Anchor.AnchorTypes.EMPTY;
				}
				return _OppositeAnchors[FunctionBox.SelectedIndex];
			}
		}

		public uint Option { get; set; }

		public event PropertyChangedEventHandler PropertyChanged;

		public event FunctionChangedEventHandler FunctionChanged;

		public GPIO()
		{
			InitializeComponent();
			base.DataContext = this;
		}

		public void FlipHorizontal()
		{
			MainPanel.FlowDirection = ((MainPanel.FlowDirection == FlowDirection.LeftToRight) ? FlowDirection.RightToLeft : FlowDirection.LeftToRight);
			FunctionBox.FlowDirection = FlowDirection.LeftToRight;
		}

		public void NotifyPropertyChanged(string PropertyName)
		{
			this.PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(PropertyName));
		}

		private void Function_SelectionChanged(object sender, SelectionChangedEventArgs e)
		{
			int selectedIndex = (sender as ComboBox).SelectedIndex;
			if (selectedIndex != -1 && _OwnAnchors != null && selectedIndex < _OwnAnchors.Length)
			{
				ConnectionPoint.Type = _OwnAnchors[selectedIndex];
			}
			if (base.IsLoaded)
			{
				this.FunctionChanged?.Invoke(ConnectionPoint.Number, selectedIndex);
			}
		}
	}
}
