﻿// Decompiled with JetBrains decompiler
// Type: ChipStudio.RecentFiles
// Assembly: ChipStudio, Version=1.2.9.0, Culture=neutral, PublicKeyToken=null
// MVID: 334E3BEA-37C7-4274-8118-535AAEFA1546
// Assembly location: D:\DocAndSec\Desktop\AUDIO\ChipDip\ChipStudio_soft_v1.2.9\ChipStudio_v1.2.9.exe

using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Xml.Linq;

#nullable disable
namespace ChipStudio;

public class RecentFiles
{
  private const int FILE_COUNT_MAX = 10;
  private readonly string Name;
  private readonly List<string> FilesPaths = new List<string>(10);
  private readonly string DataFilePath;

  public RecentFiles(string Title)
  {
    this.Name = Title;
    this.DataFilePath = Path.Combine(Shared.ApplicationDataPath, this.Name + ".xml");
    if (Directory.Exists(Shared.ApplicationDataPath))
    {
      if (!File.Exists(this.DataFilePath))
        return;
      XElement xelement = XDocument.Load(this.DataFilePath).Element((XName) this.Name);
      List<string> stringList;
      if (xelement == null)
      {
        stringList = (List<string>) null;
      }
      else
      {
        IEnumerable<XElement> source = xelement.Elements((XName) "Path");
        stringList = source != null ? source.Select<XElement, string>((Func<XElement, string>) (p => p.Value)).ToList<string>() : (List<string>) null;
      }
      this.FilesPaths = stringList;
      if (this.FilesPaths != null)
        return;
      this.FilesPaths = new List<string>(10);
    }
    else
      Directory.CreateDirectory(Shared.ApplicationDataPath);
  }

  public void Add(string FilePath)
  {
    this.FilesPaths.Remove(FilePath);
    if (this.FilesPaths.Count == 10)
      this.FilesPaths.RemoveAt(0);
    this.FilesPaths.Add(FilePath);
  }

  public void Delete(string FilePath) => this.FilesPaths.Remove(FilePath);

  public string[] Get()
  {
    List<string> stringList = new List<string>((IEnumerable<string>) this.FilesPaths);
    stringList.Reverse();
    return stringList.ToArray();
  }

  public void Save()
  {
    XDocument xdocument = new XDocument(new object[1]
    {
      (object) new XElement((XName) this.Name)
    });
    foreach (string filesPath in this.FilesPaths)
      xdocument.Root.Add((object) new XElement((XName) "Path", (object) filesPath));
    xdocument.Save(this.DataFilePath);
  }
}
