using System.ComponentModel;
using System.Windows;
using System.Windows.Markup;

namespace ChipStudio
{
	public partial class ProgressWindow : Window, INotifyPropertyChanged, IComponentConnector
	{
		private double progress;

		private string description = string.Empty;

		public double Minimum { get; set; }

		public double Maximum { get; set; }

		public double Progress
		{
			get
			{
				return progress;
			}
			set
			{
				if (progress != value)
				{
					progress = value;
					NotifyPropertyChanged("Progress");
				}
			}
		}

		public string Description
		{
			get
			{
				return description;
			}
			set
			{
				if (description != value)
				{
					description = value;
					NotifyPropertyChanged("Description");
				}
			}
		}

		public event PropertyChangedEventHandler PropertyChanged;

		public ProgressWindow()
		{
			InitializeComponent();
			base.DataContext = this;
		}

		public void NotifyPropertyChanged(string PropertyName)
		{
			this.PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(PropertyName));
		}
	}
}
