using System;
using System.Collections.Generic;
using System.Windows.Controls;
using System.Windows.Markup;

namespace ChipStudio
{
	public partial class Selector : UserControl, IComponentConnector
	{
		private readonly List<string> Items = new List<string>();

		public string Title { get; set; }

		public int ListWidth { get; set; }

		public int SelectedIndex { get; set; }

		public string SelectedItem
		{
			get
			{
				if (Items.Count == 0 || SelectedIndex == -1)
				{
					return null;
				}
				return Items[SelectedIndex];
			}
		}

		public Selector()
		{
			InitializeComponent();
			base.DataContext = this;
		}

		public void Update(string[] NewItems, Schema.UpdateOptions Option)
		{
			ItemsList.ItemsSource = null;
			switch (Option)
			{
			case Schema.UpdateOptions.Init:
				Items.AddRange(NewItems);
				break;
			case Schema.UpdateOptions.Add:
				Items.Add(NewItems[NewItems.Length - 1]);
				break;
			case Schema.UpdateOptions.Remove:
			{
				int num = Array.IndexOf(NewItems, Items[SelectedIndex]);
				SelectedIndex = ((num != -1) ? num : 0);
				Items.Clear();
				Items.AddRange(NewItems);
				break;
			}
			}
			ItemsList.SelectionChanged -= ItemsList_SelectionChanged;
			if (SelectedIndex == -1 && Items.Count != 0)
			{
				SelectedIndex = 0;
			}
			ItemsList.ItemsSource = Items;
			ItemsList.SelectedIndex = SelectedIndex;
			ItemsList.SelectionChanged += ItemsList_SelectionChanged;
		}

		private void ItemsList_SelectionChanged(object sender, SelectionChangedEventArgs e)
		{
			if (ItemsList.SelectedIndex != -1)
			{
				SelectedIndex = ItemsList.SelectedIndex;
			}
		}
	}
}
