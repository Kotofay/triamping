using System.Windows.Markup;

namespace ChipStudio
{
	public partial class SchemaBlock_Comment : SchemaBlock, IComponentConnector
	{
		public override SchemaBlockTypes BlockType => SchemaBlockTypes.Comment;

		public override bool IsConnectable => false;

		public string Comment
		{
			get
			{
				return CommentBox.Text;
			}
			set
			{
				CommentBox.Text = value;
			}
		}

		public SchemaBlock_Comment()
		{
			InitializeComponent();
			base.DataContext = this;
		}
	}
}
