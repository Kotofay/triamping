using System.Windows;
using System.Windows.Markup;

namespace ChipStudio
{
	public partial class CLIModuleSettings : Window, IComponentConnector
	{
		public CLIModule Settings { get; } = new CLIModule();

		public CLIModuleSettings(CLIModule InitSettings)
		{
			InitializeComponent();
			if (InitSettings.IsEnabled)
			{
				IsEnabledCheck.IsChecked = true;
			}
		}

		private void OKButton_Click(object sender, RoutedEventArgs e)
		{
			base.DialogResult = true;
			Settings.IsEnabled = IsEnabledCheck.IsChecked == true;
		}

		private void CancelButton_Click(object sender, RoutedEventArgs e)
		{
			base.DialogResult = false;
		}
	}
}
