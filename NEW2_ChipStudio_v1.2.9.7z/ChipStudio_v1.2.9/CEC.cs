﻿// Decompiled with JetBrains decompiler
// Type: ChipStudio.CEC
// Assembly: ChipStudio, Version=1.2.9.0, Culture=neutral, PublicKeyToken=null
// MVID: 334E3BEA-37C7-4274-8118-535AAEFA1546
// Assembly location: D:\DocAndSec\Desktop\AUDIO\ChipDip\ChipStudio_soft_v1.2.9\ChipStudio_v1.2.9.exe

#nullable disable
namespace ChipStudio;

public class CEC
{
  private const byte CEC_OPT_TV_ON = 1;
  private const byte CEC_OPT_TV_OFF = 2;
  private const byte CEC_OPT_DEVICE_ON = 4;
  private const byte CEC_OPT_DEVICE_OFF = 8;
  private const byte CEC_OPT_AUDIO_STATUS = 16 /*0x10*/;
  public const int CECDefaultPort = 1;
  public const string CECDefaultDevName = "ChipDipDAC";

  public bool IsEnabled { get; set; }

  public int PortNumber { get; set; } = 1;

  public string Name { get; set; } = "ChipDipDAC";

  public int VolumeGpio { get; set; } = -1;

  public int MuteGpio { get; set; } = -1;

  public bool IsTVonEnabled { get; set; }

  public bool IsTVoffEnabled { get; set; }

  public bool IsDeviceOnEnabled { get; set; }

  public bool IsDeviceOffEnabled { get; set; }

  public bool IsAudioStatusEnabled { get; set; }

  public byte Options()
  {
    byte num = 0;
    if (this.IsTVonEnabled)
      num |= (byte) 1;
    if (this.IsTVoffEnabled)
      num |= (byte) 2;
    if (this.IsDeviceOnEnabled)
      num |= (byte) 4;
    if (this.IsDeviceOffEnabled)
      num |= (byte) 8;
    if (this.IsAudioStatusEnabled)
      num |= (byte) 16 /*0x10*/;
    return num;
  }
}
