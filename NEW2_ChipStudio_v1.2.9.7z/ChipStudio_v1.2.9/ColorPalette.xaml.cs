using System.Windows;
using System.Windows.Markup;
using Xceed.Wpf.Toolkit;

namespace ChipStudio
{
	public partial class ColorPalette : Window, IComponentConnector
	{	
		public string Color => Palette.HexadecimalString;

		public ColorPalette(string InitColor)
		{
			InitializeComponent();
			Palette.HexadecimalString = InitColor;
		}

		private void OKButton_Click(object sender, RoutedEventArgs e)
		{
			base.DialogResult = true;
		}

		private void CancelButton_Click(object sender, RoutedEventArgs e)
		{
			base.DialogResult = false;
		}
	}
}
