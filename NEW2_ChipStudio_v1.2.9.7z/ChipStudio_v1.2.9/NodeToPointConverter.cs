﻿// Decompiled with JetBrains decompiler
// Type: ChipStudio.NodeToPointConverter
// Assembly: ChipStudio, Version=1.2.9.0, Culture=neutral, PublicKeyToken=null
// MVID: 334E3BEA-37C7-4274-8118-535AAEFA1546
// Assembly location: D:\DocAndSec\Desktop\AUDIO\ChipDip\ChipStudio_soft_v1.2.9\ChipStudio_v1.2.9.exe

using System;
using System.Collections.ObjectModel;
using System.Globalization;
using System.Windows;
using System.Windows.Data;
using System.Windows.Media;

#nullable disable
namespace ChipStudio;

public class NodeToPointConverter : IValueConverter
{
  public object Convert(object value, Type targetType, object parameter, CultureInfo culture)
  {
    if (value == null)
      return (object) null;
    PointCollection pointCollection = new PointCollection();
    foreach (ConnectionNode connectionNode in (Collection<ConnectionNode>) (value as ObservableCollection<ConnectionNode>))
      pointCollection.Add(new Point()
      {
        X = connectionNode.AnchorPoint.X,
        Y = connectionNode.AnchorPoint.Y
      });
    return (object) pointCollection;
  }

  public object ConvertBack(object value, Type targetType, object parameter, CultureInfo culture)
  {
    throw new NotImplementedException();
  }
}
