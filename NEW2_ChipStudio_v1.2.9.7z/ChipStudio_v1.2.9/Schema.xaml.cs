using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Markup;

namespace ChipStudio
{
	public partial class Schema : UserControl, IComponentConnector
	{
		public enum UpdateOptions : byte
		{
			Init,
			Add,
			Remove
		}

		private const string BlockDuplicateInfo = "Schema already contains selected block";

		private const string BlockDuplicateInfoHeader = "Block duplicate";

		private const string ControllerDuplicateInfo = "Schema can contain only one controller";

		private const string ControllerDuplicateInfoHeader = "Controller duplicate";

		private static readonly Cursor PROJECT_FIELD_CURSOR_MAIN = Cursors.Arrow;

		private static readonly Cursor PROJECT_FIELD_CURSOR_CONNECTION_ACTIVE = Cursors.Cross;

		private const int ZIndex_ActiveConnection = -2;

		private const int ZIndex_NormalElement = -1;

		private const int ZIndex_ActiveElement = 0;

		private const int ZIndex_NormalConnection = 0;

		private const int BlockMoveStep = 5;

		private const double StartX = 50.0;

		private const double StartY = 50.0;

		private const double BlockStep = 75.0;

		private Action ControllerAdded;

		private int ActiveSchemaElementIndex = -1;

		private bool IsConnectionActive;

		private readonly List<DSPCellsList> DSPCells = new List<DSPCellsList>();

		private TreeView DSPCellsView;

		private bool IsMovingPending;

		public Schema()
		{
			InitializeComponent();
			base.DataContext = this;
		}

		public SchemaBlock_Controller GetController()
		{
			return GetController(ProjectSchema.Children);
		}

		public void ImportDSP(List<string> Parts, List<DataTransfer[]> Boot, List<DSPCell[]> DSPCells)
		{
			List<SchemaBlock_DSP> list = ProjectSchema.Children.OfType<SchemaBlock_DSP>().ToList();
			int i;
			for (i = 0; i < Parts.Count; i++)
			{
				SchemaBlock_DSP[] array = list.Where((SchemaBlock_DSP b) => b.Title.IndexOf(Parts[i]) != -1).ToArray();
				if (array.Length == 0)
				{
					SchemaBlock_DSP schemaBlock_DSP = CreateDSPBlock(Parts[i], Boot[i], DSPCells[i]);
					if (schemaBlock_DSP != null)
					{
						schemaBlock_DSP.UpperLeftPoint = new Point(50.0, 50.0 + (double)i * 75.0);
						ImportDSPBlock(schemaBlock_DSP);
					}
				}
				else
				{
					array[0].UpdateBootAndCells(Boot[i].ToList(), DSPCells[i].ToList());
					list.Remove(array[0]);
				}
			}
		}

		public void AddElements(ISchemaElement[] Elements)
		{
			foreach (ISchemaElement element in Elements)
			{
				AddElement(element);
			}
			DSPCellsSetChanged(UpdateOptions.Init);
			DSPSetChanged(UpdateOptions.Init);
			ComparatorSetChanged(UpdateOptions.Init);
		}

		public void ImportDSPBlock(SchemaBlock_DSP DSP)
		{
			DSP.Title = SetBlockTitle(DSP.Title);
			DSP.SetDSPTitleToCells();
			AddElement(DSP);
			DSPCellsSetChanged(UpdateOptions.Init);
			DSPSetChanged(UpdateOptions.Init);
		}

		public void AddElement(ISchemaElement Element)
		{
			if (Element.ElementType == Shared.ElementTypeBlock)
			{
				SchemaBlock schemaBlock = Element as SchemaBlock;
				schemaBlock.AddConnectionEventHandler(AddConnectionNode);
				switch (schemaBlock.BlockType)
				{
				case SchemaBlock.SchemaBlockTypes.DSP:
				{
					(schemaBlock as SchemaBlock_DSP).FileParseEnd += DSPFileParseEnd;
					List<DSPCell> cells = (schemaBlock as SchemaBlock_DSP).GetCells();
					if (cells.Count != 0)
					{
						DSPFileParseEnd(cells, SchemaBlock_DSP.FileParseOption.Replace);
					}
					break;
				}
				case SchemaBlock.SchemaBlockTypes.DSPCell:
				{
					int dSPIndexInListByName = GetDSPIndexInListByName((schemaBlock as SchemaBlock_DSPCell).DSPTitle);
					int dSPCellIndexInDSPListByName = GetDSPCellIndexInDSPListByName(dSPIndexInListByName, schemaBlock.Title.ToString());
					(schemaBlock as SchemaBlock_DSPCell).Initialize(DSPCells[dSPIndexInListByName].DSPBlocks[dSPCellIndexInDSPListByName]);
					break;
				}
				}
				ProjectSchema.Children.Add(schemaBlock);
			}
			else if (Element.ElementType == Shared.ElementTypeConnection)
			{
				ProjectSchema.Children.Add(Element as Connection);
			}
		}

		public void SetDSPCellsView(TreeView View)
		{
			DSPCellsView = View;
		}

		public void DragDropBlock(MouseButtonEventArgs e)
		{
			if (e.Source is TreeViewItem treeViewItem)
			{
				DragDrop.DoDragDrop(treeViewItem, treeViewItem, DragDropEffects.Copy);
			}
		}

		public void Clear()
		{
			ProjectSchema.Children.Clear();
			DSPCells.Clear();
			DSPCellsView.Items.Clear();
			ActiveSchemaElementIndex = -1;
			IsMovingPending = false;
		}

		public UIElementCollection GetElements()
		{
			return ProjectSchema.Children;
		}

		public void DeleteElement()
		{
			if (!ProjectSchema.IsMouseOver || ActiveSchemaElementIndex == -1)
			{
				return;
			}
			ISchemaElement schemaElement = ProjectSchema.Children[ActiveSchemaElementIndex] as ISchemaElement;
			bool flag = false;
			bool flag2 = false;
			bool flag3 = false;
			if (schemaElement.ElementType == Shared.ElementTypeBlock)
			{
				SchemaBlock schemaBlock = schemaElement as SchemaBlock;
				if (schemaBlock.BlockType == SchemaBlock.SchemaBlockTypes.DSP)
				{
					flag2 = true;
					DeleteDSPCellsFromSchematic(schemaBlock.Title);
					for (int i = 0; i < DSPCells.Count; i++)
					{
						if (DSPCells[i].Name == schemaBlock.Title)
						{
							DSPCells.RemoveAt(i);
							DSPCellsView.Items.RemoveAt(i);
						}
					}
				}
				DeleteBlockConnections(schemaBlock.FullName);
				if (schemaBlock is SchemaBlock_DSPCell)
				{
					flag = true;
				}
				else if (schemaBlock is SchemaBlock_Comparator)
				{
					flag3 = true;
				}
				schemaBlock.Dispose();
			}
			ProjectSchema.Children.RemoveAt(ActiveSchemaElementIndex);
			if (flag)
			{
				DSPCellsSetChanged(UpdateOptions.Remove);
			}
			else if (flag2)
			{
				DSPSetChanged(UpdateOptions.Remove);
			}
			else if (flag3)
			{
				ComparatorSetChanged(UpdateOptions.Remove);
			}
			ActiveSchemaElementIndex = -1;
		}

		public void SetControllerAddedCallback(Action Callback)
		{
			ControllerAdded = Callback;
		}

		public static SchemaBlock_Controller GetController(UIElementCollection Schema)
		{
			SchemaBlock_Controller[] array = Schema.OfType<SchemaBlock_Controller>().ToArray();
			if (array.Length == 0)
			{
				return null;
			}
			return array[0];
		}

		public static SchemaBlock_DSP[] GetDSPs(UIElementCollection Schema)
		{
			return Schema.OfType<SchemaBlock_DSP>().ToArray();
		}

		public static SchemaBlock_DSP GetDSP(UIElementCollection Schema, string Title)
		{
			SchemaBlock_DSP[] array = (from d in GetDSPs(Schema)
				where d.Title == Title
				select d).ToArray();
			if (array.Length == 0)
			{
				return null;
			}
			return array[0];
		}

		public static SchemaBlock_DSPCell[] GetDSPCells(UIElementCollection Schema)
		{
			return Schema.OfType<SchemaBlock_DSPCell>().ToArray();
		}

		public static SchemaBlock_DSPCell[] GetDSPCells(UIElementCollection Schema, string FullName)
		{
			return (from d in GetDSPCells(Schema)
				where d.FullName == FullName
				select d).ToArray();
		}

		public static SchemaBlock_LED[] GetLEDs(UIElementCollection Schema)
		{
			return Schema.OfType<SchemaBlock_LED>().ToArray();
		}

		public static SchemaBlock_PixelLED[] GetPixelLEDs(UIElementCollection Schema)
		{
			return Schema.OfType<SchemaBlock_PixelLED>().ToArray();
		}

		public static SchemaBlock_Read[] GetReads(UIElementCollection Schema)
		{
			return Schema.OfType<SchemaBlock_Read>().ToArray();
		}

		public static SchemaBlock_Comparator[] GetComparators(UIElementCollection Schema)
		{
			return Schema.OfType<SchemaBlock_Comparator>().ToArray();
		}

		public static Connection[] GetConnections(UIElementCollection Schema)
		{
			return Schema.OfType<Connection>().ToArray();
		}

		public static Connection[] GetConnections(UIElementCollection Schema, ConnectionNode Node1, ConnectionNode Node2)
		{
			return (from c in GetConnections(Schema)
				where (c.Nodes[0].BlockName == Node1.BlockName && c.Nodes[0].AnchorNumber == Node1.AnchorNumber && c.Nodes[1].BlockName == Node2.BlockName && c.Nodes[1].AnchorNumber == Node2.AnchorNumber) || (c.Nodes[0].BlockName == Node2.BlockName && c.Nodes[0].AnchorNumber == Node2.AnchorNumber && c.Nodes[1].BlockName == Node1.BlockName && c.Nodes[1].AnchorNumber == Node1.AnchorNumber)
				select c).ToArray();
		}

		private SchemaBlock_DSP CreateDSPBlock(string Part, DataTransfer[] Boot, DSPCell[] Cells)
		{
			SchemaBlock_DSP schemaBlock_DSP = new SchemaBlock_DSP(Part);
			if (!schemaBlock_DSP.IsReady)
			{
				return null;
			}
			schemaBlock_DSP.Title = Part;
			schemaBlock_DSP.SetBoot(Boot);
			schemaBlock_DSP.SetCells(Cells);
			schemaBlock_DSP.AddConstantCells();
			return schemaBlock_DSP;
		}

		private string SetBlockTitle(string ModuleType)
		{
			return ModuleType + "_" + FindBlockIndex(ModuleType);
		}

		private int FindBlockIndex(string ModuleType)
		{
			int[] array = (from b in ProjectSchema.Children.OfType<SchemaBlock>()
				where b.Title.IndexOf(ModuleType) != -1
				select b.SchemaIndex).ToArray();
			int i;
			for (i = 0; i < int.MaxValue && Array.IndexOf(array, i) != -1; i++)
			{
			}
			return i;
		}

		private void AddConnectionNode(ConnectionNode Node)
		{
			if (!IsConnectionActive)
			{
				Connection connection = new Connection();
				connection.AddNode(Node);
				ApplyNodeFilterToAllBlocks(Node);
				connection.AddNode(new ConnectionNode(null, Node.AnchorNumber, Node.AnchorPoint, Anchor.AnchorTypes.EMPTY));
				ProjectSchema.Children.Add(connection);
				Panel.SetZIndex(connection, -2);
				IsConnectionActive = true;
				ProjectSchema.MouseRightButtonDown += Schema_MouseRightButtonDown;
				Schema_ChangeCursor(PROJECT_FIELD_CURSOR_CONNECTION_ACTIVE);
			}
			else
			{
				Connection obj = ProjectSchema.Children[ProjectSchema.Children.Count - 1] as Connection;
				obj.RemoveNodeAt(1);
				obj.AddNode(Node);
				DiscardNodeFilterInAllBlocks();
				Panel.SetZIndex(obj, 0);
				IsConnectionActive = false;
				ProjectSchema.MouseRightButtonDown -= Schema_MouseRightButtonDown;
				Schema_ChangeCursor(PROJECT_FIELD_CURSOR_MAIN);
			}
		}

		private void ApplyNodeFilterToAllBlocks(ConnectionNode Node)
		{
			for (int i = 0; i < ProjectSchema.Children.Count; i++)
			{
				if (ProjectSchema.Children[i] is SchemaBlock schemaBlock)
				{
					schemaBlock.ApplyFilter(Node);
				}
			}
		}

		private void DiscardNodeFilterInAllBlocks()
		{
			for (int i = 0; i < ProjectSchema.Children.Count; i++)
			{
				if (ProjectSchema.Children[i] is SchemaBlock schemaBlock)
				{
					schemaBlock.DiscardFilter();
				}
			}
		}

		private void DSPFileParseEnd(List<DSPCell> CellList, SchemaBlock_DSP.FileParseOption Option)
		{
			string dSPTitle = CellList[0].DSPTitle;
			bool flag = true;
			int index = 0;
			for (int i = 0; i < DSPCells.Count; i++)
			{
				if (DSPCells[i].Name == dSPTitle)
				{
					flag = false;
					index = i;
					break;
				}
			}
			if (flag)
			{
				DSPCells.Add(new DSPCellsList
				{
					Name = dSPTitle
				});
				DSPCellsView.Items.Add(new TreeViewItem
				{
					Header = dSPTitle,
					IsExpanded = true
				});
				index = DSPCells.Count - 1;
			}
			else
			{
				(DSPCellsView.Items[index] as TreeViewItem).Items.Clear();
				switch (Option)
				{
				case SchemaBlock_DSP.FileParseOption.Replace:
					DSPCells[index].DSPBlocks.Clear();
					DeleteDSPCellsFromSchematic(dSPTitle);
					break;
				case SchemaBlock_DSP.FileParseOption.Update:
				{
					for (int num = DSPCells[index].DSPBlocks.Count - 1; num >= 0; num--)
					{
						bool flag2 = false;
						int num2 = 0;
						for (num2 = 0; num2 < CellList.Count; num2++)
						{
							if (DSPCells[index].DSPBlocks[num].Title == CellList[num2].Title)
							{
								flag2 = true;
								break;
							}
						}
						for (int num3 = ProjectSchema.Children.Count - 1; num3 >= 0; num3--)
						{
							if (ProjectSchema.Children[num3] is SchemaBlock_DSPCell schemaBlock_DSPCell && schemaBlock_DSPCell.DSPTitle == dSPTitle && schemaBlock_DSPCell.Title == DSPCells[index].DSPBlocks[num].Title)
							{
								if (!flag2)
								{
									DeleteBlockConnections(schemaBlock_DSPCell.FullName);
									ProjectSchema.Children.RemoveAt(num3);
									DSPCellsSetChanged(UpdateOptions.Remove);
								}
								else
								{
									schemaBlock_DSPCell.Update(CellList[num2]);
								}
								break;
							}
						}
						DSPCells[index].DSPBlocks.RemoveAt(num);
					}
					break;
				}
				}
			}
			DSPCells[index].DSPBlocks.AddRange(CellList);
			foreach (DSPCell Cell in CellList)
			{
				TreeViewItem treeViewItem = new TreeViewItem
				{
					Header = Cell.Title
				};
				if (Cell.IsControllable)
				{
					treeViewItem.PreviewMouseLeftButtonDown += DSPCell_PreviewMouseLeftButtonDown;
				}
				(DSPCellsView.Items[index] as TreeViewItem).Items.Add(treeViewItem);
			}
		}

		private void DeleteDSPCellsFromSchematic(string DSPTitle)
		{
			SchemaBlock_DSPCell[] array = (from b in ProjectSchema.Children.OfType<SchemaBlock_DSPCell>()
				where b.DSPTitle == DSPTitle
				select b).ToArray();
			foreach (SchemaBlock_DSPCell schemaBlock_DSPCell in array)
			{
				DeleteBlockConnections(schemaBlock_DSPCell.FullName);
				ProjectSchema.Children.Remove(schemaBlock_DSPCell);
				DSPCellsSetChanged(UpdateOptions.Remove);
			}
		}

		private void DeleteBlockConnections(string BlockTitle)
		{
			Connection[] array = (from c in ProjectSchema.Children.OfType<Connection>()
				where c.Nodes[0].BlockName.IndexOf(BlockTitle) != -1 || c.Nodes[1].BlockName.IndexOf(BlockTitle) != -1
				select c).ToArray();
			foreach (Connection element in array)
			{
				ProjectSchema.Children.Remove(element);
			}
		}

		private void DSPCellsSetChanged(UpdateOptions Option)
		{
			ILed[] array = ProjectSchema.Children.OfType<ILed>().ToArray();
			if (array.Length != 0)
			{
				SchemaBlock_DSPCell[] dSPCells = GetDSPCells();
				ILed[] array2 = array;
				for (int i = 0; i < array2.Length; i++)
				{
					array2[i].UpdateBlockList(dSPCells, Option);
				}
			}
		}

		private void DSPSetChanged(UpdateOptions Option)
		{
			IDSPDependent[] array = ProjectSchema.Children.OfType<IDSPDependent>().ToArray();
			if (array.Length != 0)
			{
				string[] dSPTitles = GetDSPTitles();
				IDSPDependent[] array2 = array;
				for (int i = 0; i < array2.Length; i++)
				{
					array2[i].UpdateDSPList(dSPTitles, Option);
				}
			}
		}

		private void ComparatorSetChanged(UpdateOptions Option)
		{
			IComparatorDependent[] array = ProjectSchema.Children.OfType<IComparatorDependent>().ToArray();
			if (array.Length != 0)
			{
				string[] comparatorTitles = GetComparatorTitles();
				IComparatorDependent[] array2 = array;
				for (int i = 0; i < array2.Length; i++)
				{
					array2[i].UpdateComparatorList(comparatorTitles, Option);
				}
			}
		}

		private SchemaBlock_DSPCell[] GetDSPCells()
		{
			return ProjectSchema.Children.OfType<SchemaBlock_DSPCell>().ToArray();
		}

		private string[] GetDSPTitles()
		{
			return (from d in GetDSPs(ProjectSchema.Children)
				select d.Title).ToArray();
		}

		private string[] GetComparatorTitles()
		{
			return (from d in GetComparators(ProjectSchema.Children)
				select d.Title).ToArray();
		}

		private int GetDSPIndexInListByName(string DSPTitle)
		{
			int result = -1;
			for (int i = 0; i < DSPCells.Count; i++)
			{
				if (DSPCells[i].Name == DSPTitle)
				{
					result = i;
					break;
				}
			}
			return result;
		}

		private int GetDSPCellIndexInDSPListByName(int DSPIndex, string CellTitle)
		{
			int result = -1;
			for (int i = 0; i < DSPCells[DSPIndex].DSPBlocks.Count; i++)
			{
				if (DSPCells[DSPIndex].DSPBlocks[i].Title == CellTitle)
				{
					result = i;
					break;
				}
			}
			return result;
		}

		private void SelectElement(ISchemaElement Element)
		{
			if (ActiveSchemaElementIndex != -1)
			{
				DeselectElement();
			}
			if (Element != null)
			{
				if (Element.ElementType == Shared.ElementTypeBlock)
				{
					ActiveSchemaElementIndex = ProjectSchema.Children.IndexOf(Element as SchemaBlock);
					IsMovingPending = true;
				}
				else if (Element.ElementType == Shared.ElementTypeConnection)
				{
					ActiveSchemaElementIndex = ProjectSchema.Children.IndexOf(Element as Connection);
				}
				(ProjectSchema.Children[ActiveSchemaElementIndex] as ISchemaElement).IsSelected = true;
				Panel.SetZIndex(ProjectSchema.Children[ActiveSchemaElementIndex], 0);
			}
		}

		private void DeselectElement()
		{
			(ProjectSchema.Children[ActiveSchemaElementIndex] as ISchemaElement).IsSelected = false;
			Panel.SetZIndex(ProjectSchema.Children[ActiveSchemaElementIndex], -1);
			ActiveSchemaElementIndex = -1;
			IsMovingPending = false;
		}

		private void Schema_ChangeCursor(Cursor NewCursor)
		{
			ProjectSchema.Cursor = NewCursor;
		}

		private static double RoundCoordinate(double value)
		{
			int num = (int)Math.Round(value);
			int num2 = num % 5;
			if (num2 != 0)
			{
				num += 5 - num2;
			}
			return num;
		}

		private void Schema_Drop(object sender, DragEventArgs e)
		{
			TreeViewItem treeViewItem = (TreeViewItem)e.Data.GetData(e.Data.GetFormats()[0]);
			if (treeViewItem == null)
			{
				return;
			}
			Point position = e.GetPosition(ProjectSchema);
			position.X = RoundCoordinate(position.X);
			position.Y = RoundCoordinate(position.Y);
			string text = treeViewItem.Header.ToString();
			string text2 = (treeViewItem.Parent as TreeViewItem).Header.ToString();
			string title = SetBlockTitle(text);
			if (text2 == Shared.ControllersFolder)
			{
				if (GetController(ProjectSchema.Children) != null)
				{
					MessageBox.Show("Schema can contain only one controller", "Controller duplicate", MessageBoxButton.OK, MessageBoxImage.Asterisk);
					return;
				}
				SchemaBlock_Controller schemaBlock_Controller = new SchemaBlock_Controller(text)
				{
					Title = title,
					UpperLeftPoint = position
				};
				if (schemaBlock_Controller.IsReady)
				{
					schemaBlock_Controller.AddConnectionEventHandler(AddConnectionNode);
					ProjectSchema.Children.Add(schemaBlock_Controller);
					Panel.SetZIndex(schemaBlock_Controller, -1);
					ControllerAdded?.Invoke();
				}
				return;
			}
			if (text2 == Shared.DSPCodecFolder)
			{
				SchemaBlock_DSP schemaBlock_DSP = new SchemaBlock_DSP(text)
				{
					Title = title,
					UpperLeftPoint = position
				};
				if (schemaBlock_DSP.IsReady)
				{
					schemaBlock_DSP.FileParseEnd += DSPFileParseEnd;
					schemaBlock_DSP.AddConnectionEventHandler(AddConnectionNode);
					ProjectSchema.Children.Add(schemaBlock_DSP);
					Panel.SetZIndex(schemaBlock_DSP, -1);
					DSPSetChanged(UpdateOptions.Add);
				}
				return;
			}
			switch (text)
			{
			case "LED":
			{
				SchemaBlock_LED schemaBlock_LED = new SchemaBlock_LED
				{
					Title = title,
					UpperLeftPoint = position
				};
				schemaBlock_LED.AddConnectionEventHandler(AddConnectionNode);
				schemaBlock_LED.UpdateBlockList(GetDSPCells(), UpdateOptions.Init);
				schemaBlock_LED.UpdateComparatorList(GetComparatorTitles(), UpdateOptions.Init);
				ProjectSchema.Children.Add(schemaBlock_LED);
				Panel.SetZIndex(schemaBlock_LED, -1);
				return;
			}
			case "PixelLED":
			{
				SchemaBlock_PixelLED schemaBlock_PixelLED = new SchemaBlock_PixelLED
				{
					Title = title,
					UpperLeftPoint = position
				};
				schemaBlock_PixelLED.AddConnectionEventHandler(AddConnectionNode);
				schemaBlock_PixelLED.UpdateBlockList(GetDSPCells(), UpdateOptions.Init);
				schemaBlock_PixelLED.UpdateComparatorList(GetComparatorTitles(), UpdateOptions.Init);
				ProjectSchema.Children.Add(schemaBlock_PixelLED);
				Panel.SetZIndex(schemaBlock_PixelLED, -1);
				return;
			}
			case "Read":
			{
				SchemaBlock_Read schemaBlock_Read = new SchemaBlock_Read
				{
					Title = title,
					UpperLeftPoint = position
				};
				schemaBlock_Read.AddConnectionEventHandler(AddConnectionNode);
				schemaBlock_Read.UpdateDSPList(GetDSPTitles(), UpdateOptions.Init);
				ProjectSchema.Children.Add(schemaBlock_Read);
				Panel.SetZIndex(schemaBlock_Read, -1);
				return;
			}
			case "Comparator":
			{
				SchemaBlock_Comparator schemaBlock_Comparator = new SchemaBlock_Comparator
				{
					Title = title,
					UpperLeftPoint = position
				};
				schemaBlock_Comparator.AddConnectionEventHandler(AddConnectionNode);
				ProjectSchema.Children.Add(schemaBlock_Comparator);
				Panel.SetZIndex(schemaBlock_Comparator, -1);
				ComparatorSetChanged(UpdateOptions.Add);
				return;
			}
			case "Comment":
			{
				SchemaBlock_Comment element = new SchemaBlock_Comment
				{
					Title = title,
					UpperLeftPoint = position
				};
				ProjectSchema.Children.Add(element);
				Panel.SetZIndex(element, -1);
				return;
			}
			}
			int dSPIndexInListByName = GetDSPIndexInListByName((treeViewItem.Parent as TreeViewItem).Header.ToString());
			int dSPCellIndexInDSPListByName = GetDSPCellIndexInDSPListByName(dSPIndexInListByName, treeViewItem.Header.ToString());
			string DSPTitle = DSPCells[dSPIndexInListByName].DSPBlocks[dSPCellIndexInDSPListByName].DSPTitle;
			string CellTitle = DSPCells[dSPIndexInListByName].DSPBlocks[dSPCellIndexInDSPListByName].Title;
			SchemaBlock_DSPCell[] array = (from b in ProjectSchema.Children.OfType<SchemaBlock_DSPCell>()
				where b.Title == CellTitle && b.DSPTitle == DSPTitle
				select b).ToArray();
			if (array.Length != 0)
			{
				MessageBox.Show("Schema already contains selected block", "Block duplicate", MessageBoxButton.OK, MessageBoxImage.Asterisk);
				ActiveSchemaElementIndex = ProjectSchema.Children.IndexOf(array[0]);
				(ProjectSchema.Children[ActiveSchemaElementIndex] as ISchemaElement).IsSelected = true;
				return;
			}
			SchemaBlock_DSPCell schemaBlock_DSPCell = new SchemaBlock_DSPCell
			{
				Title = CellTitle,
				DSPTitle = DSPTitle,
				UpperLeftPoint = position
			};
			schemaBlock_DSPCell.AddConnectionEventHandler(AddConnectionNode);
			schemaBlock_DSPCell.Initialize(DSPCells[dSPIndexInListByName].DSPBlocks[dSPCellIndexInDSPListByName]);
			ProjectSchema.Children.Add(schemaBlock_DSPCell);
			Panel.SetZIndex(schemaBlock_DSPCell, -1);
			DSPCellsSetChanged(UpdateOptions.Add);
		}

		private void Schema_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
		{
			if (!IsConnectionActive)
			{
				SelectElement(e.Source as ISchemaElement);
			}
		}

		private void Schema_MouseRightButtonDown(object sender, MouseButtonEventArgs e)
		{
			if (IsConnectionActive)
			{
				ProjectSchema.Children.RemoveAt(ProjectSchema.Children.Count - 1);
				DiscardNodeFilterInAllBlocks();
				IsConnectionActive = false;
				ProjectSchema.MouseRightButtonDown -= Schema_MouseRightButtonDown;
				Schema_ChangeCursor(PROJECT_FIELD_CURSOR_MAIN);
			}
		}

		private void Schema_MouseMove(object sender, MouseEventArgs e)
		{
			Point position = e.GetPosition(ProjectSchema);
			if (!IsConnectionActive)
			{
				if (ActiveSchemaElementIndex == -1 || !IsMovingPending || !(ProjectSchema.Children[ActiveSchemaElementIndex] is SchemaBlock schemaBlock))
				{
					return;
				}
				position.X = RoundCoordinate(position.X);
				position.Y = RoundCoordinate(position.Y);
				Point point = schemaBlock.ClickPoint();
				point.X = RoundCoordinate(point.X);
				point.Y = RoundCoordinate(point.Y);
				position.X -= point.X;
				position.Y -= point.Y;
				schemaBlock.UpperLeftPoint = position;
				for (int i = 0; i < ProjectSchema.Children.Count; i++)
				{
					if (ProjectSchema.Children[i] is Connection connection)
					{
						int anchorNumberInBlock = connection.GetAnchorNumberInBlock(schemaBlock.FullName);
						if (anchorNumberInBlock != -1)
						{
							connection.Update(schemaBlock.GetAnchorConnectionNode(anchorNumberInBlock));
						}
					}
				}
			}
			else if (ProjectSchema.Children[ProjectSchema.Children.Count - 1] is Connection connection2)
			{
				LinePoint anchorpoint = new LinePoint
				{
					X = position.X,
					Y = position.Y
				};
				connection2.Update(new ConnectionNode(null, 0, anchorpoint, Anchor.AnchorTypes.EMPTY));
			}
		}

		private void DSPCell_PreviewMouseLeftButtonDown(object sender, MouseButtonEventArgs e)
		{
			DragDropBlock(e);
		}

		private void Schema_MouseLeftButtonUp(object sender, MouseButtonEventArgs e)
		{
			IsMovingPending = false;
		}
	}
}
