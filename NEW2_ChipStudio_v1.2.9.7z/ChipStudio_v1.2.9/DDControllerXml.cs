﻿// Decompiled with JetBrains decompiler
// Type: ChipStudio.DDControllerXml
// Assembly: ChipStudio, Version=1.2.9.0, Culture=neutral, PublicKeyToken=null
// MVID: 334E3BEA-37C7-4274-8118-535AAEFA1546
// Assembly location: D:\DocAndSec\Desktop\AUDIO\ChipDip\ChipStudio_soft_v1.2.9\ChipStudio_v1.2.9.exe

using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Windows;
using System.Xml.Linq;

#nullable disable
namespace ChipStudio;

public class DDControllerXml : IDDController
{
    private const string USBPacketSizeString = "USBPacketSize";

    private const string DownLoadAPIString = "DownLoadAPI";

    private const string GpioNumString = "Gpio";

    private const string ValuesString = "Values";

    private const string TimerPCSString = "TimerPCS";

    private const string TimerARRString = "TimerARR";

    private const string GPIOSString = "GPIOS";

    private const string GpioElement = "gpio";

    private const string RegGPIOsString = "RegGPIOs";

    private const string GPIOInterfacesString = "GPIOInterfaces";

    private const string DSPInterfacesString = "DSPInterfaces";

    private const string TouchCapGpioString = "TouchCapGpio";

    private const string FunctionsString = "Functions";

    private const string LinesString = "Lines";

    private const string FunctionIndexString = "FunctionIndex";

    private const string USBSettingsString = "USBSettings";

    private const string AudioConfigurationString = "AudioConfiguration";

    private const string OptionString = "Option";

    private const string ProjectMemorySizeString = "ProjectMemorySize";

    private static readonly string[] DelayDefaultStrings = new string[8] { "5", "50", "100", "500", "1000", "1500", "2000", "2500" };

    private int TouchCapGpioNum = -1;

    private string[] RegGPIOsTitles;

    private string[] GPIOITitles;

    private string[] DSPITitles;

    private string[][] RegGpiosFuncs;

    private string[][] GPIOIFuncs;

    private string[][] DSPIFuncs;

    private bool[] IsRegGpioEnabled;

    private bool[] IsGPIOIEnabled;

    private bool[] IsDSPIEnabled;

    private int[] GPIOI_FunctionIndex;

    private int[][] GPIOI_Lines;

    private uint[] GPIO_Options;

    public bool IsLoaded { get; }

    public byte ID { get; }

    public byte DownLoadAPI { get; }

    public ushort USBPacketSize { get; }

    public int ProjectMemorySize { get; }

    public string[] DelayValues { get; }

    public int[] DelayTimerPCS { get; }

    public int[] DelayTimerARR { get; }

    public string[] MuteValues { get; }

    public int[] MuteTimerPCS { get; }

    public int[] MuteTimerARR { get; }

    public bool IsPixelSupported { get; }

    public bool IsCLISupported { get; }

    public int[] CLIGpio { get; } = new int[2] { -1, -1 };

    public int PixelGpio { get; } = -1;

    public bool IsCECSupported { get; }

    public int CECGpio { get; } = -1;

    public uint OptionsMask { get; }

    public bool AreUSBSetsSupported { get; }

    public string[] AudioConfiguration { get; }

    public DDControllerXml(string ModuleType)
    {
        if (!Directory.Exists(Shared.DDControllerPath))
        {
            MessageBox.Show("Folder\n\r..." + Shared.DDControllerFolder + "\n\r" + Shared.DoesNotExistString, "", MessageBoxButton.OK, MessageBoxImage.Hand);
            return;
        }
        string text = ModuleType + Shared.DDFileExt;
        string text2 = Shared.DDControllerPath + Shared.FilePathSlash + text;
        if (!File.Exists(text2))
        {
            MessageBox.Show("Device description file\n\r" + text + "\n\r" + Shared.DoesNotExistString, "", MessageBoxButton.OK, MessageBoxImage.Hand);
            return;
        }
        XDocument xDocument = XDocument.Load(text2);
        if (!int.TryParse(xDocument.Element("Controller")?.Attribute("ID")?.Value, out var Value))
        {
            return;
        }
        ID = (byte)Value;
        if (!int.TryParse(xDocument.Element("Controller")?.Attribute("USBPacketSize")?.Value, out Value))
        {
            return;
        }
        USBPacketSize = (ushort)Value;
        if (!int.TryParse(xDocument.Element("Controller")?.Attribute("DownLoadAPI")?.Value, out Value))
        {
            return;
        }
        DownLoadAPI = (byte)Value;
        ProjectMemorySize = (int.TryParse(xDocument.Element("Controller")?.Attribute("ProjectMemorySize")?.Value, out Value) ? (Value * 1024) : 0);
        IsPixelSupported = bool.TryParse(xDocument.Element("Controller")?.Element("PixelLED")?.Attribute("IsEnabled")?.Value, out var result) && result;
        if (IsPixelSupported)
        {
            string text3 = xDocument.Element("Controller")?.Element("PixelLED")?.Attribute("Gpio")?.Value;
            if (text3 != null)
            {
                PixelGpio = (int.TryParse(text3, out Value) ? Value : (-1));
            }
        }
        IsCLISupported = bool.TryParse(xDocument.Element("Controller")?.Element("CLI")?.Attribute("IsEnabled")?.Value, out result) && result;
        if (IsCLISupported)
        {
            string text3 = xDocument.Element("Controller")?.Element("CLI")?.Attribute("Gpio")?.Value;
            if (text3 != null)
            {
                CLIGpio = (from p in text3.Split(";"[0])
                           select (!int.TryParse(p, out Value)) ? (-1) : Value).ToArray();
            }
        }
        IsCECSupported = bool.TryParse(xDocument.Element("Controller")?.Element("CEC")?.Attribute("IsEnabled")?.Value, out result) && result;
        if (IsCECSupported)
        {
            CECGpio = (int.TryParse(xDocument.Element("Controller")?.Element("CEC")?.Attribute("Gpio")?.Value, out Value) ? Value : (-1));
        }
        OptionsMask = (uint.TryParse(xDocument.Element("Controller")?.Element("Options")?.Attribute("Mask")?.Value, out var result2) ? result2 : 0u);
        AreUSBSetsSupported = bool.TryParse(xDocument.Element("Controller")?.Element("USBSettings")?.Attribute("IsEnabled")?.Value, out var result3) && result3;
        if (AreUSBSetsSupported)
        {
            AudioConfiguration = xDocument.Element("Controller")?.Element("USBSettings")?.Element("AudioConfiguration")?.Value.Split(";"[0]);
        }
        DelayValues = xDocument.Element("Controller")?.Element("Delay")?.Element("Values")?.Value.Split(";"[0]);
        if (DelayValues == null)
        {
            DelayValues = DelayDefaultStrings;
        }
        DelayTimerPCS = (from p in xDocument.Element("Controller")?.Element("Delay")?.Element("TimerPCS")?.Value.Split(";"[0])
                         select (!int.TryParse(p, out var result4)) ? 1 : result4).ToArray();
        DelayTimerARR = (from p in xDocument.Element("Controller")?.Element("Delay")?.Element("TimerARR")?.Value.Split(";"[0])
                         select (!int.TryParse(p, out var result5)) ? 1 : result5).ToArray();
        XElement xElement = xDocument.Element("Controller")?.Element("Mute");
        if (xElement != null)
        {
            MuteValues = xElement.Element("Values")?.Value.Split(";"[0]);
            MuteTimerPCS = (from p in xElement.Element("TimerPCS")?.Value.Split(";"[0])
                            select (!int.TryParse(p, out var result6)) ? 1 : result6).ToArray();
            MuteTimerARR = (from p in xElement.Element("TimerARR")?.Value.Split(";"[0])
                            select (!int.TryParse(p, out var result7)) ? 1 : result7).ToArray();
        }
        if (ConfigGpios(xDocument))
        {
            IsLoaded = true;
        }
    }

    public void GetGpioDescription(string GpioType, out string[] GPIOsTitles, out string[][] GpiosFuncs, out bool[] IsGpioEnabled)
    {
        if (GpioType == "GPIOI")
        {
            GPIOsTitles = GPIOITitles;
            GpiosFuncs = GPIOIFuncs;
            IsGpioEnabled = IsGPIOIEnabled;
        }
        else if (GpioType == "DSPI")
        {
            GPIOsTitles = DSPITitles;
            GpiosFuncs = DSPIFuncs;
            IsGpioEnabled = IsDSPIEnabled;
        }
        else
        {
            GPIOsTitles = RegGPIOsTitles;
            GpiosFuncs = RegGpiosFuncs;
            IsGpioEnabled = IsRegGpioEnabled;
        }
    }

    public uint[] GetGpioOptions()
    {
        return GPIO_Options;
    }

    public int GetTouchCapGpio()
    {
        return TouchCapGpioNum;
    }

    public void GetGpioILinesAndFuncIndex(out int[][] Lines, out int[] FuncIndex)
    {
        FuncIndex = GPIOI_FunctionIndex;
        Lines = GPIOI_Lines;
    }

    private bool ConfigGpios(XDocument xdoc)
    {
        string[] array = new string[3] { "RegGPIOs", "GPIOInterfaces", "DSPInterfaces" };
        for (int i = 0; i < array.Length; i++)
        {
            bool result;
            int result2;
            var array2 = (from p in xdoc.Element("Controller")?.Element("GPIOS")?.Element(array[i])?.Elements("gpio")
                          select new
                          {
                              Title = p.Attribute("Title")?.Value,
                              IsEnabled = (!bool.TryParse(p.Attribute("IsEnabled")?.Value, out result) || result),
                              Functions = p.Element("Functions")?.Value.Split(";"[0]),
                              Lines = p.Element("Lines")?.Value.Split(";"[0]),
                              FunctionIndex = (int.TryParse(p.Element("FunctionIndex")?.Value, out result2) ? result2 : 0)
                          }).ToArray();
            if (array2 == null)
            {
                return false;
            }
            string[][] array3 = array2.Select(p => p.Functions).ToArray();
            string[] array4 = array2.Select(p => p.Title).ToArray();
            bool[] array5 = array2.Select(p => p.IsEnabled).ToArray();
            switch (array[i])
            {
                case "RegGPIOs":
                    {
                        RegGPIOsTitles = array4;
                        RegGpiosFuncs = array3;
                        IsRegGpioEnabled = array5;
                        string s = xdoc.Element("Controller")?.Element("GPIOS")?.Element("RegGPIOs")?.Attribute("TouchCapGpio")?.Value;
                        TouchCapGpioNum = (int.TryParse(s, out var result4) ? result4 : (-1));
                        GPIO_Options = (from p in xdoc.Element("Controller")?.Element("GPIOS")?.Element("RegGPIOs")?.Elements("gpio")
                                        select uint.TryParse(p.Attribute("Option")?.Value, out var result5) ? result5 : 0u).ToArray();
                        break;
                    }
                case "GPIOInterfaces":
                    {
                        GPIOITitles = array4;
                        GPIOIFuncs = array3;
                        IsGPIOIEnabled = array5;
                        GPIOI_FunctionIndex = array2.Select(p => p.FunctionIndex).ToArray();
                        string[][] array6 = array2.Select(p => p.Lines).ToArray();
                        if (GPIOI_FunctionIndex == null || array6 == null)
                        {
                            return false;
                        }
                        int num = array2.Count();
                        GPIOI_Lines = new int[num][];
                        for (int j = 0; j < num; j++)
                        {
                            GPIOI_Lines[j] = array6[j].Select((string p) => int.TryParse(p, out var result3) ? result3 : 0).ToArray();
                        }
                        break;
                    }
                case "DSPInterfaces":
                    DSPITitles = array4;
                    DSPIFuncs = array3;
                    IsDSPIEnabled = array5;
                    break;
                default:
                    return false;
            }
        }
        return true;
    }
}
