using System.Collections.Generic;
using System.Windows;
using System.Windows.Markup;

namespace ChipStudio
{
	public partial class LEDStatesWindow : Window, IComponentConnector
	{
		private static readonly string StatesWord = "States";

		public List<LEDStateTemplate> LEDStatesList = new List<LEDStateTemplate>();

		public LEDStatesWindow(string Title, List<LEDStateTemplate> LEDStatesList)
		{
			InitializeComponent();
			base.DataContext = this;
			base.Title = Title + " " + StatesWord;
			this.LEDStatesList = LEDStatesList;
			LEDStates.ItemsSource = LEDStatesList;
		}

		private void OKButton_Click(object sender, RoutedEventArgs e)
		{
			base.DialogResult = true;
		}

		private void CancelButton_Click(object sender, RoutedEventArgs e)
		{
			base.DialogResult = false;
		}
	}
}
