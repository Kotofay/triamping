using System.Windows;
using System.Windows.Markup;
using System.Windows.Media;

namespace ChipStudio
{
	public partial class SchemaBlock_Controller : SchemaBlock, IComponentConnector
	{
		private static readonly string[] MUTE_ACTIVE_LEVELS = new string[2] { "LOW", "HIGH" };

		private const int DELAY_INDEX_DEFAULT = 3;

		private const int MUTE_INDEX_DEFAULT = 1;

		private const int MUTE_LEVEL_INDEX_DEFAULT = 0;

		private readonly Controller CtrlDev;

		public bool IsReady => CtrlDev.IsLoaded;

		public string Module { get; }

		public ushort USBPacketSize => CtrlDev.USBPacketSize;

		public override byte CoreID => CtrlDev.ID;

		public byte DownLoadAPI => CtrlDev.DownLoadAPI;

		public int ProjectMemorySize => CtrlDev.ProjectMemorySize;

		public override SchemaBlockTypes BlockType => SchemaBlockTypes.Controller;

		public PixelModule PixelSettings
		{
			get
			{
				return CtrlDev.GetPixelSettings();
			}
			set
			{
				CtrlDev.SetPixelSettings(value);
			}
		}

		public CLIModule CLISettings
		{
			get
			{
				return CtrlDev.GetCLISettings();
			}
			set
			{
				CtrlDev.SetCLISettings(value);
			}
		}

		public CEC CECSettings
		{
			get
			{
				return CtrlDev.GetCECSettings();
			}
			set
			{
				CtrlDev.SetCECSettings(value);
			}
		}

		public ControllerOptions Options
		{
			get
			{
				return CtrlDev.GetOptions();
			}
			set
			{
				CtrlDev.SetOptions(value);
			}
		}

		public int MuteIndex
		{
			get
			{
				return MuteSelector.SelectedIndex;
			}
			set
			{
				if (CtrlDev.MuteValues != null)
				{
					MuteSelector.SelectedIndex = ((value < CtrlDev.MuteValues.Length) ? value : 0);
				}
				else
				{
					MuteSelector.SelectedIndex = -1;
				}
			}
		}

		public int MuteLevel
		{
			get
			{
				return MuteLevelSelector.SelectedIndex;
			}
			set
			{
				MuteLevelSelector.SelectedIndex = ((value < MUTE_ACTIVE_LEVELS.Length) ? value : 0);
			}
		}

		public bool AreUSBSetsSupported => CtrlDev.AreUSBSetsSupported;

		public string[] AudioDescription => CtrlDev.GetAudioConfiguration();

		public SchemaBlock_Controller(string moduletype)
		{
			InitializeComponent();
			base.DataContext = this;
			Module = moduletype;
			CtrlDev = new Controller(new DDControllerXml(Module));
			if (CtrlDev.IsLoaded)
			{
				GPIOsItems.ItemsSource = CtrlDev.GPIOsGroup;
				GPIOInterfacesItems.ItemsSource = CtrlDev.GPIOIGroup;
				DSPInterfacesItems.ItemsSource = CtrlDev.DSPIGroup;
				if (CtrlDev.IsPixelSupported)
				{
					PixelPanel.Visibility = Visibility.Visible;
					PixelsItems.ItemsSource = CtrlDev.PixelGroup;
				}
				if (CtrlDev.IsCLISupported)
				{
					CLIPanel.Visibility = Visibility.Visible;
					CLIItems.ItemsSource = CtrlDev.CLIGroup;
				}
				if (CtrlDev.IsCECSupported)
				{
					CECButton.Visibility = Visibility.Visible;
				}
				if (CtrlDev.AreOptionsSupported)
				{
					OptionsButton.Visibility = Visibility.Visible;
				}
				CtrlDev.SetGpioClickAction(base.ConnectionPoint_LeftButtonDown);
				StartDelaySelector.ItemsSource = CtrlDev.DelayValues;
				StartDelaySelector.SelectedIndex = 3;
				if (CtrlDev.MuteValues != null)
				{
					MuteSelector.ItemsSource = CtrlDev.MuteValues;
					MuteSelector.SelectedIndex = 1;
					MuteLevelSelector.ItemsSource = MUTE_ACTIVE_LEVELS;
					MuteLevelSelector.SelectedIndex = 0;
					MutePanel.Visibility = Visibility.Visible;
				}
			}
		}

		public override void UpdateConnectionPoints()
		{
			if (base.Parent is Visual visual)
			{
				CtrlDev.UpdateGpioPoints(visual);
			}
		}

		public override ConnectionNode GetAnchorConnectionNode(int AnchorNumber)
		{
			GPIO line = CtrlDev.GetLine(AnchorNumber);
			if (line == null)
			{
				return null;
			}
			return new ConnectionNode(FullName, AnchorNumber, line.ConnectionPoint.RelativeCenter, line.ConnectionPoint.Type);
		}

		public ConnectionNode GetCLIConnectionNode()
		{
			GPIO cLILine = CtrlDev.GetCLILine();
			if (cLILine == null)
			{
				return null;
			}
			return new ConnectionNode(FullName, cLILine.ConnectionPoint.Number, cLILine.ConnectionPoint.RelativeCenter, cLILine.ConnectionPoint.Type);
		}

		public override void ApplyFilter(ConnectionNode Node)
		{
			if (FullName != Node.BlockName)
			{
				CtrlDev.ApplyGpioFilter(Node.AnchorType);
			}
			else
			{
				CtrlDev.ApplyGpioFilter(Node.AnchorNumber);
			}
		}

		public override void DiscardFilter()
		{
			CtrlDev.DiscardGpioFilter();
		}

		public byte[] GetGPIOFunctions()
		{
			return CtrlDev.GPIOsFunctionsGet();
		}

		public void SetGPIOFunctions(int[] FuncList)
		{
			CtrlDev.GPIOsFunctionsSet(FuncList);
		}

		public bool[] GetGPIOsActivity()
		{
			return CtrlDev.GetActiveRegGPIOs();
		}

		public byte GetInterfaceNum(byte GpioNum)
		{
			return CtrlDev.InterfaceNumber(GpioNum);
		}

		public void SetBootGpios(int BootType, int BootGpioCount)
		{
		}

		public void GetStartDelay(out int TimPSC, out int TimARR)
		{
			TimPSC = CtrlDev.DelayTimPSC(StartDelaySelector.SelectedIndex);
			TimARR = CtrlDev.DelayTimARR(StartDelaySelector.SelectedIndex);
		}

		public void GetStartDelayParams(out bool IsDelayActive, out int DelayIndex)
		{
			DelayIndex = StartDelaySelector.SelectedIndex;
			if (StartDelayCheck.IsChecked == true)
			{
				IsDelayActive = true;
			}
			else
			{
				IsDelayActive = false;
			}
		}

		public void SetStartDelayParams(bool IsDelayActive, int DelayIndex)
		{
			StartDelaySelector.SelectedIndex = DelayIndex;
			StartDelayCheck.IsChecked = IsDelayActive;
		}

		public void GetMuteTimParams(out int TimPSC, out int TimARR)
		{
			TimPSC = CtrlDev.MuteTimPSC(MuteSelector.SelectedIndex);
			TimARR = CtrlDev.MuteTimARR(MuteSelector.SelectedIndex);
		}

		private void EnableStreamLR()
		{
		}

		private void EnableStreamBCLK()
		{
		}

		protected override void Dispose(bool disposing)
		{
		}

		private void EditPixelModule_Click(object sender, RoutedEventArgs e)
		{
			PixelModuleSettings pixelModuleSettings = new PixelModuleSettings(PixelSettings);
			if (pixelModuleSettings.ShowDialog() == true)
			{
				PixelSettings = pixelModuleSettings.Settings;
			}
		}

		private void EditCLIModule_Click(object sender, RoutedEventArgs e)
		{
			CLIModuleSettings cLIModuleSettings = new CLIModuleSettings(CLISettings);
			if (cLIModuleSettings.ShowDialog() == true)
			{
				CLISettings = cLIModuleSettings.Settings;
			}
		}

		private void CECButton_Click(object sender, RoutedEventArgs e)
		{
			CECModuleSettings cECModuleSettings = new CECModuleSettings(CECSettings, CtrlDev.GPIOsGroup.Length);
			if (cECModuleSettings.ShowDialog() == true)
			{
				CECSettings = cECModuleSettings.Settings;
			}
		}

		private void OptionsButton_Click(object sender, RoutedEventArgs e)
		{
			ControllerOptionSettings controllerOptionSettings = new ControllerOptionSettings(Options, CtrlDev.SupportedOptions);
			if (controllerOptionSettings.ShowDialog() == true)
			{
				Options = controllerOptionSettings.Settings;
			}
		}
	}
}
