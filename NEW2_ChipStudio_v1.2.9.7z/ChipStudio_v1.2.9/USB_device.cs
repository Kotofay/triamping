﻿// Decompiled with JetBrains decompiler
// Type: ChipStudio.USB_device
// Assembly: ChipStudio, Version=1.2.9.0, Culture=neutral, PublicKeyToken=null
// MVID: 334E3BEA-37C7-4274-8118-535AAEFA1546
// Assembly location: D:\DocAndSec\Desktop\AUDIO\ChipDip\ChipStudio_soft_v1.2.9\ChipStudio_v1.2.9.exe

using LibUsbDotNet;
using LibUsbDotNet.Main;

#nullable disable
namespace ChipStudio;

internal class USB_device
{
  private const int DEV_VID = 1155;
  private const int DEV_PID = 41488;
  private const int USBWriteTimeOut = 5000;
  private const int USBReadTimeOut = 5000;
  private static UsbDevice USBDev;
  private static UsbEndpointWriter USBDevWriter;
  private static UsbEndpointReader USBDevReader;

  public static bool Open()
  {
    USB_device.USBDev = UsbDevice.OpenUsbDevice(new UsbDeviceFinder(1155, 41488));
    if (USB_device.USBDev == null)
      return false;
    if (USB_device.USBDev is IUsbDevice usbDev)
    {
      usbDev.SetConfiguration((byte) 1);
      usbDev.ClaimInterface(0);
    }
    USB_device.USBDevReader = USB_device.USBDev.OpenEndpointReader(ReadEndpointID.Ep01);
    USB_device.USBDevWriter = USB_device.USBDev.OpenEndpointWriter(WriteEndpointID.Ep01);
    return true;
  }

  public static void Close()
  {
    if (USB_device.USBDev == null)
      return;
    if (USB_device.USBDev.IsOpen)
    {
      if (USB_device.USBDev is IUsbDevice usbDev)
        usbDev.ReleaseInterface(0);
      USB_device.USBDev.Close();
    }
    USB_device.USBDev = (UsbDevice) null;
    UsbDevice.Exit();
  }

  public static bool Write(byte[] Buffer)
  {
    int transferLength;
    return USB_device.USBDevWriter != null && USB_device.USBDevWriter.Write(Buffer, 5000, out transferLength) == ErrorCode.None && transferLength == Buffer.Length;
  }

  public static bool Read(byte[] Buffer)
  {
    int transferLength;
    return USB_device.USBDevReader != null && USB_device.USBDevReader.Read(Buffer, 5000, out transferLength) == ErrorCode.None && transferLength == Buffer.Length;
  }
}
