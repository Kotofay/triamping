﻿// Decompiled with JetBrains decompiler
// Type: ChipStudio.DSPBootParser_Generic
// Assembly: ChipStudio, Version=1.2.9.0, Culture=neutral, PublicKeyToken=null
// MVID: 334E3BEA-37C7-4274-8118-535AAEFA1546
// Assembly location: D:\DocAndSec\Desktop\AUDIO\ChipDip\ChipStudio_soft_v1.2.9\ChipStudio_v1.2.9.exe

using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Windows;

#nullable disable
namespace ChipStudio;

public class DSPBootParser_Generic : IDSPBootParser
{
  public bool TryParse(string ProjectFile, out List<DataTransfer> BootSequence)
  {
    BootSequence = new List<DataTransfer>();
    string[][] array = ((IEnumerable<string>) File.ReadAllLines(ProjectFile)).Where<string>((Func<string, bool>) (s => s.StartsWith("0x"))).Select<string, string>((Func<string, string>) (s => s.Replace(" ", "").Replace("\t", "").Replace("0x", ""))).Select<string, string>((Func<string, string>) (s => !s.EndsWith(",") ? s : s.Remove(s.Length - 1))).Select<string, string[]>((Func<string, string[]>) (s => s.Split(","[0]))).ToArray<string[]>();
    if (array == null || array.Length == 0)
    {
      int num = (int) MessageBox.Show("File does not contain DSP configuration", "", MessageBoxButton.OK, MessageBoxImage.Hand);
      return false;
    }
    for (int index1 = 0; index1 < ((IEnumerable<string[]>) array).Count<string[]>(); ++index1)
    {
      ushort[] numArray = new ushort[array[index1].Length];
      for (int index2 = 0; index2 < array[index1].Length; ++index2)
      {
        uint result;
        if (!Shared.TryParseHEX(array[index1][index2], out result))
        {
          int num = (int) MessageBox.Show($"Unable to convert <{array[index1][index2]}>: string <{index1.ToString()}>, element <{index2.ToString()}>.", "", MessageBoxButton.OK, MessageBoxImage.Hand);
          return false;
        }
        numArray[index2] = (ushort) result;
      }
      if (numArray != null)
      {
        if (numArray.Length == 1)
        {
          int num1 = (int) MessageBox.Show($"String <{index1.ToString()}> contains no data and will be ignored.", "", MessageBoxButton.OK, MessageBoxImage.Exclamation);
        }
        else
        {
          DataTransfer dataTransfer = new DataTransfer(numArray[0], numArray.Length - 1, (byte) 0, DataTransfer.TransferTypes.Write);
          for (int index3 = 1; index3 < numArray.Length; ++index3)
            dataTransfer.Data[index3 - 1] = (byte) numArray[index3];
          BootSequence.Add(dataTransfer);
        }
      }
    }
    return true;
  }
}
