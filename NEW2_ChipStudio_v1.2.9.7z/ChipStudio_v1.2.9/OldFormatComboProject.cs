﻿// Decompiled with JetBrains decompiler
// Type: ChipStudio.OldFormatComboProject
// Assembly: ChipStudio, Version=1.2.9.0, Culture=neutral, PublicKeyToken=null
// MVID: 334E3BEA-37C7-4274-8118-535AAEFA1546
// Assembly location: D:\DocAndSec\Desktop\AUDIO\ChipDip\ChipStudio_soft_v1.2.9\ChipStudio_v1.2.9.exe

using System.Collections.Generic;
using System.IO;

#nullable disable
namespace ChipStudio;

public class OldFormatComboProject
{
  private const string ComboSettingsString = "ComboSettings";
  private const string ComboPartsString = "ComboParts";
  private const string ControllerString = "Controller";
  private const string ComboTypeString = "ComboType";
  private const string ComboSubTypeString = "ComboSubType";
  private const string ComboChangeProjectMethod = "DoNotReboot";
  private const int ParamNameIndex = 0;
  private const int ParamValueIndex = 1;

  public static bool Open(
    string FilePath,
    ComboProjectParameters Params,
    List<ComboProjectPart> Parts)
  {
    using (StreamReader streamReader = File.OpenText(FilePath))
    {
      string Input1 = streamReader.ReadLine();
      while (streamReader.Peek() >= 0 && Input1.IndexOf("#End FileDescription") == -1)
        Input1 = streamReader.ReadLine();
      while (streamReader.Peek() >= 0 && Input1.IndexOf("#Begin ComboSettings") == -1)
        Input1 = streamReader.ReadLine();
      while (streamReader.Peek() >= 0)
      {
        Input1 = streamReader.ReadLine();
        if (Input1.IndexOf("#End ") == -1)
        {
          string[] values = Shared.ConvertFileFieldToValues(Input1);
          if (values[0] == "Controller")
            Params.Controller = values[1];
          else if (values[0] == "ComboType")
          {
            int result;
            if (!int.TryParse(values[1], out result))
              return false;
            Params.Type = result;
          }
          else if (values[0] == "ComboSubType")
          {
            int result;
            if (!int.TryParse(values[1], out result))
              return false;
            Params.SubType = result;
          }
          else if (values[0] == "DoNotReboot")
          {
            bool result;
            if (!bool.TryParse(values[1], out result))
              return false;
            Params.DoNotReboot = result;
          }
        }
        else
          break;
      }
      while (streamReader.Peek() >= 0 && Input1.IndexOf("#Begin ComboParts") == -1)
        Input1 = streamReader.ReadLine();
      while (streamReader.Peek() >= 0)
      {
        string Input2 = streamReader.ReadLine();
        if (Input2.IndexOf("#End ") == -1)
        {
          ComboProjectPart comboProjectPart = new ComboProjectPart();
          comboProjectPart.Name = Shared.ConvertFileFieldToValues(Input2)[0];
          if (comboProjectPart.Name.Length < 7)
            comboProjectPart.Name = (string) null;
          Parts.Add(comboProjectPart);
        }
        else
          break;
      }
    }
    return true;
  }
}
