using System.Windows;
using System.Windows.Markup;

namespace ChipStudio
{
	public partial class ControllerInfoDialog : Window, IComponentConnector
	{
		public ControllerInfoDialog()
		{
			InitializeComponent();
		}

		private void ControllerInfo_Click(object sender, RoutedEventArgs e)
		{
			if (ControllerDriver.IsDeviceConnected())
			{
				ControllerDriver.OpenDevice();
				ControllerInfo deviceInfo = ControllerDriver.GetDeviceInfo();
				ControllerDriver.CloseDevice();
				DeviceName.Content = deviceInfo.Name;
				FWVersion.Content = deviceInfo.FirmwareVersion;
			}
			else
			{
				MessageBox.Show("Controller is not connected", "", MessageBoxButton.OK, MessageBoxImage.Hand);
				DeviceName.Content = "";
				FWVersion.Content = "";
			}
		}

		private void CloseButton_Click(object sender, RoutedEventArgs e)
		{
			base.DialogResult = false;
		}
	}
}
