﻿// Decompiled with JetBrains decompiler
// Type: ChipStudio.DSPCellTAS3251
// Assembly: ChipStudio, Version=1.2.9.0, Culture=neutral, PublicKeyToken=null
// MVID: 334E3BEA-37C7-4274-8118-535AAEFA1546
// Assembly location: D:\DocAndSec\Desktop\AUDIO\ChipDip\ChipStudio_soft_v1.2.9\ChipStudio_v1.2.9.exe

#nullable disable
namespace ChipStudio;

public class DSPCellTAS3251 : IDSPCellSpecific
{
  private const string VOLUME_CELL_NAME = "Volume";
  private const int TAS3251_FILTER_DATA_COUNT = 20;
  private const int RDC2_0050_CELL_FILTER_INDEX = 0;
  private const int RDC2_0050_CELL_FREQ_INDEX = 1;
  private const int RDC2_0050_CELL_BAND_INDEX = 2;
  private const int RDC2_0050_CELL_PATHS_COUNT = 3;

  public DSPCellTAS3251(DSPCell InCell) => InCell.WriteType = DSPCell.WriteTypes.BlockWrite;

  public int OneValueSize(DSPCell Cell) => Cell.ParamsSize;

  public bool TryParseData(string FileName, out byte[] Result, DSPCell Cell)
  {
    return SharedTI.TryParseDSPCellDataTI(FileName, out Result, Cell);
  }
}
